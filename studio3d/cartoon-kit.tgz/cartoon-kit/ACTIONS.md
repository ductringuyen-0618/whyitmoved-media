# Action + emotion kit (finance-modern style)

Reference: examples/finance-modern (selloff short: modern city, bank, glass chip tower, USD stacks, vest crowd) and examples/action-reel (one shot per action).
Copy web/toon.js + web/main.js from finance-modern for the new features.

## Faces (opts.expr)
cry (streaming tears, pass tt = 0..1 phase to animate), sad, dizzy, excited, cool, plus neutral stern grin laugh whistle nervous shock relief snore squint stubborn.
## Arm poses (L / R)
flail (new), up, temple, cheek, point, cross, hip, wave, lift, reach, thumb, hang.
## Body actions (actor extras, 2nd arg of the cast helper)
- fall / faint: { roll: 0 -> -1.5 (or +1.52) } rotates the whole card about the feet; ramp with t*t, pair with tilt flail then 'dizzy' + fxStars / fxDust.
- jump: { y: abs(sin(f*0.2))*0.55 }.
- driver: second card, scale 0.6, y 0.5, x = carX - 0.35, expr 'cool'.
## World props (worldAt state)
car: { pos:[x,0,z], s, spin: frames*0.55, yaw }   rocket: { pos, s, flame, rot }   moon: { pos, s }   (pos in metres; keep the moon far: z -34, s ~0.9)
## FX cards (T.fx*)
fxDollar(p,t) floating $, fxSpeed(p,t) speed lines, fxSweat(p,t), fxDust(p,k), fxStars(p,t).
## Safety rule
No suicide imagery (no jumping from buildings). Use falls, faints, tears and flattened-by-crash gags instead.
