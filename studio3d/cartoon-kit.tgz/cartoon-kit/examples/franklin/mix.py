"""mix.py voice.mp3 music.wav sfx.wav -> mix_raw.wav. Music at 50 % of the voice's gated RMS, SFX at 50 % (peaks capped at 0.7x voice peak)."""
import sys, subprocess, wave, numpy as np
SR = 48000
def rd(p):
    if p.endswith('.wav'):
        with wave.open(p) as f: x = np.frombuffer(f.readframes(f.getnframes()), np.int16).astype(np.float32) / 32768
        return x
    return np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True).stdout, np.float32).copy()
v, m, s = rd(sys.argv[1]), rd(sys.argv[2]), rd(sys.argv[3]); N = len(m)
vv = np.zeros(N, np.float32); vv[:min(N, len(v))] = v[:N]
def grms(x):  # gated RMS: only windows within 20 dB of the loudest
    w = 4800; r = np.array([np.sqrt(np.mean(x[i:i + w] ** 2)) for i in range(0, len(x) - w, w)])
    g = r[r > r.max() * 0.1]; return float(np.sqrt(np.mean(g ** 2)))
rv, rm, rs = grms(vv), grms(m), grms(s) if np.abs(s).max() > 0 else 1.0
gm = 0.5 * rv / rm
gs = 0.5 * rv / rs
vp = np.abs(vv).max(); sp = np.abs(s).max() * gs
if sp > 0.7 * vp: gs *= 0.7 * vp / sp
mix = vv + m * gm + s * gs
pk = np.abs(mix).max()
if pk > 0.95: mix *= 0.95 / pk
pcm = (np.clip(mix, -1, 1) * 32767).astype(np.int16)
with wave.open("mix_raw.wav", "wb") as f:
    f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR); f.writeframes(pcm.tobytes())
db = lambda a, b: 20 * np.log10(max(a, 1e-9) / max(b, 1e-9))
print(f"music vs voice {db(grms(m*gm), rv):+.1f} dB, sfx vs voice {db(grms(s*gs), rv):+.1f} dB (rms), sfx peak {db(np.abs(s).max()*gs, vp):+.1f} dB vs voice peak")
