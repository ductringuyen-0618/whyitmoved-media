// "Franklin's 200-year gift" — timed to voice.mp3 (33.96 s, 30 fps, 1019 frames).
import { M as MO, clamp, lerp, lerp3, ramp, camFromKeys, idle, blinkAt, walk, q } from './motion.js';
export const FPS = 30, TOTAL = 1019, DECK = 0;
export const SHOTS = [
  { id: 'hook', a: 0, b: 128, light: 'day' }, { id: 'wait', a: 129, b: 216, light: 'day' }, { id: 'y1790', a: 217, b: 256, light: 'day' },
  { id: 'split', a: 257, b: 356, light: 'day' }, { id: 'lend', a: 357, b: 476, light: 'day' }, { id: 'century', a: 477, b: 572, light: 'day' },
  { id: 'locked', a: 573, b: 700, light: 'day' }, { id: 'later', a: 701, b: 742, light: 'day' }, { id: 'boston', a: 743, b: 852, light: 'day' },
  { id: 'philly', a: 853, b: 912, light: 'day' }, { id: 'penny', a: 913, b: 980, light: 'golden' }, { id: 'time', a: 981, b: 1018, light: 'golden' },
];
export const shotAt = (f) => SHOTS.find((s) => f >= s.a && f <= s.b) || SHOTS[SHOTS.length - 1];
const smooth = MO.smooth;
// ---------- lights ----------
export const LIGHTS = {
  day: { az: 130, el: 48, sky: '#c4d6f2', ground: '#8a8262', hemi: 1.15, sun: '#fff1dc', sunI: 2.5, fog: '#cadcf0', fogNear: 70, fogFar: 900,
    skyTop: '#3f80d4', skyHor: '#c3daf2', sat: 1.12, waterDeep: '#2c6c8c', waterShal: '#5aaec4', glint: '#effaff', vig: 0.2, shadowExt: 18 },
  golden: { az: 70, el: 20, sky: '#b8b0d0', ground: '#8a7255', hemi: 1.1, sun: '#ffd0a0', sunI: 2.6, fog: '#f4d6b6', fogNear: 60, fogFar: 760,
    skyTop: '#7f86c8', skyHor: '#ffd7a0', sunDisc: '#fff0c8', sunSize: 0.0035, sat: 1.08, gain: '#fff8ee', waterDeep: '#3d5a86', waterShal: '#d99a6e', glint: '#ffe2a8', vig: 0.26, shadowExt: 18 },
};
export const lightFor = (S, f) => ({ ...LIGHTS[S.light] });
// ---------- cameras ----------
const WIDE = (y = 2.2) => ({ pos: [0, y, 18], look: [0, 2.3, 0], fov: 42 });
const CAMS = {
  hook: [{ f: 0, pos: [-2.9, 1.7, 5.4], look: [0.3, 1.5, 1.6], fov: 31 }, { f: 128, pos: [-2.2, 1.65, 4.6], look: [0.3, 1.5, 1.6], fov: 26 }],
  wait: [{ f: 129, pos: [-1.6, 1.7, 5.6], look: [0, 1.7, 1.2], fov: 30 }, { f: 160, pos: [0, 2.2, 13], look: [0, 2.4, 0.5], fov: 40, path: [[-0.8, 1.9, 8.5]] }, { f: 216, pos: [0, 2.3, 15], look: [0, 2.7, 0.5], fov: 40 }],
  y1790: [{ f: 217, pos: [0, 3.0, 14.5], look: [-0.3, 3.0, 0], fov: 34 }, { f: 256, pos: [0, 3.0, 12.5], look: [-0.3, 3.0, 0], fov: 32 }],
  split: [{ f: 257, pos: [0, 2.0, 15], look: [0, 1.8, 0.8], fov: 40 }, { f: 356, pos: [0, 1.9, 12.5], look: [0, 1.7, 0.8], fov: 38 }],
  lend: [{ f: 357, pos: [0, 1.9, 15], look: [0, 1.7, 1.4], fov: 40 }, { f: 476, pos: [0.3, 1.9, 13.5], look: [0, 1.7, 1.4], fov: 38 }],
  century: [{ f: 477, pos: [0, 2.4, 13], look: [0, 2.7, 0.8], fov: 40 }, { f: 572, pos: [0, 2.2, 11.5], look: [0, 2.5, 0.8], fov: 38 }],
  locked: [{ f: 573, pos: [0, 2.0, 9.5], look: [0, 2.0, 1.6], fov: 36 }, { f: 700, pos: [0, 2.3, 9.8], look: [0, 2.7, 1.6], fov: 34 }],
  later: [{ f: 701, pos: [0, 2.4, 11.5], look: [0, 2.8, 0.8], fov: 36 }, { f: 742, pos: [0, 2.3, 15.5], look: [0, 2.4, 0.8], fov: 40 }],
  boston: [{ f: 743, pos: [-0.3, 2.0, 14], look: [-1.2, 1.9, 1.3], fov: 38 }, { f: 852, pos: [-3.0, 2.4, 10.2], look: [-1.8, 2.5, 1.3], fov: 36 }],
  philly: [{ f: 853, pos: [0.3, 2.0, 14], look: [1.2, 1.9, 1.3], fov: 38 }, { f: 912, pos: [3.0, 2.3, 10.2], look: [1.8, 2.4, 1.3], fov: 36 }],
  penny: [{ f: 913, pos: [-2.6, 1.6, 5.2], look: [0, 1.5, 1.6], fov: 29 }, { f: 980, pos: [-2.0, 1.6, 4.5], look: [0, 1.5, 1.6], fov: 25 }],
  time: [{ f: 981, pos: [-1.2, 1.8, 7.5], look: [0.8, 2.0, 1.4], fov: 34 }, { f: 1018, pos: [0, 2.6, 17], look: [0.4, 2.4, 0.5], fov: 42 }],
};
const KICKS = [{ f: 219, a: 0.04 }, { f: 507, a: 0.03 }, { f: 603, a: 0.03 }, { f: 703, a: 0.04 }];
export const camAt = (f) => {
  const S = shotAt(f); const c = camFromKeys(CAMS[S.id], f, { creep: 0.0008, kicks: KICKS });
  c.flash = (f >= 217 && f < 223) ? (1 - (f - 217) / 6) * 0.8 : (f >= 701 && f < 707) ? (1 - (f - 701) / 6) * 0.8 : (f >= 505 && f < 510) ? (1 - (f - 505) / 5) * 0.6 : 0;
  c.shadowAt = [0, 0, 1.4];
  return c;
};
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
export const dofAt = (f) => {
  const S = shotAt(f), C = camAt(f);
  switch (S.id) {
    case 'hook': case 'penny': return { focus: dist(C.pos, [0, 1.5, 1.6]), cinf: 10 };
    case 'wait': return { focus: dist(C.pos, [0, 1.6, 1.4]), cinf: f < 160 ? 7 : 0 };
    case 'lend': return { focus: dist(C.pos, [0, 1.5, 1.4]), cinf: 4 };
    case 'locked': return { focus: dist(C.pos, [0, 1.2, 1.8]), cinf: 6 };
    case 'boston': return { focus: dist(C.pos, [-1.8, 1.4, 1.3]), cinf: 5 };
    case 'philly': return { focus: dist(C.pos, [1.8, 1.4, 1.3]), cinf: 5 };
    default: return { focus: 14, cinf: 0 };
  }
};
// ---------- world state ----------
const PA = [-1.8, 0, 1.3], PB = [1.8, 0, 1.3];
export const worldAt = (f) => {
  const S = shotAt(f), W = { p1: 0, p2: 0, p1Pos: PA, p2Pos: PB, p1S: 1, p2S: 1, year: null, m1: null, m2: null, chest: null, clock: null };
  const yr = (a, b, y0, y1) => String(Math.round((y0 + (y1 - y0) * clamp(ramp(f, a, b), 0, 1)) / 5) * 5);
  switch (S.id) {
    case 'hook': W.chest = { pos: [1.15, 0, 1.9], s: 1.0, open: smooth(ramp(f, 36, 62)) * (f < 110 ? 1 : 1 - smooth(ramp(f, 110, 126))) }; break;
    case 'wait': W.chest = { pos: [1.15, 0, 1.9], s: 1.0, open: 0, lock: true };
      if (f >= 150) W.year = { pos: [0, 0, 0.1], s: 1, txt: '200 YEARS', bg: '#7a1f1a', size: 105 }; break;
    case 'y1790': W.year = { pos: [0, 0, 0.1], s: 1, txt: '1790', bg: '#27406f', size: 130 }; break;
    case 'split': W.chest = { pos: [0, 0, 2.6], s: 0.9, open: 1 }; W.p1 = 0.3 * ramp(f, 285, 320); W.p2 = 0.3 * ramp(f, 300, 335); W.p1S = W.p2S = 0.9; break;
    case 'lend': W.p1 = W.p2 = 0.3 + 0.18 * ramp(f, 396, 470); break;
    case 'century': { const c = ramp(f, 477, 505); W.year = { pos: [0, 0, 0.1], s: 1, txt: yr(477, 505, 1790, 1890), bg: c >= 1 ? '#7a1f1a' : '#27406f', size: 130 };
      const sp = ramp(f, 522, 566); W.p1 = W.p2 = (0.48 + 0.52 * c) - 0.72 * smooth(sp); break; }
    case 'locked': { W.chest = { pos: [0, 0, 2.1], s: 1.35, open: f < 585 ? 1 - smooth(ramp(f, 573, 585)) : 0, lock: f >= 596 };
      W.year = { pos: [0, 0, -0.6], s: 1, txt: f < 640 ? '1890' : yr(640, 698, 1890, 1990), bg: '#27406f', size: 130 };
      W.p1 = 0.28 + 0.32 * ramp(f, 640, 698); W.p1Pos = [-1.9, 0, 1.9]; W.p1S = 0.8; break; }
    case 'later': W.year = { pos: [0, 0, 0.1], s: 1, txt: '1990', bg: '#7a1f1a', size: 130 }; W.p1 = W.p2 = 0.3 + 0.5 * ramp(f, 705, 742); break;
    case 'boston': W.p2 = 0.8; W.p2S = 1.1; W.p1 = 0.8 + 0.2 * ramp(f, 744, 800); W.p1S = 1.0 + 0.7 * smooth(ramp(f, 744, 800));
      if (f >= 765) W.m1 = { pos: [-1.8, 0, 1.4], s: 0.64 + 0.08 * Math.max(0, Math.sin((f - 765) * 0.5) * Math.exp(-(f - 765) * 0.1)), txt: '$4.5 MILLION' }; break;
    case 'philly': W.p1 = 1; W.p1S = 1.7; W.m1 = { pos: [-1.8, 0, 1.4], s: 0.64, txt: '$4.5 MILLION' }; W.p2 = 0.8 + 0.2 * ramp(f, 853, 885); W.p2S = 1.1 + 0.4 * smooth(ramp(f, 853, 885));
      if (f >= 865) W.m2 = { pos: [1.8, 0, 1.4], s: 0.64 + 0.08 * Math.max(0, Math.sin((f - 865) * 0.5) * Math.exp(-(f - 865) * 0.1)), txt: '$2 MILLION' }; break;
    case 'penny': W.p1 = 1; W.p1S = 1.7; W.p2 = 1; W.p2S = 1.5; W.p1Pos = [-4.4, 0, 0.6]; W.p2Pos = [4.4, 0, 0.6]; break;
    case 'time': W.p1 = 1; W.p1S = 1.7; W.p2 = 1; W.p2S = 1.5; W.p1Pos = [-3.9, 0, 0.8]; W.p2Pos = [4.2, 0, 0.8];
      W.clock = { pos: [1.5, 0, 1.2], s: 1.2, a: 0.4 + 5.0 * smooth(ramp(f, 983, 1018)) }; break;
  }
  return W;
};
// ---------- actors ----------
const R = (T, who, o, pos, extra = {}) => ({ key: who + JSON.stringify(o), draw: (p) => T.romanFront(p, who, o), x: pos[0], y: pos[1], z: pos[2], ...extra });
export const actorsAt = (f, T) => {
  const S = shotAt(f), out = [];
  const I = (s) => idle(f, s);
  const tint = S.light === 'golden' ? '#ffe6cc' : '#ffffff';
  const guy = (who, seed, o, pos, ex = {}) => out.push(R(T, who, { seed, blink: blinkAt(f, seed), ...I(seed), ...o }, pos, { tint, ...ex }));
  const fr = (o, pos = [0, DECK, 1.6], ex = {}) => guy('franklin', 5, o, pos, ex);
  const cheer = (who, seed, pos, ph = 0) => { const d = Math.sin((f + ph) * 0.33); guy(who, seed, { expr: 'laugh', L: d > 0 ? 'up' : 'hang', R: d > 0 ? 'hang' : 'up', tilt: q(-d * 5, 1), bob: q(Math.abs(d) * 0.025, 3) }, pos); };
  switch (S.id) {
    case 'hook': { fr({ expr: f < 40 ? 'neutral' : 'smile', L: 'hip', R: f > 36 && f < 110 ? 'reach' : 'hip', look: 0.4, bob: 0 }, [0, DECK, 1.6]); break; }
    case 'wait': { fr({ expr: 'smile', L: 'hip', R: f > 150 ? 'up' : 'hip', look: 0.2 }, [-0.1, DECK, 1.9]); break; }
    case 'y1790': { fr({ expr: 'smile', L: 'hip', R: 'point', look: 0.6, facing: 0.3 }, [-1.9, DECK, 1.9]); break; }
    case 'split': { fr({ expr: 'grin', L: 'hip', R: 'wave', wv: f * 0.3 }, [0, DECK, 0.9]); break; }
    case 'lend': { const t = ramp(f, 400, 476);
      guy('tradeA', 31, { expr: 'grin', L: 'up', R: 'hip', facing: 0.4, bob: q(Math.abs(Math.sin(f * 0.3)) * 0.02, 3) }, [-1.0 - 1.2 * t, DECK, 2.7]);
      guy('tradeB', 32, { expr: 'grin', L: 'hip', R: 'up', facing: -0.4, bob: q(Math.abs(Math.sin(f * 0.3 + 1)) * 0.02, 3) }, [1.0 + 1.2 * t, DECK, 2.7]);
      fr({ expr: 'smile', L: 'hip', R: 'hip' }, [0, DECK, 0.4]); break; }
    case 'century': { fr({ expr: f < 520 ? 'smile' : 'laugh', L: 'hip', R: f < 520 ? 'hip' : 'up' }, [0, DECK, 1.6]);
      if (f > 520) { cheer('civA', 11, [-3.4, DECK, 2.2], 0); cheer('civB', 12, [-0.9, DECK, 3.0], 5); cheer('workB', 14, [3.4, DECK, 2.2], 9); cheer('civC', 13, [0.9, DECK, 3.0], 3); } break; }
    case 'locked': { fr({ expr: 'smile', L: 'cross', R: 'hang', look: -0.5, facing: -0.3 }, [2.3, DECK, 1.9]); break; }
    case 'later': { fr({ expr: 'smile', L: 'hip', R: 'hip' }, [0, DECK, 2.3]); break; }
    case 'boston': { cheer('civA', 11, [-3.2, DECK, 2.1], 0); cheer('workB', 14, [-0.4, DECK, 2.2], 7); cheer('civC', 13, [-2.6, DECK, 3.2], 3); break; }
    case 'philly': { cheer('civB', 12, [3.0, DECK, 2.1], 2); cheer('towner', 15, [0.4, DECK, 2.2], 6); cheer('tradeA', 31, [2.5, DECK, 3.2], 9); break; }
    case 'penny': { fr({ expr: 'grin', L: 'up', R: 'up', bob: q(Math.abs(Math.sin(f * 0.2)) * 0.01, 3) }, [0, DECK, 1.6]); break; }
    case 'time': { fr({ expr: 'smile', L: 'hip', R: f > 990 ? 'point' : 'hip', look: 0.7, facing: 0.35 }, [-0.4, DECK, 1.6]); break; }
  }
  return out;
};
// ---------- 2D effects ----------
const FX = (key, draw, pos, s, extra = {}) => ({ key, draw, x: pos[0], y: pos[1], z: pos[2], s, blob: false, shadow: false, order: 5, ...extra });
const star = (f, key, pos, s, per = 24, ph = 0) => { const t = q((((f + ph) % per) / per), 2); return FX(key + t, (p) => { p.g.translate(0, 80); (window.__T).fxStars(p, t); }, pos, s); };
export const fxAt = (f, T) => {
  const S = shotAt(f), out = [];
  const st = (key, pos, s, per = 24, ph = 0) => { const t = q((((f + ph) % per) / per), 2); out.push(FX(key + t, (p) => { p.g.translate(0, 80); T.fxStars(p, t); }, pos, s)); };
  if (S.id === 'hook' && f >= 40 && f < 100) st('hk', [1.15, 1.2, 2.0], 0.9);
  if (S.id === 'wait' && f >= 150 && f < 200) st('wt', [0, 4.5, 0.4], 1.4, 30);
  if (S.id === 'y1790' && f >= 217) st('y9', [0, 4.2, 0.4], 1.5, 30);
  if (S.id === 'split' && f >= 285) { st('s1', [-1.8, 1.1, 1.3], 0.9, 28, 0); st('s2', [1.8, 1.1, 1.3], 0.9, 28, 11); }
  if (S.id === 'lend') { st('l1', [-2.0, 2.3, 2.7], 0.5, 22, 0); st('l2', [2.0, 2.3, 2.7], 0.5, 22, 9); if (f > 400) { st('l3', [-1.8, 1.3, 1.3], 0.8, 30, 4); st('l4', [1.8, 1.3, 1.3], 0.8, 30, 14); } }
  if (S.id === 'century' && f >= 505 && f < 535) st('c1', [0, 4.6, 0.4], 1.5, 30);
  if (S.id === 'century' && f >= 540) { st('c2', [-1.8, 1.4, 1.3], 0.8, 26, 0); st('c3', [1.8, 1.4, 1.3], 0.8, 26, 13); }
  if (S.id === 'locked' && f >= 596 && f < 630) st('lk', [0, 1.2, 2.2], 1.1, 24);
  if (S.id === 'locked' && f >= 640) st('lg', [-1.9, 1.3, 1.9], 0.7, 26, 7);
  if (S.id === 'later' && f >= 703 && f < 735) st('lt', [0, 4.5, 0.4], 1.5, 30);
  if (S.id === 'boston' && f >= 765) { st('b1', [-1.8, 3.2, 1.6], 1.0, 24); st('b2', [-3.2, 2.8, 2.1], 0.7, 20, 8); }
  if (S.id === 'philly' && f >= 865) { st('p1', [1.8, 3.0, 1.6], 1.0, 24); st('p2', [3.0, 2.8, 2.1], 0.7, 20, 8); }
  if (S.id === 'penny') st('pn', [0.9, 2.2, 1.7], 0.5, 40);
  if (S.id === 'time' && f >= 983) st('tm', [1.5, 3.7, 1.3], 0.8, 28);
  return out;
};
