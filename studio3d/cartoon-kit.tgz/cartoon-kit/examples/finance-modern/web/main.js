import * as THREE from './lib/three.module.js';
import * as T from './toon.js';
import * as P from './paint.js';
import { SHOTS, TOTAL, shotAt, camAt, dofAt, LIGHTS, lightFor, actorsAt, worldAt, fxAt } from './story.js';

const W = 1080, H = 1920;
const canvas = document.getElementById('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, preserveDrawingBuffer: true });
renderer.setPixelRatio(1); renderer.setSize(W, H, false);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, W / H, 0.08, 1500);
const rx = (a) => a * Math.PI / 180;

// ---------- materials ----------
const grad = (() => { const d = new Uint8Array([90, 90, 90, 255, 255, 255, 255, 255]); const t = new THREE.DataTexture(d, 2, 1); t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t; })();
const toon = (opts) => new THREE.MeshToonMaterial({ gradientMap: grad, ...opts });
const texM = (c, rx_ = 1, ry_ = 1, color = '#ffffff') => toon({ map: P.tex(c, rx_, ry_), color });
const M = {
  plank: texM(P.planks(1), 1, 6), beam: texM(P.beam(2), 1, 2), beamDark: texM(P.beam(3, [28, 36, 30]), 1, 2),
  rot: texM(P.rotten(4), 1, 1), rotB: texM(P.rotten(14), 1, 1),
  stone: texM(P.stone(4), 1, 1), stoneMoss: texM(P.mossy(P.stone(4), 5, 1.2), 1, 1),
  grass: texM(P.grass(6), 40, 40), dirt: texM(P.dirt(7), 6, 30), plaster: texM(P.plaster(8), 1, 1), plaster2: texM(P.plaster(18, 28), 1, 1),
  roof: texM(P.roof(9), 2, 2), marble: texM(P.marble(10), 1, 1), marbleTop: toon({ color: '#ece2cf' }),
  trunk: toon({ color: '#6a4a32' }), cypress: toon({ color: '#3f6b36' }), pine: toon({ color: '#5c8a3c' }), bush: toon({ color: '#6c9a42' }),
  hill: toon({ color: '#7aa64c' }), hillFar: toon({ color: '#86ad60' }), mount: toon({ color: '#8fa7b8' }), snow: toon({ color: '#f4f6fa' }),
  iron: toon({ color: '#5c5a57' }), bronze: toon({ color: '#b08a4a' }), wood: toon({ color: '#7a5434' }), door: toon({ color: '#5a3a24' }),
  window: toon({ color: '#2b2430' }), red: toon({ color: '#b8282b' }),
};
M.banner = new THREE.MeshToonMaterial({ gradientMap: grad, map: P.tex(P.banner()), alphaTest: 0.5, side: THREE.DoubleSide });
// helmet
const helmetIn = P.tex(P.helmetInside()); helmetIn.wrapS = helmetIn.wrapT = THREE.ClampToEdgeWrapping;
M.helmIn = new THREE.MeshToonMaterial({ gradientMap: grad, map: helmetIn, side: THREE.BackSide });
M.helmOut = toon({ color: '#8f8a7e' });

// ---------- ink / normal-depth contract ----------
const NOINK = 'noink'; // userData flag: never outlined (cards, fx, water handled specially)
const ndMat = new THREE.ShaderMaterial({
  vertexShader: `varying vec3 vN; varying float vD; void main(){ vN = normalize(normalMatrix*normal); vec4 mv = modelViewMatrix*vec4(position,1.); vD = -mv.z; gl_Position = projectionMatrix*mv; }`,
  fragmentShader: `varying vec3 vN; varying float vD; void main(){ vec3 n = normalize(vN); if(!gl_FrontFacing) n = -n; gl_FragColor = vec4(n*.5+.5, vD); }`,
  side: THREE.DoubleSide,
});
const cardNd = (map) => new THREE.ShaderMaterial({
  uniforms: { map: { value: map } },
  vertexShader: `varying vec2 vUv; varying float vD; void main(){ vUv=uv; vec4 mv = modelViewMatrix*vec4(position,1.); vD=-mv.z; gl_Position=projectionMatrix*mv; }`,
  fragmentShader: `uniform sampler2D map; varying vec2 vUv; varying float vD; void main(){ if(texture2D(map,vUv).a<.5) discard; gl_FragColor=vec4(0.,0.,0.,vD); }`,
  side: THREE.DoubleSide,
});
const waterNd = new THREE.ShaderMaterial({
  vertexShader: `varying float vD; void main(){ vec4 mv = modelViewMatrix*vec4(position,1.); vD=-mv.z; gl_Position=projectionMatrix*mv; }`,
  fragmentShader: `varying float vD; void main(){ gl_FragColor=vec4(.5,1.,.5,vD); }`,
});

// ---------- helpers ----------
const add = (geo, mat, x = 0, y = 0, z = 0, parent = scene, opts = {}) => {
  const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = opts.cast ?? true; m.receiveShadow = true; parent.add(m); return m;
};
const box = (w, h, d) => new THREE.BoxGeometry(w, h, d);
const uvScale = (geo, su, sv) => { const uv = geo.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * su, uv.getY(i) * sv); return geo; };
/** box with world-scaled UVs per face (texel density 1 tile per `t` metres) */
const tbox = (w, h, d, t = 2) => {
  const g = box(w, h, d), uv = g.attributes.uv;
  const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] / t, uv.getY(i) * dims[f][1] / t); }
  return g;
};

// ---------- sky ----------
const skyU = { top: { value: new THREE.Color() }, hor: { value: new THREE.Color() }, sunDir: { value: new THREE.Vector3() }, sunCol: { value: new THREE.Color() }, sunSize: { value: 0 } };
const sky = new THREE.Mesh(new THREE.SphereGeometry(1200, 32, 16), new THREE.ShaderMaterial({
  uniforms: skyU, side: THREE.BackSide, depthWrite: false, fog: false,
  vertexShader: `varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }`,
  fragmentShader: `uniform vec3 top, hor, sunDir, sunCol; uniform float sunSize; varying vec3 vP;
    void main(){ float h = clamp(vP.y,0.,1.); vec3 c = mix(hor, top, pow(h, .55)); if(vP.y<0.) c = hor;
      float s = dot(normalize(vP), normalize(sunDir)); c += sunCol * (smoothstep(1.-sunSize, 1.-sunSize*.6, s) + .35*pow(max(s,0.), 24.)*step(.001,sunSize));
      gl_FragColor = vec4(c,1.); }`,
}));
sky.userData.sky = true; scene.add(sky);

// ---------- lights ----------
const hemi = new THREE.HemisphereLight('#ffffff', '#ffffff', 1); scene.add(hemi);
const sun = new THREE.DirectionalLight('#ffffff', 2); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048); sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.03; sun.shadow.radius = 2;
scene.add(sun); scene.add(sun.target);
scene.fog = new THREE.Fog('#ffffff', 40, 600);

// ---------- world (Gold Rush town, 1848) ----------
const DECK = 0, WX = 34; // street level, river centre x
const world = new THREE.Group(); scene.add(world);
M.street = toon({ color: '#9fb58a' }); M.wall = texM(P.planks(3), 1, 1); M.wall2 = texM(P.planks(5), 1, 1);
M.gold = toon({ color: '#ffd23a' }); M.goldD = toon({ color: '#f0b020' }); M.steel = toon({ color: '#8d98a6' }); M.canvas = toon({ color: '#e8dcc0' }); M.canvas2 = toon({ color: '#d7c49a' });
M.sack = toon({ color: '#b89a68' }); M.glass = toon({ color: '#d9b45a' });
const waterU = { t: { value: 0 }, deep: { value: new THREE.Color('#2f6f8f') }, shal: { value: new THREE.Color('#5fa8bf') }, glint: { value: new THREE.Color('#e9f6ff') } };
const waterMat = new THREE.ShaderMaterial({
  uniforms: { ...THREE.UniformsUtils.clone(THREE.UniformsLib.fog), ...waterU }, fog: true,
  vertexShader: `#include <fog_pars_vertex>
    varying vec3 vW; void main(){ vec4 w = modelMatrix*vec4(position,1.); vW = w.xyz; vec4 mvPosition = viewMatrix*w; gl_Position = projectionMatrix*mvPosition;
    #include <fog_vertex>
    }`,
  fragmentShader: `#include <fog_pars_fragment>
    uniform float t; uniform vec3 deep, shal, glint; varying vec3 vW;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
    float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y); }
    void main(){ vec2 p = vW.zx*vec2(.12,.35) + vec2(-t*.25, 0.);
      float n = noise(p) * .6 + noise(p*2.3 + 7.) * .4; float edge = smoothstep(4., 9., abs(vW.x-34.));
      vec3 c = mix(deep, shal, .35 + .4*n + .4*edge);
      float streak = smoothstep(.72, .78, noise(vW.zx*vec2(.09,.8) + vec2(-t*.6, 0.))) * (1.-edge*.5);
      c = mix(c, glint, streak*.75);
      gl_FragColor = vec4(c,1.);
      #include <fog_fragment>
    }`,
});
const water = new THREE.Mesh(new THREE.PlaneGeometry(16, 900), waterMat); water.rotation.x = -Math.PI / 2; water.position.set(WX, -0.7, -200);
water.userData.nd = waterNd; water.receiveShadow = false; scene.add(water);
// ground: street/dirt each side of the river, banks sloping into the water
{ const gl = add(new THREE.PlaneGeometry(300, 600), M.street, 0, 0, 0, world, { cast: false }); gl.rotation.x = -Math.PI / 2; gl.position.set(WX - 8 - 150, 0, -150);
  const gr = add(new THREE.PlaneGeometry(300, 600), M.street, 0, 0, 0, world, { cast: false }); gr.rotation.x = -Math.PI / 2; gr.position.set(WX + 8 + 150, 0, -150);
  for (const s of [-1, 1]) { const b = add(box(3.2, 0.2, 600), M.street, WX + s * 9.4, -0.38, -150, world, { cast: false }); b.rotation.z = s * 0.2; } }
// ---------- colonial town (Franklin) ----------
M.conc = toon({ color: '#dde1e6' }); M.concD = toon({ color: '#b4bac3' }); M.glass = toon({ color: '#6fa8cf' }); M.glassD = toon({ color: '#3f6f98' }); M.mull = toon({ color: '#2a3442' }); M.bill = toon({ color: '#79b974' }); M.billD = toon({ color: '#5c9c5a' }); M.white = toon({ color: '#f2f4f6' }); M.asph = toon({ color: '#4b515a' }); M.stripe = toon({ color: '#f4f4ee' });
M.slate = toon({ color: '#3b4452' }); M.trim = toon({ color: '#eceff2' }); M.doorC = toon({ color: '#27405e' }); M.winC = toon({ color: '#9fd0ea' });
M.chestW = toon({ color: '#8a5a30' }); M.chestB = toon({ color: '#c7a24a' }); M.clockF = toon({ color: '#fff8e6' }); M.postW = toon({ color: '#3a4350' });
const signTex = (txt, bg, fg, w = 640, h = 200, size = 110) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d');
  g.fillStyle = bg; g.fillRect(0, 0, w, h); g.strokeStyle = '#1a2230'; g.lineWidth = 12; g.strokeRect(6, 6, w - 12, h - 12);
  g.fillStyle = fg; let sz = size; g.font = `900 ${sz}px Arial Black, Arial`; while (g.measureText(txt).width > w * 0.84 && sz > 18) { sz -= 3; g.font = `900 ${sz}px Arial Black, Arial`; } g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(txt, w / 2, h / 2 + 6); return c; };
const signMesh = (txt, bg, fg, w, h, x, y, z, parent = world, size = 110) => { const px = Math.round(w / h * 200); return add(new THREE.PlaneGeometry(w, h), toon({ map: P.tex(signTex(txt, bg, fg, px, 200, size)) }), x, y, z, parent, { cast: false }); };
// plaza: sidewalk plus asphalt street with crosswalk
{ const pl = add(new THREE.PlaneGeometry(40, 15), toon({ color: '#b7bcc4' }), 0, 0.02, 1.5, world, { cast: false }); pl.rotation.x = -Math.PI / 2;
  const rd = add(new THREE.PlaneGeometry(40, 5.5), M.asph, 0, 0.03, 8.4, world, { cast: false }); rd.rotation.x = -Math.PI / 2;
  for (let i = -8; i <= 8; i++) { const s = add(new THREE.PlaneGeometry(0.5, 2.4), M.stripe, i * 1.1, 0.04, 8.4, world, { cast: false }); s.rotation.x = -Math.PI / 2; }
  for (let i = -9; i <= 9; i++) { const s = add(new THREE.PlaneGeometry(1.4, 0.12), M.stripe, i * 2.2 + 0.5, 0.04, 10.6, world, { cast: false }); s.rotation.x = -Math.PI / 2; } }
const windows = (g, w, h, d, y0, rows, cols, mat) => { // glass grid on the front face
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) add(box(w / cols * 0.7, h / rows * 0.6, 0.06), mat, -w / 2 + (c + 0.5) * w / cols, y0 + (r + 0.5) * h / rows, d / 2 + 0.03, g, { cast: false }); };
// classical bank / exchange: columns, steps, flat cornice
const bankHall = (x, z, w, h, d, txt, col, size) => {
  const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g);
  add(tbox(w, h, d, 2), M.conc, 0, h / 2, 0, g);
  add(tbox(w + 0.5, 0.35, d + 0.5, 2), M.concD, 0, h + 0.18, 0, g);
  add(tbox(w * 0.7, 0.5, d * 0.7, 2), M.concD, 0, h + 0.6, 0, g);
  add(tbox(w + 0.5, 0.2, 1.1, 1), M.concD, 0, 0.1, d / 2 + 0.6, g);
  for (let i = 0; i < 5; i++) add(new THREE.CylinderGeometry(0.13, 0.13, h * 0.78, 10), M.white, -w * 0.4 + i * w * 0.2, h * 0.4 + 0.1, d / 2 + 0.5, g);
  add(tbox(w * 0.95, 0.22, 0.9, 1), M.white, 0, h * 0.82 + 0.1, d / 2 + 0.5, g);
  add(box(1.0, 1.7, 0.1), M.doorC, 0, 0.95, d / 2 + 0.04, g, { cast: false });
  for (const s of [-1, 1]) add(box(0.8, 1.2, 0.08), M.glass, s * w * 0.3, h * 0.42, d / 2 + 0.04, g, { cast: false });
  signMesh(txt, col, '#fff6dc', w * 0.9, 0.62, 0, h * 0.82 + 0.1, d / 2 + 1.0, g, size);
  return g;
};
// glass tower: curtain wall grid, stepped crown, rooftop kit
const glassTower = (x, z, w, h, d, txt, col, size) => {
  const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g);
  add(tbox(w, h, d, 2), M.glass, 0, h / 2, 0, g);
  for (let r = 1; r < 6; r++) add(box(w + 0.04, 0.07, d + 0.04), M.mull, 0, r * h / 6, 0, g, { cast: false });
  for (let c = 1; c < 5; c++) add(box(0.07, h, 0.07), M.mull, -w / 2 + c * w / 5, h / 2, d / 2 + 0.03, g, { cast: false });
  add(tbox(w * 0.72, 2.6, d * 0.72, 2), M.glassD, 0, h + 1.3, 0, g);
  for (let r = 1; r < 4; r++) add(box(w * 0.72 + 0.04, 0.07, d * 0.72 + 0.04), M.mull, 0, h + r * 0.65, 0, g, { cast: false });
  add(new THREE.CylinderGeometry(0.04, 0.06, 1.4, 6), M.mull, 0.4, h + 3.3, 0, g);
  add(box(1.3, 2.0, 0.1), M.mull, 0, 1.0, d / 2 + 0.04, g, { cast: false });
  signMesh(txt, col, '#fff6dc', w * 0.92, 0.75, 0, h - 0.55, d / 2 + 0.07, g, size);
  return g;
};
const hall = (x, z, w, h, d, txt, col, size) => (x < 0 ? bankHall : glassTower)(x, z, w, h, d, txt, col, size);
hall(-1.95, -4, 3.5, 3.7, 4.2, 'NASDAQ', '#16325f', 110); hall(1.95, -4, 3.5, 3.7, 4.2, 'CHIP MAKERS', '#0f4a5a', 70);
// modern flat-roof houses and mid-rise offices alongside
const modernHouse = (x, z, w, h, d) => { const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g);
  add(tbox(w, h * 0.7, d, 2), M.white, 0, h * 0.35, 0, g); add(tbox(w * 0.7, h * 0.5, d * 0.9, 2), M.concD, -w * 0.18, h * 0.7 + h * 0.25, 0, g);
  add(tbox(w * 1.1, 0.14, d * 1.1, 1), M.mull, 0, h * 0.7 + 0.07, 0, g);
  add(box(w * 0.55, h * 0.42, 0.06), M.glassD, w * 0.12, h * 0.34, d / 2 + 0.04, g, { cast: false }); add(box(w * 0.3, h * 0.3, 0.06), M.glass, -w * 0.2, h * 0.95, d * 0.45 + 0.04, g, { cast: false }); return g; };
const office = (x, z, w, h, d) => { const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g);
  add(tbox(w, h, d, 2), M.conc, 0, h / 2, 0, g); windows(g, w * 0.9, h * 0.92, d, h * 0.04, 6, 4, M.glass); add(tbox(w + 0.2, 0.18, d + 0.2, 1), M.concD, 0, h + 0.09, 0, g); return g; };
modernHouse(-5.6, -5, 3.0, 3.0, 3.4); modernHouse(5.6, -5, 3.0, 3.2, 3.4); office(-9.2, -6, 3.6, 5.8, 3.6); office(9.2, -6, 3.6, 7.0, 3.6);
modernHouse(-13, -7, 3.6, 3.2, 3.6); office(13, -7, 3.6, 5.0, 3.6);
// sign posts (dynamic text): year board + two money boards
const mkSign = (w, h, y, postX) => { const g = new THREE.Group(); world.add(g); const px = Math.round(w / h * 200); const c = document.createElement('canvas'); c.width = px; c.height = 200; const t = P.tex(c);
  const bd = add(new THREE.PlaneGeometry(w, h), toon({ map: t }), 0, y, 0, g, { cast: false }); add(tbox(0.2, y - h / 2, 0.14, 1), M.postW, 0, (y - h / 2) / 2, -0.06, g);
  g.userData = { c, t, key: '' }; return g; };
const setSign = (g, txt, bg, fg, size) => { const k = txt + bg; if (g.userData.key === k) return; g.userData.key = k; const { c, t } = g.userData; c.getContext('2d').drawImage(signTex(txt, bg, fg, c.width, c.height, size), 0, 0); t.needsUpdate = true; };
const yearS = mkSign(3.8, 1.3, 4.1), moneyS1 = mkSign(2.6, 0.95, 3.6), moneyS2 = mkSign(2.6, 0.95, 3.3);
// trees + hills + mountains
const pine = (x, z, h = 6) => { const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g); add(new THREE.CylinderGeometry(0.2, 0.3, h * 0.4, 6), M.trunk, 0, h * 0.2, 0, g);
  for (let k = 0; k < 3; k++) add(new THREE.ConeGeometry(1.9 - k * 0.45, h * 0.5, 8), M.pine, 0, h * 0.45 + k * h * 0.22, 0, g); return g; };
const rt = P.rng(44);
for (let i = 0; i < 52; i++) { const x = -70 + rt() * 150, z = -22 - rt() * 70, w = 3 + rt() * 4, h = 8 + rt() * 26; const g = new THREE.Group(); g.position.set(x, 0, z); world.add(g); add(tbox(w, h, w, 2), i % 3 ? M.glass : (i % 3 === 0 ? M.glassD : M.conc), 0, h / 2, 0, g); for (let r = 1; r < h / 2.2; r++) add(box(w + 0.04, 0.06, w + 0.04), M.mull, 0, r * 2.2, 0, g, { cast: false }); }
for (let i = 0; i < 10; i++) { const x = WX + 12 + rt() * 40, z = 4 - rt() * 90; pine(x, z, 4 + rt() * 3); }
for (let i = 0; i < 16; i++) { const a = rt() * Math.PI + Math.PI, d = 170 + rt() * 160; const h = add(new THREE.SphereGeometry(40 + rt() * 40, 20, 10), i % 2 ? M.hill : M.hillFar, Math.cos(a) * d * 1.2, -12, Math.sin(a) * d - 60, world, { cast: false }); h.scale.y = 0.5 + rt() * 0.3; }
for (let i = 0; i < 12; i++) { const a = rt() * Math.PI + Math.PI, d = 520 + rt() * 200, hh = 120 + rt() * 120, r_ = 110 + rt() * 70; const g = new THREE.Group(); g.position.set(Math.cos(a) * d, -5, Math.sin(a) * d - 120); world.add(g); add(new THREE.ConeGeometry(r_, hh, 7), M.mount, 0, hh / 2, 0, g, { cast: false }); add(new THREE.ConeGeometry(r_ * 0.3, hh * 0.3, 7), M.snow, 0, hh * 0.86, 0, g, { cast: false }); }
// chest (lid hinged at the back), coin piles, clock
const chest = new THREE.Group(); world.add(chest);
add(tbox(1.1, 0.55, 0.7, 1), M.chestW, 0, 0.28, 0, chest); for (const s of [-1, 1]) add(box(0.1, 0.58, 0.74), M.chestB, s * 0.38, 0.28, 0, chest);
const lidP = new THREE.Group(); lidP.position.set(0, 0.56, -0.35); chest.add(lidP);
add(tbox(1.12, 0.18, 0.72, 1), M.chestW, 0, 0.09, 0.36, lidP); for (const s of [-1, 1]) add(box(0.1, 0.2, 0.76), M.chestB, s * 0.38, 0.09, 0.36, lidP);
const chestCoins = add(new THREE.SphereGeometry(0.48, 12, 6), M.gold, 0, 0.5, 0, chest); chestCoins.scale.y = 0.4;
const lockM = add(box(0.2, 0.22, 0.08), M.chestB, 0, 0.5, 0.38, chest); const lockArc = add(new THREE.TorusGeometry(0.07, 0.025, 6, 10, Math.PI), M.steel, 0, 0.63, 0.38, chest);
const makePile = () => { const pile = new THREE.Group(); world.add(pile); const coins = []; let k = 0;
  for (let layer = 0; layer < 7; layer++) { const n = 15 - layer * 2; for (let j = 0; j < Math.max(1, n); j++) { const a = j / Math.max(1, n) * Math.PI * 2 + layer, r = layer === 6 ? 0 : 0.1 + (6 - layer) * 0.1;
    const c = add(box(0.5, 0.05, 0.26), (k % 3) ? M.bill : M.billD, Math.cos(a) * r, 0.04 + layer * 0.07, Math.sin(a) * r, pile); c.rotation.set(Math.sin(k) * 0.05, a, Math.cos(k) * 0.05); coins.push(c); k++; } }
  return { pile, coins }; };
const P1 = makePile(), P2 = makePile();
M.dcW = toon({ color: '#7d8794' }); M.dcL = toon({ color: '#8fe3ff' }); M.dcD = toon({ color: '#4a5260' });
const dcG = new THREE.Group(); dcG.position.set(0, 0, -1.2); world.add(dcG);
add(tbox(3.2, 2.6, 2.4, 2), M.dcW, 0, 1.3, 0, dcG); add(tbox(3.4, 0.2, 2.6, 2), M.dcD, 0, 2.7, 0, dcG);
for (let r = 0; r < 3; r++) for (let c = 0; c < 6; c++) add(box(0.34, 0.2, 0.06), M.dcL, -1.25 + c * 0.5, 0.7 + r * 0.55, 1.23, dcG, { cast: false });
for (const x of [-1.0, 0, 1.0]) add(new THREE.CylinderGeometry(0.28, 0.28, 0.4, 10), M.dcD, x, 3.0, 0.2, dcG);
signMesh('DATA CENTER', '#16264a', '#8fe3ff', 2.6, 0.6, 0, 2.15, 1.26, dcG, 70);
dcG.visible = false;
const clock = new THREE.Group(); world.add(clock);
{ add(new THREE.CylinderGeometry(0.06, 0.06, 2.2, 6), M.postW, 0, 1.1, -0.1, clock);
  const face = add(new THREE.CylinderGeometry(0.9, 0.9, 0.12, 24), M.clockF, 0, 2.7, 0, clock); face.rotation.x = Math.PI / 2;
  const rim = add(new THREE.TorusGeometry(0.9, 0.07, 8, 28), M.chestB, 0, 2.7, 0.04, clock);
  for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; add(box(0.07, i % 3 ? 0.1 : 0.18, 0.04), M.postW, Math.sin(a) * 0.75, 2.7 + Math.cos(a) * 0.75, 0.08, clock).rotation.z = -a; }
  var hourH = new THREE.Group(), minH = new THREE.Group(); hourH.position.set(0, 2.7, 0.1); minH.position.set(0, 2.7, 0.13); clock.add(hourH, minH);
  add(box(0.09, 0.45, 0.03), M.postW, 0, 0.22, 0, hourH); add(box(0.06, 0.7, 0.03), M.postW, 0, 0.35, 0, minH); }
// ---------- action props: sports car, rocket, moon ----------
M.carR = toon({ color: '#d4262e' }); M.carG = toon({ color: '#f1b82e' }); M.tire = toon({ color: '#1d2029' }); M.rim = toon({ color: '#cfd5dd' }); M.rkW = toon({ color: '#f5f6f8' }); M.rkR = toon({ color: '#d6313a' });
M.flameO = new THREE.MeshBasicMaterial({ color: '#ff9a2e' }); M.flameY = new THREE.MeshBasicMaterial({ color: '#ffe46b' }); M.moonM = toon({ color: '#ece9de' }); M.moonC = toon({ color: '#c9c5b6' }); M.headL = new THREE.MeshBasicMaterial({ color: '#fff6b8' });
const carG = new THREE.Group(); world.add(carG); const wheels = [];
add(tbox(2.4, 0.42, 1.05, 2), M.carR, 0, 0.5, 0, carG); { const ws = add(box(0.06, 0.42, 0.9), M.glass, 0.25, 0.9, 0, carG, { cast: false }); ws.rotation.z = -0.5; }
add(box(2.45, 0.07, 0.3), M.carG, 0, 0.62, 0, carG, { cast: false }); add(box(0.5, 0.06, 1.1), M.carR, -1.15, 1.02, 0, carG); for (const s of [-1, 1]) add(box(0.06, 0.2, 0.06), M.mull, -1.15, 0.9, s * 0.4, carG);
for (const s of [-1, 1]) add(new THREE.SphereGeometry(0.1, 8, 6), M.headL, 1.2, 0.52, s * 0.35, carG, { cast: false });
for (const x of [-0.8, 0.8]) for (const s of [-1, 1]) { const w = new THREE.Group(); w.position.set(x, 0.3, s * 0.52); carG.add(w); const tr = add(new THREE.CylinderGeometry(0.3, 0.3, 0.2, 14), M.tire, 0, 0, 0, w); tr.rotation.x = Math.PI / 2; const rm = add(new THREE.CylinderGeometry(0.17, 0.17, 0.22, 8), M.rim, 0, 0, 0, w); rm.rotation.x = Math.PI / 2; add(box(0.08, 0.34, 0.24), M.mull, 0, 0, 0, w, { cast: false }); wheels.push(w); }
carG.visible = false;
const rocketG = new THREE.Group(); world.add(rocketG);
add(new THREE.CylinderGeometry(0.42, 0.42, 2.2, 16), M.rkW, 0, 1.1, 0, rocketG); add(new THREE.ConeGeometry(0.42, 1.0, 16), M.rkR, 0, 2.7, 0, rocketG);
{ const win = add(new THREE.CylinderGeometry(0.2, 0.2, 0.1, 14), M.glass, 0, 1.5, 0.4, rocketG); win.rotation.x = Math.PI / 2; const rim = add(new THREE.TorusGeometry(0.2, 0.04, 6, 14), M.carG, 0, 1.5, 0.45, rocketG); }
for (let i = 0; i < 3; i++) { const a = i * Math.PI * 2 / 3; const fin = add(tbox(0.08, 0.9, 0.55, 1), M.rkR, Math.sin(a) * 0.5, 0.35, Math.cos(a) * 0.5, rocketG); fin.rotation.y = a; }
const flame1 = add(new THREE.ConeGeometry(0.32, 1.3, 10), M.flameO, 0, -0.55, 0, rocketG, { cast: false }); flame1.rotation.x = Math.PI; const flame2 = add(new THREE.ConeGeometry(0.18, 0.9, 10), M.flameY, 0, -0.4, 0, rocketG, { cast: false }); flame2.rotation.x = Math.PI;
rocketG.visible = false;
const moonG = new THREE.Group(); world.add(moonG); add(new THREE.SphereGeometry(4, 24, 16), M.moonM, 0, 0, 0, moonG, { cast: false });
for (const [x, y, r] of [[-1.2, 1.0, 0.7], [1.4, -0.6, 0.9], [0.4, 1.9, 0.45], [-1.6, -1.5, 0.55]]) { const c = add(new THREE.SphereGeometry(r, 10, 6), M.moonC, x, y, 3.55, moonG, { cast: false }); c.scale.z = 0.25; }
moonG.visible = false;
// clouds: painted billboards far away (no fog, no ink)
const clouds = [];
{ const r = P.rng(90);
  for (let i = 0; i < 14; i++) {
    const c = document.createElement('canvas'); c.width = 600; c.height = 400; const pen = new T.Pen(c.getContext('2d')); pen.ol = 0;
    pen.g.translate(300, 200); pen.g.scale(1.4, 1.2); pen.g.translate(-300, -200); T.fxCloud(pen, i + 1);
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 0.667), new THREE.MeshBasicMaterial({ map: P.tex(c), transparent: true, fog: false, depthWrite: false }));
    const a = r() * Math.PI + Math.PI, d = 650 + r() * 250; m.position.set(Math.cos(a) * d, 120 + r() * 160, Math.sin(a) * d - 100); m.scale.setScalar(160 + r() * 140);
    m.userData.ndSkip = true; m.renderOrder = -1; scene.add(m); clouds.push(m);
  } }


// ---------- cards ----------
const CW = 1200, CH = 2000, CM = 2.25; // canvas px, card height in metres (design 600x1000 -> 2.25 m)
const cardGeo = new THREE.PlaneGeometry(CM * 0.6, CM); cardGeo.translate(0, CM / 2 - CM * 0.025, 0);
const blobTex = P.tex(P.radial('20,14,30', 0.6));
class Card {
  constructor(scale = 1) {
    [this.c, this.g] = (() => { const c = document.createElement('canvas'); c.width = CW; c.height = CH; return [c, c.getContext('2d')]; })();
    this.t = new THREE.CanvasTexture(this.c); this.t.colorSpace = THREE.SRGBColorSpace; this.t.anisotropy = 4;
    this.mat = new THREE.MeshBasicMaterial({ map: this.t, transparent: true, alphaTest: 0.02, side: THREE.DoubleSide, fog: true });
    this.mesh = new THREE.Mesh(cardGeo, this.mat); this.mesh.userData.nd = cardNd(this.t); this.mesh.castShadow = true;
    this.mesh.customDepthMaterial = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: this.t, alphaTest: 0.5 });
    this.blob = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, fog: true }));
    this.blob.rotation.x = -Math.PI / 2; this.blob.userData.ndSkip = true; this.blob.renderOrder = 1;
    scene.add(this.mesh); scene.add(this.blob); this.key = ''; this.mesh.visible = this.blob.visible = false;
  }
  draw(key, fn) {
    if (key === this.key) return; this.key = key;
    const g = this.g; g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, CW, CH); g.setTransform(CW / 600, 0, 0, CH / 1000, 0, 0);
    const p = new T.Pen(g); fn(p); this.t.needsUpdate = true;
  }
}
const cards = []; const getCard = (i) => cards[i] || (cards[i] = new Card());

// ---------- render targets & post ----------
const rtColor = new THREE.WebGLRenderTarget(W, H, { samples: 4, type: THREE.HalfFloatType });
const rtNd = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
const rtInk = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType });
const fsCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1), fsGeo = new THREE.PlaneGeometry(2, 2);
const fs = (mat) => { const s = new THREE.Scene(); s.add(new THREE.Mesh(fsGeo, mat)); return s; };
const inkU = { col: { value: rtColor.texture }, nd: { value: rtNd.texture }, res: { value: new THREE.Vector2(W, H) }, px: { value: 1.6 }, fogCol: { value: new THREE.Color() },
  sat: { value: 1.08 }, lift: { value: new THREE.Color(0, 0, 0) }, gain: { value: new THREE.Color(1, 1, 1) }, vig: { value: 0.22 }, flash: { value: 0 } };
const inkScene = fs(new THREE.ShaderMaterial({ uniforms: inkU, vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }`,
  fragmentShader: `uniform sampler2D col, nd; uniform vec2 res; uniform float px, sat, vig, flash; uniform vec3 fogCol, lift, gain; varying vec2 vUv;
  float edgeAt(vec2 uv, float r){
    vec4 c = texture2D(nd, uv); if (dot(c.rgb,c.rgb) < .01) return 0.; float d = c.a; vec3 n = c.rgb*2.-1.;
    float e = 0.; float rr = r * clamp(7./d, .62, 1.25);
    for (int i=0;i<16;i++){ float a = float(i)*.785398 + (i>7 ? .39 : 0.); float k = i>7 ? .5 : 1.;
      vec2 o = vec2(cos(a), sin(a))*rr*k/res; vec4 s = texture2D(nd, uv+o);
      float ds = s.a; bool card = dot(s.rgb,s.rgb) < .01;
      if (card && ds > 0.) continue;            // character cards: never outlined by the world ink
      if (card) ds = 1e4;                        // sky
      vec3 ns = s.rgb*2.-1.;
      e = max(e, smoothstep(.006, .02, (ds - d)/d));                           // depth jump, near side only
      if (!card && abs(ds-d)/d < .06) e = max(e, smoothstep(.88, .72, dot(n, ns)) * .9); // crease
    }
    return e * (1. - smoothstep(140., 520., d)*.8);
  }
  void main(){
    vec3 c = texture2D(col, vUv).rgb;
    float e = edgeAt(vUv, px);
    c = mix(c, vec3(.012,.01,.014), e);
    if (flash < -0.5) c = vec3(e);
    float l = dot(c, vec3(.299,.587,.114)); c = mix(vec3(l), c, sat);
    c = c*gain + lift;
    vec2 q = vUv-.5; c *= 1. - vig*dot(q*vec2(1.,.75), q*vec2(1.,.75))*2.2;
    c = mix(c, vec3(1.), flash);
    gl_FragColor = vec4(c,1.); }` }));
const dofU = { src: { value: rtInk.texture }, nd: { value: rtNd.texture }, res: { value: new THREE.Vector2(W, H) }, focus: { value: 5 }, cinf: { value: 0 }, near: { value: 1 } };
const dofScene = fs(new THREE.ShaderMaterial({ uniforms: dofU, vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }`,
  fragmentShader: `uniform sampler2D src, nd; uniform vec2 res; uniform float focus, cinf, near; varying vec2 vUv;
  float coc(vec2 uv){ float d = texture2D(nd, uv).a; if (d <= 0.) d = 2000.; float k = 1. - focus/d; return k > 0. ? cinf*k : min(-k*cinf*near, cinf*1.4); }
  void main(){
    float c0 = coc(vUv);
    if (cinf < .5 || c0 < .6) { gl_FragColor = linearToOutputTexel(vec4(texture2D(src, vUv).rgb, 1.)); return; }
    vec3 acc = vec3(0.); float wsum = 0.;
    for (int i=0;i<48;i++){ float fi = float(i); float r = sqrt((fi+.5)/48.); float a = fi*2.39996;
      vec2 o = vec2(cos(a), sin(a))*r*c0/res; float cs = coc(vUv+o);
      float w = smoothstep(r*c0-1.5, r*c0+.5, cs + .5);
      acc += texture2D(src, vUv+o).rgb*w; wsum += w; }
    gl_FragColor = linearToOutputTexel(vec4(acc/max(wsum,1e-3), 1.)); }` }));
// final copy with sRGB handled by the renderer output (we render to screen with linear->sRGB in the shader chunk)
dofScene.children[0].material.toneMapped = false;

// ---------- per-frame state ----------
const tmpV = new THREE.Vector3();
function applyLight(L, f) {
  hemi.color.set(L.sky); hemi.groundColor.set(L.ground); hemi.intensity = L.hemi;
  sun.color.set(L.sun); sun.intensity = L.sunI;
  scene.fog.color.set(L.fog); scene.fog.near = L.fogNear; scene.fog.far = L.fogFar;
  skyU.top.value.set(L.skyTop); skyU.hor.value.set(L.skyHor); skyU.sunCol.value.set(L.sunDisc || '#000'); skyU.sunSize.value = L.sunSize || 0;
  inkU.sat.value = L.sat; inkU.gain.value.set(L.gain || '#ffffff'); inkU.lift.value.set(L.lift || '#000000');
  waterU.deep.value.set(L.waterDeep); waterU.shal.value.set(L.waterShal); waterU.glint.value.set(L.glint);
}
function placeSun(L, focus) {
  // sun direction from azimuth/elevation in world space
  const az = rx(L.az), el = rx(L.el); tmpV.set(Math.cos(el) * Math.cos(az), Math.sin(el), Math.cos(el) * Math.sin(az));
  skyU.sunDir.value.copy(tmpV);
  sun.position.copy(focus).addScaledVector(tmpV, 80); sun.target.position.copy(focus);
  const ext = L.shadowExt || 30, sc = sun.shadow.camera; sc.left = -ext; sc.right = ext; sc.top = ext; sc.bottom = -ext; sc.near = 1; sc.far = 200; sc.updateProjectionMatrix();
}

function worldState(S, f) {
  const fill = (P, v, pos, sc) => { const n = Math.round(Math.max(0, Math.min(1, v || 0)) * P.coins.length); P.coins.forEach((c, i) => { c.visible = i < n; }); P.pile.visible = n > 0; P.pile.position.set(...pos); P.pile.scale.setScalar(sc); };
  fill(P1, S.p1, S.p1Pos || [-1.8, 0, 1.3], S.p1S || 1); fill(P2, S.p2, S.p2Pos || [1.8, 0, 1.3], S.p2S || 1);
  const sg = (g, s, txt, bg, size) => { g.visible = !!s; if (s) { g.position.set(...s.pos); g.scale.setScalar(s.s || 1); setSign(g, txt, bg, '#fff6dc', size || 120); } };
  sg(yearS, S.year, S.year && S.year.txt, S.year && (S.year.bg || '#27406f'), S.year && S.year.size); sg(moneyS1, S.m1, S.m1 && S.m1.txt, S.m1 && S.m1.bg || '#1f6b3a', 80); sg(moneyS2, S.m2, S.m2 && S.m2.txt, S.m2 && S.m2.bg || '#1f6b3a', 80);
  dcG.visible = !!S.dc;
  chest.visible = !!S.chest; if (S.chest) { chest.position.set(...S.chest.pos); chest.scale.setScalar(S.chest.s || 1); lidP.rotation.x = -(S.chest.open || 0) * 1.9; chestCoins.visible = (S.chest.open || 0) > 0.3; lockM.visible = lockArc.visible = !!S.chest.lock; }
  clock.visible = !!S.clock; if (S.clock) { clock.position.set(...S.clock.pos); clock.scale.setScalar(S.clock.s || 1); minH.rotation.z = -S.clock.a * 12; hourH.rotation.z = -S.clock.a; }
  carG.visible = !!S.car; if (S.car) { carG.position.set(...S.car.pos); carG.scale.setScalar(S.car.s || 1); carG.rotation.y = S.car.yaw || 0; wheels.forEach((w) => { w.rotation.z = -(S.car.spin || 0); }); }
  rocketG.visible = !!S.rocket; if (S.rocket) { rocketG.position.set(...S.rocket.pos); rocketG.scale.setScalar(S.rocket.s || 1); rocketG.rotation.z = -(S.rocket.rot || 0); const fl = 0.8 + 0.4 * Math.sin(f * 1.7); flame1.scale.set(1, fl * (S.rocket.flame ?? 1), 1); flame2.scale.set(1, (1.3 - fl * 0.5) * (S.rocket.flame ?? 1), 1); }
  moonG.visible = !!S.moon; if (S.moon) { moonG.position.set(...S.moon.pos); moonG.scale.setScalar(S.moon.s || 1); }
  waterU.t.value = f / 30;
}


function drawActors(list, cam) {
  cards.forEach((c) => { c.mesh.visible = c.blob.visible = false; });
  list.forEach((a, i) => {
    const c = getCard(i);
    c.draw(a.key, a.draw);
    c.mesh.visible = true; c.mesh.position.set(a.x, a.y, a.z);
    const s = a.s || 1; c.mesh.scale.set(s * (a.flip ? -1 : 1), s, s);
    c.mesh.rotation.set(0, Math.atan2(cam.position.x - a.x, cam.position.z - a.z) + (a.yaw || 0), a.roll || 0);
    c.mat.color.set(a.tint || '#ffffff'); c.mat.opacity = a.alpha ?? 1;
    c.mesh.castShadow = a.shadow !== false;
    c.mesh.renderOrder = a.order || 2;
    if (a.blob !== false && a.y < DECK + 0.5) { c.blob.visible = true; c.blob.position.set(a.x, (a.ground ?? DECK) + 0.02, a.z); c.blob.scale.set(0.95 * s, 0.6 * s, 1); }
  });
}

const swapForNd = (on) => {
  scene.traverse((o) => {
    if (!o.isMesh) return;
    if (on) {
      o.userData.mat0 = o.material;
      if (o.userData.ndSkip) { o.userData.vis0 = o.visible; o.visible = false; return; }
      if (o === sky || o.userData.sky) { o.userData.vis0 = o.visible; o.visible = false; return; }
      o.material = o.userData.nd || ndMat;
    } else {
      o.material = o.userData.mat0; if (o.userData.vis0 !== undefined) { o.visible = o.userData.vis0; delete o.userData.vis0; }
    }
  });
};

window.renderFrame = (f) => {
  const S = shotAt(f), L = lightFor(S, f), C = camAt(f);
  applyLight(L, f);
  camera.position.set(...C.pos); camera.up.set(0, 1, 0); camera.lookAt(...C.look); camera.rotateZ(rx(C.roll || 0));
  camera.fov = C.fov; camera.updateProjectionMatrix(); camera.updateMatrixWorld();
  const W_ = worldAt(f); worldState(W_, f);
  placeSun(L, new THREE.Vector3(...(C.shadowAt || C.look)));
  drawActors([...actorsAt(f, T), ...fxAt(f, T)], camera);
  sky.position.copy(camera.position);
  for (const c of clouds) c.quaternion.copy(camera.quaternion);
  // pass A: colour
  renderer.setRenderTarget(rtColor); renderer.setClearColor(0x000000, 1); renderer.clear(); renderer.render(scene, camera);
  // pass B: normal + depth
  const fog = scene.fog; scene.fog = null; const sm = renderer.shadowMap.enabled; renderer.shadowMap.enabled = false; renderer.shadowMap.autoUpdate = false;
  swapForNd(true); renderer.setRenderTarget(rtNd); renderer.setClearColor(0x000000, 0); renderer.clear(); renderer.render(scene, camera); swapForNd(false);
  scene.fog = fog; renderer.shadowMap.enabled = sm; renderer.shadowMap.autoUpdate = true;
  if (window.DEBUG_ND) { const dm = new THREE.MeshBasicMaterial({ map: rtNd.texture }); const ds = fs(dm); renderer.setRenderTarget(null); renderer.render(ds, fsCam); return true; }
  // ink + grade
  const D = dofAt(f);
  inkU.px.value = 2.5; inkU.flash.value = window.DEBUG_E ? -1 : (C.flash || 0); inkU.vig.value = L.vig ?? 0.22;
  renderer.setRenderTarget(rtInk); renderer.render(inkScene, fsCam);
  // lens
  dofU.focus.value = D.focus; dofU.cinf.value = D.cinf; dofU.near.value = D.near ?? 1;
  renderer.setRenderTarget(null); renderer.render(dofScene, fsCam);
  return true;
};
window.TOTAL = TOTAL;
window.ready = true;
