// "AI chip selloff" — shot boundaries come from phr.js (phrase starts), so swapping the voice only needs gen_phr.py.
import { M as MO, clamp, lerp, lerp3, ramp, camFromKeys, idle, blinkAt, walk, q } from './motion.js';
import { MK, TOTAL_F } from './phr.js';
export const FPS = 30, TOTAL = TOTAL_F, DECK = 0;
const ORDER = ['hook', 'chips', 'rally', 'ask', 'congress', 'analysts', 'qcom', 'trillion', 'party', 'payoff'];
export const SHOTS = ORDER.map((id, i) => ({ id, a: MK[id], b: (i === ORDER.length - 1 ? TOTAL_F : MK[ORDER[i + 1]]) - 1, light: id === 'payoff' ? 'golden' : 'day' }));
export const shotAt = (f) => SHOTS.find((s) => f >= s.a && f <= s.b) || SHOTS[SHOTS.length - 1];
const smooth = MO.smooth;
export const LIGHTS = {
  day: { az: 130, el: 48, sky: '#c4d6f2', ground: '#8a8262', hemi: 1.15, sun: '#fff1dc', sunI: 2.5, fog: '#cadcf0', fogNear: 70, fogFar: 900,
    skyTop: '#3f80d4', skyHor: '#c3daf2', sat: 1.12, waterDeep: '#2c6c8c', waterShal: '#5aaec4', glint: '#effaff', vig: 0.2, shadowExt: 18 },
  golden: { az: 70, el: 20, sky: '#b8b0d0', ground: '#8a7255', hemi: 1.1, sun: '#ffd0a0', sunI: 2.6, fog: '#f4d6b6', fogNear: 60, fogFar: 760,
    skyTop: '#7f86c8', skyHor: '#ffd7a0', sunDisc: '#fff0c8', sunSize: 0.0035, sat: 1.08, gain: '#fff8ee', waterDeep: '#3d5a86', waterShal: '#d99a6e', glint: '#ffe2a8', vig: 0.26, shadowExt: 18 },
};
export const lightFor = (S, f) => ({ ...LIGHTS[S.light] });
// ---------- cameras (portrait: half-width = d*tan(fov/2)*0.5625) ----------
const A = (s, e) => [{ f: s.a, ...e[0] }, { f: s.b, ...e[1] }];
const CAMDEF = {
  hook: [{ pos: [0, 2.2, 17.5], look: [0, 2.7, 0.8], fov: 41 }, { pos: [0, 2.0, 14.5], look: [0, 2.5, 0.8], fov: 40 }],
  chips: [{ pos: [0, 2.0, 14.5], look: [0, 2.2, 1.0], fov: 40 }, { pos: [0, 1.9, 13.0], look: [0, 2.1, 1.0], fov: 38 }],
  rally: [{ pos: [0, 2.2, 16.5], look: [0, 2.6, 0.8], fov: 41 }, { pos: [0.3, 2.3, 14.5], look: [0, 2.6, 0.8], fov: 40 }],
  ask: [{ pos: [-1.0, 1.9, 9.5], look: [0, 1.9, 2.0], fov: 34 }, { pos: [-0.6, 1.8, 8.2], look: [0, 1.9, 2.0], fov: 31 }],
  congress: [{ pos: [0, 2.0, 13.5], look: [0, 2.0, -0.5], fov: 38 }, { pos: [0, 2.1, 11.0], look: [0, 2.0, -0.5], fov: 36 }],
  analysts: [{ pos: [0, 2.4, 13.0], look: [0, 2.8, 0.8], fov: 38 }, { pos: [0, 2.5, 11.5], look: [0, 3.0, 0.8], fov: 36 }],
  qcom: [{ pos: [0, 2.3, 13.0], look: [0, 2.7, 0.8], fov: 38 }, { pos: [0, 2.4, 11.0], look: [0, 2.8, 0.8], fov: 35 }],
  trillion: [{ pos: [0, 2.4, 14.5], look: [0, 2.6, 1.2], fov: 40 }, { pos: [0.3, 2.4, 12.5], look: [0.8, 2.6, 1.2], fov: 38 }],
  party: [{ pos: [0, 2.1, 16.0], look: [0, 2.4, 0.8], fov: 41 }, { pos: [0, 3.4, 15.0], look: [0, 7.5, 0.8], fov: 45 }],
  payoff: [{ pos: [-1.0, 2.0, 11.0], look: [0, 2.6, 1.0], fov: 36 }, { pos: [0, 2.8, 18.5], look: [0, 2.8, 0.8], fov: 42 }],
};
const KICKS = SHOTS.filter((s) => ['hook', 'chips', 'trillion'].includes(s.id)).map((s) => ({ f: s.a + 2, a: 0.04 }));
export const camAt = (f) => {
  const S = shotAt(f); const c = camFromKeys(A(S, CAMDEF[S.id]), f, { creep: 0.0008, kicks: KICKS });
  const k = f - S.a; c.flash = (['trillion', 'party'].includes(S.id) && k < 6) ? (1 - k / 6) * 0.7 : 0;
  c.shadowAt = [0, 0, 1.4]; return c;
};
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
export const dofAt = (f) => { const S = shotAt(f), C = camAt(f); return S.id === 'ask' ? { focus: dist(C.pos, [0, 1.5, 2.2]), cinf: 6 } : { focus: 14, cinf: 0 }; };
// ---------- world state ----------
const RED = '#8a1c1c', GRN = '#1f6b3a', NAVY = '#27406f';
const SIGN = [0, 0, 0.1];
export const worldAt = (f) => {
  const S = shotAt(f), r = (a, b) => clamp(ramp(f, a, b), 0, 1), k = f - S.a, n = S.b - S.a;
  const W = { p1: 1, p2: 1, p1Pos: [-1.8, 0, 1.3], p2Pos: [1.8, 0, 1.3], p1S: 1, p2S: 1, year: null, m1: null, m2: null, chest: null, clock: null, dc: false };
  const sg = (txt, bg, size) => { W.year = { pos: SIGN, s: 1, txt, bg, size }; };
  switch (S.id) {
    case 'hook': sg('NASDAQ -5%', RED, 112); W.p1 = W.p2 = 1 - 0.4 * r(S.a + 20, S.b); break;
    case 'chips': sg('CHIPS -11%', RED, 112); W.p1 = W.p2 = 0.6 - 0.25 * r(S.a, S.b);
      if (f >= MK.micron - 2) W.m1 = { pos: [-1.8, 0, 1.4], s: 0.7, txt: 'MICRON -12%', bg: RED };
      if (f >= MK.amd - 2) W.m2 = { pos: [1.8, 0, 1.4], s: 0.7, txt: 'AMD -13%', bg: RED }; break;
    case 'rally': sg('WEDNESDAY: RALLY', GRN, 74); W.p1 = W.p2 = 0.35 + 0.6 * r(S.a, S.a + 40); W.car = { pos: [-5 + 10 * r(S.a + 8, S.a + 120), 0, 4.2], s: 1.0, spin: (10 * r(S.a + 8, S.a + 120)) / 0.3, yaw: 0 }; break;
    case 'ask': sg('THURSDAY?', RED, 120); W.p1 = W.p2 = 0.95 - 0.55 * r(S.a + 10, S.a + 60); break;
    case 'congress': sg('NEW CONGRESS?', NAVY, 84); W.year.pos = [0, 0, -3.2]; W.p1 = W.p2 = 0.4; W.dc = true; break;
    case 'analysts': W.p1 = W.p2 = 0.4; if (f < MK.notlaw - 3) sg('ANALYSTS: A WORRY', NAVY, 70); else sg('NOT A NEW LAW', '#6b5a1f', 86); break;
    case 'qcom': sg('QUALCOMM: WEAK OUTLOOK', '#8a5a1c', 58); W.p1 = W.p2 = 0.4 - 0.1 * r(S.a, S.b); break;
    case 'trillion': sg('$2 TRILLION GONE', RED, 78); W.p1 = W.p2 = 0.3 * (1 - r(S.a + 10, S.b - 5)); W.clock = { pos: [3.1, 0, 1.2], s: 0.85, a: 0.4 + 0.5236 * r(S.a, S.b - 10) }; break;
    case 'party': sg('YESTERDAY: PARTY', GRN, 78); W.p1 = W.p2 = 0.95; { const t = r(S.a + 14, S.a + 62); W.rocket = { pos: [0, 0.2 + 22 * t * t, -1.2], s: 1.1, flame: t > 0 ? 1.2 : 0.4, rot: 0 }; W.moon = { pos: [4.5, 24, -34], s: 0.9 }; } break;
    case 'payoff': sg('HOW MUCH IS AI WORTH?', NAVY, 62); W.p1 = W.p2 = 0.6; break;
  }
  return W;
};
// ---------- actors ----------
const R = (T, who, o, pos, extra = {}) => ({ key: who + JSON.stringify(o), draw: (p) => T.romanFront(p, who, o), x: pos[0], y: pos[1], z: pos[2], ...extra });
export const actorsAt = (f, T) => {
  const S = shotAt(f), out = [], tint = S.light === 'golden' ? '#ffe6cc' : '#ffffff';
  const I = (s) => idle(f, s);
  const guy = (who, seed, o, pos, ex = {}) => out.push(R(T, who, { seed, blink: blinkAt(f, seed), ...I(seed), ...o }, pos, { tint, ...ex }));
  const CAST = [['mA', 11, -3.0, 2.2], ['mD', 14, -0.9, 2.7], ['mB', 12, 0.9, 2.7], ['mC', 13, 3.0, 2.2], ['mE', 31, -1.9, 3.3], ['mF', 15, 1.9, 3.3]];
  const each = (fn, ex) => CAST.forEach(([w, sd, x, z], i) => guy(w, sd, fn(i, sd), [x, DECK, z], ex ? ex(i) : {}));
  const k = f - S.a, tt = q((f * 0.05) % 1, 2), ramp01 = (a, b) => clamp(ramp(f, S.a + a, S.a + b), 0, 1);
  const bounce = (i, a = 0.025) => q(Math.abs(Math.sin((f + i * 5) * 0.33)) * a, 3);
  switch (S.id) {
    case 'hook': each((i) => i === 4 ? { expr: 'shock', L: 'flail', R: 'flail', tilt: q(-12 * Math.sin(ramp01(40, 62) * 3), 1) } : ({ expr: 'shock', L: 'temple', R: 'temple', tilt: q(Math.sin((f + i * 7) * 0.4) * 3, 1), bob: bounce(i, 0.015) }), (i) => i === 4 ? { roll: q(-1.5 * Math.pow(ramp01(40, 62), 2), 2) } : {}); break;
    case 'chips': each((i) => ({ expr: 'cry', tt: q((tt + i * 0.13) % 1, 2), L: 'cheek', R: i % 2 ? 'cheek' : 'temple', tilt: q(Math.sin((f + i * 7) * 0.9) * 2.5, 1), bob: q(Math.abs(Math.sin((f + i * 4) * 0.5)) * 0.018, 3) })); break;
    case 'rally': case 'party': each((i) => { const d = Math.sin((f + i * 6) * 0.33); return { expr: 'excited', L: 'up', R: 'up', tilt: q(-d * 5, 1) }; }, (i) => ({ y: q(DECK + Math.abs(Math.sin((f + i * 6) * 0.2)) * 0.55, 3) }));
      if (S.id === 'rally') { const t = ramp01(8, 120), cx = -5 + 10 * t; out.push(R(T, 'mA', { seed: 21, expr: 'cool', L: 'up', R: 'hang' }, [cx - 0.12, 0.46, 4.2], { s: 0.62, blob: false, shadow: false })); } break;
    case 'ask': each((i) => ({ expr: 'nervous', L: i % 2 ? 'temple' : 'cheek', R: i % 2 ? 'cheek' : 'hang', look: 0.4 * (i % 2 ? 1 : -1), headTilt: q(5 * Math.sin(f * 0.1 + i), 1) })); break;
    case 'congress': each((i) => ({ expr: 'nervous', L: 'hang', R: i % 2 ? 'point' : 'hang', look: 0.5 * Math.sign(-CAST[i][2] || 1), facing: 0 })); break;
    case 'analysts': each((i) => ({ expr: 'neutral', L: 'cross', R: 'hang', look: 0.3 * (i % 2 ? 1 : -1) })); break;
    case 'qcom': each((i) => ({ expr: 'nervous', L: 'hang', R: 'hang', bob: bounce(i, 0.01) })); break;
    case 'trillion': each((i) => i === 3 ? { expr: 'dizzy', L: 'hang', R: 'hang', tilt: q(Math.sin(f * 0.35) * 7 * (1 - ramp01(36, 66)) + 14 * ramp01(36, 66), 1) } : ({ expr: i % 2 ? 'cry' : 'shock', tt: q((tt + i * 0.17) % 1, 2), L: 'up', R: 'up', tilt: q(Math.sin((f + i * 7) * 0.5) * 4, 1), bob: bounce(i, 0.02) }), (i) => i === 3 ? { roll: q(1.52 * Math.pow(ramp01(36, 66), 2), 2) } : {}); break;
    case 'payoff': each((i) => ({ expr: f - S.a > 40 ? 'smile' : 'nervous', L: 'up', R: 'up', headTilt: q(4 * Math.sin(f * 0.08 + i), 1), look: 0.3 * (i % 2 ? 1 : -1) })); break;
  }
  return out;
};
// ---------- 2D effects ----------
const FX = (key, draw, pos, s, extra = {}) => ({ key, draw, x: pos[0], y: pos[1], z: pos[2], s, blob: false, shadow: false, order: 5, ...extra });
export const fxAt = (f, T) => {
  const S = shotAt(f), out = [];
  const st = (key, pos, s, per = 24, ph = 0) => { const t = q((((f + ph) % per) / per), 2); out.push(FX(key + t, (p) => { p.g.translate(0, 80); T.fxStars(p, t); }, pos, s)); };
  if (S.id === 'rally') { const t = q(((f - S.a) % 20) / 20, 2), cx = -5 + 10 * clamp(ramp(f, S.a + 8, S.a + 120), 0, 1); out.push(FX('sp' + t, (p) => T.fxSpeed(p, t), [cx - 2.6, 0.4, 4.7], 1.3)); const t2 = q(((f - S.a) % 30) / 30, 2); out.push(FX('d' + t2, (p) => T.fxDollar(p, t2), [-3.4, 2.2, 1.0], 2.0)); }
  if (S.id === 'hook' && f - S.a > 62) { const kk = Math.min(1, (f - S.a - 62) / 8); out.push(FX('dust' + q(kk, 1), (p) => T.fxDust(p, kk), [-1.2, 0.2, 3.3], 1.0)); }
  if (S.id === 'rally' || S.id === 'party') { st('a', [-1.8, 1.4, 1.3], 0.8, 26, 0); st('b', [1.8, 1.4, 1.3], 0.8, 26, 13); st('c', [0, 5.0, 0.4], 1.3, 30); }
  if (S.id === 'payoff' && f - S.a > 50) st('p', [0, 5.1, 0.4], 1.2, 34);
  return out;
};
