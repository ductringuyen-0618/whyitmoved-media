"""Writes web/phr.js: MK = named start frames found in work/words.json (word-level timing), TOTAL_F."""
import json, re
W = json.load(open('work/words.json')); D = json.load(open('work/phrases.json'))['duration']
norm = lambda s: re.sub(r"[^a-z']", '', s.lower())
toks = [norm(w['w']) for w in W]
def find(seq, nth=0):
    seq = [norm(x) for x in seq]; hits = [i for i in range(len(toks) - len(seq) + 1) if toks[i:i + len(seq)] == seq]
    return round(W[hits[nth]]['s'] * 30)
MK = {'hook': 0, 'chips': find(['the', 'chip', 'index']), 'micron': find(['micron']), 'amd': find(['and', 'amd']), 'rally': find(['so', 'what']), 'yesterday1': find(['yesterday']), 'ask': find(['today'], 1),
      'congress': find(['could', 'a', 'new']), 'analysts': find(['analysts']), 'notlaw': find(['not', 'a', 'new', 'law']), 'qcom': find(['and', "qualcomm's"]), 'trillion': find(['reports']),
      'party': find(['yesterday'], 1), 'payoff': find(['today'], 2)}
print(MK)
open('web/phr.js', 'w').write(f"export const MK = {json.dumps(MK)}; export const TOTAL_F = {round(D * 30)};\n")
