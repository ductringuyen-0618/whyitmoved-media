// Action-kit demo reel: cry, trip, faint, jump, car, rocket. Each shot 70 frames.
import { M as MO, clamp, lerp, ramp, camFromKeys, idle, blinkAt, q } from './motion.js';
export const FPS = 30, TOTAL = 420, DECK = 0;
const IDS = ['cry', 'trip', 'faint', 'jump', 'car', 'rocket'];
export const SHOTS = IDS.map((id, i) => ({ id, a: i * 70, b: i * 70 + 69, light: 'day' }));
export const shotAt = (f) => SHOTS.find((s) => f >= s.a && f <= s.b) || SHOTS[SHOTS.length - 1];
export const LIGHTS = { day: { az: 130, el: 48, sky: '#c4d6f2', ground: '#8a8262', hemi: 1.15, sun: '#fff1dc', sunI: 2.5, fog: '#cadcf0', fogNear: 70, fogFar: 900,
  skyTop: '#3f80d4', skyHor: '#c3daf2', sat: 1.12, waterDeep: '#2c6c8c', waterShal: '#5aaec4', glint: '#effaff', vig: 0.2, shadowExt: 18 } };
export const lightFor = () => ({ ...LIGHTS.day });
const CAM = {
  cry: [{ pos: [0, 1.9, 9.0], look: [0, 1.9, 2.5], fov: 34 }, { pos: [0, 1.9, 8.0], look: [0, 1.9, 2.5], fov: 32 }],
  trip: [{ pos: [0, 2.0, 12.5], look: [0, 1.6, 2.5], fov: 38 }, { pos: [0, 2.0, 11.5], look: [0, 1.5, 2.5], fov: 37 }],
  faint: [{ pos: [0, 2.0, 12.5], look: [0, 1.6, 2.5], fov: 38 }, { pos: [0, 2.0, 11.5], look: [0, 1.5, 2.5], fov: 37 }],
  jump: [{ pos: [0, 2.2, 12.0], look: [0, 2.2, 2.5], fov: 38 }, { pos: [0, 2.2, 11.0], look: [0, 2.2, 2.5], fov: 37 }],
  car: [{ pos: [0, 1.6, 12.0], look: [0, 1.2, 3.5], fov: 38 }, { pos: [0, 1.6, 12.0], look: [0, 1.2, 3.5], fov: 38 }],
  rocket: [{ pos: [0, 1.8, 14.0], look: [0, 3.5, 2.0], fov: 42 }, { pos: [0, 14, 16.0], look: [0, 30, -10], fov: 50 }],
};
export const camAt = (f) => { const S = shotAt(f); return { ...camFromKeys([{ f: S.a, ...CAM[S.id][0] }, { f: S.b, ...CAM[S.id][1] }], f, { creep: 0 }), flash: 0, shadowAt: [0, 0, 2.5] }; };
export const dofAt = () => ({ focus: 12, cinf: 0 });
export const worldAt = (f) => {
  const S = shotAt(f), k = f - S.a, n = 69, r = (a, b) => clamp(ramp(f, S.a + a, S.a + b), 0, 1);
  const W = { p1: 0.9, p2: 0.9, p1Pos: [-1.8, 0, 1.3], p2Pos: [1.8, 0, 1.3], year: null, m1: null, m2: null, chest: null, clock: null, dc: false, car: null, rocket: null, moon: null };
  if (S.id === 'car') W.car = { pos: [-8 + 16 * r(4, 62), 0, 3.4], s: 1.0, spin: k * 0.55, yaw: 0 };
  if (S.id === 'rocket') { const t = r(6, 66); W.rocket = { pos: [0, 0.2 + 46 * t * t, 2.2], s: 1.1, flame: 1.2, rot: 0 }; W.moon = { pos: [5, 40, -40], s: 3.2 }; }
  return W;
};
const R = (T, who, o, pos, extra = {}) => ({ key: who + JSON.stringify(o), draw: (p) => T.romanFront(p, who, o), x: pos[0], y: pos[1], z: pos[2], ...extra });
export const actorsAt = (f, T) => {
  const S = shotAt(f), out = [], k = f - S.a, I = (s) => idle(f, s);
  const CAST = [['mA', 11, -3.0, 2.2], ['mD', 14, -0.9, 2.7], ['mB', 12, 0.9, 2.7], ['mC', 13, 3.0, 2.2], ['mE', 31, -1.9, 3.3], ['mF', 15, 1.9, 3.3]];
  const guy = (i, o, ex = {}) => { const [w, sd, x, z] = CAST[i]; out.push(R(T, w, { seed: sd, blink: blinkAt(f, sd), ...I(sd), ...o }, [x, DECK, z], ex)); };
  const sh = (i, a = 3) => q(Math.sin((f + i * 7) * 0.9) * a, 1);
  switch (S.id) {
    case 'cry': for (let i = 0; i < 6; i++) guy(i, { expr: 'cry', tt: q((f * 0.05 + i * 0.13) % 1, 2), L: 'cheek', R: i % 2 ? 'cheek' : 'temple', tilt: sh(i, 2.5), bob: q(Math.abs(Math.sin((f + i * 4) * 0.5)) * 0.018, 3) }); break;
    case 'trip': for (let i = 0; i < 6; i++) { if (i === 1) { const t = clamp(ramp(f, S.a + 14, S.a + 30), 0, 1), e = t * t; guy(1, { expr: 'shock', L: 'flail', R: 'flail', tilt: q(-12 * Math.sin(t * 3), 1) }, { roll: q(-1.5 * e, 2), x: -0.9 + 0.3 * e }); } else guy(i, { expr: k > 20 ? 'shock' : 'neutral', L: 'temple', R: 'temple', tilt: sh(i, 1.5) }); } break;
    case 'faint': for (let i = 0; i < 6; i++) { if (i === 2) { const t = clamp(ramp(f, S.a + 20, S.a + 48), 0, 1); guy(2, { expr: 'dizzy', L: 'hang', R: 'hang', tilt: q(Math.sin(f * 0.35) * 7 * (1 - t) + 14 * t, 1) }, { roll: q(1.52 * t * t, 2) }); } else guy(i, { expr: 'nervous', L: 'cheek', R: 'hang', look: 0.4 }); } break;
    case 'jump': for (let i = 0; i < 6; i++) { const j = Math.abs(Math.sin((f + i * 6) * 0.22)) * 0.9; guy(i, { expr: 'excited', L: 'up', R: 'up', tilt: sh(i, 3) }, { y: q(DECK + j, 3) }); } break;
    case 'car': { const t = clamp(ramp(f, S.a + 4, S.a + 62), 0, 1), cx = -8 + 16 * t; for (let i = 0; i < 6; i++) guy(i, { expr: 'excited', L: 'up', R: 'up', look: -0.4 }); out.push(R(T, 'mA', { seed: 21, expr: 'cool', L: 'up', R: 'hang' }, [cx - 0.35, 0.5, 3.4], { s: 0.62, blob: false, shadow: false })); break; }
    case 'rocket': for (let i = 0; i < 6; i++) guy(i, { expr: k < 40 ? 'excited' : 'shock', L: 'up', R: 'up', look: 0, tilt: sh(i, 2) }, { y: 0 }); break;
  }
  return out;
};
const FX = (key, draw, pos, s, extra = {}) => ({ key, draw, x: pos[0], y: pos[1], z: pos[2], s, blob: false, shadow: false, order: 5, ...extra });
export const fxAt = (f, T) => {
  const S = shotAt(f), out = [], k = f - S.a;
  if (S.id === 'faint' && k > 24) { const t = q((k % 24) / 24, 2); out.push(FX('st' + t, (p) => { p.g.translate(0, 80); T.fxStars(p, t); }, [-0.2, 0.9, 3.0], 0.9)); }
  if (S.id === 'trip' && k > 28) out.push(FX('dust' + Math.min(6, k - 28), (p) => T.fxDust(p, Math.min(1, (k - 28) / 8)), [-0.6, 0.2, 3.0], 1.0));
  if (S.id === 'jump') { const t = q((k % 30) / 30, 2); out.push(FX('d' + t, (p) => T.fxDollar(p, t), [0, 2.4, 1.0], 2.0)); }
  if (S.id === 'car') { const t = q((k % 20) / 20, 2); out.push(FX('sp' + t, (p) => T.fxSpeed(p, t), [-8 + 16 * clamp(ramp(f, S.a + 4, S.a + 62), 0, 1) - 2.4, 0.4, 3.9], 1.3)); }
  return out;
};
