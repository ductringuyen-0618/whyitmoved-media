// "The Shovel Salesman Who Got Rich" — timed to voice.mp3 (42.61 s, 30 fps, 1278 frames).
import { M as MO, clamp, lerp, lerp3, ramp, camFromKeys, idle, blinkAt, walk, q } from './motion.js';
export const FPS = 30, TOTAL = 1278, DECK = 0;
export const SHOTS = [
  { id: 'hook', a: 0, b: 96, light: 'day' }, { id: 'rich', a: 97, b: 210, light: 'golden' }, { id: 'store', a: 211, b: 331, light: 'day' },
  { id: 'secret', a: 332, b: 386, light: 'day' }, { id: 'river', a: 387, b: 456, light: 'day' }, { id: 'quiet', a: 457, b: 521, light: 'day' },
  { id: 'tools', a: 522, b: 683, light: 'day' }, { id: 'walk', a: 684, b: 865, light: 'day' }, { id: 'run', a: 866, b: 997, light: 'day' },
  { id: 'dig', a: 998, b: 1053, light: 'day' }, { id: 'shovels', a: 1054, b: 1083, light: 'day' }, { id: 'one', a: 1084, b: 1146, light: 'day' },
  { id: 'payoff', a: 1147, b: 1277, light: 'golden' },
];
export const shotAt = (f) => SHOTS.find((s) => f >= s.a && f <= s.b) || SHOTS[SHOTS.length - 1];
const smooth = MO.smooth;
const BR = [0, DECK, 1.5]; // Brannan's home mark
const BX = (f) => 0 + 18 * smooth(ramp(f, 684, 865)) * 0 + 17 * ramp(f, 690, 865); // walk x
// ---------- lights ----------
export const LIGHTS = {
  day: { az: 130, el: 48, sky: '#c4d6f2', ground: '#8a8262', hemi: 1.15, sun: '#fff1dc', sunI: 2.5, fog: '#cadcf0', fogNear: 70, fogFar: 900,
    skyTop: '#3f80d4', skyHor: '#c3daf2', sat: 1.12, waterDeep: '#2c6c8c', waterShal: '#5aaec4', glint: '#effaff', vig: 0.2, shadowExt: 18 },
  golden: { az: 70, el: 20, sky: '#b8b0d0', ground: '#8a7255', hemi: 1.1, sun: '#ffd0a0', sunI: 2.6, fog: '#f4d6b6', fogNear: 60, fogFar: 760,
    skyTop: '#7f86c8', skyHor: '#ffd7a0', sunDisc: '#fff0c8', sunSize: 0.0035, sat: 1.08, gain: '#fff8ee', waterDeep: '#3d5a86', waterShal: '#d99a6e', glint: '#ffe2a8', vig: 0.26, shadowExt: 18 },
};
export const lightFor = (S, f) => ({ ...LIGHTS[S.light] });
// ---------- cameras ----------
const CAMS = {
  hook: [{ f: 0, pos: [-5.2, 1.7, 2.4], look: [0, 1.55, 1.5], fov: 30 }, { f: 96, pos: [-4.0, 1.65, 2.1], look: [0, 1.55, 1.5], fov: 27 }],
  rich: [{ f: 97, pos: [-4.0, 1.65, 2.1], look: [0, 1.55, 1.5], fov: 27 }, { f: 190, pos: [-7.5, 2.4, 5.5], look: [1.8, 1.1, 1.4], fov: 38, path: [[-5.5, 1.9, 3.5]] }, { f: 210, pos: [-7.6, 2.4, 5.6], look: [1.8, 1.1, 1.4], fov: 38 }],
  store: [{ f: 211, pos: [0.6, 2.5, 15.5], look: [0.2, 2.7, 0], fov: 40 }, { f: 331, pos: [1.6, 1.8, 7.4], look: [1.2, 1.5, 0.7], fov: 34 }],
  secret: [{ f: 332, pos: [-5.2, 1.7, 2.8], look: [0, 1.55, 1.5], fov: 28 }, { f: 386, pos: [-4.6, 1.7, 2.5], look: [0, 1.55, 1.5], fov: 25 }],
  river: [{ f: 387, pos: [1.5, 1.6, 6], look: [4, 1.4, 1.5], fov: 34 }, { f: 456, pos: [22, 2.0, 9], look: [34, 0.3, -2], fov: 36 }],
  quiet: [{ f: 457, pos: [-7.5, 1.9, 4.5], look: [0, 1.4, 1.5], fov: 34 }, { f: 521, pos: [-6.0, 1.8, 3.6], look: [0, 1.45, 1.5], fov: 31 }],
  tools: [{ f: 522, pos: [-1.6, 1.8, 9.0], look: [-0.6, 1.2, 1.4], fov: 36 }, { f: 683, pos: [-1.3, 1.65, 8.0], look: [-0.5, 1.25, 1.4], fov: 34 }],
  walk: [],
  run: [{ f: 866, pos: [4.2, 1.5, 10.5], look: [4.2, 1.3, 1.2], fov: 44 }, { f: 997, pos: [22.5, 1.5, 10.5], look: [22.5, 1.3, 1.2], fov: 44 }],
  dig: [{ f: 998, pos: [18, 1.8, 7.5], look: [24, 1.2, 1.5], fov: 34 }, { f: 1053, pos: [18.5, 1.8, 7], look: [24, 1.2, 1.5], fov: 32 }],
  shovels: [{ f: 1054, pos: [-2.5, 1.7, 10.5], look: [-1.5, 1.2, 0.8], fov: 36 }, { f: 1083, pos: [-2.2, 1.6, 8.6], look: [-1.5, 1.1, 0.8], fov: 33 }],
  one: [{ f: 1084, pos: [-5.0, 1.6, 5.2], look: [1.9, 1.45, 2.7], fov: 32 }, { f: 1146, pos: [-3.2, 1.58, 4.8], look: [1.9, 1.5, 2.7], fov: 27 }],
  payoff: [{ f: 1147, pos: [-2.2, 1.6, 6.5], look: [1.9, 1.35, 1.3], fov: 36 }, { f: 1277, pos: [-1.0, 2.6, 14], look: [3.6, 1.3, 1.4], fov: 42, path: [[-1.8, 2.0, 9.5]] }],
};
const KICKS = [{ f: 172, a: 0.03 }, { f: 574, a: 0.03 }, { f: 622, a: 0.03 }, { f: 646, a: 0.03 }, { f: 1060, a: 0.04 }];
export const camAt = (f) => {
  const S = shotAt(f); let c;
  if (S.id === 'walk') { const x = BX(f); const a = { f: 684, pos: [x + 0.2, 1.9, 8.2], look: [x + 0.2, 1.6, 2.2], fov: 40 }; c = { ...a, pos: [x + 0.2, 1.9, 8.2], look: [x + 0.2, 1.6, 2.2], fov: lerp(40, 36, ramp(f, 684, 865)), roll: 0 }; }
  else if (S.id === 'run') { const xc = 3.2 + 3.0 * (f - 866) / 30; c = { pos: [xc, 1.5, 10.5], look: [xc, 1.3, 1.2], fov: 44, roll: 0 }; }
  else c = camFromKeys(CAMS[S.id], f, { creep: 0.0008, kicks: KICKS });
  c.flash = f >= 211 && f < 217 ? (1 - (f - 211) / 6) * 0.85 : 0;
  c.shadowAt = S.id === 'river' ? [30, 0, 0] : S.id === 'run' ? [4.2 + 4.2 * (f - 866) / 30, 0, 1.2] : S.id === 'dig' ? [24, 0, 1.5] : S.id === 'walk' ? [BX(f), 0, 2] : [0.5, 0, 1.2];
  return c;
};
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
export const dofAt = (f) => {
  const S = shotAt(f), C = camAt(f);
  switch (S.id) {
    case 'hook': case 'rich': case 'secret': return { focus: dist(C.pos, [0, 1.5, 1.5]), cinf: f < 130 || S.id !== 'rich' ? 11 : 3 };
    case 'quiet': return { focus: dist(C.pos, [0, 1.4, 1.5]), cinf: 6 };
    case 'walk': return { focus: dist(C.pos, [BX(f), 1.5, 2.5]), cinf: 6 };
    case 'shovels': return { focus: dist(C.pos, [0, 1.0, 1.2]), cinf: 9 };
    case 'one': return { focus: dist(C.pos, [0.4, 1.5, 0.6]), cinf: 9 };
    case 'payoff': return { focus: dist(C.pos, [1.2, 1.4, 1.3]), cinf: f < 1190 ? 7 : 0 };
    case 'river': return { focus: 18, cinf: 0 };
    default: return { focus: 12, cinf: 0 };
  }
};
// ---------- world state ----------
export const worldAt = (f) => {
  const S = shotAt(f), W = { b1848: f >= 211 && f < 332, bShovels: f >= 1054, tools: 0, coins: 0, pilePos: [2.2, 0, 1.3], pileS: 1.0, bottle: null };
  if (f >= 522) W.tools = f >= 683 ? 24 : Math.floor(24 * ramp(f, 560, 678));
  if (f >= 683) W.tools = 24;
  if (S.id === 'rich') W.coins = ramp(f, 124, 188);
  if (f >= 1147) { W.coins = 1; W.pileS = 1.5; W.pilePos = [3.0, 0, 1.6]; }
  if (S.id === 'walk' || S.id === 'run' && f < 880) { const x = S.id === 'walk' ? BX(f) : 17; W.bottle = { pos: [x + 0.5, 2.02 + 0.03 * Math.sin(f * 0.3), 2.45], ry: f * 0.05, rz: 0.25 + 0.1 * Math.sin(f * 0.4), s: 1.0 }; }
  return W;
};
// ---------- actors ----------
const R = (T, who, o, pos, extra = {}) => ({ key: who + JSON.stringify(o), draw: (p) => T.romanFront(p, who, o), x: pos[0], y: pos[1], z: pos[2], ...extra });
export const actorsAt = (f, T) => {
  const S = shotAt(f), out = [];
  const I = (s) => idle(f, s);
  const bran = (o, pos = BR, ex = {}) => out.push(R(T, 'brannan', { seed: 5, blink: blinkAt(f, 5), ...I(5), ...o }, pos, { tint: S.light === 'golden' ? '#ffe6cc' : '#ffffff', ...ex }));
  const guy = (who, seed, o, pos, ex = {}) => out.push(R(T, who, { seed, blink: blinkAt(f, seed), ...I(seed), ...o }, pos, { tint: S.light === 'golden' ? '#ffe6cc' : '#ffffff', ...ex }));
  switch (S.id) {
    case 'hook': { const sh = f > 48 && f < 80 ? 6 * Math.sin((f - 48) / 32 * Math.PI * 4) : 0; bran({ expr: f < 48 ? 'neutral' : 'nervous', L: 'hip', R: 'hang', headTilt: q(sh, 1), look: f > 48 ? 0.5 * Math.sin(f * 0.3) : 0 }); break; }
    case 'rich': { const g = f > 150; bran({ expr: g ? 'grin' : 'smile', L: g ? 'hip' : 'hang', R: g ? 'up' : 'hip', bob: q(g ? Math.abs(Math.sin(f * 0.35)) * 0.02 : 0, 3) }); break; }
    case 'store': { bran({ expr: 'grin', L: 'hip', R: 'wave', wv: f * 0.4 }, [1.2, DECK, 0.7]); guy('civA', 11, { L: 'hang', R: 'hang', facing: 1 }, [-9 + (f - 211) * 0.03, DECK, 1.6]); guy('towner', 12, { facing: -1 }, [8 - (f - 211) * 0.025, DECK, 2.1]); break; }
    case 'secret': { bran({ expr: 'grin', L: 'cheek', R: 'hang', look: 0.8, facing: 0.35, headTilt: q(-4 + 2 * Math.sin(f * 0.2), 1) }); break; }
    case 'river': { if (f < 410) bran({ expr: 'grin', look: 0.9, facing: 0.5 }); break; }
    case 'quiet': { bran({ expr: 'grin', L: 'cross', R: 'hang', look: -0.6 }); guy('civA', 11, { facing: 1, step: q((walk(f, 457, 1.1).phase), 2) }, [-6 + walk(f, 457, 1.1).dist * 1.2, DECK, -0.1]); guy('minerB', 14, { facing: -1 }, [6, DECK, -0.4]); break; }
    case 'tools': { const x = 0.3 + 0.3 * Math.sin(f * 0.05); const sw = Math.sin(f * 0.28); bran({ expr: 'grin', L: sw > 0 ? 'reach' : 'hang', R: sw > 0 ? 'hang' : 'reach', lift: 0.3, tilt: q(sw * 4, 1), bob: q(Math.abs(sw) * 0.02, 3) }, [x, DECK, 1.7]); break; }
    case 'walk': { const x = BX(f), w = walk(f, 690, 1.9, 0.7); bran({ expr: 'laugh', L: 'hip', R: 'up', step: q(w.phase, 2), bob: q(Math.abs(Math.sin(f * 0.45)) * 0.02, 3) }, [x, DECK, 2.3]);
      const b = [['minerA', 21, -3, -0.3], ['minerB', 22, 2.5, 0.2], ['towner', 23, 7, -0.5], ['civA', 24, 11, 0.2]];
      b.forEach(([w2, sd, dx, z]) => { const px = dx + 0.5 * (sd % 3); const near = Math.abs(x - px) < 9; guy(w2, sd, { facing: x > px ? 0.5 : -0.3, look: near ? 0.8 : 0, expr: near && f > 740 ? 'shock' : 'neutral', L: near && f > 780 ? 'point' : 'hang', R: 'hang' }, [px, DECK, z - 0.2]); });
      break; }
    case 'run': { const base = [['minerA', 21, 0], ['minerB', 22, -2.6], ['towner', 23, -4.2], ['civA', 24, -1.4], ['minerC', 25, -5.4], ['minerD', 26, -3.4], ['minerE', 27, -6.8]];
      const t = (f - 866) / 30; base.forEach(([w2, sd, dx], i) => { const v = 4.2 + (i % 3) * 0.35, x = 4.2 + dx * 0.75 + 4.2 * t + (f < 880 ? 0 : 0), z = 0.1 + (i % 4) * 0.75; const ph = ((t * v / 1.0) + i * 0.3) % 1;
        guy(w2, sd, { expr: 'laugh', L: 'up', R: i % 2 ? 'up' : 'wave', wv: f * 0.5, tilt: -7, step: q(ph, 2), bob: q(Math.abs(Math.sin((f + i * 3) * 0.5)) * 0.03, 3) }, [x, DECK, z]); }); break; }
    case 'dig': { const m = [['minerA', 21, 21.5, 1.2], ['minerB', 22, 23.5, 2.2], ['minerC', 25, 25.3, 1.0], ['minerD', 26, 22.3, 0.2]];
      m.forEach(([w2, sd, x, z]) => guy(w2, sd, { expr: f > 1010 ? 'nervous' : 'neutral', L: 'temple', R: 'cheek', swirl: q((f * 0.35) % 6.283, 1), headTilt: q(5 * Math.sin(f * 0.3 + sd), 1) }, [x, DECK, z])); break; }
    case 'shovels': { bran({ expr: 'grin', L: 'hip', R: 'hip' }, [1.6, DECK, 0.3]); break; }
    case 'one': { bran({ expr: 'grin', L: 'hip', R: 'cross', look: 0.5, bob: q(f > 1100 ? Math.abs(Math.sin(f * 0.3)) * 0.02 : 0, 3) }, [1.9, DECK, 2.7]); break; }
    case 'payoff': { const g = f - 1147; bran({ expr: 'laugh', L: 'hip', R: 'hip', bob: q(Math.abs(Math.sin(f * 0.32)) * 0.025, 3), tilt: q(2 * Math.sin(f * 0.16), 1) }, [1.2, DECK, 1.3]);
      [['minerA', 21, 9, 0.2], ['minerB', 22, 11.5, 1.1], ['minerC', 25, 14, 0.4], ['minerE', 27, 7.2, 2.0]].forEach(([w2, sd, x, z], i) => { const d = Math.sin((f + i * 6) * 0.33); guy(w2, sd, { expr: 'nervous', L: d > 0 ? 'lift' : 'hang', R: d > 0 ? 'hang' : 'lift', tilt: q(-d * 5, 1), bob: q(Math.abs(d) * 0.02, 3), look: 0.3 }, [x, DECK, z]); }); break; }
  }
  return out;
};
// ---------- 2D effects ----------
const FX = (key, draw, pos, s, extra = {}) => ({ key, draw, x: pos[0], y: pos[1], z: pos[2], s, blob: false, shadow: false, order: 5, ...extra });
export const fxAt = (f, T) => {
  const S = shotAt(f), out = [];
  if (S.id === 'rich' && f >= 150) { const t = q(((f - 150) / 24) % 1, 2); out.push(FX('st' + t, (p) => { p.g.translate(0, 80); T.fxStars(p, t); }, [2.2, 1.6, 1.4], 1.1)); }
  if (S.id === 'river' || (S.id === 'secret' && f > 380)) for (let i = 0; i < 4; i++) { const t = q(((f * 0.035) + i * 0.27) % 1, 2); out.push(FX('sp' + t, (p) => { p.g.translate(0, 40); T.fxStars(p, t); }, [30 + i * 2.6, 0.15, -1 + (i % 2) * 2], 0.9 + 0.2 * (i % 2))); }
  if (S.id === 'tools') for (let i = 0; i < 2; i++) { const t = q(((f * 0.05) + i * 0.5) % 1, 2); out.push(FX('pf' + t, (p) => { p.g.translate(150, 700); p.g.scale(1.0, 1.0); T.fxPuff(p, t); }, [5.2 + i * 0.5, 0.1, 1.9], 0.5)); }
  if (S.id === 'run') for (let i = 0; i < 6; i++) { const t = q(((f * 0.06) + i / 6) % 1, 2); out.push(FX('rp' + t, (p) => { p.g.translate(150, 700); T.fxPuff(p, t); }, [4 + (f - 866) * 0.14 + i * -1.4, 0.1, 0.6 + (i % 3) * 0.9], 0.55)); }
  if (S.id === 'walk' && f > 700) { const t = q(((f * 0.07)) % 1, 2); out.push(FX('st2' + t, (p) => { p.g.translate(0, 80); T.fxStars(p, t); }, [BX(f) + 0.55, 2.4, 2.4], 0.5)); }
  if (S.id === 'payoff') { const t = q(((f - 1147) / 30) % 1, 2); out.push(FX('st3' + t, (p) => { p.g.translate(0, 80); T.fxStars(p, t); }, [2.6, 2.0, 1.4], 1.2)); out.push(FX('st4' + t, (p) => { p.g.translate(0, 80); T.fxStars(p, (t + 0.5) % 1); }, [3.1, 1.2, 1.9], 0.9)); }
  return out;
};
