# FACTS: Intel (INTC) plunge, Fri Oct 30 2026

Method: all facts from pages fetched with WebFetch. [2x]=two+ fetched sources agree, [1x]=single-sourced. Close vs intraday marked. No advice or predictions.

## 3-sentence summary (12-year-old level)
Intel makes the "brains" for most laptops, and on Thursday night it told investors its next three months would be much weaker than expected because people are buying far fewer PCs. A shortage of memory chips (the short-term storage PCs need) has made PCs more expensive, so customers are holding off. The next day Intel's stock closed down 28.58%, its worst day in about 50 years, and other chip stocks fell along with it.

## Numbered facts

1. **Timing.** Intel reported Q3 results on Thu Oct 29, 2026, 4:01pm EDT; the stock fell the next session, Fri Oct 30. [1x primary + 2x coverage] https://www.intc.com/news-events/press-releases/detail/1786/intel-reports-third-quarter-2026-financial-results ; https://www.ibtimes.com.au/intel-shares-plunge-weak-pc-outlook-forecast-1877636
2. **The CLOSE.** INTC closed $65.76, down $26.31 (-28.58%) from $92.07 (Thu close). Open $68.36; range $63.20-$68.77; closed $2.56 above the low. [2x: Gotrade, Gadget Scout (Gadget Scout cites AP)] https://www.heygotrade.com/en/news/intel-intc-stock-news-november-2-2026/ ; https://www.gadgetscout.co.uk/articles/intel-shares-slump-28-58-on-pc-slowdown-warning.html
3. **Intraday figures are different.** IBTimes: down 27.4% (~$66.84) near 10:45am EDT, "as much as 30%" intraday. Reuters (morning, pre-close): "sank 30%... headed for its biggest one-day decline ever" and ~$146bn of market value wiped. Use 28.58% for the close. [2x] IBTimes AU ; https://whbl.com/2026/10/30/intel-warning-sparks-chip-rout-as-pc-weakness-clouds-turnaround/ (Reuters)
4. **"Worst day" wording.** IBTimes: only worse session in 50+ years was Jul 5, 1974 (-29.9%). Gadget Scout (citing AP): worst day since 1974. So the close is second-worst, not "worst ever"; Reuters' "biggest ever" was written while the stock was down ~30% pre-close. [2x] IBTimes AU ; Gadget Scout
5. **Q3 was fine.** Revenue $16.5bn, +21% YoY (in line); adj. EPS 52c vs 41c expected; Data Center & AI +78% to $7.3bn; Foundry +58% to $6.7bn; Client Computing (PCs) -5% to $8.1bn. [2x] Intel release (above) ; IBTimes AU
6. **Q4 guidance is the trigger.** Revenue $15.0-16.0bn (vs ~$17bn expected); non-GAAP EPS $0.25 (vs ~$0.43 consensus); gross margin ~38% vs 43% in Q3. [2x: Intel release for revenue/EPS; IBTimes/Gadget Scout for consensus] Intel release ; IBTimes AU
7. **Stated reason: PC slowdown.** CFO David Zinsner (release): "we see the PC slowdown continuing at least through the first half of next year." IBTimes: Intel expects the PC market to shrink 12% in 2026 and 10% in 2027. CEO Lip-Bu Tan: conditions last "until memory availability and prices begin to normalize." [2x] Intel release ; IBTimes AU
8. **Memory shortage.** IBTimes: a global memory-chip shortage has raised PC prices and squeezed corporate budgets. Gadget Scout: memory makers are shifting capacity to high-bandwidth memory for AI data centres, leaving less ordinary memory for PCs; OEMs also cutting inventory. [2x, same theme] IBTimes AU ; Gadget Scout
9. **Israel factory accident.** IBTimes: early-October accident at Intel's Israel factory expected to cut Q4 revenue by ~$300m. Gadget Scout says Kiryat Gat, "mid-October," production halted ~2 weeks. The Intel release itself does NOT mention it (checked: "Israel" appears only in the risk-factor boilerplate). [2x media, NOT in company release; date conflict early vs mid-Oct] IBTimes AU ; Gadget Scout ; Intel release
10. **Cash flow worries.** Reuters: Intel does not expect positive cash flow this year; IBTimes: no positive free cash flow expected in 2027 as capex rises. Intel had $21.84bn cash vs $46.32bn long-term debt at end-Sept; 5-yr CDS widened 17.5 bps to 124.75 (Reuters). Note: "this year" (Reuters) vs "2027" (IBTimes) are different claims. [1x each] Reuters via WHBL ; IBTimes AU
11. **Analyst reaction.** BofA (Vivek Arya) downgraded to neutral, target $100 from $145; Roth downgraded, target $70 from $120; Cantor target $90 from $125 (IBTimes). Seaport's Jay Goldberg (Reuters): "a loss of faith in management's credibility"; "Intel is producing too many chips for consumer PCs in the worst PC market in 15 years"; "Bad planning is the cause." (Opinion of one analyst, not established fact.) [1x each] IBTimes AU ; Reuters via WHBL
12. **Sympathy moves (not closes unless stated).** Reuters: AMD, Arm, Qualcomm, Nvidia, Broadcom, Micron fell 4% to 12%; Dell, HPE, Super Micro fell 6% to 11%; ASML -6%+, TSMC ~-2%, KOSPI -3.5%, Samsung -3% (timing within day not stated). IBTimes at ~10:45am: Dell -13%, AMD -10%, Nvidia -3%. [2x, partly different snapshots] Reuters via WHBL ; IBTimes AU
13. **Index close that day.** Nasdaq Composite -2.86%, S&P 500 -1.82%, Dow -1.09% (Yahoo data via Gotrade; Nasdaq figure also in the TSLA Oct 30 page citing AP). Gotrade/Reuters note Amazon's results (Oct 29) also weighed; Intel and Amazon on track to lose ~$300bn combined (IBTimes, intraday). So not all of Nasdaq's drop is Intel. [2x] https://www.heygotrade.com/en/news/amazon-amzn-stock-news-november-2-2026/ ; https://www.heygotrade.com/en/news/tesla-tsla-stock-news-november-2-2026/ ; IBTimes AU
14. **Context.** Intel shares had more than doubled YTD before the drop (Reuters). The US government held a ~10% stake (since Aug 2025) and faced a ~$12bn hit (Reuters). Mood: "sell first, ask questions later" (Matt Britzman, Hargreaves Lansdown, via Reuters). [1x] Reuters via WHBL

## Conflicts
- Intraday vs close: 27%/30% (intraday, IBTimes/Reuters) vs 28.58% (close). 
- "Biggest ever" (Reuters, pre-close) vs "worst since 1974" (AP via Gadget Scout/IBTimes).
- Factory accident: "early October" vs "mid-October"; in media but absent from Intel's release.
- Search-snippet headlines ("25% after-hours", "12%", "26%") were NOT verified; ignore.

## What NOT to claim
- Do NOT say Intel "lost money" or "had a bad quarter": Q3 beat on EPS and grew 21%. The drop is about the FORECAST.
- Do NOT call it "worst day ever" (1974 was -29.9% per IBTimes). Say "worst day in about 50 years."
- Do NOT say Intel's drop CAUSED other stocks' falls or the whole Nasdaq decline; Reuters says tech sentiment was already fragile (Alphabet, Meta, Amazon results). Say "chip stocks fell alongside."
- Do NOT state "bad planning" as fact (one analyst's view). Do NOT claim the Israel accident was in Intel's release.
- Do NOT predict recovery, price targets as targets for viewers, or buy/sell.

## Visual metaphor
Intel is a bakery that baked a mountain of cookies (PCs) for a bake sale, then the town's flour/sugar (memory chips) got scarce and expensive so almost no customers show up. Forecast = the sign on the door: "Next 3 months: way fewer customers." Stock = a giant cookie tower sliding down the shelf.
