# FACTS: Alphabet (GOOGL) drop, Thu Oct 29 2026

WINDOW WARNING: the move is Oct 29, one day BEFORE the requested Oct 30-Nov 3 window (reported after the Oct 28 close). It is still the biggest sourced large-cap mover I found besides Intel. Method: pages fetched with WebFetch. [2x]/[1x] = number of fetched sources. No advice or predictions.

## 3-sentence summary (12-year-old level)
Google's parent company Alphabet reported its numbers on Wednesday Oct 28, and its cloud business grew a huge 103%, but its profit per share came in at $2.12 when people expected about $3.02. It is also spending a giant $51.4 billion in one quarter on AI computer buildings and more spending is coming, while its cash flow turned negative. The next day (Thu Oct 29) the stock fell about 12.6%, which people read as investors getting nervous about paying so much for AI.

## Numbered facts

1. **Timing.** Results out after the close Wed Oct 28, 2026; the stock fell in the Thursday Oct 29 session. [2x] https://www.xtb.com/en/market-analysis/alphabet-disappoints-wall-street-despite-record-results-shares-plunge-over-8-and-test-300 ; https://www.trefis.com/stock/googl/articles/621527/what-sent-alphabet-stock-lower/2026-10-30
2. **After-hours (NOT a close).** XTB (Oct 28, 20:37): shares -8.25% in after-hours trading, "testing the $300" area. [1x] XTB
3. **The move on Oct 29.** Trefis: GOOGL "fell 12.6% on Thursday, October 29, 2026, compared with a 0.3% slip for the S&P 500"; close $283.82 cited (close basis inferred; Trefis does not explicitly say close-to-close). Gotrade's Microsoft page also says Alphabet fell 12.64% that session. [2x, close basis not explicit] Trefis ; https://www.heygotrade.com/en/news/microsoft-msft-stock-news-october-30-2026/
4. **EPS miss.** EPS $2.12 vs $3.02 expected (Trefis); XTB says "nearly $3.00." Net income $26.2bn, -25% YoY (XTB). [2x] Trefis ; XTB
5. **Revenue.** $127.6bn, +25% YoY, vs ~$128.0bn expected (slight miss). Operating income $40.6bn (+30%), margin 31.8% (XTB). Trefis calls a revenue-based explanation "thin" since the revenue gap was only ~$0.4bn. [2x] Trefis ; XTB
6. **Cloud was strong.** Google Cloud revenue +103% to $30.7bn; Cloud operating income $3.6bn to $11.1bn (XTB). Search ads +12% (management blamed mainly currency for weaker growth, per Trefis). [2x] Trefis ; XTB
7. **Spending.** Capex $51.4bn in the quarter (+114% YoY), mostly AI infrastructure. FY2026 capex guidance $195-205bn kept (implying ~$63-73bn in Q4 per XTB); management said 2027 spending will "increase significantly." [2x] Trefis ; XTB
8. **Cash.** Free cash flow -$9.1bn. XTB: ~$28.7bn raised from bonds and $12.4bn from equity issuance. [2x on FCF] Trefis ; XTB
9. **Investment loss.** Trefis: other income/expense was a loss of $8.2bn, mainly an unrealized loss on the SpaceX investment. XTB: $8.7bn loss on equity investments cutting EPS by $0.55, with specific investments NOT disclosed. [conflict: amount and attribution] Trefis ; XTB
10. **Attribution of the drop.** XTB (its own wording): "Wall Street is no longer willing to reward technology giants solely for impressive AI growth rates" citing the EPS miss, negative cash flow and capex risk. Trefis: news reports "tied the decline to doubts about returns on AI infrastructure spending," and the move was "largely" Alphabet's own (XLC fell 1.9%, Nasdaq -1.4%, Alphabet ~12% of XLC). No named analyst is quoted in either. [2x, both are interpretation] Trefis ; XTB
11. **Peers that day.** Amazon -4.2% / -4.25%, Meta +2.0%, Microsoft -0.16% (close $530.14). Microsoft's Azure beat and lower capex cushioned it (Gotrade). [2x] Trefis ; Gotrade MSFT page
12. **Price context.** $283.82 close is near the 52-wk closing low ($273.50, Mar 30); 52-wk high $402.62 (May 13); down 26.2% since Apr 30 (Trefis). [1x] Trefis

## Conflicts
- Size of drop: -8.25% after-hours (XTB) vs -12.6% session (Trefis/Gotrade). Different measures. Search snippets mentioned 7%-10% figures from other outlets; I did not fetch them, so not used.
- Investment loss: $8.2bn mainly SpaceX (Trefis) vs $8.7bn undisclosed (XTB).
- Whether 12.6% is close or intraday is not stated explicitly in Trefis.

## What NOT to claim
- Do NOT say Alphabet "missed" in general: revenue was a near-miss, cloud was +103%, operating income was up. The miss is EPS (partly an investment loss), plus cash flow and capex worry.
- Do NOT state the cause as proven. Both sources describe how reports "tied" it to AI-spending doubts.
- Do NOT say the SpaceX loss caused the drop (Trefis alone names SpaceX; XTB says undisclosed).
- Do NOT call 12.6% a close without the caveat. Do NOT use it as inside the Oct 30-Nov 3 window.
- No predictions, advice, price targets.

## Visual metaphor
A giant piggy bank with a hole: Google pours $51 billion a quarter into building AI "server warehouses" while the cash coming back is thinner than expected, so investors shake the piggy bank and it rattles.
