# FACTS: Where did $2 trillion of big tech go? (as of Wed Nov 4 2026)

Sources: Reuters via Korea Times (RT, Oct 30); Yahoo/Gadget Review (YG, Oct 31; cites CNBC, CNN); Ground News aggregation of Reuters/CNBC on Alphabet (GN); Yahoo midday Oct 30 piece (earlier fact pack FACTS_BIGCHIP #9).

1. "More than $2 trillion in market value set to be wiped from the Nasdaq 100 this month" (October). A PROJECTION/month-to-date figure, not a one-day loss. Nasdaq 100 down more than 5.8% so far in October. Slightly more than SpaceX's entire market value. [RT, Reuters, Oct 30; YG says "lost over the month", unnamed upstream] -> say "about $2 trillion in October", "more than $2 trillion at risk".
2. Alphabet, Thu Oct 29: fell about 12% (13% in some sources), roughly $500B of value, its worst day on record. Close vs intraday not stated. [GN; RT says "biggest one-day percentage drop on record"; YG 12%+ / ~$500B] -> "about 12%", "roughly $500 billion".
3. Why Alphabet (GN, citing CNBC): capex $51.4B in the quarter; free cash flow negative $9.1B and buybacks halted; Google Cloud revenue +103% (Pichai defended the spending); search and other revenue about +12% to ~$63B, below estimates (newstarget citing CNBC, single). 2026 capex guidance $195-205B, rising "significantly" in 2027.
4. Amazon: free cash flow negative $42.4B for the 12 months to Sep 30 2026, vs +$14.8B a year earlier; capex expected ~$220B in 2026; AWS +39% (CNBC via YG). Stock move not reliably stated (ticker -1.41%, snapshot): do not show a % for Amazon.
5. Amazon and Intel together threatened to erase roughly $200B (YG, Oct 30, close/intraday unclear). Skip or say "roughly".
6. Meta, Alphabet and Amazon raised spending forecasts (RT). Meta: negative free cash flow in the period (CNBC via YG); planned record $97.5B fund raise (RT).
7. Microsoft and SpaceX "broke from the gloom" on results showing AI spending was starting to pay off (RT). Microsoft stayed cash-flow positive (YG).
8. Scale of spending (JPMorgan, via RT): this year's capex by Amazon, Alphabet, Meta, Oracle and Microsoft would likely equal their cumulative spending since ChatGPT launched in Nov 2022. Morgan Stanley forecasts AI infrastructure capex above $1 trillion next year. JPMorgan: $900B global AI capex in 2026.
9. Quote (John Bilton, JPMorgan Asset Management, via RT): "It may be that we've overestimated how strong the growth might be, but they're not going negative in aggregate." Also "We have an insatiable and growing demand for data."
10. Investor worry (RT): whether AI investment will generate returns quickly enough; rising borrowing costs make debt-funded investment pricier.
11. Oct 30 close: Nasdaq Comp -2.86%, S&P 500 -1.82% (CNN via YG/ST). Intel -28.58% that day (earlier pack).

DO NOT CLAIM: $2T lost in one day; exact Alphabet close/value; Amazon %; Microsoft/Meta % moves; an "AI bubble" verdict; predictions; buy/sell; "wiped out forever". Alphabet's drop was Thursday Oct 29, NOT Oct 30. Cloud +103% single-sourced (GN, via Pichai): safe to attribute "Google says".
Safe on screen (<=2 numbers per beat): $2T (Oct, Nasdaq 100); Alphabet -12% / $500B; capex $51.4B / FCF -$9.1B; Amazon FCF -$42.4B; Cloud +103%.
