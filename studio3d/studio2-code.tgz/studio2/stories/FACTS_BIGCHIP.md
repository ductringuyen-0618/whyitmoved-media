# FACTS: Nvidia, Intel, AMD fall despite AI boom (Fri Oct 30 2026; updated through Mon Nov 2)

Method: every fact from a page fetched this session. [2x]=two independent sources agree, [1x]=single. CLOSE vs INTRADAY marked. Intel facts reused from FACTS_INTC.md (not redone). No advice or predictions.
Short names: GOT = heygotrade.com; FOOL = fool.com; IND = indmoney.com; BIGGO = finance.biggo.com; TKEY = tradingkey.com; TIN = tradingandinvestmentnews.co.uk; YAH = Yahoo (Investopedia); STT = stocktitan.net

## Numbered facts
1. **Intel CLOSE Oct 30:** $65.76, -28.58% (reused, [2x] per FACTS_INTC).
2. **AMD CLOSE Oct 30:** $504.80, -10.88% (-$61.62) from $566.42; volume 39.7M vs 30-day avg 20.9M. [2x: GOT, IND; FOOL body text agrees] https://www.heygotrade.com/en/news/amd-amd-stock-news-november-2-2026/ ; https://www.indmoney.com/blog/us-stocks/why-nvidia-intel-amd-broadcom-micron-stocks-falling ; https://www.fool.com/coverage/stock-market-today/2026/10/30/stock-market-today-oct-30-intel-plunges-nearly-29-as-weak-outlook-rattles-wall-street/
3. **Nvidia CLOSE Oct 30:** $204.64, -4.22% (-$9.02) from $213.66. [2x: GOT, IND; FOOL body] https://www.heygotrade.com/en/news/nvidia-nvda-stock-news-november-2-2026/ ; IND
4. **Chip index and market that day:** CNN (via STT): chipmaker index "sank 7.2%" (index not named, close vs intraday not stated). YAH/Investopedia: SOXX ETF down >8% (ETF, intraday-written). Nasdaq Comp CLOSE -2.86%, S&P 500 -1.82%, Dow ~-1.1% (STT/CNN; Nasdaq also in FOOL). [Nasdaq 2x; chip index 1x] https://www.stocktitan.net/articles/stock-market-today-live-october-30-2026 ; https://finance.yahoo.com/markets/stocks/articles/stock-market-today-nasdaq-p-123540419.html
5. **Intraday snapshots (NOT closes):** Nvidia -4.53% at 1pm ET, AMD -8.11% premarket (STT). Reuters/IBTimes intraday ranges are in FACTS_INTC #12 (Reuters: AMD, Nvidia et al. fell 4%-12%). [1x]
6. **Month context:** IND: Philadelphia Semiconductor Index lost >15% over October. [1x] (No per-stock week/month return found for NVDA/AMD on Oct 30.)
7. **Stated trigger (named sources):** CNBC: Intel guided Q4 adj. EPS 25c on $15-16bn revenue vs 43c / $17.1bn expected. Intel CFO David Zinsner: "we see the PC slowdown continuing at least through the first half of next year." CNBC tied the global tech selloff to the Amazon and Intel results. [2x CNBC via STT/GOT; Zinsner via GOT AMD page + TIN]
8. **"AI spending" worry (named):** GOT (citing CNBC): investors are questioning whether big tech's AI spending will pay off. CNN (via STT): selling tied to "worries about the AI boom." CNBC's Matt Orton (Raymond James): positioning across the space remains crowded. Reuters' Matt Britzman (Hargreaves Lansdown): "sell-first, ask-questions-later mood." [CNBC point 1x via GOT; CNN 1x]
9. **Amazon/Alphabet context:** YAH: Amazon missed expectations, free cash flow fell amid heavy AI spending (stock -~1.4%); a disappointing Alphabet report Thursday weighed on tech. No Meta mention. TKEY (Nov 3): cites high full-year capex at Alphabet and Amazon pressuring free cash flow. [2x for Amazon/Alphabet FCF/capex theme] YAH link above ; https://www.tradingkey.com/analysis/stocks/us-stocks/262265872-stock-amd-price-prediction-ai-sox-tradingkey
10. **Sources with NO company-specific reason for NVDA/AMD:** GOT says none of the coverage it reviewed pointed to Nvidia-specific news; STT and YAH give no Nvidia/AMD-specific reason. [3x absence]
11. **Nvidia AI numbers (latest quarter, Q2 FY2027):** revenue $96.2bn, +106% YoY; Data Center $89.0bn, +117%. Next earnings Tue Nov 17 2026 (call 2pm PT). [1x, GOT] NVDA page above
12. **AMD AI numbers (Q2 2026):** Data Center revenue $6.7bn, +107% YoY; Client $3.1bn, +23%; Q3 guidance ~$13bn +/- $300m, gross margin ~56%. Total Q2 revenue figure NOT stated reliably on the page (page text says $11.5bn is the comparison base; do not use). Next earnings Tue Nov 3 2026 after close, call 5pm ET. [1x, GOT; Nov 3 date also in BIGGO and TIN = 2x]
13. **Intel AI side (reused):** Data Center & AI +78% to $7.3bn; FOOL notes this "points to strength in data center demand." [2x: Intel release per FACTS_INTC, FOOL]
14. **Why AI strength did not protect (sourced only):**
   - IND (author's own analysis, no named source): Nvidia fell "despite strong AI growth" because expectations were already high and ~93% of revenue is data centres. AMD: exposure to both PC chips and AI accelerators, plus uncertainty before Nov 3 results. [1x, analysis]
   - FOOL (author RJ Fulton, no named sources): investors questioning whether AI demand can justify high valuations and heavy capital spending. [1x, analysis]
   - TIN (citing others): memory makers shifting capacity to high-bandwidth memory for AI chips, raising ordinary PC memory costs; Intel expects PC market -12% in 2026, -10% in 2027. This explains INTEL's PC weakness, not Nvidia/AMD's drop. [2x with FACTS_INTC #7-8]
15. **Mon Nov 2 moves (CLOSE):** AMD -7.52% to $466.84 (TKEY; TIN cites 24/7 Wall St for -7.5%) [2x]. Intel -8.8% (BIGGO, TIN) [2x]. Nvidia ~-1% (BIGGO; FOOL's stray parenthetical -1.26% matches) [2x, approximate]. Philadelphia Semi Index -3.37% to 10,328.33, lowest since Apr 29 (BIGGO); TIN: 29.4% below its Jun 22 record [2x]. Nasdaq Comp -1.07% to 25,164.32 (BIGGO, FOOL parenthetical). https://finance.biggo.com/news/0fdc7b63-56dd-4eda-afd1-d8e45967a7bb ; https://www.tradingandinvestmentnews.co.uk/ai-chip-stocks-borrowing/
16. **Reasons given for Nov 2 (attributed):** BIGGO: Marvell -12.72% on ~$115bn Lumentum deal and Lumentum -18% were the biggest drags; "AI monetization doubts"; Longbow's Jake Dollarhide: "At some point, spending stops adding value and just adds cost." TKEY (Block Tao): pre-earnings hedging before AMD, capex/ROI worries, risk reduction ahead of Nov 3 midterms. [BIGGO and TKEY each 1x]
17. **Multi-day (TKEY, as of Nov 2 close):** Nvidia fell >8% over five days; SOX fell >10% over the same five days. TIN (citing Protos): Nvidia ~17% below its 2026 peak. [2x-ish, different windows]
18. **Nov 3 (today):** No NVDA/AMD/INTC Nov 3 price data found. AMD reports after the close tonight. Nvidia reports Nov 17.

## Conflicts / data traps
- FOOL's body closes (INTC -28.58, AMD -10.88, NVDA -4.22) match other sources. Its PARENTHETICALS (-8.80, -7.52, -1.26, indexes -0.51/-1.07) are the NOV 2 moves, mis-placed. Do not use them as Oct 30. FOOL also says S&P -2.07% in text; STT/CNN say -1.82%: use -1.82% (S&P 2x unclear; avoid on screen).
- "Chip index -7.2%" (CNN) vs SOXX >8% (YAH) vs SOX Oct 30 close not found. Avoid an exact index number for Oct 30.
- Intel volume: FOOL text 447.8M vs GOT 455.6M. Skip volume.
- Intel accident ($300m) appears in IND (citing 10-Q), but FACTS_INTC found it absent from the release: do not feature.
- Reuters "4%-12%" intraday sympathy range vs closes of -4.22% (NVDA), -10.88% (AMD).

## 3-sentence summary (12-year-old level)
Friday, Intel warned that people are buying fewer computers because a shortage made memory chips pricey, and its stock dropped almost 29%. Nvidia and AMD, which sell chips for AI, got dragged down too, AMD about 11% and Nvidia about 4%, even though sources said Nvidia and AMD had no bad news of their own. Reports said investors were also nervous about whether huge AI spending will pay off, and on Monday chip stocks fell again before AMD's report on Tuesday night.

## What NOT to claim
- No "Nvidia/AMD fell BECAUSE of Intel": say "fell the same day"/"alongside"; sources say tie to Intel is media framing, and Amazon/Alphabet results also weighed.
- No memory-shortage cause for Nvidia/AMD (sources apply it to Intel/PCs only).
- No "AI bubble", "AI boom is over", valuation verdicts; IND/FOOL/TKEY are analysis, attribute if used ("one analysis said").
- No Oct 30 SOX number; no week/month % for NVDA or AMD on Oct 30 (not sourced); don't use FOOL parentheticals.
- No Nov 3 moves; no AMD earnings results/expectations (not fetched); no predictions, price targets, buy/sell.
- Don't say Intel "lost money"; its AI data-center segment grew 78%.
- Don't use Nvidia Q2 FY2027 numbers as "this week's"; they are the latest reported quarter ($96.2bn, single source, verify before final render).
- Don't mention Israel accident, midterm effect, or Marvell as causes of Oct 30.

## Safe numbers on screen (<=2 per beat)
- Beat 1 (hook, Oct 30 closes): Intel -28.58%; AMD -10.88%
- Beat 2 (Nvidia): Nvidia -4.22% (close $204.64)
- Beat 3 (the "reason"): Intel Q4 revenue guide $15-16bn vs ~$17.1bn expected [2x]
- Beat 4 (AI boom side): Nvidia Data Center $89.0bn, +117% [1x]; AMD Data Center +107% to $6.7bn [1x]; (Intel +78% to $7.3bn alt.)
- Beat 5 (what sources said): "worries about the AI boom" (CNN) / "will AI spending pay off" (CNBC), text only, no number
- Beat 6 (Mon Nov 2): AMD -7.52% ; Intel -8.8%; tag "AMD reports Tue Nov 3 after close"
