# BIGCHIP v1 - "Why Nvidia, Intel & AMD fell despite the AI boom" (48.5 s, am_michael 0.88)
Facts: stories/FACTS_BIGCHIP.md. Numbers on screen <=2/beat: INTEL -28.6% & AMD -10.9% (b1), NVDA -4.2%, INTEL AI +78%, AI SALES 2x+ (NVDA/AMD, single-source: verify), AMD -7.5% (Mon close).
1 Intel crashed almost twenty-nine percent in one day.
2 AMD fell eleven. Nvidia fell four.
3 Wait. Isn't AI booming?
4 Friday, Intel warned that people are buying fewer computers.
5 A memory chip shortage made computers cost more.
6 Intel's own AI business grew seventy-eight percent.
7 But its forecast was weak, and that is what scared investors.
8 Nvidia and AMD sell AI chips, and their AI sales more than doubled.
9 Reports found no bad news from either company that day.
10 Yet they fell too.
11 CNBC said investors are asking if big tech's AI spending will pay off.
12 So the boom did not stop.
13 The worry is whether it pays off.
14 Monday, AMD dropped another seven percent.
15 Follow for the next stock move.
