import numpy as np
from scipy.signal import lfilter
OSR=48000
def np_noise(n,rng): return rng.standard_normal(n)
def lp(x,cut): 
    cut=float(np.mean(cut)); a=1-np.exp(-2*np.pi*cut/OSR); return lfilter([a],[1,-(1-a)],x)
def tone(f0,f1,d,sq=0.0,vib=0):
    n=int(d*OSR); tt=np.arange(n)/OSR; f=np.linspace(f0,f1,n)*(1+vib*np.sin(2*np.pi*7*tt))
    ph=2*np.pi*np.cumsum(f)/OSR; w=np.sin(ph)
    if sq: w=w*(1-sq)+np.sign(w)*sq
    return w
def env(n,a=0.005,r=8.0):
    tt=np.arange(n)/OSR; return np.minimum(1,tt/a)*np.exp(-tt*r)
def sfx(kind,rng):
    R=lambda d:int(d*OSR)
    if kind=="screech": n=R(.6); x=lp(rng.standard_normal(n),3500)*0.5+tone(1400,900,.6,.5)*0.4; return x*np.minimum(1,np.arange(n)/OSR/.03)*np.minimum(1,(.6-np.arange(n)/OSR)/.2)
    if kind=="crash": n=R(.7); tt=np.arange(n)/OSR; return (lp(rng.standard_normal(n),5000)*np.exp(-tt*7)+tone(90,40,.7)*np.exp(-tt*8))*1.0
    if kind=="slap": n=R(.15); tt=np.arange(n)/OSR; return np.diff(rng.standard_normal(n+1))*np.exp(-tt*50)+tone(300,120,.15)*np.exp(-tt*30)
    if kind=="boing": n=R(.45); tt=np.arange(n)/OSR; return tone(200,500,.45,0.3,0.06)*np.exp(-tt*6)
    if kind=="pop": return tone(900,250,.09)*env(R(.09),.002,40)
    if kind=="plink": return tone(1500,1500,.3)*env(R(.3),.002,12)
    if kind=="pew": return tone(2400,300,.25,.4)*env(R(.25),.002,8)
    if kind=="sizzle": n=R(.5); return lp(rng.standard_normal(n),7000)*env(n,.01,5)*0.5
    if kind=="whoosh": n=R(.35); tt=np.linspace(0,1,n); return lp(rng.standard_normal(n),400+4000*np.sin(np.pi*tt)**2)*np.sin(np.pi*tt)**1.5
    if kind=="ding": n=R(.9); tt=np.arange(n)/OSR; return (np.sin(2*np.pi*1320*tt)+.5*np.sin(2*np.pi*2640*tt))*np.exp(-tt*5)*.6
    if kind=="dopp": n=R(1.0); tt=np.arange(n)/OSR; f=1500-700*tt; return np.sin(2*np.pi*np.cumsum(f)/OSR)*np.exp(-tt*3)*.5*(1+.3*np.sin(2*np.pi*14*tt))
    if kind=="thud": n=R(.4); tt=np.arange(n)/OSR; return tone(110,40,.4)*np.exp(-tt*10)+lp(rng.standard_normal(n),600)*np.exp(-tt*20)*.4
    if kind=="boom": n=R(.9); tt=np.arange(n)/OSR; return tone(70,30,.9)*np.exp(-tt*4)+lp(rng.standard_normal(n),500)*np.exp(-tt*6)*.6
    if kind=="glass": n=R(.35); tt=np.arange(n)/OSR; return np.diff(rng.standard_normal(n+1))*np.exp(-tt*18)*.6+np.sin(2*np.pi*3800*tt)*np.exp(-tt*25)*.3
    if kind=="beep": return tone(1800,1800,.12,.6)*env(R(.12),.002,3)
    if kind=="brrr": n=R(1.3); tt=np.arange(n)/OSR; return np.sign(np.sin(2*np.pi*70*tt))*(np.sin(2*np.pi*14*tt)>-.2)*.3+np.diff(rng.standard_normal(n+1))*.1
    if kind=="gasp": n=R(.5); tt=np.arange(n)/OSR; return lp(rng.standard_normal(n),2500-1500*tt)*np.sin(np.pi*tt/.5)*.8
    if kind=="squawk": n=R(.4); tt=np.arange(n)/OSR; return tone(700,400,.4,.7,.03)*np.sin(np.pi*tt/.4)**.5*.5
    if kind=="ow": return tone(300,380,.28,.3,.02)*env(R(.28),.01,5)
    if kind=="tink": return tone(2200,2200,.15)*env(R(.15),.001,25)*.6
    if kind=="wah": n=R(1.0); f=np.concatenate([np.linspace(260,230,R(.5)),np.linspace(220,150,n-R(.5))]); tt=np.arange(n)/OSR; return np.sin(2*np.pi*np.cumsum(f)/OSR)*np.minimum(1,(1-tt)/.2)*.5
    if kind=="squeak": n=R(.5); tt=np.arange(n)/OSR; return tone(500,1700,.5,.3,.03)*np.sin(np.pi*tt/.5)*.5
    if kind=="stamp": n=R(.35); tt=np.arange(n)/OSR; return tone(100,40,.35)*np.exp(-tt*12)+np.diff(rng.standard_normal(n+1))*np.exp(-tt*80)*.5
    if kind=="tick": n=R(.05); return np.diff(rng.standard_normal(n+1))*np.exp(-np.arange(n)/OSR*150)
    if kind=="tock": n=R(.06); return tone(500,300,.06)*env(n,.001,60)
    if kind=="snore": n=R(.8); tt=np.arange(n)/OSR; return lp(rng.standard_normal(n),300)*np.sin(np.pi*tt/.8)**2*.8
    if kind=="creak": n=R(.6); tt=np.arange(n)/OSR; return tone(180,260,.6,.6,.08)*np.sin(np.pi*tt/.6)*.4
    if kind=="rev": n=R(1.4); tt=np.arange(n)/OSR; return tone(70,180,1.4,.8,.03)*.5*np.minimum(1,tt/.1)+lp(rng.standard_normal(n),1500)*.2
    if kind=="squelch": n=R(.5); tt=np.arange(n)/OSR; return tone(120,60,.5,.3,.2)*np.sin(np.pi*tt/.5)*.5
    if kind=="fwip": n=R(.3); tt=np.linspace(0,1,n); return lp(rng.standard_normal(n),3000)*np.sin(np.pi*tt)*.7
    if kind=="paper": n=R(.5); tt=np.linspace(0,1,n); return lp(rng.standard_normal(n),6000)*np.sin(np.pi*tt)**2*(0.5+.5*np.sin(40*tt))*.5
    if kind=="coo": n=R(.6); tt=np.arange(n)/OSR; return tone(300,250,.6,0,.02)*np.sin(np.pi*tt/.6)*.5
    if kind=="bonk": n=R(.3); tt=np.arange(n)/OSR; return tone(420,200,.3)*np.exp(-tt*14)
    raise KeyError(kind)
GAIN={"screech":.5,"crash":.7,"thud":.7,"boom":.9,"stamp":.8,"bonk":.7,"glass":.5,"whoosh":.4}
def music(total,rng):
    n=int(total*OSR); out=np.zeros(n); beat=60/116
    hz=lambda m:440*2**((m-69)/12)
    roots=[45,41,48,43]
    for b in range(int(total/beat)+1):
        t0=b*beat; r=roots[(b//4)%4]
        for off,f in ((0,r-12),(.5,r-5)):
            s=int((t0+off*beat)*OSR); d=int(.18*OSR)
            if s+d<n:
                tt=np.arange(d)/OSR; out[s:s+d]+=np.sin(2*np.pi*hz(f)*tt)*np.exp(-tt*9)*.6
        s=int(t0*OSR); d=int(.12*OSR)
        if s+d<n:
            tt=np.arange(d)/OSR; out[s:s+d]+=np.sign(np.sin(2*np.pi*hz(r+12+[0,4,7,12][b%4])*tt))*np.exp(-tt*18)*.2
    return out/np.abs(out).max()
