import sys,json,os; sys.dont_write_bytecode=True
sys.path.insert(0,'/home/claude/studio2/bigchip/audio')
import numpy as np, soundfile as sf
from sfx3 import sfx, OSR, lp
from render5_music import music
W=json.load(open('/home/claude/studio2/bigchip/vo_exact.json'))
def T(line,word,occ=0):
    return [w for w in W if w['line']==line and w['word'].strip('.,?!').lower()==word.lower()][occ]['start']
DUR=49.4; n=int(DUR*OSR); rng=np.random.default_rng(11)
EV=[(T(1,'crashed')+.75,"thud","hit"),(T(2,'fell',0)+.8,"bonk","soft"),(T(2,'fell',1)+.5,"bonk","soft"),(T(3,'booming'),"ding","soft"),
 (T(4,'buying')+.1,"pop","tick"),(T(4,'computers')-.15,"pop","tick"),(T(5,'cost'),"plink","soft"),(T(6,'seventy-eight')+.7,"ding","soft"),
 (T(7,'weak')+.1,"thud","soft"),(T(8,'doubled')+.3,"ding","soft"),(T(10,'fell')+.7,"thud","hit"),(T(12,'dropped')+.85,"thud","hit")]
print([(round(a,2),b) for a,b,c in EV])
os.makedirs('stems',exist_ok=True)
v,sr=sf.read('/home/claude/studio2/bigchip/vo.wav'); assert sr==24000
v48=np.interp(np.linspace(0,len(v),int(len(v)*OSR/24000),endpoint=False),np.arange(len(v)),v)
vo=np.zeros(n); k=min(n,len(v48)); vo[:k]=v48[:k]; vo=vo/np.abs(vo).max()*.9
sf.write('stems/stem_voice.wav',vo,OSR,subtype='FLOAT')
evs=[];wavs=[];plan=[]
for i,(t,kind,cls) in enumerate(EV):
    w=sfx(kind,rng)*.5; evs.append(dict(t=t,kind=kind,dur=len(w)/OSR)); wavs.append(w); plan.append(dict(i=i,t=t,kind=kind,**{"class":cls}))
np.savez('stems/sfx_event_waves.npz',*wavs); json.dump(evs,open('stems/sfx_events.json','w'),indent=1); json.dump(plan,open('stems/sfx_plan.json','w'),indent=1)
bed=music(DUR,rng); envv=np.convolve(np.abs(vo),np.ones(int(.25*OSR))/int(.25*OSR),mode="same")
sf.write('stems/stem_music.wav',bed*.07*(1-.55*np.clip(envv/.08,0,1)),OSR,subtype='FLOAT')
tt=np.arange(n)/OSR
pad=(np.sin(2*np.pi*110*tt)+.6*np.sin(2*np.pi*164.8*tt)+.4*np.sin(2*np.pi*220*tt))*(0.8+0.2*np.sin(2*np.pi*.25*tt))
sf.write('stems/stem_pad.wav',pad*.012,OSR,subtype='FLOAT'); sf.write('stems/stem_room.wav',lp(rng.standard_normal(n),900)*.02,OSR,subtype='FLOAT')
