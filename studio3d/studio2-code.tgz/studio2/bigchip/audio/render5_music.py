import numpy as np
from sfx3 import OSR
def music(total,rng):
    n=int(total*OSR); out=np.zeros(n); beat=60/116; hz=lambda m:440*2**((m-69)/12); roots=[45,41,48,43]
    for b in range(int(total/beat)+1):
        t0=b*beat; r=roots[(b//4)%4]
        for off,f in ((0,r-12),(.5,r-5)):
            s=int((t0+off*beat)*OSR); d=int(.18*OSR)
            if s+d<n:
                tt=np.arange(d)/OSR; out[s:s+d]+=np.sin(2*np.pi*hz(f)*tt)*np.exp(-tt*9)*.6
        s=int(t0*OSR); d=int(.12*OSR)
        if s+d<n:
            tt=np.arange(d)/OSR; out[s:s+d]+=np.sign(np.sin(2*np.pi*hz(r+12+[0,4,7,12][b%4])*tt))*np.exp(-tt*18)*.2
    return out/np.abs(out).max()
