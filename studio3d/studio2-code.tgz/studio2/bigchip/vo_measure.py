# Measures wall-to-wall VO with Kokoro am_michael, same per-line method as pilot/build/render.py voice()
import sys, os, json, wave, hashlib
sys.dont_write_bytecode=True
sys.path.insert(0,'/home/claude/studio2/pilot/build')
import numpy as np
from pathlib import Path
import stockshort_B3 as S
SP=float(os.environ.get("VSP","0.88")); EXTRA=float(os.environ.get("EXTRA","0.08"))
LINES=json.load(open('/home/claude/studio2/bigchip/lines.json'))
cache=Path('/home/claude/studio2/bigchip/.vcache'); cache.mkdir(exist_ok=True)
words=[]; rows=[]; pieces=[]; t=0.0; prev_sp_end=None
for n,text in LINES:
    k=cache/(hashlib.md5(f"{text}|am_michael|{SP}".encode()).hexdigest()+".wav")
    if not k.exists(): S.synth(text,k,'am_michael',SP)
    a,sr=S._read_wav(k)
    if sr!=24000: a=np.interp(np.linspace(0,len(a),int(len(a)*24000/sr),endpoint=False),np.arange(len(a)),a)
    s0,s1=S.speech_bounds(a,24000); a=a[max(0,int((s0-.03)*24000)):int((s1+.06)*24000)].astype('float32')
    dur=len(a)/24000; speak=s1-s0
    start=t
    toks=text.split(); wts=[S._syllables(x) for x in toks]; tot=sum(wts); acc=0.0
    for tok,w in zip(toks,wts):
        ws=start+0.03+speak*acc/tot; acc+=w
        words.append({"line":n,"word":tok,"start":round(ws,3),"end":round(start+0.03+speak*acc/tot,3)})
    sp_start=start+0.03; sp_end=start+0.03+speak
    gap=None if prev_sp_end is None else round(sp_start-prev_sp_end,3)
    rows.append({"n":n,"text":text,"start":round(sp_start,2),"end":round(sp_end,2),"gap_before":gap,"words":len(toks)})
    prev_sp_end=sp_end
    pieces.append(a); t+=dur+EXTRA; pieces.append(np.zeros(int(EXTRA*24000),'float32'))
audio=np.concatenate(pieces)
total=rows[-1]["end"]
with wave.open('/home/claude/studio2/bigchip/vo.wav','wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000)
    w.writeframes((np.clip(audio,-1,1)*32767).astype('<i2').tobytes())
json.dump({"voice":"am_michael","speed":SP,"total_s":total,"max_gap_s":max(r["gap_before"] or 0 for r in rows),"lines":rows,"words":words},open('/home/claude/studio2/bigchip/vo_timing.json','w'),indent=1)
print(f"speed {SP} total {total:.2f}s words {sum(r['words'] for r in rows)} wav {len(audio)/24000:.2f}s")
for r in rows: print(r["n"],r["start"],r["end"],r["gap_before"],r["text"])
print("max gap",max(r["gap_before"] or 0 for r in rows))
