import sys, subprocess, tempfile
sys.path.insert(0,'/home/claude/studio2/intel/build'); sys.dont_write_bytecode=True
from pathlib import Path
from multiprocessing import Pool
import anim_intel as A
N=A.NFR
def chunk(a): return [A.frame(i/30).convert("RGBA").tobytes() for i in range(*a)]
if __name__=="__main__":
    out=sys.argv[1]; raw="/home/claude/studio2/intel/build/silent.mp4"
    enc=subprocess.Popen(["ffmpeg","-y","-v","error","-f","rawvideo","-pix_fmt","rgba","-s","1080x1920","-r","30","-i","-","-c:v","libx264","-preset","veryfast","-crf","18","-pix_fmt","yuv420p",raw],stdin=subprocess.PIPE)
    chunks=[(i,min(N,i+12)) for i in range(0,N,12)]
    with Pool(2) as p:
        for k,res in enumerate(p.imap(chunk,chunks)):
            for b in res: enc.stdin.write(b)
    enc.stdin.close(); enc.wait()
    subprocess.run(["python3","/home/claude/studio2/pilot2/audio/mix.py","--voice","/home/claude/studio2/intel/build/vo.wav","--events","stems/sfx_events.json","--sfx-npz","stems/sfx_event_waves.npz","--plan","stems/sfx_plan.json",
      "--bed","stems/stem_music.wav:-26","--bed","stems/stem_pad.wav:-34","--bed","stems/stem_room.wav:-44","--out","stems/mix.wav","--video",raw,"--out-video",out,"--report","stems/mix_report.json","--duration",str(A.DUR)],cwd="/home/claude/studio2/intel/build",check=True)
    print("saved",out)
