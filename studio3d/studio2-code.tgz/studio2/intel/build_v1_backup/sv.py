# ---------------------------------------------------------------- "Patch and the Rack" (server theme)
INKB = (5, 16, 24)
NAVY = (11, 37, 48)
NAVY2 = (17, 55, 70)
NAVY3 = (26, 78, 96)
CRM = (255, 244, 220)
TLP = (24, 197, 176)
TLD = (10, 104, 100)
TLL = (110, 236, 218)
GLD = (255, 200, 61)
GLDD = (214, 150, 30)
RED = (232, 69, 44)
GRY = (150, 158, 170)
GRYD = (98, 106, 120)
GRYL = (200, 207, 216)
RKC = (70, 60, 150)
RKL = (106, 96, 188)
RKD = (38, 32, 92)
BOTC = (112, 138, 176)
BOTL = (146, 172, 208)
BOT2 = (156, 134, 190)
WINC = (8, 48, 56)
PINC = (214, 220, 230)
DIMC = (150, 170, 178)


class SP(Pen):
    """Pen with the dark-ink outline used in the server set."""
    def rr(s, box, r, fill=None, w=8, out=INKB):
        Pen.rr(s, box, r, fill, w, out)

    def el(s, box, fill=None, w=8, out=INKB):
        Pen.el(s, box, fill, w, out)

    def ln(s, pts, w=8, fill=INKB):
        Pen.ln(s, pts, w, fill)

    def poly(s, pts, fill, w=7, out=INKB):
        Pen.poly(s, pts, fill, w, out)

    def arc(s, box, a0, a1, w=8, fill=INKB):
        Pen.arc(s, box, a0, a1, w, fill)

    def pie(s, box, a0, a1, fill, w=7, out=INKB):
        Pen.pie(s, box, a0, a1, fill, w, out)


_SC = {}


def _svc(key, w, h, fn):
    if key not in _SC:
        if len(_SC) > 260:
            _SC.clear()
        _SC[key] = _ss(w, h, fn)
    return _SC[key]


def stext(img, xy, s, size, fill=CRM, sw=8, rot=0.0, sc=1.0, alpha=1.0, ink=INKB):
    if sc <= 0.02:
        return
    ptext(img, xy, s, size, fill, sw=sw, rot=rot, sc=sc, ink=ink, alpha=alpha)


def spill(img, cx, cy, s, size, fill, tc=CRM, padx=34, h=None, rot=0.0, sc=1.0, w_min=0, alpha=1.0, ow=7):
    if sc <= 0.02:
        return
    f = font("bold", size)
    probe = ImageDraw.Draw(Image.new("L", (4, 4)))
    tw = int(probe.textlength(s, font=f))
    w = max(w_min, tw + 2 * padx)
    hh = h or int(size * 1.7)
    T = _ss(w + 24, hh + 24, lambda d, k: SP(d, k).rr((10, 10, w + 10, hh + 10), hh // 2.4, fill, ow))
    ImageDraw.Draw(T).text(((w + 24) // 2, (hh + 24) // 2 + 1), s, font=f, fill=tuple(tc) + (255,), anchor="mm")
    if alpha < 1:
        T.putalpha(T.getchannel("A").point(lambda a: int(a * alpha)))
    blit(img, T, cx, cy, (w + 24) / 2, (hh + 24) / 2, sc, sc, rot)


def sburst(img, cx, cy, r1, r2, n, rot, fill, sw=8, alpha=1.0):
    T = int(r2 * 2 + 30)

    def fn(d, k):
        pts = []
        for i in range(n * 2):
            r = r2 if i % 2 == 0 else r1
            a = rot + _m.pi * i / n
            pts.append(((T / 2 + r * _m.cos(a)) * k, (T / 2 + r * _m.sin(a)) * k))
        d.polygon(pts, fill=fill, outline=INKB, width=int(sw * k))
    tile = _ss(T, T, fn)
    if alpha < 1:
        tile.putalpha(tile.getchannel('A').point(lambda a: int(a * alpha)))
    put(img, tile, cx - T / 2, cy - T / 2)


def tint(img, col, a):
    if a > 0.01:
        img.alpha_composite(Image.new("RGBA", img.size, tuple(col) + (int(255 * clamp01(a)),)))


def speed_lines(img, cx, cy, t, n=22, r0=380, r1=1000, col=(255, 255, 255), a=200, seed=1, width=9):
    rnd = _rnd.Random(seed)
    d = ImageDraw.Draw(img)
    for i in range(n):
        ang = rnd.uniform(0, 2 * _m.pi)
        ra = r0 + rnd.uniform(0, 160) + (t * 900) % 120
        rb = r1
        wdt = rnd.uniform(0.012, 0.03)
        pts = [(cx + _m.cos(ang - wdt) * rb, cy + _m.sin(ang - wdt) * rb), (cx + _m.cos(ang + wdt) * rb, cy + _m.sin(ang + wdt) * rb),
               (cx + _m.cos(ang) * ra, cy + _m.sin(ang) * ra)]
        d.polygon(pts, fill=col + (a,))


def blink_at(t, seed=0.0, per=3.1):
    ph = (t + seed * 0.77) % per
    return ph < 0.13


def swob(t, f=1.0, a=1.0):
    return _m.sin(t * f * 6.283) * a


# ---------------------------------------------------------------- icons
def draw_icon(p, kind, cx, cy, s=1.0, col=CRM, bg=WINC):
    if kind == "wrench":
        p.ln([(cx - 28 * s, cy + 24 * s), (cx + 14 * s, cy - 18 * s)], 13 * s, col)
        p.el((cx + 5 * s, cy - 44 * s, cx + 41 * s, cy - 8 * s), col, 0)
        p.poly([(cx + 20 * s, cy - 28 * s), (cx + 50 * s, cy - 30 * s), (cx + 32 * s, cy - 54 * s)], bg, 0)
    elif kind == "magnifier":
        p.el((cx - 30 * s, cy - 32 * s, cx + 12 * s, cy + 10 * s), None, 8 * s, col)
        p.ln([(cx + 8 * s, cy + 6 * s), (cx + 32 * s, cy + 30 * s)], 12 * s, col)
    elif kind == "shield":
        p.poly([(cx, cy - 34 * s), (cx + 28 * s, cy - 22 * s), (cx + 26 * s, cy + 6 * s), (cx, cy + 34 * s),
                (cx - 26 * s, cy + 6 * s), (cx - 28 * s, cy - 22 * s)], GLD, 0)
        p.ln([(cx - 12 * s, cy - 2 * s), (cx - 2 * s, cy + 10 * s), (cx + 14 * s, cy - 12 * s)], 8 * s, bg)
    elif kind in ("gear", "gear_dim"):
        c = col if kind == "gear" else (122, 130, 146)
        pts = []
        for k_ in range(8):
            a = _m.radians(k_ * 45)
            for da, rr_ in ((-13, 25), (-8, 36), (8, 36), (13, 25)):
                pts.append((cx + _m.cos(a + _m.radians(da)) * rr_ * s, cy + _m.sin(a + _m.radians(da)) * rr_ * s))
        p.poly(pts, c, 0)
        p.el((cx - 11 * s, cy - 11 * s, cx + 11 * s, cy + 11 * s), bg, 0)
    elif kind == "arrow":
        p.poly([(cx, cy - 36 * s), (cx + 34 * s, cy), (cx + 12 * s, cy), (cx + 12 * s, cy + 34 * s),
                (cx - 12 * s, cy + 34 * s), (cx - 12 * s, cy), (cx - 34 * s, cy)], col, 0)
    else:  # traces
        c = (30, 120, 120)
        p.ln([(cx - 46 * s, cy + 12 * s), (cx - 14 * s, cy + 12 * s), (cx - 4 * s, cy - 10 * s), (cx + 30 * s, cy - 10 * s)], 6 * s, c)
        p.ln([(cx - 30 * s, cy - 16 * s), (cx - 6 * s, cy - 16 * s)], 6 * s, c)
        p.el((cx + 30 * s, cy - 18 * s, cx + 46 * s, cy - 2 * s), c, 0)
        p.el((cx + 18 * s, cy + 6 * s, cx + 32 * s, cy + 20 * s), c, 0)


# ---------------------------------------------------------------- PATCH (hero chip)
def _arm(p, side, a, col, hand):
    sx = 94 if side < 0 else 306
    sy = 194
    ar = _m.radians(a)
    L = 64
    hx, hy = sx + side * _m.sin(ar) * L, sy + _m.cos(ar) * L
    p.ln([(sx, sy), (hx, hy)], 28, INKB)
    p.ln([(sx, sy), (hx, hy)], 17, col)
    p.el((hx - 17, hy - 17, hx + 17, hy + 17), hand, 7)


def patch_tile(icon="none", eyes="open", mouth="smile", al=0, ar=0, cheeks=0, sweat=0):
    al, ar = int(round(al / 15.0)) * 15, int(round(ar / 15.0)) * 15
    key = ("patch", icon, eyes, mouth, al, ar, cheeks, sweat)

    def fn(d, k):
        p = SP(d, k)
        for i in range(4):
            cx = 90 + 220 * (i + 0.5) / 4
            p.rr((cx - 9, 40, cx + 9, 78), 5, PINC, 6)
            p.rr((cx - 9, 282, cx + 9, 324), 5, PINC, 6)
        for i in range(4):
            cy = 70 + 220 * (i + 0.5) / 4
            p.rr((56, cy - 9, 98, cy + 9), 5, PINC, 6)
            p.rr((302, cy - 9, 344, cy + 9), 5, PINC, 6)
        _arm(p, -1, al, TLP, TLL)
        _arm(p, 1, ar, TLP, TLL)
        p.rr((90, 70, 310, 290), 40, TLP, 10)
        p.rr((106, 82, 250, 96), 7, TLL, 0)
        p.ln([(106, 270), (150, 270), (160, 280)], 5, TLD)
        p.ln([(294, 270), (258, 270), (250, 280)], 5, TLD)
        p.rr((130, 88, 270, 160), 16, WINC, 7)
        draw_icon(p, icon, 200, 124, 0.9)
        if cheeks:
            p.el((112, 232, 140, 252), (255, 150, 140), 0)
            p.el((260, 232, 288, 252), (255, 150, 140), 0)
        cy = 208
        for sg, ex in ((-1, 158), (1, 242)):
            if eyes in ("open", "lookl", "lookr", "lookup", "worry", "sad"):
                lx = {"lookl": -7, "lookr": 7}.get(eyes, 0)
                ly = -8 if eyes == "lookup" else 0
                p.el((ex - 22, cy - 24, ex + 22, cy + 24), (255, 255, 255), 6)
                p.el((ex - 10 + lx, cy - 11 + ly, ex + 10 + lx, cy + 13 + ly), INKB, 0)
                p.el((ex - 5 + lx, cy - 9 + ly, ex + 3 + lx, cy - 1 + ly), (255, 255, 255), 0)
                if eyes == "worry":
                    p.ln([(ex - sg * 20, cy - 36 - (8 if sg < 0 else 0) + (8 if sg < 0 else 0)), (ex + sg * 20, cy - 50)] if False else
                         [(ex + (-20 if sg < 0 else 20), cy - 34 - 0), (ex + (20 if sg < 0 else -20), cy - 48)], 8)
            elif eyes == "blink":
                p.ln([(ex - 18, cy + 4), (ex + 18, cy + 4)], 8)
            elif eyes == "happy":
                p.arc((ex - 19, cy - 10, ex + 19, cy + 26), 200, 340, 8)
            elif eyes == "wide":
                p.el((ex - 27, cy - 32, ex + 27, cy + 32), (255, 255, 255), 6)
                p.el((ex - 6, cy - 6, ex + 6, cy + 8), INKB, 0)
            elif eyes == "squint":
                if sg < 0:
                    p.ln([(ex - 18, cy - 14), (ex + 10, cy + 2), (ex - 18, cy + 18)], 8)
                else:
                    p.ln([(ex + 18, cy - 14), (ex - 10, cy + 2), (ex + 18, cy + 18)], 8)
        if mouth == "grin":
            p.pie((166, 232, 234, 284), 0, 180, (120, 30, 40), 7)
            p.el((184, 262, 216, 280), (240, 110, 110), 0)
        elif mouth == "open":
            p.el((184, 242, 216, 278), (120, 30, 40), 7)
            p.el((190, 260, 210, 275), (240, 110, 110), 0)
        elif mouth == "o":
            p.el((190, 244, 210, 270), (120, 30, 40), 6)
        elif mouth == "flat":
            p.ln([(182, 262), (218, 262)], 7)
        elif mouth == "worry":
            p.ln([(172, 266), (186, 258), (200, 266), (214, 258), (228, 266)], 6)
        elif mouth == "smirk":
            p.ln([(178, 262), (204, 266), (228, 252)], 7)
        elif mouth == "sad":
            p.arc((176, 256, 224, 290), 200, 340, 7)
        else:
            p.arc((170, 232, 230, 274), 20, 160, 8)
        if sweat:
            p.poly([(300, 96), (288, 126), (300, 140), (312, 126)], (140, 210, 255), 5)
    return _svc(key, 400, 340, fn)


PIV_P = (200, 324)


def put_patch(layer, x, y, sc=1.0, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, patch_tile(**kw), x, y, PIV_P[0], PIV_P[1], sc * sx, sc * sy, rot)


# ---------------------------------------------------------------- FIXED FRED
def fred_tile(eyes="sad", mouth="frown", ghost=0, effort=0, sweat=0, ar=8, al=8):
    key = ("fred", eyes, mouth, ghost, round(effort, 1), sweat, int(ar / 8), int(al / 8))
    body = mix(GRY, (232, 110, 90), effort * 0.7)

    def fn(d, k):
        p = SP(d, k)
        for i in range(4):
            cx = 90 + 220 * (i + 0.5) / 4
            p.rr((cx - 9, 40, cx + 9, 78), 5, GRYL, 6)
            p.rr((cx - 9, 282, cx + 9, 324), 5, GRYL, 6)
        for i in range(4):
            cy = 70 + 220 * (i + 0.5) / 4
            p.rr((56, cy - 9, 98, cy + 9), 5, GRYL, 6)
            p.rr((302, cy - 9, 344, cy + 9), 5, GRYL, 6)
        _arm(p, -1, al, body, GRYL)
        _arm(p, 1, ar, body, GRYL)
        p.rr((90, 70, 310, 290), 40, body, 10)
        p.rr((106, 82, 250, 96), 7, mix(body, (255, 255, 255), 0.35), 0)
        p.rr((120, 84, 280, 168), 18, (66, 72, 86), 7)
        draw_icon(p, "gear", 200, 126, 1.0, (176, 184, 198), (66, 72, 86))
        if ghost:
            draw_icon(p, "wrench", 214, 128, 0.95, (255, 120, 100), (66, 72, 86))
        # plate + screws
        p.rr((60, 298, 340, 346), 12, GRYD, 8)
        for sx_ in (98, 302):
            p.el((sx_ - 15, 307, sx_ + 15, 337), GRYL, 6)
            p.ln([(sx_ - 8, 322), (sx_ + 8, 322)], 5)
            p.ln([(sx_, 314), (sx_, 330)], 5)
        cy = 212
        for sg, ex in ((-1, 158), (1, 242)):
            if eyes == "sad":
                p.el((ex - 22, cy - 22, ex + 22, cy + 22), (255, 255, 255), 6)
                p.el((ex - 9, cy + 0, ex + 9, cy + 18), INKB, 0)
                p.poly([(ex - 25, cy - 26), (ex + 25, cy - 26), (ex + 25, cy - 8 + sg * 7), (ex - 25, cy - 8 - sg * 7)], body, 0)
                p.ln([(ex - 24, cy - 8 - sg * 7), (ex + 24, cy - 8 + sg * 7)], 7)
            elif eyes == "strain":
                if sg < 0:
                    p.ln([(ex - 18, cy - 14), (ex + 10, cy + 2), (ex - 18, cy + 18)], 9)
                else:
                    p.ln([(ex + 18, cy - 14), (ex - 10, cy + 2), (ex + 18, cy + 18)], 9)
            elif eyes == "closed":
                p.arc((ex - 19, cy - 14, ex + 19, cy + 18), 20, 160, 8)
            elif eyes == "wide":
                p.el((ex - 25, cy - 28, ex + 25, cy + 28), (255, 255, 255), 6)
                p.el((ex - 6, cy - 6, ex + 6, cy + 8), INKB, 0)
            elif eyes == "squish":
                if sg < 0:
                    p.ln([(ex - 18, cy - 10), (ex + 10, cy + 4), (ex - 18, cy + 18)], 8)
                else:
                    p.ln([(ex + 18, cy - 10), (ex - 10, cy + 4), (ex + 18, cy + 18)], 8)
        if mouth == "frown":
            p.arc((166, 256, 234, 294), 200, 340, 8)
        elif mouth == "grit":
            p.rr((170, 252, 230, 280), 8, (255, 255, 255), 6)
            for xx in (185, 200, 215):
                p.ln([(xx, 253), (xx, 279)], 4)
        elif mouth == "o":
            p.el((188, 246, 212, 280), (60, 30, 40), 6)
        elif mouth == "flat":
            p.ln([(176, 264), (224, 264)], 7)
        if sweat:
            p.poly([(300, 96), (288, 126), (300, 140), (312, 126)], (140, 210, 255), 5)
    return _svc(key, 400, 350, fn)


PIV_F = (200, 342)


def put_fred(layer, x, y, sc=1.0, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, fred_tile(**kw), x, y, PIV_F[0], PIV_F[1], sc * sx, sc * sy, rot)


# ---------------------------------------------------------------- FORECASTER bots
def bot_tile(which, mood="smug", jaw=0.0, glass=0.0, clip="", snap=0, sweat=0, leg=0.0, arm=0, look=0):
    key = ("bot", which, mood, round(jaw, 1), round(glass, 1), clip, snap, sweat, round(leg * 2) / 2.0, arm, look)
    body = BOTC if which == 0 else BOT2
    head = BOTL if which == 0 else (186, 164, 214)

    def fn(d, k):
        p = SP(d, k)
        u1, u2 = max(0, leg) * 14, max(0, -leg) * 14
        p.rr((124, 520, 164, 604 - u1), 12, (70, 84, 112), 7)
        p.rr((196, 520, 236, 604 - u2), 12, (70, 84, 112), 7)
        p.el((98, 586 - u1, 172, 616 - u1), (40, 48, 64), 7)
        p.el((188, 586 - u2, 262, 616 - u2), (40, 48, 64), 7)
        # antenna
        p.ln([(180, 128), (180, 88)], 8)
        p.el((164, 66, 196, 98), RED if which == 0 else GLD, 7)
        # torso
        p.rr((92, 332, 268, 540), 44, body, 9)
        p.poly([(146, 334), (214, 334), (180, 392)], (255, 255, 255), 6)
        if which == 0:
            p.poly([(172, 366), (188, 366), (196, 416), (180, 452), (164, 416)], RED, 5)
        else:
            p.poly([(180, 372), (146, 354), (146, 394)], GLD, 5)
            p.poly([(180, 372), (214, 354), (214, 394)], GLD, 5)
            p.el((168, 360, 192, 384), GLD, 5)
        # left arm with pencil
        p.ln([(104, 380), (74, 466)], 38, INKB)
        p.ln([(104, 380), (74, 466)], 25, body)
        if snap < 1:
            p.poly([(58, 410), (76, 404), (92, 500), (74, 504)], (255, 214, 70), 6)
            p.poly([(74, 504), (92, 500), (82, 528)], (240, 190, 130), 5)
            p.poly([(58, 410), (76, 404), (78, 392), (61, 397)], (255, 168, 168), 5)
        else:
            p.poly([(66, 462), (82, 458), (92, 500), (74, 504)], (255, 214, 70), 6)
            p.poly([(74, 504), (92, 500), (82, 528)], (240, 190, 130), 5)
        p.el((54, 456, 94, 494), BOTL, 7)
        # head
        p.rr((78, 118, 282, 340), 46, head, 9)
        p.rr((60, 190, 84, 262), 8, GRYL, 6)
        p.rr((276, 190, 300, 262), 8, GRYL, 6)
        if which == 1:
            p.pie((120, 96, 240, 150), 180, 360, (70, 50, 90), 7)
        gy = -glass * 190
        # brows
        by = -glass * 10
        if mood == "worry":
            p.ln([(110, 180 + by), (160, 162 + by)], 9)
            p.ln([(250, 180 + by), (200, 162 + by)], 9)
        elif mood == "shock":
            p.ln([(112, 160 + by), (162, 150 + by)], 9)
            p.ln([(248, 160 + by), (198, 150 + by)], 9)
        else:
            p.ln([(110, 170), (160, 184)], 9)
            p.ln([(250, 170), (200, 184)], 9)
        # eyes behind glasses
        lx = look * 6
        if glass > 0.3 or mood == "shock":
            for ex in (140, 220):
                p.el((ex - 26, 190, ex + 26, 252 + jaw * 4), (255, 255, 255), 7)
                p.el((ex - 5, 214, ex + 5, 228), INKB, 0)
        else:
            for ex in (140, 220):
                p.el((ex - 8 + lx, 206, ex + 8 + lx, 228), INKB, 0)
        # mouth
        if jaw > 0.05:
            wdt, hgt = 30 + jaw * 26, 10 + jaw * 56
            p.el((180 - wdt / 2, 280, 180 + wdt / 2, 280 + hgt), (120, 30, 40), 7)
        elif mood == "worry":
            p.ln([(146, 296), (160, 288), (174, 296), (188, 288), (202, 296), (216, 288)], 7)
        elif mood == "grin":
            p.pie((148, 272, 212, 316), 0, 180, (120, 30, 40), 7)
        else:
            p.ln([(150, 296), (180, 290), (212, 280)], 8)
        # glasses
        lens = (222, 240, 255)
        p.rr((108, 186 + gy, 172, 256 + gy), 14, lens if glass > 0.3 else None, 8)
        p.rr((188, 186 + gy, 252, 256 + gy), 14, lens if glass > 0.3 else None, 8)
        p.ln([(172, 206 + gy), (188, 206 + gy)], 7)
        if glass <= 0.3 and mood != "shock":
            p.rr((112, 190, 168, 252), 10, (222, 240, 255, 255), 0)
            p.rr((192, 190, 248, 252), 10, (222, 240, 255, 255), 0)
            for ex in (140, 220):
                p.el((ex - 8 + lx, 206, ex + 8 + lx, 228), INKB, 0)
            p.rr((108, 186, 172, 256), 14, None, 8)
            p.rr((188, 186, 252, 256), 14, None, 8)
        # right arm + clipboard
        p.ln([(256, 384), (262, 470)], 38, INKB)
        p.ln([(256, 384), (262, 470)], 25, body)
        p.rr((206, 400, 352, 560), 12, (196, 146, 92), 8)
        p.rr((216, 416, 342, 550), 5, (255, 255, 255), 5)
        p.rr((250, 390, 308, 416), 8, (170, 176, 192), 6)
        if clip:
            p.txt((279, 486), clip, 34 if len(clip) < 5 else 25, RED if clip[0] != "^" else (20, 150, 90))
        else:
            for yy in (440, 468, 496):
                p.ln([(226, yy), (332, yy)], 5, (176, 176, 186))
        p.el((196, 452, 238, 494), BOTL, 7)
        if sweat:
            p.poly([(292, 150), (280, 182), (292, 196), (304, 182)], (140, 210, 255), 5)
    return _svc(key, 370, 630, fn)


PIV_B = (180, 616)


def put_bot(layer, i, x, y, sc=0.9, sx=1.0, sy=1.0, rot=0.0, flip=False, **kw):
    tile = bot_tile(i, **kw)
    if flip:
        tile = tile.transpose(Image.FLIP_LEFT_RIGHT)
    blit(layer, tile, x, y, PIV_B[0] if not flip else 370 - PIV_B[0], PIV_B[1], sc * sx, sc * sy, rot)


# ---------------------------------------------------------------- RACK (AI server)
RK_W, RK_H = 400, 920
CELL = {}
for _i in range(8):
    _c, _r = _i % 2, _i // 2
    CELL[_i] = (52 + _c * 156, 414 + _r * 116, 52 + _c * 156 + 140, 414 + _r * 116 + 104)


def rack_body():
    def fn(d, k):
        p = SP(d, k)
        p.rr((36, 40, 364, 900), 44, RKC, 10)
        p.rr((52, 52, 340, 66), 7, RKL, 0)
        p.rr((50, 70, 350, 320), 36, RKD, 8)
        p.rr((44, 330, 356, 396), 14, (30, 26, 70), 7)
        for i in range(8):
            x0, y0, x1, y1 = CELL[i]
            p.rr((x0 - 4, y0 - 4, x1 + 4, y1 + 4), 14, (28, 24, 66), 6)
        for yy in range(404, 884, 116):
            p.ln([(190, yy - 10), (210, yy - 10)], 3, RKL)
        p.rr((120, 888, 280, 910), 8, RKD, 6)
    return _svc(("rackbody",), RK_W, RK_H, fn)


def rack_label(img, sc=1.0):
    pass


def rack_compose(look=0.0, blink=0.0, mouth="worry", lights=0.0, cells=None, brow=1.0, panic=0.0, label=True, now=0.0):
    """Returns a fresh RGBA tile: body + face + slot content.  cells: {i: (kind, u)}  kind in q / ok / empty."""
    tile = rack_body().copy()
    d = ImageDraw.Draw(tile)
    # LEDs on the head panel
    for j in range(5):
        on = (_m.sin(now * (6 + 4 * panic) + j * 1.9) > 0.1)
        col = (RED if panic > 0.3 else (255, 190, 60)) if on else (70, 60, 100)
        if j % 2 and not on:
            col = (60, 54, 96)
        d.ellipse((68 + j * 24, 84, 84 + j * 24, 100), fill=col + (255,), outline=INKB + (255,), width=3)

    def face(dd, k):
        p = SP(dd, k)
        # huge eye
        ex, ey = 200, 188
        sq = 1 - 0.92 * blink
        p.el((ex - 88, ey - 88 * sq, ex + 88, ey + 88 * sq), (255, 255, 255), 8)
        if sq > 0.3:
            px, py = ex + look * 30, ey + 6
            p.el((px - 34, py - 38 * sq, px + 34, py + 38 * sq), (36, 24, 60), 0)
            p.el((px - 14, py - 26 * sq, px - 2, py - 14 * sq), (255, 255, 255), 0)
        # brow
        if brow > 0:
            p.ln([(ex - 98, ey - 78), (ex + 20, ey - 100 - 8 * brow)], 13)
        # mouth
        if mouth == "worry":
            p.ln([(150, 296), (170, 284), (190, 296), (210, 284), (230, 296), (250, 284)], 8, (230, 220, 255))
        elif mouth == "shout":
            p.rr((120, 262, 280, 316), 22, (120, 30, 40), 8)
            p.rr((150, 290, 250, 314), 12, (240, 110, 110), 0)
            p.rr((132, 266, 268, 276), 4, (255, 255, 255), 0)
        elif mouth == "relief":
            p.arc((150, 258, 250, 306), 20, 160, 8, (230, 220, 255))
        elif mouth == "o":
            p.el((180, 262, 220, 308), (120, 30, 40), 7)
        # label plate
        if label:
            p.txt((200, 363), "AI SERVER", 40, (230, 226, 255))
    t2 = _ss(RK_W, 340, lambda dd, k: face(dd, k))
    tile.alpha_composite(t2, (0, 0))
    # slot contents
    d = ImageDraw.Draw(tile)
    for i in range(8):
        x0, y0, x1, y1 = CELL[i]
        st = (cells or {}).get(i)
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        d.rounded_rectangle((x0, y0, x1, y1), radius=12, fill=(18, 16, 44, 255))
        if not st:
            continue
        kind, u = st
        if kind == "q":
            r = 38 * pop(u)
            fl = 0.5 + 0.5 * _m.sin(now * 14 + i)
            d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=mix((190, 40, 30), RED, fl) + (255,), outline=INKB + (255,), width=5)
            d.text((cx, cy + 2), "?", font=font("bold", int(56 * pop(u))), fill=(255, 255, 255, 255), anchor="mm")
        elif kind == "ok":
            # mini Patch happy + green LED
            mp = patch_tile("none", "happy", "smile", 0, 0)
            sc = 0.36 * (1 + 0.15 * _m.exp(-8 * u) * _m.cos(22 * u))
            w_, h_ = int(mp.width * sc), int(mp.height * sc)
            im = mp.resize((max(1, w_), max(1, h_)), Image.LANCZOS)
            tile.alpha_composite(im, (int(cx - 200 * sc), int(y1 - 4 - 324 * sc)))
            d.ellipse((x1 - 22, y0 + 8, x1 - 8, y0 + 22), fill=(80, 255, 140, 255), outline=INKB + (255,), width=3)
    return tile


PIV_R = (200, 900)


def put_rack(layer, x, y, sc=0.9, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, rack_compose(**kw), x, y, PIV_R[0], PIV_R[1], sc * sx, sc * sy, rot)


def rack_cell_xy(i, x, y, sc):
    x0, y0, x1, y1 = CELL[i]
    return x + ((x0 + x1) / 2 - 200) * sc, y + ((y0 + y1) / 2 - 900) * sc


# ---------------------------------------------------------------- background set
TOWERS = [(60, 210, 860), (330, 170, 760), (560, 240, 900), (850, 180, 800), (1090, 220, 880), (1330, 170, 740)]


def sv_bg(layer, now, pan=0.0, mode="hall", reveal=1.0, alert=0.0):
    d = ImageDraw.Draw(layer)
    # sky gradient
    col_top, col_bot = (8, 28, 38), (14, 46, 60)
    if getattr(sv_bg, "_g", None) is None:
        g = Image.new("RGBA", (1, H))
        gd = ImageDraw.Draw(g)
        for y in range(H):
            gd.point((0, y), fill=mix(col_top, col_bot, clamp01(y / 1300.0)) + (255,))
        sv_bg._g = g.resize((W, H))
    layer.paste(sv_bg._g, (0, 0))
    if mode == "hook":
        rays(layer, 540, 600, 0, 2400, 18, now * 0.12, (13, 52, 66), None, 0.5)
        d.ellipse((300, 380, 780, 860), fill=(16, 60, 74, 255))
    if reveal <= 0.001:
        return
    off = (1 - ease(reveal)) * 1200
    # far towers (parallax 0.25)
    for i, (x, w, h) in enumerate(TOWERS):
        xs = (x - pan * 0.25) % 1560 - 240 + off
        if xs > W or xs + w < 0:
            continue
        top = 1280 - h
        d.rounded_rectangle((xs, top, xs + w, 1290), radius=16, fill=(14, 44, 58, 255), outline=(20, 62, 80, 255), width=4)
        for r_ in range(int(h // 56)):
            yy = top + 24 + r_ * 56
            d.rounded_rectangle((xs + 14, yy, xs + w - 14, yy + 34), radius=8, fill=(11, 36, 48, 255))
            on = _m.sin(now * (1.2 + (i + r_) % 3) + i * 2.1 + r_ * 1.3) > 0.15
            c = (40, 180, 160) if on else (22, 70, 80)
            if (i + r_) % 5 == 0 and on:
                c = (255, 190, 60)
            d.ellipse((xs + 22, yy + 11, xs + 34, yy + 23), fill=c + (255,))
    # mid shelves (parallax 0.6)
    for r_, yy in enumerate((660, 820, 980, 1140)):
        d.rounded_rectangle((-20 + off, yy, W + 20 + off, yy + 120), radius=14, fill=(15, 49, 63, 255), outline=(21, 66, 84, 255), width=4)
        sh = (pan * 0.6) % 150
        for s_ in range(-1, 9):
            sx_ = s_ * 150 - sh + off
            d.rounded_rectangle((sx_ + 14, yy + 14, sx_ + 136, yy + 106), radius=10, fill=(12, 40, 52, 255))
            ph = s_ * 1.7 + r_ * 2.3 + int(pan * 0.6 / 150) * 1.7
            on = _m.sin(now * 2.4 + ph) > 0.2
            d.ellipse((sx_ + 26, yy + 26, sx_ + 40, yy + 40), fill=((60, 255, 160) if on else (24, 76, 80)) + (255,))
            d.ellipse((sx_ + 50, yy + 26, sx_ + 64, yy + 40), fill=((255, 190, 60) if (not on and (s_ + r_) % 3 == 0) else (24, 76, 80)) + (255,))
            d.line([(sx_ + 26, yy + 66), (sx_ + 120, yy + 66)], fill=(21, 66, 84, 255), width=4)
            d.line([(sx_ + 26, yy + 82), (sx_ + 100, yy + 82)], fill=(21, 66, 84, 255), width=4)
    # floor
    fy = 1280
    d.rectangle((0 + off, fy, W + off, H), fill=(11, 33, 43, 255))
    d.rectangle((0 + off, fy, W + off, fy + 10), fill=(26, 130, 128, 255))
    for k in range(-2, 40):
        x0 = k * 70 - (pan % 70) + off
        d.line([(x0, fy + 12), (x0 - 160, H)], fill=(17, 52, 66, 255), width=3)
    for k, yy in enumerate((fy + 40, fy + 100, fy + 190, fy + 300)):
        d.line([(0, yy), (W, yy)], fill=(15, 46, 58, 255), width=2)
    cabs = [((232, 69, 44), 1310, 0.0), ((255, 200, 61), 1352, 1.6), ((24, 197, 176), 1396, 3.1)]
    for col, yy, ph in cabs:
        pts = [(x_ + off, yy + _m.sin((x_ + pan) * 0.012 + ph) * 9) for x_ in range(-40, W + 60, 30)]
        d.line(pts, fill=tuple(int(c * 0.55) for c in col) + (255,), width=9, joint="curve")
    for k in range(-2, 24):
        x0 = k * 60 - (pan % 120) + off
        d.polygon([(x0, fy + 12), (x0 + 30, fy + 12), (x0 + 14, fy + 30), (x0 - 16, fy + 30)], fill=(GLD[0] // 2, GLD[1] // 2, 20, 255))
    for k in range(-1, 12):
        x0 = k * 130 - (pan % 130) + off
        d.rounded_rectangle((x0 + 8, fy + 150, x0 + 118, fy + 250), radius=10, outline=(20, 62, 78, 255), width=3)
        d.rounded_rectangle((x0 + 20, fy + 330, x0 + 106, fy + 400), radius=10, outline=(18, 56, 70, 255), width=3)
    # ceiling cables + lamps
    for k in range(4):
        cx_ = (k * 330 + 90 - pan * 0.4) % 1400 - 150 + off
        d.line([(cx_, 380), (cx_, 440 + 20 * k % 3)], fill=(30, 90, 108, 255), width=5)
        d.polygon([(cx_ - 34, 470 + 20 * k % 3), (cx_ + 34, 470 + 20 * k % 3), (cx_ + 18, 440 + 20 * k % 3), (cx_ - 18, 440 + 20 * k % 3)], fill=(46, 120, 138, 255))
    if alert > 0.01:
        tint(layer, (190, 30, 20), 0.22 * alert * (0.5 + 0.5 * _m.sin(now * 9)))


def sweepy(layer, now, pan=0.0, y=1488):
    """tiny cleaning robot rolling along the floor, bumps into the edges and turns."""
    per = 7.0
    ph = (now % per) / per
    u = 1 - abs(2 * ph - 1)
    x = lerp(120, 960, ease(clamp01(u * 1.6)) if False else u) - pan * 0.0
    face = 1 if ph < 0.5 else -1
    def fn(d, k):
        p = SP(d, k)
        p.rr((8, 24, 148, 70), 22, (200, 207, 216), 6)
        p.rr((28, 12, 128, 36), 10, (150, 158, 170), 6)
        p.el((98, 30, 132, 62), (255, 255, 255), 5)
        p.el((114, 40, 126, 54), INKB, 0)
        p.ln([(40, 12), (36, -2)], 4)
        p.el((30, -10, 42, 2), RED, 4)
        p.el((18, 60, 50, 80), (40, 48, 64), 5)
        p.el((106, 60, 138, 80), (40, 48, 64), 5)
    tile = _svc(("sweepy",), 160, 84, fn)
    if face < 0:
        tile = tile.transpose(Image.FLIP_LEFT_RIGHT)
    bob = abs(_m.sin(now * 12)) * 2
    blit(layer, tile, x, y - bob, 80, 80, 1.0, 1.0, 0)


# ---------------------------------------------------------------- frame furniture
def sv_header(img, spec, now, total):
    d = ImageDraw.Draw(img)
    d.rectangle((0, 0, W, 366), fill=(5, 18, 26, 255))
    d.rectangle((0, 366, W, 374), fill=TLP + (255,))
    d.rectangle((0, 214, W, 222), fill=(16, 52, 66, 255))
    d.rectangle((0, 214, int(W * clamp01(now / total)), 222), fill=GLD + (255,))
    mv = float(spec["move_pct"])
    chip = f"{spec.get('ticker', '')} {'+' if mv >= 0 else '-'}{abs(mv):g}%"
    f = font("bold", 50)
    tw = int(d.textlength(chip, font=f))
    cw = tw + 56
    spill(img, 60 + cw / 2 - 12, 272, chip, 50, TLP, tc=INKB, padx=28, h=70, ow=5)
    d = ImageDraw.Draw(img)
    d.text((60 + cw + 22, 272), "Lattice - morning trading", font=font("bold", 32), fill=CRM + (255,), anchor="lm")
    d.text((W - 60, 250), "WHY IT", font=font("bold", 30), fill=GLD + (255,), anchor="rm")
    d.text((W - 60, 284), "MOVED?", font=font("bold", 30), fill=CRM + (255,), anchor="rm")
    d.text((60, 313), "Educational only - not financial advice", font=font("medium", 25), fill=DIMC + (255,), anchor="lm")
    d.text((60, 346), "DRAMATIZATION - CARTOON, NOT REAL EVENTS", font=font("bold", 34), fill=(170, 186, 194, 255), anchor="lm")
    d.text((540, 1486), "DRAMATIZATION - NOT FINANCIAL ADVICE", font=font("bold", 36), fill=(120, 150, 160, 255), anchor="mm")


SV_TR = 0.42


def _sv_layer(b, tb, spec, z_extra=1.0):
    CAM.update(z=1.0, px=540.0, py=960.0, dx=0.0, dy=0.0, rot=0.0)
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    SCENES[b["visual"]["type"]](layer, b["visual"], tb, spec, b["cues"])
    CAM["z"] *= z_extra
    return cam_apply(layer)


def sv_frame(spec, beats, now, total, kw_times, dbg=False):
    bi = 0
    for i, b_ in enumerate(beats):
        if now >= b_["start"] - 1e-6:
            bi = i
    b = beats[bi]
    tb = now - b["start"]
    punch = max([0.0] + [max(0.0, 1 - abs(now - kt - 0.08) / 0.14) for kt in kw_times if -0.1 < now - kt < 0.3])
    zx = 1 + 0.014 * punch
    layer = _sv_layer(b, tb, spec, zx)
    if bi > 0 and tb < SV_TR:
        u = ease(tb / SV_TR)
        pv = beats[bi - 1]
        prev = _sv_layer(pv, (b["start"] - pv["start"]) + tb, spec, zx)
        base = Image.new("RGBA", (W, H), NAVY + (255,))
        base.paste(prev, (-int(u * W), 0))
        base.paste(layer, (int((1 - u) * W), 0))
        a = _m.sin(_m.pi * clamp01(tb / SV_TR))
        rnd = _rnd.Random(int(now * 30))
        dd = ImageDraw.Draw(base)
        for _ in range(14):
            yy = rnd.randint(400, 1500)
            x0 = rnd.randint(0, W)
            ln_ = int(rnd.uniform(200, 520) * a)
            dd.rounded_rectangle((x0 - ln_ // 2, yy, x0 + ln_ // 2, yy + 5), radius=2, fill=(220, 240, 245, int(150 * a)))
        layer = base
    sv_header(layer, spec, now, total)
    if dbg:
        dd = ImageDraw.Draw(layer)
        dd.rectangle((0, 1310, W, 1430), outline=(255, 0, 255, 255), width=3)
        dd.line([(0, 1520), (W, 1520)], fill=(255, 0, 255, 255), width=3)
    return layer


# ---------------------------------------------------------------- BEAT 1: hook
ICON_SEQ = ["wrench", "shield", "wrench", "magnifier", "shield", "wrench"]


def hook_draw(img, t, tt, tc, td, final=False):
    reveal = clamp01((t - tc) / 0.7)
    sv_bg(img, t, pan=t * 24, mode="hook", reveal=reveal)
    if reveal > 0.4:
        sweepy(img, t, t * 24)
    # rising gold chevrons after the slam
    if t >= tt:
        k = t - tt
        dd = ImageDraw.Draw(img)
        for i in range(12):
            sp_ = 260 + 40 * (i % 4)
            y = 1230 - ((k * sp_ + i * 137) % 860)
            x = 60 + i * 86 + _m.sin(k * 2 + i) * 12
            a = clamp01(k / 0.3) * clamp01((y - 420) / 120)
            if a < 0.05:
                continue
            s_ = 20 + 6 * (i % 3)
            col = TLP if i % 2 == 0 else GLD
            dd.polygon([(x, y - s_), (x + s_, y + s_ * 0.2), (x + s_ * 0.45, y + s_ * 0.2), (x + s_ * 0.45, y + s_),
                        (x - s_ * 0.45, y + s_), (x - s_ * 0.45, y + s_ * 0.2), (x - s_, y + s_ * 0.2)], fill=col + (255,), outline=INKB + (255,))
    # Patch
    cyc = 0.75
    ci = int(t / cyc)
    k = t - ci * cyc
    icon = ICON_SEQ[ci % len(ICON_SEQ)]
    sq = 0.2 * _m.exp(-11 * k) * _m.cos(30 * k) if (ci > 0 or final is False) else 0.0
    if ci == 0:
        sq = 0.0
    sx, sy = 1 + sq * 0.9, 1 - sq
    px, py = 540, 1086 - abs(_m.sin(t * 5.0)) * 8
    eyes = "lookup"
    mouth = "smile"
    al = ar = 8
    if t >= tt:
        kk = t - tt
        eyes = "wide" if kk < 0.45 else "happy"
        mouth = "grin" if kk < 3 else "open"
        al = ar = 150 + _m.sin(kk * 14) * 16 if kk < 2.2 else 40
        py -= 70 * _m.sin(clamp01(kk / 0.4) * _m.pi)
        sy *= 1 + 0.12 * _m.sin(clamp01(kk / 0.4) * _m.pi)
    elif blink_at(t, 0.3):
        eyes = "blink"
    put_patch(img, px, py, 1.6, sx, sy, 0, icon=icon, eyes=eyes, mouth=mouth, al=al, ar=ar)
    # sparkle ring on icon swap
    if ci > 0 and k < 0.35:
        rr_ = 40 + 120 * ease(k / 0.35)
        ImageDraw.Draw(img).ellipse((px - rr_, py - 300 - rr_ * 0.5, px + rr_, py - 300 + rr_ * 0.5), outline=GLD + (int(255 * (1 - k / 0.35)),), width=7)
    # +13%
    sc = 1.0 + 0.02 * _m.sin(t * 4)
    rot = -3.0
    cy13 = 520 + _m.sin(t * 2.4) * 5
    if t >= tt:
        kk = t - tt
        sc = lerp(1.4, 1.0, spr(kk, 14, 6)) if kk < 1.0 else 1.0 + 0.02 * _m.sin(t * 4)
        rot = -3.0 + _m.sin(kk * 20) * 5 * _m.exp(-4 * kk)
        if kk < 0.6:
            e = ease(kk / 0.3)
            sburst(img, 540, 520, 170 + 90 * e, 270 + 120 * e, 12, kk * 0.6, (255, 214, 92, 255), 8, alpha=clamp01(1 - kk / 0.6))
    stext(img, (540, cy13), "+13%", 250, GLD, sw=18, rot=rot, sc=sc)
    spill(img, 540, 636, "MORNING TRADING", 56, TLP, tc=INKB, padx=34, h=84, ow=6)
    # text lines
    if t < tc + 0.05:
        a = pop((t - 0.0 + 0.3) / 0.3) if not final else 1.0
        stext(img, (540, 1180), "WHY? A CHIP THAT", 60, CRM, sw=9, sc=max(0.01, a) * (1 - clamp01((t - tc) / 0.2)))
        stext(img, (540, 1250), "CHANGES JOBS.", 64, GLD, sw=9, sc=max(0.01, a) * (1 - clamp01((t - tc) / 0.2)))
    if t >= tc:
        a = pop((t - tc) / 0.3)
        stext(img, (540, 1180), "AS A CARTOON", 70, CRM, sw=10, sc=a)
    if t >= td:
        k2 = t - td
        pulse = 1 + 0.08 * _m.sin(k2 * 16) * _m.exp(-3 * k2)
        spill(img, 540, 1256, "DRAMATIZATION", 58, RED, tc=CRM, padx=40, sc=pop(k2 / 0.3) * pulse, ow=7)
    if t >= tt and t < tt + 0.35:
        sx_, sy_ = shake(14 * (1 - (t - tt) / 0.35), t)
        CAM["dx"], CAM["dy"] = sx_, sy_
        CAM["z"] = 1 + 0.05 * _m.sin(clamp01((t - tt) / 0.35) * _m.pi)


def scene_sv_hook(img, v, t, spec, cues):
    hook_draw(img, t, cues.at("thirteen", 1.0), cues.at("cartoon", 3.5), cues.at("dramatization", 4.2))


GY = 1190


def wobble_in(t, t0, dur=0.5):
    return clamp01((t - t0) / dur)


def pegboard(img, t, hot=None, used=()):
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((40, 640, 1040, 860), radius=22, fill=(22, 66, 82, 255), outline=(30, 92, 112, 255), width=6)
    for gx in range(70, 1030, 46):
        for gy in range(662, 850, 46):
            d.ellipse((gx - 3, gy - 3, gx + 3, gy + 3), fill=(14, 44, 58, 255))
    for i, (kind, x) in enumerate((("wrench", 200), ("magnifier", 540), ("shield", 880))):
        if kind in used:
            continue
        d.rounded_rectangle((x - 70, 668, x + 70, 832), radius=16, fill=(12, 40, 52, 255))
        T = _ss(160, 160, lambda dd, k, kind=kind: draw_icon(SP(dd, k), kind, 80, 84, 1.3, (176, 210, 214), (12, 40, 52)))
        put(img, T, x - 80, 664 + (-10 if hot == kind else 0))


def conveyor(img, t, y=600):
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((20, y + 30, 1060, y + 60), radius=14, fill=(20, 60, 76, 255), outline=(30, 92, 112, 255), width=4)
    for k in range(-1, 18):
        x = k * 70 + (t * 80) % 70
        d.ellipse((x - 8, y + 38, x + 8, y + 54), fill=(12, 40, 52, 255))
    for k in range(5):
        x = ((k * 260 + t * 80) % 1300) - 110
        done = x > 540
        d.rounded_rectangle((x, y - 6, x + 56, y + 32), radius=8, fill=(TLP if done else GRY) + (255,), outline=INKB + (255,), width=4)
        for q in range(3):
            d.line([(x + 12 + q * 16, y - 14), (x + 12 + q * 16, y - 6)], fill=PINC + (255,), width=4)


def card_text(img, cx, cy, w, h, lines, sizes, cols, sc=1.0, fill=(10, 36, 46)):
    T = _ss(w + 24, h + 24, lambda d, k: SP(d, k).rr((10, 10, w + 10, h + 10), 30, fill, 8))
    dd = ImageDraw.Draw(T)
    n = len(lines)
    tot = sum(sizes) * 1.12
    y = (h + 24) / 2 - tot / 2
    for ln_, sz, col in zip(lines, sizes, cols):
        y += sz * 0.56
        dd.text(((w + 24) / 2, y), ln_, font=font("bold", sz), fill=col + (255,), anchor="mm")
        y += sz * 0.56
    blit(img, T, cx, cy, (w + 24) / 2, (h + 24) / 2, sc, sc, 0)


# ---------------------------------------------------------------- BEAT 2: meet Patch and Fred
def c2(c):
    return dict(tp=c.at("Patch", 0.15), tpr=c.at("programmable", 3.0), tcu=c.at("customized", 4.3), tsw1=c.at("switch", 7.1),
                tsw2=c.at("jobs", 7.45), tfx=c.at("Fixed", 7.95), tcant=c.at("cannot", 8.5), tone=c.at("one", 9.6), tfor=c.at("Forever", 10.3),
                tlat=c.at("Lattice", 1.4))


def scene_sv_meet(img, v, t, spec, cues):
    q = c2(cues)
    sv_bg(img, t, pan=t * 18, mode="bench")
    conveyor(img, t)
    icon = "none"
    hot = None
    used = []
    if t >= q["tcu"]:
        icon = "wrench"; used = ["wrench"]; hot = None
    if t >= q["tsw1"]:
        icon = "magnifier"; used = ["magnifier"]
    if t >= q["tsw2"]:
        icon = "shield"; used = ["shield"]
    if t >= q["tfx"]:
        icon = "wrench"; used = ["wrench"]
    pegboard(img, t, hot, used)
    sweepy(img, t, t * 18)
    # swap time (latest)
    sw_ts = [x for x in (q["tcu"], q["tsw1"], q["tsw2"], q["tfx"] + 0.15) if t >= x]
    ks = t - sw_ts[-1] if sw_ts else 9.0
    sq = 0.22 * _m.exp(-10 * ks) * _m.cos(28 * ks) if ks < 1 else 0
    ent = spr(t - 0.0, 12, 5.5)
    py = GY - (1 - ent) * 700
    px = 320
    eyes = "open"; mouth = "smile"; al = ar = 8
    if blink_at(t, 0.5):
        eyes = "blink"
    if t >= q["tpr"] and t < q["tcu"] + 1.2:
        eyes = "happy"; mouth = "grin"
    if q["tsw1"] <= t < q["tfx"]:
        eyes = "wide"; mouth = "open"; al, ar = 120 + swob(t, 3, 30), 120 - swob(t, 3, 30)
    if t >= q["tfx"]:
        eyes = "lookr"; mouth = "smirk"; ar = 90
    if t >= q["tfor"]:
        mouth = "smirk"
    hop = abs(_m.sin(t * 3.2)) * 6 if t > 0.9 else 0
    put_patch(img, px, py - hop, 1.55, 1 + sq * 0.9, 1 - sq, swob(t, 0.8, 1.2), icon=icon, eyes=eyes, mouth=mouth, al=al, ar=ar, cheeks=1 if t > q["tpr"] else 0)
    if ks < 0.4:  # spark ring + tool trail
        rr_ = 30 + 130 * ease(ks / 0.4)
        ImageDraw.Draw(img).ellipse((px - rr_, py - 300 - rr_ * 0.5, px + rr_, py - 300 + rr_ * 0.5), outline=GLD + (int(255 * (1 - ks / 0.4)),), width=7)
    # name tag
    if t >= q["tp"]:
        k = t - q["tp"]
        spill(img, 320, 690, "PATCH", 62, TLP, tc=INKB, padx=34, sc=pop(k / 0.3), rot=-4 + swob(t, 0.7, 2), ow=7)
    # programmable chip
    if q["tpr"] <= t < q["tfx"] - 0.1:
        k = t - q["tpr"]
        if t < q["tcu"]:
            spill(img, 540, 500, "PROGRAMMABLE", 70, GLD, tc=INKB, padx=44, sc=pop(k / 0.3), ow=7)
        else:
            card_text(img, 540, 510, 880, 250, ["PROGRAMMABLE =", "CUSTOMIZED AFTER", "MANUFACTURING"], [60, 60, 60], [GLD, CRM, CRM], sc=pop((t - q["tcu"]) / 0.3))
    # Fred
    if t >= q["tfx"] - 0.1:
        k = t - (q["tfx"] - 0.1)
        fx = lerp(1350, 790, ease(k / 0.55))
        land = max(0.0, k - 0.55)
        fsq = 0.1 * _m.exp(-9 * land) * _m.cos(22 * land) if k > 0.55 else 0
        eff = 0.0; eyes = "sad"; mouth = "frown"; ghost = 0; jx = 0; sw_ = 0
        if q["tcant"] - 0.5 <= t < q["tone"] - 0.2:
            eff = clamp01((t - (q["tcant"] - 0.5)) / 0.4); eyes = "strain"; mouth = "grit"
            jx = _m.sin(t * 60) * 5 * eff
            ghost = 1 if int(t * 8) % 2 == 0 else 0
        if t >= q["tfor"]:
            sw_ = 1
        put_fred(img, fx + jx, GY + 14, 1.4, 1 + fsq * 0.8, 1 - fsq, 0, eyes=eyes, mouth=mouth, ghost=ghost, effort=round(eff, 1), sweat=1 if eff > 0.5 else sw_)
        if t >= q["tcant"]:
            kk = t - q["tcant"]
            if kk < 1.4:
                bubble(img, (560, 640, 1020, 790), tail=(790, 880), fill=(255, 255, 255, 255))
                stext(img, (790, 715), "CAN'T!", 84, RED, sw=0, sc=max(0.01, spr(kk, 16, 6)), rot=swob(t, 6, 3) * (1 - kk / 1.4))
        if t >= q["tone"] and t < q["tfor"] + 0.2:
            spill(img, 790, 560, "ONE JOB", 64, GLD, tc=INKB, padx=40, sc=pop((t - q["tone"]) / 0.3), ow=7)
        if t >= q["tfor"]:
            kk = t - q["tfor"]
            stext(img, (540, 520), "FOREVER.", 110, CRM, sw=12, sc=max(0.01, pop(kk / 0.3)), rot=-3)
            # drip + cobweb + spider
            sp_y = 640 + 120 * ease(kk / 0.8)
            dd = ImageDraw.Draw(img)
            dd.line([(950, 400), (950, sp_y)], fill=(210, 220, 224, 255), width=3)
            dd.ellipse((935, sp_y, 965, sp_y + 28), fill=(30, 30, 40, 255), outline=INKB + (255,))
            for lg in (-1, 1):
                for j in range(3):
                    dd.line([(950, sp_y + 14), (950 + lg * (22 + j * 6), sp_y + 4 + j * 9)], fill=(30, 30, 40, 255), width=3)
    if t < 0.5 and False:
        pass


# ---------------------------------------------------------------- BEAT 3: Rack panics, slots fill
def c3(c):
    return dict(tpan=c.at("panic", 2.0), tslot=c.at("Every", 2.55), thelp=c.at("helper", 3.8), tmg=c.at("management", 4.6),
                tmore=c.at("more", 6.3), teach=c.at("each", 7.2), trk=c.at("Rack", 0.4), tai=c.at("AI", 0.9))


RKX, RKS = 790, 0.85


def scene_sv_rack(img, v, t, spec, cues):
    q = c3(cues)
    alert = clamp01((t - q["tpan"]) / 0.5)
    sv_bg(img, t, pan=t * 22, mode="hall", alert=alert * (1 - clamp01((t - q["teach"]) / 1.0)))
    sweepy(img, t, t * 22)
    # cell timeline
    fill_t = {}
    for i in range(8):
        fill_t[i] = q["thelp"] + 0.45 + i * 0.16 if i < 2 else q["tmore"] + 0.45 + (i - 2) * 0.13
    cells = {}
    for i in range(8):
        tq_ = q["tslot"] + i * 0.1
        if t >= fill_t[i]:
            cells[i] = ("ok", t - fill_t[i])
        elif t >= tq_:
            cells[i] = ("q", t - tq_)
    ent = clamp01((t - 0.0) / 0.45)
    rx = lerp(1500, RKX, ease(ent))
    lsq = 0.0
    if t > 0.45:
        k = t - 0.45
        lsq = 0.08 * _m.exp(-7 * k) * _m.cos(20 * k)
    shk = 0.0
    if q["tpan"] <= t < q["teach"] + 0.6:
        shk = 7 * (1 - clamp01((t - q["teach"]) / 0.6))
    ox, oy = shake(shk, t, 40) if shk else (0, 0)
    panic = alert
    mouth = "worry" if t < q["teach"] else "relief"
    if t >= q["tpan"] and t < q["tslot"] + 0.3:
        mouth = "shout"
    look = -0.8 + 0.2 * _m.sin(t * 3)
    put_rack(img, rx + ox, GY + 36 + oy, RKS, 1 + lsq * 0.7, 1 - lsq, 0, look=look, blink=1.0 if blink_at(t, 0.2, 2.6) else 0.0,
             mouth=mouth, panic=panic, cells=cells, now=t, brow=1.0 if t < q["teach"] else 0.0)
    # sweat drops
    if t >= q["tpan"]:
        k = t - q["tpan"]
        rnd = _rnd.Random(3)
        dd = ImageDraw.Draw(img)
        for j in range(9):
            tj = j * 0.12
            kk = k - tj
            if kk < 0 or kk > 1.2:
                continue
            ang = rnd.uniform(-2.6, -0.5)
            sp_ = rnd.uniform(350, 620)
            x = rx - 40 + _m.cos(ang) * sp_ * kk
            y = 560 + _m.sin(ang) * sp_ * kk + 1100 * kk * kk
            dd.polygon([(x, y - 20), (x - 11, y + 8), (x, y + 18), (x + 11, y + 8)], fill=(140, 210, 255, 255), outline=INKB + (255,))
    # Patch hero
    if t >= 0.0:
        px = 250
        eyes = "lookr"; mouth = "open"; al = 20; ar = 60
        if blink_at(t, 0.9):
            eyes = "blink"
        py = GY
        sq = 0.0
        # launch squash for each clone
        for i in range(8):
            ln_ = fill_t[i] - 0.45
            if 0 <= t - ln_ < 0.3:
                sq = max(sq, 0.2 * _m.sin(_m.pi * (t - ln_) / 0.3))
        if t >= q["thelp"]:
            eyes = "happy"; mouth = "grin"; ar = 150
        put_patch(img, px, py, 1.4, 1 - sq * 0.4, 1 + sq * 0.5, 0, icon="wrench", eyes=eyes, mouth=mouth, al=al, ar=ar, cheeks=1)
    # flying copies
    for i in range(8):
        ln_ = fill_t[i] - 0.45
        u = (t - ln_) / 0.45
        if 0 <= u < 1:
            cx0, cy0 = 300, GY - 190
            tx, ty = rack_cell_xy(i, rx, GY + 36, RKS)
            e = ease(u)
            x = lerp(cx0, tx, e)
            y = lerp(cy0, ty + 20, e) - 220 * _m.sin(_m.pi * u)
            put_patch(img, x, y, 0.36, 1, 1, u * 360, icon="none", eyes="happy", mouth="grin", al=100, ar=100)
    if t >= q["tmg"]:
        card_text(img, 285, 560, 500, 270, ["MGMT SAYS:", "MORE CHIPS", "PER SERVER"], [56, 62, 62], [GLD, CRM, CRM], sc=pop((t - q["tmg"]) / 0.3) * (1 - 0 * t))
    if t >= q["tpan"] and t < q["tpan"] + 1.0:
        spill(img, 285, 560, "PANIC!", 90, RED, tc=CRM, padx=50, sc=pop((t - q["tpan"]) / 0.25), rot=-5 + swob(t, 8, 3), ow=8)
    if q["tpan"] <= t < q["tpan"] + 0.4:
        CAM["dx"], CAM["dy"] = shake(10 * (1 - (t - q["tpan"]) / 0.4), t)


# ---------------------------------------------------------------- BEAT 4: the bet and the record
def c4(c):
    return dict(tf=c.at("Forecasters", 0.2), tw=c.at("Wall", 1.3), tbet=c.at("bet", 2.6), t256=c.at("two hundred", 3.4), t56=c.at("fifty-six", 4.3),
                tsold=c.at("sold", 5.9), t91=c.at("ninety-one", 6.7), trec=c.at("record", 8.1), t118=c.at("up", 8.7), te=c.at("eighteen", 9.5))


STK_X, STK_PX = 640, 1.9


def draw_stack(img, h, wob=0.0):
    d = ImageDraw.Draw(img)
    base = GY + 6
    n = int(h // 15)
    for i in range(n):
        yy = base - (i + 1) * 15
        ox = _m.sin(i * 1.9) * 4 + _m.sin(wob * 14 + i) * 2 * min(1, i / 8)
        d.rounded_rectangle((STK_X - 90 + ox, yy, STK_X + 90 + ox, yy + 17), radius=8, fill=(GLD if i % 2 == 0 else (240, 176, 40)) + (255,), outline=INKB + (255,), width=4)
    d.rounded_rectangle((STK_X - 110, base - 4, STK_X + 110, base + 22), radius=8, fill=(60, 80, 96, 255), outline=INKB + (255,), width=5)


def scene_sv_bet(img, v, t, spec, cues):
    q = c4(cues)
    sv_bg(img, t, pan=-t * 20 + 200, mode="bay")
    sweepy(img, t, 0)
    # spotlight cone
    tint(img, (255, 230, 150), 0.0)
    gtop = lambda val: GY + 6 - val * STK_PX
    val = 0.0
    if t >= q["tsold"]:
        val = 291 * ease((t - q["tsold"]) / (q["t91"] + 0.5 - q["tsold"]))
    draw_stack(img, val * STK_PX, t)
    # bots walking in
    mood = "smug"
    for i in (0, 1):
        d0 = q["tf"] + 0.3 * i
        u = clamp01((t - d0) / 1.1)
        x = lerp(-220, (130, 350)[i], ease(u))
        walking = 0 < u < 1
        ph = t * 15
        leg = _m.sin(ph) if walking else 0
        dy = -abs(_m.sin(ph)) * 10 if walking else 0
        clip = ""
        if t >= q["tbet"]:
            clip = "$256M"
        mood = "smug"
        if t >= q["trec"]:
            mood = "worry"
        jaw = 0.0
        sq = 0.0
        if u >= 1:
            k = t - (d0 + 1.1)
            sq = 0.07 * _m.exp(-8 * k) * _m.cos(18 * k)
        put_bot(img, i, x, GY + 20 + dy, 1.05, 1 + sq, 1 - sq, _m.sin(ph) * 3 if walking else 0, mood=mood, leg=leg, clip=clip, sweat=1 if t >= q["trec"] + 0.3 else 0, jaw=0.0)
    # Patch + coin toss
    ent = clamp01((t - 0.2) / 0.4)
    pa = 8
    if q["tsold"] <= t < q["t91"] + 0.5:
        pa = 100 + swob(t, 5, 40)
    eyes, mouth = ("happy", "grin") if t >= q["tsold"] else ("open", "smile")
    sqp = 0.0
    if t >= q["trec"]:
        sqp = 0.06 * _m.sin((t - q["trec"]) * 16) * _m.exp(-(t - q["trec"]) * 2)
    put_patch(img, 910, GY + 6 - (1 - spr(t, 12, 6)) * 600, 1.2, 1 - sqp, 1 + sqp, 0, icon="wrench", eyes=eyes, mouth=mouth, al=pa, ar=8, cheeks=1)
    if q["tsold"] <= t < q["t91"] + 0.5:
        for j in range(12):
            tj = q["tsold"] + 0.08 + j * 0.1
            u = (t - tj) / 0.45
            if 0 <= u < 1:
                x = lerp(870, STK_X, ease(u))
                y = lerp(GY - 150, gtop(val) - 10, ease(u)) - 160 * _m.sin(_m.pi * u)
                ImageDraw.Draw(img).ellipse((x - 20, y - 8, x + 20, y + 10), fill=GLD + (255,), outline=INKB + (255,), width=4)
    # labels
    if q["tw"] <= t < q["tbet"]:
        spill(img, 260, 560, "ANALYST BOTS", 62, BOTC, tc=CRM, padx=40, sc=pop((t - q["tw"]) / 0.3), ow=7)
    if q["tbet"] <= t < q["trec"] - 0.05:
        n256 = int(256 * ease((t - q["t256"]) / (q["t56"] + 0.3 - q["t256"]))) if t >= q["t256"] else 0
        txt = f"${n256}M BET" if t >= q["t256"] else "THE BET"
        spill(img, 270, 560, txt, 66, CRM, tc=RED, padx=40, sc=pop((t - q["tbet"]) / 0.3), ow=7, w_min=420)
    if t >= q["t56"]:
        dashed(img, 30, 740, int(gtop(256)), RED, ease((t - q["t56"]) / 0.4), w=8)
    if val > 1:
        spill(img, STK_X + 60, max(430, gtop(val) - 70), f"${int(val)}M", 78, GLD, tc=INKB, padx=34, ow=7, sc=1.0)
    if t >= q["trec"]:
        k = t - q["trec"]
        sc = lerp(2.2, 1.0, spr(k, 16, 7)) if k < 0.8 else 1.0
        stext(img, (640, 880), "RECORD Q3", 104, RED, sw=14, rot=-12, sc=sc)
        if k < 0.5:
            CAM["dx"], CAM["dy"] = shake(12 * (1 - k / 0.5), t)
            sburst(img, 640, 880, 160 + 120 * ease(k / 0.4), 260 + 150 * ease(k / 0.4), 12, k, (255, 214, 92, 255), 8, alpha=1 - k / 0.5)
    if t >= q["t118"]:
        k = t - q["t118"]
        n118 = int(118 * ease(k / max(0.3, q["te"] + 0.3 - q["t118"]))) if k < 5 else 118
        card_text(img, 300, 470, 520, 190, [f"+{n118}%", "vs A YEAR AGO"], [92, 56], [GLD, CRM], sc=pop(k / 0.3))


# ---------------------------------------------------------------- BEAT 5: shock, but wait, the note
def c5(c):
    return dict(tsh=c.at("shocked", 0.7), tbut=c.at("But", 1.2), tpin=c.at("pins", 1.6), tnote=c.at("note", 2.0), tgu=c.at("guidance", 5.0),
                t335=c.at("three hundred", 5.9), tmil=c.at("million", 7.3))


def scene_sv_shock(img, v, t, spec, cues):
    q = c5(cues)
    FZ = 0.4
    ta = t if t < q["tbut"] else (q["tbut"] if t < q["tbut"] + FZ else t - FZ)
    sv_bg(img, ta, pan=ta * 20, mode="hall", alert=0.0)
    sweepy(img, ta, ta * 20)
    # rack (idle, worried) right
    put_rack(img, 840, GY + 36, 0.9, look=-0.6, blink=0.0, mouth="relief" if ta > q["tnote"] else "worry", cells={i: ("ok", 5.0) for i in range(8)}, now=ta, brow=0.0)
    # bots
    for i in (0, 1):
        x = (150, 360)[i]
        kk = max(0.0, ta - q["tsh"])
        jaw = spr(kk, 14, 6) * 1.0 if ta >= q["tsh"] else 0.0
        jaw = min(1.0, jaw)
        gl = clamp01(kk / 0.25) * (1 if ta >= q["tsh"] else 0)
        sn = 1 if ta >= q["tsh"] + 0.15 else 0
        hop = -abs(_m.sin(kk * 9)) * 20 * _m.exp(-kk * 2) if ta >= q["tsh"] else 0
        put_bot(img, i, x, GY + 20 + hop, 1.05, 1, 1, swob(ta, 6, 2) * _m.exp(-kk * 2) if ta >= q["tsh"] else 0, mood="shock" if ta >= q["tsh"] else "worry",
                jaw=round(jaw, 1), glass=round(gl, 1), clip="$256M" if ta < q["tsh"] else "", snap=sn, sweat=1)
    # pencil halves flying
    if t >= q["tsh"] + 0.15:
        k = t - q["tsh"] - 0.15
        if t >= q["tbut"]:
            k = q["tbut"] - q["tsh"] - 0.15 if t < q["tbut"] + FZ else k - FZ
        for sg, rot0 in ((-1, 1), (1, -1)):
            x = 100 + sg * 160 * k
            y = 900 - 420 * k + 1200 * k * k
            T = pencil_half(0 if sg < 0 else 1)
            blit(img, T, x, y, 22, 40, 2.0, 2.0, rot0 * k * 500)
    # Patch with note
    ppx = 600
    pj = 0.0
    if t >= q["tpin"] - 0.3 and t < q["tnote"] + 0.3:
        pj = 120 * _m.sin(clamp01((t - (q["tpin"] - 0.3)) / 0.6) * _m.pi)
    put_patch(img, ppx, GY - pj, 1.25, 1, 1, 0, icon="wrench", eyes="happy" if t > q["tnote"] else "lookl", mouth="grin" if t > q["tpin"] else "smirk", al=8, ar=150 if t < q["tnote"] else 60, cheeks=1)
    # BUT WAIT
    if q["tbut"] <= t < q["tbut"] + 1.0:
        k = t - q["tbut"]
        tint(img, (0, 0, 0), 0.35 * (1 - clamp01((k - FZ) / 0.4)))
        speed_lines(img, 540, 800, k, a=190)
        stext(img, (540, 760), "BUT WAIT", 150, RED, sw=16, rot=-4, sc=lerp(2.0, 1.0, spr(k, 16, 7)))
        if k < 0.3:
            CAM["dx"], CAM["dy"] = shake(12, t)
    # note
    if t >= q["tnote"]:
        k = t - q["tnote"]
        sc = lerp(2.4, 1.0, ease(k / 0.18)) if k < 0.18 else 1.0 + 0.05 * _m.exp(-12 * (k - 0.18)) * _m.cos(30 * (k - 0.18))
        T = _ss(760, 480, lambda d, kk: SP(d, kk).rr((14, 14, 746, 466), 18, (255, 226, 110), 9))
        dd = ImageDraw.Draw(T)
        dd.text((380, 96), "NEXT QUARTER,", font=font("bold", 58), fill=INKB + (255,), anchor="mm")
        dd.text((380, 164), "OUR OWN FORECAST:", font=font("bold", 58), fill=INKB + (255,), anchor="mm")
        if t >= q["t335"]:
            u = clamp01((t - q["t335"]) / 0.9)
            n = int(335 * ease(u))
            dd.text((380, 330), f"~${n}M", font=font("bold", 150), fill=(200, 40, 30, 255), anchor="mm")
        else:
            dd.text((380, 330), "~$???", font=font("bold", 150), fill=(150, 120, 60, 255), anchor="mm")
        dd.ellipse((350, 4, 410, 54), fill=RED + (255,), outline=INKB + (255,), width=6)
        blit(img, T, 540, 810, 380, 240, sc, sc, -3)
        if k < 0.4:
            ImageDraw.Draw(img).ellipse((540 - 500 * ease(k / 0.4), 810 - 200 * ease(k / 0.4), 540 + 500 * ease(k / 0.4), 810 + 200 * ease(k / 0.4)), outline=(255, 255, 255, int(255 * (1 - k / 0.4))), width=8)
    if t >= q["tgu"]:
        spill(img, 540, 1090, "= GUIDANCE", 76, GLD, tc=INKB, padx=50, sc=pop((t - q["tgu"]) / 0.3), ow=8)
    if t >= q["tmil"] - 0.05:
        k = t - q["tmil"]
        if k < 0.5:
            sburst(img, 540, 810, 300 + 150 * ease(k / 0.4), 380 + 200 * ease(k / 0.4), 14, k, (255, 214, 92, 255), 8, alpha=0.7 * (1 - k / 0.5))


# ---------------------------------------------------------------- BEAT 6: the gap (podium)
def c6(c):
    return dict(tavg=c.at("average", 0.9), tcons=c.at("consensus", 1.9), tonly=c.at("only", 2.8), t293=c.at("two hundred", 3.2), twh=c.at("Whoops", 5.0))


def pillar(img, x0, x1, top, base, col, lines, sizes, tcols, num, sc_a=1.0):
    h = base - top
    if h < 4:
        return
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((x0, top, x1, base + 20), radius=26, fill=col + (255,), outline=INKB + (255,), width=9)
    d.rounded_rectangle((x0 + 18, top + 14, x1 - 18, top + 28), radius=7, fill=mix(col, (255, 255, 255), 0.3) + (255,))
    y = top + 40
    for ln_, sz, tc in zip(lines, sizes, tcols):
        d.text(((x0 + x1) / 2, y + sz * 0.5), ln_, font=font("bold", sz), fill=tc + (255,), anchor="mm")
        y += sz * 1.12
    d.text(((x0 + x1) / 2, y + 58), num, font=font("bold", 110), fill=CRM + (255,), anchor="mm", stroke_width=8, stroke_fill=INKB + (255,))


def scene_sv_gap(img, v, t, spec, cues):
    q = c6(cues)
    sv_bg(img, t, pan=t * 20, mode="bay")
    base = 1250
    # teal pillar (guidance) already up
    th = 519 * spr(t - 0.05, 11, 6.5)
    ttop = base - th
    gk = t - q["tavg"]
    gh = 454 * spr(gk, 11, 6.5) if gk > 0 else 0
    if t >= q["tonly"]:
        gh *= 1 - 0.2 * ease((t - q["tonly"]) / 0.35)
    gtop = base - gh
    if gh > 4:
        pillar(img, 30, 510, gtop, base, (120, 140, 168), ["FORECASTERS'", "AVERAGE", "(CONSENSUS)"], [56, 56, 56], [CRM, CRM, CRM], "$293M")
    pillar(img, 570, 1050, ttop, base, TLP, ["PATCH'S", "FORECAST", "(GUIDANCE)"], [56, 56, 56], [INKB, INKB, INKB], "$335M")
    # characters
    if th > 300:
        k = max(0.0, t - 0.5)
        put_patch(img, 810, ttop + 6, 0.98, 1, 1 - 0.04 * _m.sin(t * 5), 0, icon="shield", eyes="happy" if t < q["twh"] else "open", mouth="smirk" if t > q["tonly"] else "grin", al=130 + swob(t, 2, 20), ar=8, cheeks=1)
    if gh > 60:
        slip = t >= q["twh"]
        kk = t - q["twh"]
        bs = 0.76
        put_bot(img, 0, 270 + (-30 * ease(kk / 0.5) if slip else 0), gtop + 8 + (0 if not slip else 0), bs, 1, 1, (swob(t, 5, 6) * 1 if not slip else -25 * ease(kk / 0.5)), mood="worry" if t >= q["tonly"] else "smug",
                sweat=1 if t >= q["tonly"] else 0, clip="")
    # gap bracket
    if t >= q["tcons"] + 0.6 and gh > 60:
        a = ease((t - q["tcons"] - 0.6) / 0.3)
        dd = ImageDraw.Draw(img)
        dd.line([(540, gtop), (540, ttop)], fill=GLD + (255,), width=10)
        dd.polygon([(540, ttop - 4), (524, ttop + 24), (556, ttop + 24)], fill=GLD + (255,))
        dd.polygon([(540, gtop + 4), (524, gtop - 24), (556, gtop - 24)], fill=GLD + (255,))
        stext(img, (540, ttop - 64), "GAP", 70, GLD, sw=10, sc=max(0.01, a))
    if q["tonly"] <= t < q["twh"]:
        spill(img, 300, 520, "ONLY", 90, RED, tc=CRM, padx=50, sc=pop((t - q["tonly"]) / 0.25), rot=-5 + swob(t, 8, 2), ow=8)
    if t >= q["twh"]:
        k = t - q["twh"]
        stext(img, (300, 520), "WHOOPS.", 96, CRM, sw=11, sc=max(0.01, pop(k / 0.3)), rot=-5)
        CAM["dx"], CAM["dy"] = shake(6 * _m.exp(-k * 6), t)


# ---------------------------------------------------------------- BEAT 7: erase, shout, sigh, jump
def c7(c):
    return dict(te=c.at("erase", 0.2), trk=c.at("Rack", 0.9), tsh=c.at("shouts", 1.6), tpat=c.at("Patches", 2.3), tfr=c.at("Fred", 2.95),
                tsi=c.at("sighs", 3.3), tag=c.at("Again", 3.85), tst=c.at("Shares", 4.8), tj=c.at("jumped", 5.1))


def scene_sv_erase(img, v, t, spec, cues):
    q = c7(cues)
    pan = 880 * ease((t - (q["tfr"] - 0.55)) / 0.5)
    sv_bg(img, t, pan=pan + t * 10, mode="hall", alert=0.0)
    wx = lambda x: x - pan
    sweepy(img, t, pan)
    # --- forecasters + eraser
    for i in (0, 1):
        x = wx((130, 350)[i])
        if x < -400:
            continue
        clip = "$293M" if t < q["te"] + 0.35 else ("" if t < q["te"] + 0.9 else "^")
        mood = "worry" if t < q["te"] + 0.9 else "grin"
        put_bot(img, i, x, GY + 20, 1.0, 1, 1, swob(t, 4, 2) if t >= q["te"] + 0.9 else 0, mood=mood, clip=clip, sweat=1 if t < q["te"] + 0.9 else 0, leg=0)
    if q["te"] <= t < q["te"] + 1.1 and pan < 10:
        u = (t - q["te"]) / 1.0
        ex = lerp(-100, 520, ease(u)) + _m.sin(t * 30) * 24
        ey = 1000 + _m.sin(t * 14) * 20
        blit(img, eraser_tile(), ex, ey, 110, 60, 1.4, 1.4, -12)
        rnd = _rnd.Random(11)
        dd = ImageDraw.Draw(img)
        for j in range(18):
            tj = q["te"] + j * 0.05
            kk = t - tj
            if 0 < kk < 0.8:
                x = lerp(-100, 520, ease((tj - q["te"]) / 1.0)) + rnd.uniform(-30, 30) + rnd.uniform(-200, 200) * kk
                y = 1000 + rnd.uniform(-60, 0) - 300 * kk + 1000 * kk * kk
                s_ = rnd.uniform(8, 16)
                dd.rounded_rectangle((x - s_, y - s_, x + s_, y + s_), radius=4, fill=(255, 168, 168, 255), outline=INKB + (255,), width=3)
    # --- Rack
    rx = wx(800)
    shout = q["tsh"] <= t < q["tsh"] + 1.1
    sqr = 0.1 * _m.sin(clamp01((t - q["tsh"]) / 0.4) * _m.pi) if shout else 0
    shk = shake(6, t, 40) if shout else (0, 0)
    cells = {i: ("ok", 5.0) for i in range(8)}
    put_rack(img, rx + shk[0], GY + 36 + shk[1], 0.9, 1 - sqr * 0.5, 1 + sqr, 0, look=-0.5, blink=1.0 if blink_at(t, 0.4, 2.2) else 0, mouth="shout" if shout else "worry",
             cells=cells, now=t, panic=1.0 if t < q["tsh"] + 1.1 else 0.0, brow=1.0)
    if t >= q["trk"] and t < q["tsh"]:
        for j in range(4):
            k = t - q["trk"] - j * 0.2
            if 0 < k < 1:
                x = rx - 60 + j * 22
                y = 600 + 800 * k * k - 400 * k
                ImageDraw.Draw(img).polygon([(x, y - 18), (x - 10, y + 8), (x, y + 16), (x + 10, y + 8)], fill=(140, 210, 255, 255), outline=INKB + (255,))
    if shout:
        k = t - q["tsh"]
        bubble(img, (50, 450, 690, 630), tail=(rx - 120, 720), fill=(255, 255, 255, 255))
        stext(img, (370, 540), "MORE PATCHES!", 70, RED, sw=0, sc=max(0.01, spr(k, 16, 6)))
        CAM["dx"], CAM["dy"] = shake(8 * _m.exp(-k * 4), t)
        ring = 100 + 500 * ease(k / 0.8)
        ImageDraw.Draw(img).ellipse((rx - ring, 560 - ring, rx + ring, 560 + ring), outline=(255, 255, 255, int(200 * (1 - k / 0.8))), width=8)
    # --- Patches rain
    for i in range(11):
        tj = q["tpat"] + i * 0.11
        k = t - tj
        if k < 0:
            continue
        fx = 960 + (i * 83) % 230
        fall = 0.5
        ground = GY - (i % 3) * 64
        if k < fall:
            y = lerp(380, ground, (k / fall) ** 2)
            sq = 0
        else:
            kk = k - fall
            y = ground - abs(_m.sin(kk * 7)) * 30 * _m.exp(-kk * 4)
            sq = 0.2 * _m.exp(-12 * kk) * _m.cos(30 * kk)
        put_patch(img, wx(fx), y, 0.5, 1 + sq, 1 - sq, 0, icon="none", eyes="happy" if k > fall else "wide", mouth="grin", al=40, ar=40)
    # --- Fred
    fxs = wx(1300)
    if fxs < 1500:
        hit = t - q["tfr"]
        sqf = 0.0
        eyes, mouth = "sad", "frown"
        if hit >= 0:
            sqf = 0.2 * _m.exp(-8 * hit) * _m.cos(24 * hit) if hit < 1.0 else 0
            eyes, mouth = ("squish", "frown") if hit < 0.4 else ("sad", "frown")
        if q["tsi"] <= t:
            eyes, mouth = "closed", "o"
        put_fred(img, fxs, GY + 14, 1.1, 1 + sqf * 0.8, 1 - sqf, 0, eyes=eyes, mouth=mouth)
        # a patch lands on Fred's head
        kp = t - (q["tfr"] - 0.35)
        if 0 <= kp:
            y = lerp(380, GY - 330, clamp01(kp / 0.35) ** 2) if kp < 0.35 else GY - 330 - abs(_m.sin((kp - 0.35) * 7)) * 20 * _m.exp(-(kp - 0.35) * 4)
            put_patch(img, fxs, y, 0.45, 1, 1, 0, icon="none", eyes="happy", mouth="grin", al=40, ar=40)
        for tk_, big in ((q["tsi"], 1.0), (q["tag"], 1.5)):
            k = t - tk_
            if 0 <= k < 1.3:
                u = k / 1.3
                gx = fxs + 60 + 140 * u
                gy_ = GY - 120 - 280 * u
                T = _ss(160, 160, lambda d, kk: draw_icon(SP(d, kk), "gear", 80, 80, 1.5 * big, (200, 206, 216), (11, 37, 48)))
                T.putalpha(T.getchannel("A").point(lambda a: int(a * (1 - u))))
                blit(img, T, gx, gy_, 80, 80, 0.8 + 0.6 * u, 0.8 + 0.6 * u, u * 90)
        if t >= q["tag"]:
            stext(img, (fxs + 160, 520), "AGAIN.", 100, CRM, sw=12, sc=max(0.01, pop((t - q["tag"]) / 0.3)), rot=4)
    # --- ladder + stock jump
    lx = wx(1700)
    if lx < 1500:
        dd = ImageDraw.Draw(img)
        for rail in (-90, 90):
            dd.rounded_rectangle((lx + rail - 11, 560, lx + rail + 11, 1290), radius=8, fill=(214, 220, 230, 255), outline=INKB + (255,), width=5)
        for yy in range(600, 1280, 70):
            dd.rounded_rectangle((lx - 90, yy, lx + 90, yy + 16), radius=6, fill=(160, 170, 184, 255), outline=INKB + (255,), width=4)
        if t >= q["tst"]:
            u = clamp01((t - q["tst"]) / (q["tj"] - q["tst"] - 0.05))
            step = int(u * 9)
            by = 1170 - step * 60 + abs(_m.sin(u * 9 * _m.pi)) * -20
            if t >= q["tj"]:
                k = t - q["tj"]
                by = lerp(1170 - 9 * 60, 640, ease(k / 0.35)) - 90 * _m.sin(_m.pi * clamp01(k / 0.35))
                sc = 1.0 + 0.2 * _m.sin(clamp01(k / 0.5) * _m.pi)
                if k < 0.7:
                    sburst(img, lx, 640, 160 + 80 * ease(k / 0.4), 250 + 120 * ease(k / 0.4), 12, k, (255, 214, 92, 255), 8, alpha=1 - k / 0.7)
            else:
                sc = 0.8
            spill(img, lx, by, "+13%", 96, GLD, tc=INKB, padx=38, sc=sc, ow=8)
            if t >= q["tj"]:
                stext(img, (lx, 520), "IN MORNING", 56, CRM, sw=8)
                stext(img, (lx, 584), "TRADING", 56, CRM, sw=8)


# ---------------------------------------------------------------- BEAT 8: lesson + loop
def c8(c):
    return dict(tg=c.at("guidance", 1.6), tc=c.at("consensus", 2.4), tab=c.at("above", 5.0), tit=c.at("above", 5.0) + 0.5, tth=c.at("that's", 6.0), tw=c.at("why", 6.3),
                tl0=c.at("Analysts", 0.1), th=c.at("Here,", 3.4), tcame=c.at("came", 4.2))


def scene_sv_close(img, v, t, spec, cues):
    q = c8(cues)
    img.paste(Image.new("RGBA", (W, H), NAVY + (255,)), (0, 0))
    rays(img, 540, 900, 0, 2400, 18, t * 0.1, (14, 50, 64), None, 0.5)
    for j in range(6):
        px_ = (j * 220 + 80 + t * (18 + 7 * j)) % 1300 - 110
        py_ = (470 + (j % 2) * 60 if j < 3 else 1130 + (j % 2) * 80) + _m.sin(t * 1.6 + j) * 16
        put_patch(img, px_, py_, 0.3 + 0.05 * (j % 3), 1, 1, swob(t, 0.4, 8) + j * 10, icon=("wrench", "magnifier", "shield")[j % 3], eyes="happy", mouth="smile", al=30, ar=30)
    LINES = [(["ANALYSTS", "COMPARE"], q["tl0"], None), (["GUIDANCE", "WITH"], q["tg"], (0, TLP, q["tg"])), (["CONSENSUS."], q["tc"], (0, GRY, q["tc"])),
             (["HERE,", "GUIDANCE"], q["th"], None), (["CAME", "IN", "ABOVE", "IT."], q["tcame"], (2, GLD, q["tab"]))]
    d = ImageDraw.Draw(img)
    size = 82
    f = font("bold", size)
    gap = 24
    outk = clamp01((t - (q["tth"] - 0.1)) / 0.25)
    for li, (words, tl_, hl) in enumerate(LINES):
        tl_ = max(0.1, tl_ - 0.1) if li else 0.1
        if t < tl_:
            continue
        widths = [int(d.textlength(w_, font=f)) for w_ in words]
        total = sum(widths) + gap * (len(words) - 1)
        pk = max(0.01, pop((t - tl_) / 0.3) * (1 - ease(outk)))
        y = 500 + li * 118
        x = 540 - total / 2
        xs = []
        for wi in range(len(words)):
            xs.append(x)
            x += widths[wi] + gap
        act = None
        if hl and t >= hl[2]:
            act = hl
            pr = ease((t - hl[2]) / 0.28)
            x0m, x1m = xs[hl[0]] - 14, xs[hl[0]] + widths[hl[0]] + 14
            ph = 102 * pk
            d.rounded_rectangle((x0m, y - ph / 2, x0m + (x1m - x0m) * pr, y + ph / 2), radius=26, fill=hl[1] + (255,), outline=INKB + (255,), width=6)
        for wi, w_ in enumerate(words):
            on = act is not None and wi == act[0]
            stext(img, (xs[wi] + widths[wi] / 2, y), w_, size, INKB if on else CRM, sw=0 if on else 8, sc=pk)
    if t >= q["tit"] and t < q["tth"] + 0.1:
        pk = pop((t - q["tit"]) / 0.3) * (1 - outk)
        spill(img, 470, 1130, "FOLLOW @whyitmoved", 60, RED, tc=CRM, padx=44, sc=max(0.01, pk), ow=8)
    if t < 0.5:
        rr_ = int(1800 * (1 - ease(t / 0.5)))
        ImageDraw.Draw(img).ellipse((540 - rr_, 960 - rr_, 540 + rr_, 960 + rr_), fill=TLP + (255,), outline=INKB + (255,), width=12)
    if t >= q["tth"]:
        k = t - q["tth"]
        hk = Image.new("RGBA", (W, H), (0, 0, 0, 255))
        hook_draw(hk, 0.0, 1.0, 3.5, 4.2, final=True)
        mask = Image.new("L", (W, H), 0)
        rr2 = int(1700 * ease(k / 0.35))
        ImageDraw.Draw(mask).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), fill=255)
        img.paste(hk, (0, 0), mask)
        if k < 0.35:
            ImageDraw.Draw(img).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), outline=INKB + (255,), width=10)


# ---------------------------------------------------------------- sound
def _ev2(v, c, st):
    q = c2(c)
    ev = [(st + q["tp"], "pop"), (st + q["tp"] + 0.1, "rubber"), (st + q["tpr"], "pop"), (st + q["tcu"], "sparkle"), (st + q["tsw1"], "boing"), (st + q["tsw2"], "boing"),
          (st + q["tfx"] - 0.1, "whoosh1"), (st + q["tfx"] + 0.5, "thud"), (st + q["tcant"], "scratch"), (st + q["tcant"] - 0.4, "tick"), (st + q["tone"], "stamp"), (st + q["tfor"], "trombone")]
    ev += [(st + q["tfx"] + 0.2 + j * 0.15, "tick") for j in range(0)]
    return ev


def _ev3(v, c, st):
    q = c3(c)
    ev = [(st + 0.3, "thud"), (st + q["tpan"] - 0.1, "alarm"), (st + q["tpan"] + 0.3, "alarm"), (st + q["tpan"] + 0.7, "alarm")]
    ev += [(st + q["tslot"] + i * 0.1, "pop") for i in range(8)]
    ev += [(st + q["thelp"] + 0.45 + i * 0.16, "pop") for i in range(2)]
    ev += [(st + q["tmore"] + 0.45 + i * 0.13, "pop") for i in range(6)]
    ev += [(st + q["tmg"], "stamp"), (st + q["teach"] + 0.6, "ding")]
    return ev


def _ev4(v, c, st):
    q = c4(c)
    ev = [(st + q["tf"] + 0.1, "tick"), (st + q["tw"], "pop"), (st + q["tbet"], "pop"), (st + q["t56"], "whoosh1"), (st + q["tsold"], "boing")]
    ev += [(st + q["tsold"] + 0.08 + j * 0.1 + 0.4, "coin") for j in range(12)]
    ev += [(st + q["trec"], "stamp"), (st + q["trec"], "thud"), (st + q["t118"], "pop"), (st + q["te"] + 0.3, "ding")]
    return ev


def _ev5(v, c, st):
    q = c5(c)
    return [(st + q["tsh"], "boing"), (st + q["tsh"] + 0.15, "snap"), (st + q["tbut"], "scratch"), (st + q["tbut"] + 0.4, "stamp"),
            (st + q["tnote"], "tack"), (st + q["tgu"], "pop"), (st + q["t335"], "whoosh2"), (st + q["tmil"], "sparkle")]


def _ev6(v, c, st):
    q = c6(c)
    return [(st + 0.05, "thud"), (st + q["tavg"], "whoosh1"), (st + q["tcons"] + 0.6, "pop"), (st + q["tonly"], "wah"), (st + q["twh"], "trombone")]


def _ev7(v, c, st):
    q = c7(c)
    ev = [(st + q["te"], "scrub"), (st + q["tsh"], "shout"), (st + q["tfr"] - 0.1, "whoosh1"), (st + q["tfr"], "boing"), (st + q["tsi"], "sigh"), (st + q["tag"], "sigh"),
          (st + q["tj"], "cash"), (st + q["tj"], "ding")]
    ev += [(st + q["tpat"] + i * 0.11 + 0.5, "pop") for i in range(0, 11, 2)]
    return ev


def _ev8(v, c, st):
    q = c8(c)
    return [(st + 0.05, "whoosh2"), (st + q["tg"], "pop"), (st + q["tc"], "pop"), (st + q["tit"], "stamp"), (st + q["tth"], "whoosh1"), (st + q["tth"] + 0.25, "ding")]


def _ev1(v, c, st):
    return [(st + 0.0, "impact"), (st + c.at("thirteen", 1.0), "ding"), (st + c.at("thirteen", 1.0), "stamp"), (st + 0.75, "boing"), (st + 1.5, "boing"),
            (st + c.at("cartoon", 3.5), "whoosh1"), (st + c.at("dramatization", 4.2), "pop")]


SV_EVENTS = {"sv_hook": _ev1, "sv_meet": _ev2, "sv_rack": _ev3, "sv_bet": _ev4, "sv_shock": _ev5, "sv_gap": _ev6, "sv_erase": _ev7, "sv_close": _ev8}
SCENES.update({"sv_hook": scene_sv_hook, "sv_meet": scene_sv_meet, "sv_rack": scene_sv_rack, "sv_bet": scene_sv_bet, "sv_shock": scene_sv_shock,
               "sv_gap": scene_sv_gap, "sv_erase": scene_sv_erase, "sv_close": scene_sv_close})


def _sfx_sv(kind, sr, rng):
    import numpy as np
    if kind == "trombone":
        out = np.zeros(int(1.5 * sr))
        for j, (f0, f1, st_, dur) in enumerate(((233, 220, 0.0, 0.3), (220, 207, 0.33, 0.3), (207, 196, 0.66, 0.3), (196, 150, 0.99, 0.5))):
            n = int(dur * sr); tt = np.arange(n) / sr
            f = np.linspace(f0, f1, n) * (1 + 0.015 * np.sin(2 * np.pi * 6 * tt))
            saw = 2 * ((np.cumsum(f) / sr) % 1.0) - 1
            x = _onepole(saw, 900, sr) * np.minimum(1, tt / 0.02) * np.minimum(1, (dur - tt) / 0.06)
            s0 = int(st_ * sr)
            out[s0:s0 + n] += x
        return out / (np.abs(out).max() + 1e-9)
    if kind == "alarm":
        n = int(0.3 * sr); tt = np.arange(n) / sr
        f = np.where(tt < 0.15, 880, 660)
        return np.sign(np.sin(2 * np.pi * np.cumsum(f) / sr)) * 0.5 * np.minimum(1, (0.3 - tt) / 0.03)
    if kind == "coin":
        n = int(0.4 * sr); tt = np.arange(n) / sr
        return (np.sin(2 * np.pi * 1976 * tt) * np.exp(-tt * 18) + np.sin(2 * np.pi * 2637 * np.maximum(0, tt - 0.07)) * np.exp(-np.maximum(0, tt - 0.07) * 14) * (tt > 0.07)) * 0.8
    if kind == "tack":
        n = int(0.25 * sr); tt = np.arange(n) / sr
        return np.sin(2 * np.pi * 110 * tt) * np.exp(-tt * 30) + np.sin(2 * np.pi * 3200 * tt) * np.exp(-tt * 60) * 0.5 + np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 150) * 0.3
    if kind == "shout":
        n = int(0.7 * sr); tt = np.arange(n) / sr
        f = 150 - 40 * tt + 6 * np.sin(2 * np.pi * 9 * tt)
        saw = 2 * ((np.cumsum(f) / sr) % 1.0) - 1
        x = _onepole(saw, 1100, sr) + 0.3 * _onepole(rng.standard_normal(n), 2000, sr)
        return x / (np.abs(x).max() + 1e-9) * np.minimum(1, tt / 0.03) * np.exp(-tt * 2.5)
    if kind == "sigh":
        n = int(0.9 * sr); tt = np.arange(n) / sr
        x = _onepole(rng.standard_normal(n), 900 - 500 * tt, sr)
        return x / (np.abs(x).max() + 1e-9) * np.sin(np.pi * np.minimum(1, tt / 0.9)) ** 1.5 * 0.8
    if kind == "rubber":
        n = int(0.3 * sr); tt = np.arange(n) / sr
        f = 700 + 900 * tt + 80 * np.sin(2 * np.pi * 22 * tt)
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 8)
    if kind == "tick":
        n = int(0.05 * sr); tt = np.arange(n) / sr
        return np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 140)
    if kind == "poof":
        n = int(0.3 * sr); tt = np.arange(n) / sr
        x = _onepole(rng.standard_normal(n), 1200, sr)
        return x / (np.abs(x).max() + 1e-9) * np.exp(-tt * 12)
    if kind == "cash":
        n = int(0.9 * sr); out = np.zeros(n); tt = np.arange(n) / sr
        out += np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 60) * 0.4
        for s0, fq in ((0.12, 2349), (0.22, 3136)):
            m = n - int(s0 * sr); t2 = np.arange(m) / sr
            out[int(s0 * sr):] += np.sin(2 * np.pi * fq * t2) * np.exp(-t2 * 7)
        return out
    raise ValueError(kind)


def music_bed_sv(total, sr, rng):
    """Playful techy bed: square-ish arp + bouncy bass + soft kick/hat, 124 bpm, Am F C G; builds through the panic and payoff."""
    import numpy as np
    n = int(total * sr)
    out = np.zeros(n)
    hz = lambda m: 440 * 2 ** ((m - 69) / 12)
    chords = [(45, [57, 60, 64, 69]), (41, [57, 60, 65, 69]), (48, [60, 64, 67, 72]), (43, [59, 62, 67, 71])]
    beat = 60 / 124.0

    def note(t0, fq, dur, amp, kind):
        s0 = int(t0 * sr)
        if s0 >= n:
            return
        m = min(n - s0, int(dur * sr))
        tt = np.arange(m) / sr
        if kind == "bass":
            w = np.sin(2 * np.pi * fq * tt) + 0.35 * np.sign(np.sin(2 * np.pi * fq * tt))
            e = np.exp(-tt * 6) * np.minimum(1, tt / 0.004)
        elif kind == "kick":
            w = np.sin(2 * np.pi * np.cumsum(120 * np.exp(-tt * 25) + 45) / sr)
            e = np.exp(-tt * 14)
        else:
            w = np.sign(np.sin(2 * np.pi * fq * tt)) * 0.5 + np.sin(2 * np.pi * fq * tt) * 0.5
            e = np.exp(-tt * 10) * np.minimum(1, tt / 0.003)
        out[s0:s0 + m] += w * e * amp
    nb = int(total / beat) + 2
    for b in range(nb):
        bar, bt = divmod(b, 4)
        root, tones = chords[bar % 4]
        t0 = b * beat
        tsec = t0
        inten = 0.6 + 0.4 * (1 if (16 < tsec < 34 or tsec > 44) else 0.3)
        if bt in (0, 2):
            note(t0, hz(root - 12), 0.35, 0.8, "bass")
        elif bt == 3:
            note(t0 + beat * 0.5, hz(root - 5), 0.25, 0.5, "bass")
        for h in range(2):
            idx = (b * 2 + h) % 4
            note(t0 + h * beat / 2, hz(tones[idx]), 0.2, 0.26 * inten, "pluck")
        if tsec > 3 and bt in (0, 2):
            note(t0, 60, 0.2, 0.7 * (0.6 if tsec < 16 else 1), "kick")
        s0 = int((t0 + beat / 2) * sr)
        m = min(n - s0, int(0.04 * sr))
        if m > 0 and tsec > 6:
            out[s0:s0 + m] += np.diff(rng.standard_normal(m + 1)) * np.exp(-np.arange(m) / (0.01 * sr)) * 0.14
    return out / (np.abs(out).max() + 1e-9)


# ================================================================= B3: Bram, Beam and the Coupon Swap
CYAN = (143, 243, 255)
CYAND = (70, 190, 214)
COPPER = (224, 138, 60)
REDD = (96, 26, 24)
PINK = (255, 150, 170)


def sv_header(img, spec, now, total):
    d = ImageDraw.Draw(img)
    d.rectangle((0, 0, W, 366), fill=(5, 18, 26, 255))
    d.rectangle((0, 366, W, 374), fill=TLP + (255,))
    d.rectangle((0, 214, W, 222), fill=(16, 52, 66, 255))
    d.rectangle((0, 214, int(W * clamp01(now / total)), 222), fill=GLD + (255,))
    spill(img, 215, 272, "MRVL -12.7%", 44, RED, tc=CRM, padx=24, h=66, ow=5)
    spill(img, 530, 272, "LITE -18.6%", 44, RED, tc=CRM, padx=24, h=66, ow=5)
    d = ImageDraw.Draw(img)
    d.text((700, 272), "MON CLOSE", font=font("bold", 24), fill=DIMC + (255,), anchor="lm")
    d.text((W - 50, 250), "WHY IT", font=font("bold", 30), fill=GLD + (255,), anchor="rm")
    d.text((W - 50, 284), "MOVED?", font=font("bold", 30), fill=CRM + (255,), anchor="rm")
    d.text((60, 313), "Educational only - not financial advice", font=font("medium", 25), fill=DIMC + (255,), anchor="lm")
    d.text((60, 346), "DRAMATIZATION - CARTOON, NOT REAL EVENTS", font=font("bold", 34), fill=(170, 186, 194, 255), anchor="lm")


def heart(p, cx, cy, s, col=PINK):
    p.el((cx - 18 * s, cy - 16 * s, cx, cy + 4 * s), col, 0)
    p.el((cx, cy - 16 * s, cx + 18 * s, cy + 4 * s), col, 0)
    p.poly([(cx - 17 * s, cy - 4 * s), (cx + 17 * s, cy - 4 * s), (cx, cy + 20 * s)], col, 0)


# ---------------------------------------------------------------- BRAM (chip brain)
def bram_tile(eyes="worry", mouth="nerv", al=8, ar=8, sweat=1, tie=0):
    al, ar = int(round(al / 15.0)) * 15, int(round(ar / 15.0)) * 15
    key = ("bram", eyes, mouth, al, ar, sweat, tie)

    def fn(d, k):
        p = SP(d, k)
        for i in range(3):
            cx = 90 + 220 * (i + 0.5) / 3
            p.rr((cx - 10, 42, cx + 10, 78), 5, PINC, 6)
            p.rr((cx - 10, 282, cx + 10, 324), 5, PINC, 6)
            cy = 70 + 220 * (i + 0.5) / 3
            p.rr((56, cy - 10, 98, cy + 10), 5, PINC, 6)
            p.rr((302, cy - 10, 344, cy + 10), 5, PINC, 6)
        _arm(p, -1, al, TLP, TLL)
        _arm(p, 1, ar, TLP, TLL)
        p.rr((90, 70, 310, 290), 40, TLP, 10)
        p.rr((106, 82, 250, 94), 6, TLL, 0)
        # brain window
        p.rr((122, 84, 278, 162), 26, (150, 232, 218), 7)
        p.ln([(200, 92), (200, 154)], 5, TLD)
        p.arc((134, 92, 198, 138), 170, 320, 5, TLD)
        p.arc((202, 92, 266, 138), 220, 10, 5, TLD)
        p.arc((136, 116, 198, 160), 20, 170, 5, TLD)
        p.arc((202, 116, 264, 160), 10, 160, 5, TLD)
        # coupon-pouch belt
        p.rr((90, 268, 310, 290), 8, (196, 146, 92), 7)
        p.rr((246, 252, 304, 300), 12, (170, 120, 70), 7)
        p.poly([(258, 254), (282, 238), (292, 258)], GLD, 5)
        p.poly([(266, 254), (294, 244), (298, 262)], (240, 176, 40), 5)
        if tie:
            p.poly([(200, 284), (148, 262), (148, 308)], RED, 6)
            p.poly([(200, 284), (252, 262), (252, 308)], RED, 6)
            p.el((186, 270, 214, 298), RED, 6)
        cy = 202
        for sg, ex in ((-1, 158), (1, 242)):
            if eyes in ("worry", "open", "lookr", "wide"):
                big = 26 if eyes == "wide" else 22
                lx = 8 if eyes == "lookr" else 0
                p.el((ex - big, cy - big - 2, ex + big, cy + big + 2), (255, 255, 255), 6)
                pr = 6 if eyes == "wide" else 9
                p.el((ex - pr + lx, cy - pr, ex + pr + lx, cy + pr + 4), INKB, 0)
                p.el((ex - 3 + lx, cy - 6, ex + 3 + lx, cy), (255, 255, 255), 0)
                if eyes == "worry":
                    if sg < 0:
                        p.ln([(ex - 22, cy - 38), (ex + 20, cy - 52)], 8)
                    else:
                        p.ln([(ex + 22, cy - 38), (ex - 20, cy - 52)], 8)
            elif eyes == "blink":
                p.ln([(ex - 18, cy + 4), (ex + 18, cy + 4)], 8)
            elif eyes == "happy":
                p.arc((ex - 19, cy - 10, ex + 19, cy + 26), 200, 340, 8)
            elif eyes == "heart":
                heart(p, ex, cy, 1.2)
            elif eyes == "squint":
                if sg < 0:
                    p.ln([(ex - 18, cy - 14), (ex + 10, cy + 2), (ex - 18, cy + 18)], 8)
                else:
                    p.ln([(ex + 18, cy - 14), (ex - 10, cy + 2), (ex + 18, cy + 18)], 8)
        if mouth == "nerv":
            p.ln([(172, 250), (184, 242), (196, 252), (208, 242), (220, 252), (230, 244)], 6)
        elif mouth == "grin":
            p.pie((168, 226, 232, 268), 0, 180, (120, 30, 40), 7)
        elif mouth == "smile":
            p.arc((172, 222, 228, 258), 20, 160, 8)
        elif mouth == "o":
            p.el((188, 232, 212, 262), (120, 30, 40), 6)
        elif mouth == "open":
            p.el((180, 232, 220, 264), (120, 30, 40), 7)
        elif mouth == "sad":
            p.arc((176, 240, 224, 274), 200, 340, 7)
        elif mouth == "flat":
            p.ln([(182, 252), (218, 252)], 7)
        if sweat:
            p.poly([(302, 92), (290, 122), (302, 136), (314, 122)], (140, 210, 255), 5)
        if sweat > 1:
            p.poly([(86, 120), (76, 146), (86, 158), (96, 146)], (140, 210, 255), 5)
    return _svc(key, 400, 340, fn)


def put_bram(layer, x, y, sc=1.0, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, bram_tile(**kw), x, y, 200, 324, sc * sx, sc * sy, rot)


# ---------------------------------------------------------------- BEAM (laser)
def beam_tile(eyes="lookl", mouth="smile", al=8, ar=8, glow=0.5, brow=0, blush=1):
    al, ar = int(round(al / 15.0)) * 15, int(round(ar / 15.0)) * 15
    key = ("beam", eyes, mouth, al, ar, round(glow * 2) / 2, brow, blush)

    def fn(d, k):
        p = SP(d, k)
        for sg, sx_ in ((-1, 112), (1, 288)):
            a = al if sg < 0 else ar
            ar_ = _m.radians(a)
            hx, hy = sx_ + sg * _m.sin(ar_) * 70, 330 + _m.cos(ar_) * 70
            p.ln([(sx_, 330), (hx, hy)], 28, INKB)
            p.ln([(sx_, 330), (hx, hy)], 17, CYAN)
            p.el((hx - 17, hy - 17, hx + 17, hy + 17), (230, 252, 255), 7)
        p.rr((140, 530, 192, 568), 12, CYAND, 7)
        p.rr((208, 530, 260, 568), 12, CYAND, 7)
        p.rr((110, 90, 290, 545), 90, CYAN, 10)
        p.rr((124, 410, 276, 446), 10, CYAND, 0)
        p.rr((132, 120, 152, 380), 10, (235, 253, 255), 0)
        # nozzle (left) + glow lens
        p.rr((66, 148, 120, 206), 12, (110, 210, 228), 8)
        gl = mix((200, 240, 250), (255, 255, 255), glow)
        p.el((56, 156, 86, 198), gl, 6)
        # top dome
        p.rr((160, 64, 240, 110), 20, CYAND, 8)
        p.el((184, 72, 216, 98), mix((220, 250, 255), (255, 255, 255), glow), 0)
        cy = 252
        for sg, ex in ((-1, 162), (1, 238)):
            if eyes in ("lookl", "open", "wide"):
                big = 28 if eyes == "wide" else 24
                lx = -9 if eyes == "lookl" else 0
                p.el((ex - big, cy - big - 2, ex + big, cy + big + 2), (255, 255, 255), 6)
                p.el((ex - 9 + lx, cy - 9, ex + 9 + lx, cy + 11), INKB, 0)
                p.el((ex - 3 + lx, cy - 7, ex + 3 + lx, cy - 1), (255, 255, 255), 0)
            elif eyes == "blink":
                p.ln([(ex - 18, cy + 4), (ex + 18, cy + 4)], 8)
            elif eyes == "happy":
                p.arc((ex - 20, cy - 10, ex + 20, cy + 26), 200, 340, 8)
            elif eyes == "sleepy":
                p.el((ex - 22, cy - 18, ex + 22, cy + 22), (255, 255, 255), 6)
                p.el((ex - 8, cy + 0, ex + 8, cy + 18), INKB, 0)
                p.rr((ex - 25, cy - 22, ex + 25, cy + 2), 4, CYAN, 0)
                p.ln([(ex - 23, cy + 2), (ex + 23, cy + 2)], 7)
            elif eyes == "worry":
                p.el((ex - 24, cy - 26, ex + 24, cy + 26), (255, 255, 255), 6)
                p.el((ex - 9, cy - 5, ex + 9, cy + 13), INKB, 0)
                if sg < 0:
                    p.ln([(ex - 24, cy - 36), (ex + 18, cy - 50)], 8)
                else:
                    p.ln([(ex + 24, cy - 36), (ex - 18, cy - 50)], 8)
            if brow and sg > 0 and eyes in ("lookl", "open"):
                p.ln([(ex - 22, cy - 50), (ex + 20, cy - 62)], 8)
        if blush:
            p.el((130, 286, 156, 306), PINK, 0)
            p.el((244, 286, 270, 306), PINK, 0)
        if mouth == "smile":
            p.arc((176, 284, 224, 316), 20, 160, 7)
        elif mouth == "o":
            p.el((190, 292, 210, 318), (120, 30, 40), 6)
        elif mouth == "flat":
            p.ln([(184, 304), (216, 304)], 7)
        elif mouth == "yawn":
            p.el((176, 282, 224, 336), (120, 30, 40), 7)
            p.el((186, 312, 214, 332), (240, 110, 110), 0)
        elif mouth == "sad":
            p.arc((178, 300, 222, 326), 200, 340, 7)
        elif mouth == "wob":
            p.ln([(178, 308), (190, 300), (202, 310), (214, 300), (224, 306)], 6)
    return _svc(key, 400, 580, fn)


def put_beam(layer, x, y, sc=1.0, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, beam_tile(**kw), x, y, 200, 560, sc * sx, sc * sy, rot)


def beam_nozzle(x, y, sc):
    return x + (72 - 200) * sc, y + (177 - 560) * sc


def beam_line(img, p0, p1, t, thick=14, a=1.0, dots=True, speed=300, wav=10):
    """wavy cyan beam from p0 to p1 with light dots travelling along it"""
    n = 26
    pts = []
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    L = max(1.0, _m.hypot(dx, dy))
    nx, ny = -dy / L, dx / L
    for i in range(n + 1):
        u = i / n
        w = _m.sin(u * 14 - t * 16) * wav * _m.sin(_m.pi * u)
        pts.append((p0[0] + dx * u + nx * w, p0[1] + dy * u + ny * w))
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ld = ImageDraw.Draw(lay)
    for wd, al_ in ((thick * 3.2, 60), (thick * 1.8, 110), (thick, 255)):
        ld.line(pts, fill=CYAN + (int(al_ * a),), width=int(wd), joint="curve")
    ld.line(pts, fill=(255, 255, 255, int(255 * a)), width=max(2, int(thick * 0.35)), joint="curve")
    img.alpha_composite(lay)
    if dots:
        dd = ImageDraw.Draw(img)
        for j in range(6):
            u = ((t * speed / L) + j / 6.0) % 1.0
            x, y = p0[0] + dx * u, p0[1] + dy * u
            dd.rounded_rectangle((x - 11, y - 11, x + 11, y + 11), radius=4, fill=(255, 255, 255, int(255 * a)), outline=INKB + (int(255 * a),), width=3)


# ---------------------------------------------------------------- props
def coupon_tile(w=190, half=False):
    key = ("coupon", w, half)
    h = int(w * 0.56)

    def fn(d, k):
        p = SP(d, k)
        ww = w if not half else w // 2
        if half:
            p.poly([(4, 4), (ww - 4, 4), (ww - 14, h * 0.2), (ww - 2, h * 0.36), (ww - 14, h * 0.52), (ww - 2, h * 0.68), (ww - 14, h * 0.84), (ww - 4, h - 4), (4, h - 4)], (255, 150, 110), 6)
        else:
            p.rr((4, 4, ww - 4, h - 4), 14, GLD, 6)
            p.rr((14, 14, ww - 14, h - 14), 8, None, 3, GLDD)
        if half:
            pass
        if not half:
            p.txt((w / 2, h * 0.36), "BRAM", int(w * 0.17), INKB)
            p.txt((w / 2, h * 0.66), "STOCK", int(w * 0.17), INKB)
        else:
            p.txt((ww - 6, h * 0.36), "BR", int(w * 0.15), INKB, "rm")
    return _svc(key, w if not half else w // 2, h, fn)


def put_coupon(img, x, y, sc=1.0, rot=0.0, w=190, half=False, sx=1.0, sy=1.0):
    T = coupon_tile(w, half)
    blit(img, T, x, y, T.width / 2, T.height / 2, sc * sx, sc * sy, rot)


def cop_head(state="tired"):
    key = ("cop", state)

    def fn(d, k):
        p = SP(d, k)
        p.rr((6, 20, 104, 104), 22, (190, 196, 206), 8)
        p.rr((22, 6, 40, 24), 4, PINC, 5)
        p.rr((70, 6, 88, 24), 4, PINC, 5)
        for ex in (36, 72):
            if state == "tired":
                p.el((ex - 14, 40, ex + 14, 68), (255, 255, 255), 5)
                p.el((ex - 6, 54, ex + 6, 66), INKB, 0)
                p.rr((ex - 16, 36, ex + 16, 52), 3, (190, 196, 206), 0)
                p.ln([(ex - 15, 52), (ex + 15, 52)], 5)
            else:
                p.ln([(ex - 10, 44), (ex + 10, 64)], 6)
                p.ln([(ex + 10, 44), (ex - 10, 64)], 6)
        p.arc((36, 78, 72, 104), 200, 340, 6)
    return _svc(key, 110, 110, fn)


def cable_pts(x0, y0, x1, y1, sag, n=28, wig=0.0, t=0.0):
    pts = []
    for i in range(n + 1):
        u = i / n
        pts.append((lerp(x0, x1, u), lerp(y0, y1, u) + sag * 4 * u * (1 - u) + _m.sin(u * 9 + t * 5) * wig))
    return pts


def draw_cable(img, pts, w=34):
    d = ImageDraw.Draw(img)
    d.line(pts, fill=INKB + (255,), width=w + 12, joint="curve")
    d.line(pts, fill=COPPER + (255,), width=w, joint="curve")
    d.line([(x, y - w * 0.22) for x, y in pts], fill=(244, 178, 100, 255), width=max(4, w // 5), joint="curve")


def panel(img, ox=0.0, lit=0.0, t=0.0):
    d = ImageDraw.Draw(img)
    x0, x1 = 70 + ox, 1010 + ox
    d.rounded_rectangle((x0, 640, x1, 860), radius=26, fill=(22, 62, 78, 255), outline=INKB + (255,), width=8)
    d.rounded_rectangle((x0 + 30, 668, x1 - 30, 832), radius=16, fill=mix((9, 28, 38), (20, 90, 110), lit) + (255,), outline=INKB + (255,), width=6)
    for j in range(10):
        on = lit > 0.5 and _m.sin(t * 9 + j) > -0.2
        d.ellipse((x0 + 60 + j * 84, 872, x0 + 78 + j * 84, 890), fill=((CYAN if on else (40, 70, 80)) + (255,)), outline=INKB + (255,), width=3)
    for jx in (x0 + 90, x1 - 90):
        d.rounded_rectangle((jx - 30, 716, jx + 30, 764), radius=10, fill=(190, 196, 206, 255), outline=INKB + (255,), width=6)
        d.ellipse((jx - 12, 728, jx + 12, 752), fill=(20, 24, 30, 255))


def stall(img, cx, base, sc=1.0, popu=1.0):
    if popu <= 0.02:
        return
    W_, Hh = 540, 400
    def fn(d, k):
        p = SP(d, k)
        p.rr((30, 120, 52, 396), 6, (150, 110, 80), 6)
        p.rr((488, 120, 510, 396), 6, (150, 110, 80), 6)
        p.rr((20, 300, 520, 396), 14, (190, 140, 96), 8)
        p.rr((40, 316, 500, 330), 5, (216, 168, 120), 0)
        for i in range(9):
            col = RED if i % 2 == 0 else CRM
            x0 = 10 + i * 57
            p.poly([(x0, 40), (x0 + 57, 40), (x0 + 57, 120), (x0 + 28, 140), (x0, 120)], col, 6)
        p.rr((4, 20, 536, 50), 10, GLD, 7)
        for i in range(7):
            p.poly([(30 + i * 80, 4), (60 + i * 80, 4), (45 + i * 80, -2)], CYAN, 0) if False else None
    T = _svc(("stall",), W_, Hh, fn)
    blit(img, T, cx, base, W_ / 2, Hh, sc * popu, sc * popu, 0)


def register_tile():
    def fn(d, k):
        p = SP(d, k)
        p.rr((20, 250, 300, 296), 10, (70, 80, 96), 7)
        p.rr((34, 258, 286, 286), 6, (10, 20, 28), 0)
        p.rr((20, 90, 300, 252), 22, (120, 130, 152), 9)
        p.rr((50, 108, 270, 160), 10, (30, 60, 52), 7)
        p.txt((160, 134), "- - -", 34, (120, 230, 170))
        for r_ in range(2):
            for c_ in range(5):
                p.el((54 + c_ * 44, 176 + r_ * 36, 82 + c_ * 44, 200 + r_ * 36), (210, 214, 224), 5)
    return _svc(("reg",), 320, 300, fn)


def price_tag_tile(w=800, h=400):
    def fn(d, k):
        p = SP(d, k)
        p.rr((10, 10, w - 10, h - 10), 40, (255, 236, 160), 10)
        p.el((w / 2 - 22, 28, w / 2 + 22, 72), (11, 37, 48), 7)
    return _svc(("tag", w, h), w, h, fn)


def ease_io(x):
    x = clamp01(x)
    return x * x * (3 - 2 * x)


def stand_shadow(img, x, y, w=300):
    pass


def sweatdrop(img, x, y, s=1.0):
    ImageDraw.Draw(img).polygon([(x, y - 20 * s), (x - 11 * s, y + 8 * s), (x, y + 18 * s), (x + 11 * s, y + 8 * s)], fill=(140, 210, 255, 255), outline=INKB + (255,))


def hearts_up(img, x, y, t, n=5):
    for j in range(n):
        k = t - j * 0.25
        if 0 < k < 1.5:
            T = _ss(60, 60, lambda d, kk: heart(SP(d, kk), 30, 28, 1.0))
            blit(img, T, x + _m.sin(k * 5 + j) * 20 + j * 8, y - 150 * k, 30, 30, 1.0, 1.0, 0)


# ---------------------------------------------------------------- B1: hook
def b1c(c):
    return dict(tm=c.at("twelve", 1.1), tl=c.at("eighteen", 4.0), tc=c.at("cartoon", 6.1), td=c.at("cartoon", 6.1) + 0.3)


FY = 1360


def hook_b(img, t, q, final=False):
    reveal = clamp01((t - q["tc"]) / 0.7)
    sv_bg(img, t, pan=t * 24, mode="hook", reveal=reveal)
    t0s = [] if final else [0.0]
    flashes = t0s + [q["tl"]]
    fl = 0.0
    for tf_ in flashes:
        k = t - tf_
        if 0 <= k < 0.4:
            fl = max(fl, 0.32 * _m.exp(-k * 9))
    tint(img, RED, 0.07 + 0.03 * _m.sin(t * 5) + fl)
    if reveal > 0.4:
        sweepy(img, t, t * 24)
    # coupons raining down and shrinking
    rnd = _rnd.Random(8)
    for i in range(18):
        sp_ = rnd.uniform(130, 260)
        x0 = rnd.uniform(40, 1040)
        ph = rnd.uniform(0, 3000)
        y = 390 + (ph + t * sp_) % 1000
        u = (y - 390) / 1000.0
        sc = 0.55 * (1 - 0.6 * u)
        if i % 4 == 0:
            sc *= 1.0 - 0.35 * clamp01((u - 0.2) * 3)
        put_coupon(img, x0 + _m.sin(t * 2 + i) * 22, y, sc, _m.sin(t * 1.5 + i) * 30, 190)
    # numbers
    rows = ((478, "-12.7%", "MARVELL CLOSE", 0.0 if not final else -99.0, 0), (712, "-18.6%", "LUMENTUM CLOSE", q["tl"], 1))
    for yy, txt, lab, tcue, i in rows:
        if i == 1 and t < q["tl"] and not False:
            if t < q["tl"] - 0.001:
                continue
        sc = 1.0
        rot = -2.0 + 4 * i
        k = t - tcue
        if tcue > -50 and 0 <= k < 1.0:
            sc = lerp(1.55, 1.0, spr(k, 15, 6.5))
            rot += _m.sin(k * 22) * 5 * _m.exp(-4 * k)
            if k < 0.3:
                CAM["dx"], CAM["dy"] = shake(15 * (1 - k / 0.3), t)
        stext(img, (540, yy), txt, 120, RED, sw=12, rot=rot, sc=sc * (1 + 0.012 * _m.sin(t * 4)))
        spill(img, 540, yy + 108, lab, 56, REDD, tc=CRM, padx=30, h=80, ow=6, sc=pop(k / 0.3 + 0.4) if tcue > -50 and k < 0.3 else 1.0)
    # heading chain
    if t < q["tc"]:
        stext(img, (540, 935), "BOTH FELL. WHY?", 66, CRM, sw=9)
    elif t < q["td"]:
        stext(img, (540, 935), "AS A CARTOON", 70, CRM, sw=10, sc=pop((t - q["tc"]) / 0.3))
    else:
        k2 = t - q["td"]
        pulse = 1 + 0.08 * _m.sin(k2 * 16) * _m.exp(-3 * k2)
        spill(img, 540, 935, "DRAMATIZATION", 58, RED, tc=CRM, padx=40, sc=pop(k2 / 0.3) * pulse, ow=7)
    # characters: squash-drop on each number
    sq = 0.0
    for tf_ in flashes:
        k = t - tf_
        if 0 <= k < 0.7:
            sq += 0.2 * _m.exp(-8 * k) * _m.cos(22 * k)
    sh = swob(t, 6, 1.2)
    eyes_b = "blink" if blink_at(t, 0.4) else "worry"
    put_bram(img, 290, FY + abs(_m.sin(t * 7)) * -3, 0.95, 1 + sq * 0.6, 1 - sq, sh, eyes=eyes_b, mouth="nerv", al=20, ar=20, sweat=2)
    eyes_m = "blink" if blink_at(t, 1.3) else "worry"
    put_beam(img, 790, FY, 0.72, 1 + sq * 0.5, 1 - sq, -sh * 0.8, eyes=eyes_m, mouth="wob", al=20, ar=20, glow=0.3, blush=0)
    for j in range(3):
        k = (t * 1.3 + j * 0.33) % 1.0
        sweatdrop(img, 360 + j * 14, 1130 + 200 * k * k, 0.9)
        sweatdrop(img, 830 - j * 16, 1060 + 230 * k * k, 0.9)


def scene_sb_hook(img, v, t, spec, cues):
    hook_b(img, t, b1c(cues))


# ---------------------------------------------------------------- B2: meet Bram and Beam
def b2c(c):
    return dict(tb=c.at("Bram", 0.2), tmv=c.at("Marvell", 1.5), tdata=c.at("move", 2.6), tbm=c.at("Beam", 3.5), tlas=c.at("Lumentum", 4.7),
                tsend=c.at("send", 6.3), tlt=c.at("light", 7.1))


def scene_sb_meet(img, v, t, spec, cues):
    q = b2c(cues)
    sv_bg(img, t, pan=t * 18, mode="hall")
    sweepy(img, t, t * 18)
    BX, BSC = 250, 1.35
    MX, MSC = 830, 0.95
    ent = spr(t, 12, 5.5)
    by = GY - (1 - ent) * 700
    bump = 0.0
    if 0 <= t - q["tmv"] < 0.4:
        bump = 44 * _m.sin(_m.pi * (t - q["tmv"]) / 0.4)
    eyes, mouth = ("blink" if blink_at(t, 0.5) else "open"), "smile"
    if t >= q["tdata"]:
        eyes, mouth = "happy", "grin"
    if t >= q["tbm"]:
        eyes = "lookr" if eyes == "open" else eyes
    put_bram(img, BX, by - bump - abs(_m.sin(t * 3.2)) * 5, BSC, 1, 1 + 0.015 * _m.sin(t * 4), swob(t, 0.8, 1.0), eyes=eyes, mouth=mouth, al=8, ar=8, sweat=0)
    if t >= q["tb"]:
        spill(img, BX, 758, "BRAM", 62, TLP, tc=INKB, padx=34, sc=pop((t - q["tb"]) / 0.3), rot=-4 + swob(t, 0.7, 2), ow=7)
    if t >= q["tmv"]:
        k = t - q["tmv"]
        card_text(img, 270, 520 - (10 if 0.15 < k < 0.4 else 0), 500, 250, ["MARVELL =", "CHIPS THAT", "MOVE DATA"], [60, 60, 60], [GLD, CRM, CRM], sc=pop(k / 0.3))
    # data packets hop over Bram's pins
    if t >= q["tdata"]:
        dd = ImageDraw.Draw(img)
        for j in range(6):
            u = ((t - q["tdata"]) * 0.9 + j / 6.0) % 1.0
            x = lerp(30, 470, u)
            y = 800 - abs(_m.sin(u * 14)) * 36
            dd.rounded_rectangle((x - 13, y - 13, x + 13, y + 13), radius=5, fill=GLD + (255,), outline=INKB + (255,), width=4)
    # gag: a coupon with Bram's face pops out of the pouch and waves
    tg0 = q["tdata"] + 0.5
    if tg0 <= t < q["tbm"] + 0.3:
        k = t - tg0
        u = spr(k, 12, 6)
        pxx, pyy = 351, 1125 - 230 * u
        out = clamp01((t - (q["tbm"] - 0.1)) / 0.3)
        sc = 0.9 * (1 - out)
        if sc > 0.05:
            put_coupon(img, pxx, pyy, sc, swob(t, 2.2, 12), 190)
            dd = ImageDraw.Draw(img)
            for ex in (-18, 18):
                dd.ellipse((pxx + ex * sc * 1.2 - 6 * sc, pyy - 8 * sc - 6 * sc, pxx + ex * sc * 1.2 + 6 * sc, pyy - 8 * sc + 6 * sc), fill=INKB + (255,))
            dd.arc((pxx - 20 * sc, pyy - 4 * sc, pxx + 20 * sc, pyy + 22 * sc), 20, 160, fill=INKB + (255,), width=max(2, int(5 * sc)))
    # Beam
    if t >= q["tbm"] - 0.1:
        k = t - (q["tbm"] - 0.1)
        mx = lerp(1350, MX, ease(k / 0.6))
        pul = 0.5 + 0.5 * _m.sin(t * 9)
        flash_ = t >= q["tlt"]
        hop = 0.0
        if 0 <= t - q["tlas"] < 0.4:
            hop = 44 * _m.sin(_m.pi * (t - q["tlas"]) / 0.4)
        put_beam(img, mx, GY - hop, MSC, 1 + 0.03 * _m.sin(t * 6), 1 - 0.03 * _m.sin(t * 6), 0, eyes="blink" if blink_at(t, 0.9) else "lookl", mouth="smile",
                 al=8, ar=8, glow=1.0 if flash_ else pul, blush=1)
        if k > 0.5:
            spill(img, MX, 700, "BEAM", 62, CYAN, tc=INKB, padx=34, sc=pop((k - 0.5) / 0.3), rot=4 + swob(t, 0.7, 2), ow=7)
        nz = beam_nozzle(mx, GY - hop, MSC)
        if t >= q["tsend"]:
            a = clamp01((t - q["tsend"]) / 0.2)
            beam_line(img, nz, (460, 930), t, thick=14 if not flash_ else 24, a=a, speed=360)
        if t >= q["tlas"]:
            kk = t - q["tlas"]
            card_text(img, 810, 520 - (10 if 0.15 < kk < 0.4 else 0), 500, 250, ["LUMENTUM =", "LASERS: DATA", "AS LIGHT"], [56, 58, 58], [CYAN, CRM, CRM], sc=pop(kk / 0.3))
        if t >= q["tlt"] and t < q["tlt"] + 0.45:
            kk = t - q["tlt"]
            sburst(img, 460, 930, 60 + 120 * ease(kk / 0.4), 120 + 200 * ease(kk / 0.4), 12, kk * 2, (255, 255, 255, 255), 6, alpha=1 - kk / 0.45)


# ---------------------------------------------------------------- B3: copper to light, proposal
def b3c(c):
    return dict(tcop=c.at("copper", 1.8), tlt=c.at("light", 2.5), tcom=c.at("companies", 3.0), tprop=c.at("proposes", 4.4), tall=c.at("all", 5.3))


def scene_sb_light(img, v, t, spec, cues):
    q = b3c(cues)
    sv_bg(img, t, pan=t * 20, mode="hall")
    sweepy(img, t, t * 20)
    gone = clamp01((t - q["tprop"]) / 0.45)
    lit = clamp01((t - q["tlt"]) / 0.3)
    if gone < 1:
        ox = -ease_io(gone) * 1200
        panel(img, ox, lit, t)
        x0, x1 = 160 + ox, 920 + ox
        if t < q["tlt"] - 0.05:
            sag = 40 + 130 * ease((t - q["tcop"] + 0.3) / 0.6) if t > q["tcop"] - 0.3 else 40
            pts = cable_pts(x0, 740, x1, 740, sag, wig=2.0 if t < q["tcop"] else 5.0, t=t)
            draw_cable(img, pts)
            mid = pts[len(pts) // 2]
            T = cop_head("tired")
            blit(img, T, mid[0], mid[1], 55, 55, 1.6, 1.6, swob(t, 1.2, 6))
            dd = ImageDraw.Draw(img)
            for j in range(3):
                u = ((t * 0.12) + j / 3.0) % 1.0
                i0 = int(u * (len(pts) - 1))
                dd.rounded_rectangle((pts[i0][0] - 9, pts[i0][1] - 9, pts[i0][0] + 9, pts[i0][1] + 9), radius=3, fill=(255, 255, 255, 255), outline=INKB + (255,), width=3)
            if t >= q["tcop"]:
                spill(img, 540, 905, "COPPER", 56, COPPER, tc=INKB, padx=34, sc=pop((t - q["tcop"]) / 0.3), ow=6)
        else:
            k = t - (q["tlt"] - 0.05)
            xm = (x0 + x1) / 2
            dr = min(1.0, k * 1.5)
            rc = 38 * abs(_m.sin(k * 13)) * _m.exp(-k * 3.2)
            draw_cable(img, cable_pts(x0, 740, xm - 40 - 40 * dr, 740 + 330 * dr * dr - rc, 40))
            draw_cable(img, cable_pts(x1, 740, xm + 40 + 40 * dr, 740 + 330 * dr * dr - rc, 40))
            if k < 0.5:
                sburst(img, xm, 740, 40 + 80 * ease(k / 0.4), 80 + 150 * ease(k / 0.4), 10, k * 3, (255, 255, 255, 255), 6, alpha=1 - k / 0.5)
            beam_line(img, (x0, 740), (x1, 740), t, thick=16, a=clamp01(k / 0.12), speed=600, wav=6)
            if k < 0.05:
                flash(img, 0.85)
    if t >= 0.05:
        l2c = CYAN if t >= q["tlt"] else COPPER
        lines = ["AI DATA CENTERS:", "COPPER TO LIGHT", "(COMPANIES SAY)" if t >= q["tcom"] else ""]
        cols = [CRM, l2c, GLD]
        if t < q["tprop"] + 0.2:
            card_text(img, 540, 500, 800, 240, lines, [56, 62, 56], cols, sc=pop((t - 0.05) / 0.3))
    ph = t >= q["tprop"]
    put_bram(img, 230, GY, 1.15, 1, 1, swob(t, 1.0, 1.0), eyes="heart" if ph else "lookr", mouth="smile" if ph else "nerv", al=8, ar=150 if ph else 8, sweat=0 if ph else 1)
    put_beam(img, 860, GY, 0.9, 1, 1, 0, eyes="blink" if blink_at(t, 0.7) else "lookl", mouth="smile", al=8, ar=8, glow=0.5 + 0.4 * lit, blush=1)
    if ph:
        k = t - q["tprop"]
        stall(img, 540, GY + 36, 0.95, spr(k, 12, 6))
        hearts_up(img, 330, 940, k)
        sc = pop(k / 0.3)
        dd = ImageDraw.Draw(img)
        dd.ellipse((380 - 36 * sc, 930 - 36 * sc, 380 + 36 * sc, 930 + 36 * sc), outline=INKB + (255,), width=int(22 * sc) + 2)
        dd.ellipse((380 - 34 * sc, 930 - 34 * sc, 380 + 34 * sc, 930 + 34 * sc), outline=GLD + (255,), width=int(14 * sc) + 1)
        dd.polygon([(380, 880 - 14 * sc), (394, 894 - 14 * sc), (380, 904 - 14 * sc), (366, 894 - 14 * sc)], fill=CYAN + (255,), outline=INKB + (255,))
    if t >= q["tall"]:
        k = t - q["tall"]
        spill(img, 540, 560, "ALL STOCK", 104, GLD, tc=INKB, padx=50, sc=pop(k / 0.3) * (1 + 0.05 * _m.sin(k * 14) * _m.exp(-3 * k)), ow=8)


# ---------------------------------------------------------------- B4: all stock means coupons
def b4c(c):
    return dict(tno=c.at("no", 0.85), tcoup=c.at("coupons", 2.3), tprint=c.at("prints", 3.0), town=c.at("own", 4.9), tfour=c.at("Four", 5.5), tbm=c.at("Beam", 6.9),
                tcomp=c.at("companies", 7.7), thun=c.at("hundred", 10.3), tdebt=c.at("counting", 12.2))


def printer_tile():
    def fn(d, k):
        p = SP(d, k)
        p.rr((10, 40, 190, 150), 16, (170, 178, 192), 8)
        p.rr((30, 20, 170, 56), 8, (60, 68, 84), 7)
        p.rr((52, 66, 148, 76), 4, INKB, 0)
        p.el((150, 96, 170, 116), (90, 255, 150), 5)
        p.rr((40, 100, 120, 132), 6, (220, 226, 236), 5)
    return _svc(("printer",), 200, 160, fn)


def scene_sb_coupons(img, v, t, spec, cues):
    q = b4c(cues)
    sv_bg(img, t, pan=t * 16, mode="hall")
    sweepy(img, t, t * 16)
    BX, BSC, MX, MSC = 640, 1.2, 940, 0.85
    rx = 190 - ease((t - q["tfour"]) / 0.4) * 500
    if rx > -200:
        blit(img, register_tile(), rx, GY + 10, 160, 290, 1.0, 1.0, 0)
        if t >= q["tno"]:
            k = t - q["tno"]
            sc = pop(k / 0.25)
            dd = ImageDraw.Draw(img)
            for a, b in (((rx - 120, GY - 260), (rx + 120, GY - 20)), ((rx + 120, GY - 260), (rx - 120, GY - 20))):
                aa = (rx + (a[0] - rx) * sc, (GY - 140) + (a[1] - (GY - 140)) * sc)
                bb = (rx + (b[0] - rx) * sc, (GY - 140) + (b[1] - (GY - 140)) * sc)
                dd.line([aa, bb], fill=INKB + (255,), width=34)
                dd.line([aa, bb], fill=RED + (255,), width=20)
    # top zone phases
    if t < q["tcoup"] - 0.1:
        spill(img, 540, 470, "ALL STOCK", 92, GLD, tc=INKB, padx=50, sc=pop((t - 0.1) / 0.3), ow=8)
        if t >= q["tno"]:
            spill(img, 540, 585, "= NO CASH", 92, RED, tc=CRM, padx=50, sc=pop((t - q["tno"]) / 0.3), ow=8)
    elif t < q["tfour"] - 0.1:
        card_text(img, 540, 510, 780, 220, ["BRAM PAYS IN", "COUPONS"], [64, 84], [CRM, GLD], sc=pop((t - q["tcoup"]) / 0.3))
    else:
        k = t - q["tfour"]
        card_text(img, 540, 505, 820, 230, ["4.5 COUPONS", "= 1 BEAM SHARE"], [92, 62], [GLD, CRM], sc=pop(k / 0.3))
    if q["town"] <= t < q["tcomp"] - 0.1 and t < q["tfour"] - 0.1:
        k = t - q["town"]
        sc = lerp(2.0, 1.0, spr(k, 16, 7)) if k < 0.7 else 1.0
        spill(img, 540, 690, "= HIS OWN SHARES", 58, RED, tc=CRM, padx=40, sc=sc, rot=-3, ow=8)
    if q["tcomp"] <= t:
        k = t - q["tcomp"]
        stext(img, (540, 665), "COMPANIES' VALUE:", 56, CRM, sw=8, sc=pop(k / 0.3))
    if q["thun"] <= t:
        k = t - q["thun"]
        # starburst behind the chip, small and translucent
        if k < 0.7:
            sburst(img, 760, 770, 70 + 30 * ease(k / 0.4), 110 + 60 * ease(k / 0.4), 12, k, (255, 214, 92, 255), 6, alpha=0.5 * (1 - k / 0.7))
        spill(img, 540, 770, "~$115B INCL. DEBT", 72, GLD, tc=INKB, padx=44, sc=pop(k / 0.3), ow=8)
    # Bram + printer
    shout = q["tprint"] - 0.4 <= t < q["tprint"] + 1.8
    put_bram(img, BX, GY, BSC, 1, 1, swob(t, 1.0, 1.0), eyes="blink" if blink_at(t, 0.3) else "worry", mouth="grin" if shout else "nerv", al=8,
             ar=100 if shout else 8, sweat=1 if t < q["tcoup"] else 0)
    if t >= q["tcoup"] - 0.3:
        shk = _m.sin(t * 50) * 2 if shout else 0
        blit(img, printer_tile(), 370 + shk, GY + 4, 100, 160, 1.15, 1.15, 0)
    for j in range(9):
        t0 = q["tprint"] - 0.3 + j * 0.2
        u = (t - t0) / 0.55
        if u < 0:
            continue
        tx = 480 + (j % 3) * 8
        ty = GY - 18 - (j // 3) * 26
        if u < 1:
            x = lerp(370, tx, ease(u))
            y = lerp(GY - 150, ty, ease(u)) - 210 * _m.sin(_m.pi * u)
            put_coupon(img, x, y, 0.7, u * 400, 190)
        else:
            put_coupon(img, tx, ty, 0.7, (j * 37) % 40 - 20, 190)
    # Beam collects 4 + a torn half
    pose = "happy" if t >= q["tfour"] else "lookl"
    put_beam(img, MX, GY, MSC, 1, 1, 0, eyes="blink" if blink_at(t, 0.2) else pose, mouth="smile", al=8, ar=8, glow=0.5, blush=1)
    for j in range(5):
        t0 = q["tfour"] + 0.25 + j * 0.25
        u = (t - t0) / 0.5
        half = j == 4
        if u < 0:
            continue
        tx, ty = MX - 24 + (50 if half else 0), GY - 200 - j * 26
        if u < 1:
            x = lerp(500, tx, ease(u))
            y = lerp(GY - 30, ty, ease(u)) - 200 * _m.sin(_m.pi * u)
            put_coupon(img, x, y, 0.7, u * 360, 190, half)
        else:
            put_coupon(img, tx, ty, 0.7, 0, 190, half)


# ---------------------------------------------------------------- B5: the catch
def b5c(c):
    return dict(tcat=c.at("catch", 0.2), tfall=c.at("falls", 1.4), tshr=c.at("shrink", 2.6), tpr=c.at("price", 3.4), tdr=c.at("drops", 4.0), tmon=c.at("Monday's", 4.7),
                t771=c.at("seven", 5.9), tdol=c.at("dollars", 7.5))


def scene_sb_catch(img, v, t, spec, cues):
    q = b5c(cues)
    FZ = 0.35
    ta = t if t < q["tcat"] else (q["tcat"] if t < q["tcat"] + FZ else t - FZ)
    sv_bg(img, ta, pan=ta * 16, mode="hall")
    sweepy(img, ta, ta * 16)
    BX, MX = 250, 830
    fall = ease((t - q["tfall"]) / 0.5)
    sink = 0.22 * fall
    put_bram(img, BX, GY + 8 * fall, 1.1, 1 + sink * 0.5, 1 - sink, -6 * fall + swob(ta, 5, 1.5 * fall), eyes="squint" if fall > 0.5 else "worry", mouth="sad" if fall > 0.5 else "nerv",
             al=8, ar=8, sweat=2)
    if t >= q["tfall"]:
        for j in range(4):
            k = (t - q["tfall"] - j * 0.2) % 0.9
            sweatdrop(img, BX + 70 + j * 20, 880 + 280 * k * k, 1.0)
    shrink = 1.0
    if t >= q["tshr"]:
        k = t - q["tshr"]
        shrink = lerp(1.0, 0.6, ease(k / 0.3)) + 0.12 * _m.exp(-9 * k) * _m.cos(26 * k) * (1 if k < 0.8 else 0)
    brow = 1 if t >= q["tshr"] + 0.5 else 0
    put_beam(img, MX, GY, 0.82, 1, 1, 0, eyes="lookl" if t < q["tshr"] else "open", mouth="o" if t >= q["tshr"] else "smile", al=8, ar=8, glow=0.4, brow=brow, blush=1)
    dd = ImageDraw.Draw(img)
    for j in range(5):
        half = j == 4
        cx_, cy_ = MX - 24 + (50 if half else 0), GY - 190 - j * 24
        if t >= q["tshr"]:
            w_, h_ = 66, 40
            dd.rounded_rectangle((cx_ - w_ * (0.5 if half else 1.0) * 0.9, cy_ - h_ * 0.9, cx_ + w_ * (0.5 if half else 1.0) * 0.9, cy_ + h_ * 0.9), radius=8, outline=(235, 240, 244, 150), width=3)
        put_coupon(img, cx_, cy_ - (1 - shrink) * j * 24, 0.7 * shrink, 0, 190, half)
    if q["tcat"] <= t < q["tfall"] + 0.5:
        k = t - q["tcat"]
        sc = lerp(2.2, 1.0, spr(k, 16, 7)) if k < 0.8 else 1.0
        tint(img, (0, 0, 0), 0.3 * (1 - clamp01((k - FZ) / 0.4)))
        stext(img, (540, 600), "THE CATCH", 140, RED, sw=16, rot=-5, sc=sc)
        if k < 0.3:
            CAM["dx"], CAM["dy"] = shake(12, t)
    if q["tfall"] <= t < q["tpr"]:
        k = t - q["tfall"]
        card_text(img, 540, 500, 780, 210, ["BRAM STOCK FALLS", "COUPONS SHRINK"], [60, 60], [RED, CRM], sc=pop(k / 0.3))
    if t >= q["tpr"]:
        k = t - q["tpr"]
        drop = ease(k / 0.35)
        ang = _m.exp(-1.6 * k) * _m.sin(k * 7) * 9
        TW, TH = 780, 450
        T = price_tag_tile(TW, TH).copy()
        td = ImageDraw.Draw(T)
        td.text((TW // 2, 96), "OFFER VALUE PER", font=font("bold", 56), fill=INKB + (255,), anchor="mm")
        td.text((TW // 2, 158), "LUMENTUM SHARE", font=font("bold", 56), fill=INKB + (255,), anchor="mm")
        td.text((TW // 2, 232), "OCT 28: ~$1,132", font=font("bold", 64), fill=(138, 127, 102, 255), anchor="mm")
        extra = 0.0
        if t >= q["tdr"]:
            td.line([(150, 232), (630, 232)], fill=(90, 80, 60, 255), width=5)
            td.text((TW // 2, 300), "MON CLOSE:", font=font("bold", 56), fill=RED + (255,), anchor="mm")
            u = clamp01((t - q["t771"]) / 0.6)
            if u > 0:
                full = "~$771"
                f90 = font("bold", 96)
                tw = int(td.textlength(full, font=f90))
                part = Image.new("RGBA", (TW, TH), (0, 0, 0, 0))
                ImageDraw.Draw(part).text((TW // 2, 386), full, font=f90, fill=RED + (255,), anchor="mm", stroke_width=3, stroke_fill=INKB + (255,))
                part = part.crop((0, 0, int(TW // 2 - tw / 2 + tw * u + 6), TH))
                canvas = Image.new("RGBA", (TW, TH), (0, 0, 0, 0))
                canvas.paste(part, (0, 0))
                T.alpha_composite(canvas)
            if t >= q["t771"]:
                extra = 16 * _m.exp(-8 * (t - q["t771"])) * abs(_m.cos(20 * (t - q["t771"])))
        yy = 385 + (drop - 1) * 420 + (14 * ease((t - q["tdr"]) / 0.3) if t >= q["tdr"] else 0) + extra
        blit(img, T, 540, yy, TW // 2, 0, 0.98, 0.98, ang)
        if t >= q["t771"] and t < q["t771"] + 0.7:
            kk = t - q["t771"]
            sburst(img, 580, yy + 400, 110 + 40 * ease(kk / 0.4), 190 + 80 * ease(kk / 0.4), 12, kk * 2, (255, 120, 90, 255), 6, alpha=0.55 * (1 - kk / 0.7))
        if t >= q["tdr"]:
            ImageDraw.Draw(img).polygon([(935, yy + 120), (1055, yy + 120), (995, yy + 250)], fill=RED + (255,), outline=INKB + (255,))
            ImageDraw.Draw(img).line([(995, yy + 70), (995, yy + 125)], fill=INKB + (255,), width=3)


# ---------------------------------------------------------------- B6: no source confirms why
def b6c(c):
    return dict(tno=c.at("No source", 0.0), tonerep=c.at("One report", 2.0), tinv=c.at("investors", 2.8), tover=c.at("overpaying", 4.3), tan=c.at("One analyst", 5.1),
                tbel=c.at("below", 7.6), tfif=c.at("fifty", 8.0))


def scene_sb_why(img, v, t, spec, cues):
    q = b6c(cues)
    sv_bg(img, t, pan=t * 16, mode="hall")
    sweepy(img, t, t * 16)
    sink = lambda tt: 8 * ease((t - tt) / 0.5)
    squint = t >= q["tinv"]
    for i in (0, 1):
        x = (180, 390)[i]
        put_bot(img, i, x, GY + 20, 0.95, 1, 1, swob(t, 1.2, 4 if squint else 1.5), mood="worry" if squint else "smug", sweat=0)
    if q["tinv"] - 0.1 <= t < q["tinv"] + 2.0:
        spill(img, 285, 665, "INVESTORS", 56, BOTC, tc=CRM, padx=34, sc=pop((t - q["tinv"] + 0.1) / 0.3), ow=7)
    if q["tinv"] <= t < q["tan"] + 0.3:
        mx_, my_ = 560 + _m.sin(t * 3) * 14, 960 + _m.cos(t * 4) * 8
        dd = ImageDraw.Draw(img)
        dd.line([(mx_ + 54, my_ + 54), (mx_ + 130, my_ + 130)], fill=INKB + (255,), width=34)
        dd.line([(mx_ + 54, my_ + 54), (mx_ + 130, my_ + 130)], fill=(150, 110, 70, 255), width=20)
        dd.ellipse((mx_ - 78, my_ - 78, mx_ + 78, my_ + 78), fill=(214, 244, 255, 90), outline=INKB + (255,), width=16)
        dd.ellipse((mx_ - 78, my_ - 78, mx_ + 78, my_ + 78), outline=(190, 200, 214, 255), width=8)
        g = 0.5 + 0.5 * _m.sin(t * 6)
        dd.arc((mx_ - 52, my_ - 52, mx_ + 52, my_ + 52), 200, 250, fill=(255, 255, 255, int(120 + 135 * g)), width=9)
    ss = sink(q["tover"]) + (8 if t >= q["tan"] else 0)
    put_bram(img, 740, GY + ss, 0.95, 1, 1 - ss * 0.01, swob(t, 5, 1.5), eyes="squint" if t >= q["tover"] else "worry", mouth="sad" if t >= q["tover"] else "nerv", sweat=2)
    put_beam(img, 970, GY + ss, 0.72, 1, 1 - ss * 0.01, 0, eyes="worry", mouth="wob", al=8, ar=8, glow=0.3, blush=0)
    for j in range(3):
        k = (t * 1.1 + j * 0.33) % 1.0
        sweatdrop(img, 780 + j * 14, 960 + 220 * k * k, 0.9)
    if t < q["tonerep"] - 0.1:
        card_text(img, 540, 505, 900, 240, ["NO SOURCE CONFIRMS", "WHY BOTH FELL"], [58, 66], [CRM, GLD], sc=pop((t + 0.1) / 0.3))
    elif t < q["tan"] - 0.1:
        card_text(img, 540, 505, 900, 240, ["ONE REPORT: INVESTORS", "FEAR OVERPAYING"], [56, 66], [CRM, RED], sc=pop((t - q["tonerep"]) / 0.3))
    else:
        card_text(img, 540, 505, 900, 240, ["ONE ANALYST: ODDS OF", "DEAL CLOSING BELOW 50%"], [56, 52], [CRM, GLD], sc=pop((t - q["tan"]) / 0.3))
    if q["tover"] <= t < q["tan"]:
        k = t - q["tover"]
        spill(img, 600, 700, "OVERPAYING?", 60, RED, tc=CRM, padx=34, sc=pop(k / 0.3), rot=swob(t, 3, 3), ow=7)
    # coin: tumbles in, rolls/wobbles through "fifty percent", then stands on its edge
    t0c = q["tbel"] - 0.5
    if t >= t0c:
        k = t - t0c
        cx = 590
        flight = 1.1
        wob = 1.1
        coin = _svc(("coin2",), 240, 240, lambda d, kk: (SP(d, kk).el((10, 10, 230, 230), GLD, 9), SP(d, kk).el((34, 34, 206, 206), None, 6, GLDD), SP(d, kk).txt((120, 122), "50%", 78, INKB)))
        if k < flight:
            u = k / flight
            y = lerp(GY - 520, GY - 140, u * u) - 160 * _m.sin(_m.pi * u)
            fl = abs(_m.cos(u * 7 * _m.pi))
            blit(img, coin, cx, y, 120, 120, 1.0, max(0.12, fl), swob(u, 1.5, 20))
        elif k < flight + wob:
            kk = k - flight
            tilt = 0.55 + 0.4 * _m.exp(-2.0 * kk) * abs(_m.cos(kk * 11))
            blit(img, coin, cx, GY - 140 + 40 * (1 - tilt), 120, 120, 1.0, tilt * 0.9, 12 * _m.exp(-2 * kk) * _m.sin(kk * 11))
        else:
            kk = k - flight - wob
            edge = _svc(("coinedge2",), 60, 240, lambda d, k2: SP(d, k2).rr((8, 8, 52, 232), 14, GLD, 8))
            wob_ = 10 * _m.exp(-3 * kk) * _m.sin(kk * 14)
            blit(img, edge, cx, GY - 4, 30, 232, 1.0, 1.0, wob_)
            if kk < 0.6:
                for a in (-1, 1):
                    for j in range(3):
                        px_ = cx + a * (40 + 60 * kk * (1 + j * 0.4))
                        py_ = GY - 6 - 30 * kk * j
                        r_ = 14 * (1 - kk / 0.6) + 2
                        ImageDraw.Draw(img).ellipse((px_ - r_, py_ - r_, px_ + r_, py_ + r_), fill=(230, 230, 236, 255), outline=INKB + (255,), width=3)


# ---------------------------------------------------------------- B7: the long wait
def b7c(c):
    return dict(tw=c.at("wedding", 1.3), tfirst=c.at("first", 2.0), t28=c.at("twenty-eight", 3.0), tsh=c.at("shareholders", 3.7), tvote=c.at("shareholders", 3.7) + 0.2,
                treg=c.at("regulators", 4.6), tapp=c.at("approve", 5.4))


MONTHS = ["MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC", "JAN", "FEB", "MAR", "APR", "MAY", "JUN"]


def calendar(img, cx, cy, t, q):
    T = _ss(540, 360, lambda d, k: (SP(d, k).rr((10, 40, 530, 350), 22, CRM, 9), SP(d, k).rr((10, 20, 530, 100), 22, RED, 9), SP(d, k).el((100, 6, 140, 46), (200, 206, 216), 6), SP(d, k).el((400, 6, 440, 46), (200, 206, 216), 6)))
    tf = q["tfirst"]
    base = T.copy()
    dd = ImageDraw.Draw(base)
    sy = 1.0
    jit = 0.0
    if t < tf:
        dd.text((270, 70), "", font=font("bold", 40))
    elif t < q["t28"]:
        ph = ((t - tf) % 0.11) / 0.11
        n = int((t - tf) / 0.11)
        dd.text((270, 220), MONTHS[n % len(MONTHS)], font=font("bold", 120), fill=INKB + (255,), anchor="mm")
        sy = 1 - 0.28 * _m.sin(_m.pi * ph)
        jit = (ph - 0.5) * 6
    else:
        dd.text((270, 70), "H1", font=font("bold", 60), fill=CRM + (255,), anchor="mm")
        dd.text((270, 220), "2028", font=font("bold", 150), fill=RED + (255,), anchor="mm")
    k = t - q["t28"]
    sc = 0.85 + (0.1 * _m.exp(-8 * k) * _m.cos(24 * k) if t >= q["t28"] else 0)
    if t >= tf:
        blit(img, base, cx, cy, 270, 180, sc, sc * sy, jit)


def scene_sb_wait(img, v, t, spec, cues):
    q = b7c(cues)
    sv_bg(img, t, pan=t * 10, mode="hall")
    sweepy(img, t, t * 10)
    calendar(img, 540, 560, t, q)
    if t >= q["t28"]:
        k = t - q["t28"]
        dd = ImageDraw.Draw(img)
        for r_ in (40, 80, 120):
            rr_ = r_ * clamp01(k / 0.6)
            dd.arc((800 - rr_, 400 - rr_, 800 + rr_, 400 + rr_), 90, 180, fill=(230, 238, 240, 255), width=3)
        for a in (90, 125, 160):
            ar = _m.radians(a)
            dd.line([(800, 400), (800 + _m.cos(ar) * 130 * clamp01(k / 0.6), 400 + _m.sin(ar) * 130 * clamp01(k / 0.6))], fill=(230, 238, 240, 255), width=3)
        sp_y = 450 + 140 * ease(k / 1.2)
        dd.line([(760, 400), (760, sp_y)], fill=(230, 238, 240, 255), width=3)
        dd.ellipse((745, sp_y, 775, sp_y + 28), fill=(30, 30, 40, 255), outline=INKB + (255,))
    wt = t - q["tw"]
    BX, BY = 240, GY - 20
    put_bram(img, BX, BY, 1.1, 1, 1, swob(t, 0.6, 1), eyes="blink" if blink_at(t, 0.6) else ("lookr" if t < q["t28"] else "open"), mouth="smile" if t < q["tsh"] else "flat",
             al=8, ar=150 if int(t * 1.4) % 2 == 0 and t > q["t28"] else 120, sweat=0, tie=1)
    if t > q["t28"]:
        ImageDraw.Draw(img).ellipse((BX + 138 * 1.1 - 50, BY - 192, BX + 138 * 1.1 - 16, BY - 158), fill=GLD + (255,), outline=INKB + (255,), width=5)
    yawn = t >= q["tvote"] - 0.6 and t > q["t28"]
    MXX, MSC_ = 840, 0.74
    put_beam(img, MXX, BY, MSC_, 1, 1, 0, eyes="sleepy" if yawn else ("blink" if blink_at(t, 0.5) else "lookl"), mouth="yawn" if yawn else "smile", al=8, ar=8, glow=0.5, blush=1)
    veil = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    vd = ImageDraw.Draw(veil)
    vd.polygon([(MXX, BY - 392), (MXX - 150, BY - 90), (MXX + 150, BY - 90)], fill=(200, 250, 255, 100))
    vd.arc((MXX - 70, BY - 420, MXX + 70, BY - 340), 180, 360, fill=(255, 255, 255, 230), width=9)
    img.alpha_composite(veil)
    if yawn:
        k = t - (q["tvote"] - 0.6)
        for j in range(3):
            kk = k - j * 0.3
            if 0 < kk < 1.3:
                ImageDraw.Draw(img).ellipse((760 + j * 10, BY - 350 - 80 * kk - 14, 800 + 22 * kk + j * 10, BY - 350 - 80 * kk + 14 + 10 * kk), fill=(200, 250, 255, int(200 * (1 - kk / 1.3))))
    if t >= q["tw"]:
        spill(img, 240, 780, "WEDDING", 56, GLD, tc=INKB, padx=30, sc=pop(wt / 0.3), ow=6)
    if t >= q["tsh"]:
        card_text(img, 540, 815, 940, 150, ["IF SHAREHOLDERS +", "REGULATORS APPROVE"], [58, 58], [CRM, GLD], sc=pop((t - q["tsh"]) / 0.3))
    if t >= q["tvote"]:
        k = t - q["tvote"]
        for j, x in enumerate((400, 690)):
            T = _svc(("ballot2",), 170, 200, lambda d, kk: (SP(d, kk).rr((10, 50, 160, 192), 14, (200, 206, 216), 8), SP(d, kk).rr((40, 54, 130, 70), 5, INKB, 0), SP(d, kk).rr((54, 6, 116, 52), 5, CRM, 6)))
            u = k / 0.3 - j * 0.2
            sc_ = pop(u) if u > 0 else 0.01
            blit(img, T, x, GY, 85, 192, 1.0, sc_, 0)
            if u > 0:
                stext(img, (x, GY - 70 * sc_), "VOTE", 56, INKB, sw=0, sc=max(0.01, sc_) * 0.6)
    if t >= q["treg"]:
        k = t - q["treg"]
        sc = lerp(2.0, 1.0, spr(k, 16, 7)) if k < 0.8 else 1.0
        T = _ss(460, 130, lambda d, kk: SP(d, kk).rr((8, 8, 452, 122), 22, CRM, 8))
        ImageDraw.Draw(T).text((230, 66), "APPROVAL?", font=font("bold", 76), fill=RED + (255,), anchor="mm")
        sc *= 0.72
        blit(img, T, 540, 1005, 230, 65, sc, sc, -6)
        if k < 0.4:
            CAM["dx"], CAM["dy"] = shake(9 * (1 - k / 0.4), t)


# ---------------------------------------------------------------- B8: lesson, question and loop
def b8c(c):
    return dict(tall=c.at("all-stock", 0.4), tbuy=c.at("buyer's", 1.6), tpr=c.at("price", 2.6), twh=c.at("When", 3.3), toff=c.at("offer", 4.9), tcat=c.at("catch", 6.2),
                tq=c.at("Would", 6.7), tcoup=c.at("coupons", 7.2), tend=c.dur - 0.5)


def _phase_lines(img, d, lines, y0, size, t, t0, t1, hls, step=118):
    f = font("bold", size)
    gap = 24
    pin = pop((t - t0) / 0.3)
    pout = 1 - ease((t - (t1 - 0.2)) / 0.25) if t1 < 900 else 1.0
    for li, words in enumerate(lines):
        pk = max(0.01, pop((t - t0 - li * 0.08) / 0.3) * pout)
        widths = [int(d.textlength(w_, font=f)) for w_ in words]
        total = sum(widths) + gap * (len(words) - 1)
        y = y0 + li * step
        x = 540 - total / 2
        xs = []
        for wi in range(len(words)):
            xs.append(x)
            x += widths[wi] + gap
        hl = hls.get(li)
        act = None
        if hl and t >= hl[3]:
            act = hl
            pr = ease((t - hl[3]) / 0.28)
            x0m, x1m = xs[hl[0]] - 14, xs[hl[1]] + widths[hl[1]] + 14
            ph = 104 * pk
            d.rounded_rectangle((x0m, y - ph / 2, x0m + (x1m - x0m) * pr, y + ph / 2), radius=26, fill=hl[2] + (255,), outline=INKB + (255,), width=6)
        for wi, w_ in enumerate(words):
            on = act is not None and act[0] <= wi <= act[1]
            stext(img, (xs[wi] + widths[wi] / 2, y), w_, size, INKB if on else CRM, sw=0 if on else 8, sc=pk)


def scene_sb_close(img, v, t, spec, cues):
    q = b8c(cues)
    img.paste(Image.new("RGBA", (W, H), NAVY + (255,)), (0, 0))
    rays(img, 540, 900, 0, 2400, 18, t * 0.1, (14, 50, 64), None, 0.5)
    for j in range(6):
        px_ = (j * 220 + 80 + t * (18 + 7 * j)) % 1300 - 110
        py_ = (470 + (j % 2) * 60 if j < 3 else 1130 + (j % 2) * 80) + _m.sin(t * 1.6 + j) * 16
        put_coupon(img, px_, py_, 0.55 + 0.08 * (j % 3), swob(t, 0.4, 14) + j * 20, 190)
    d = ImageDraw.Draw(img)
    _phase_lines(img, d, [["IN AN"], ["ALL-STOCK", "DEAL,"], ["THE", "BUYER'S", "STOCK"], ["IS THE", "PRICE", "TAG"]], 540, 88, t, 0.1, q["twh"] - 0.1,
                 {1: (0, 0, TLP, q["tall"]), 2: (1, 2, TLP, q["tbuy"]), 3: (1, 2, GLD, q["tpr"])})
    if q["twh"] - 0.1 <= t < q["tcat"] - 0.1:
        _phase_lines(img, d, [["WHEN THE", "BUYER"], ["DROPS, THE"], ["WHOLE OFFER"], ["DROPS."]], 560, 92, t, q["twh"] - 0.1, q["tcat"] - 0.1,
                     {0: (1, 1, TLP, q["twh"] + 0.4), 3: (0, 0, RED, q["toff"])})
        k = t - q["twh"]
        ay = 1060 + 30 * _m.sin(k * 6)
        d.polygon([(480, ay - 40), (600, ay - 40), (600, ay + 20), (660, ay + 20), (540, ay + 110), (420, ay + 20), (480, ay + 20)], fill=RED + (255,), outline=INKB + (255,))
    if q["tcat"] - 0.1 <= t < q["tq"] - 0.1:
        k = t - q["tcat"]
        sc = lerp(2.2, 1.0, spr(k, 16, 7)) if k < 0.8 else 1.0
        stext(img, (540, 760), "THAT'S", 120, CRM, sw=12, sc=sc)
        stext(img, (540, 900), "THE CATCH.", 150, RED, sw=16, sc=sc, rot=-4)
    if t >= q["tq"] - 0.1 and t < q["tend"]:
        _phase_lines(img, d, [["WOULD YOU", "TAKE"], ["COUPONS FOR"], ["YOUR COMPANY?"]], 520, 84, t, q["tq"] - 0.1, 999, {1: (0, 0, GLD, q["tcoup"])}, step=124)
        pk = pop((t - q["tq"] - 0.8) / 0.3)
        spill(img, 540, 1000, "FOLLOW @whyitmoved", 72, RED, tc=CRM, padx=50, sc=max(0.01, pk), ow=9)
        stext(img, (540, 1120), "A DRAMATIZATION", 52, DIMC, sw=6, sc=max(0.01, pk))
    if t < 0.5:
        rr_ = int(1800 * (1 - ease(t / 0.5)))
        ImageDraw.Draw(img).ellipse((540 - rr_, 960 - rr_, 540 + rr_, 960 + rr_), fill=RED + (255,), outline=INKB + (255,), width=12)
    if t >= q["tend"]:
        k = t - q["tend"]
        hk = Image.new("RGBA", (W, H), (0, 0, 0, 255))
        hook_b(hk, 0.0, dict(tm=1.0, tl=4.0, tc=6.0, td=6.3), final=True)
        mask = Image.new("L", (W, H), 0)
        rr2 = int(1700 * ease(k / 0.35))
        ImageDraw.Draw(mask).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), fill=255)
        img.paste(hk, (0, 0), mask)
        if k < 0.35:
            ImageDraw.Draw(img).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), outline=INKB + (255,), width=10)


# ---------------------------------------------------------------- sound events
def _e1(v, c, st):
    q = b1c(c)
    return [(st + 0.0, "slide"), (st + 0.02, "thud"), (st + 0.02, "impact"), (st + q["tl"], "thud"), (st + q["tl"], "stamp"), (st + q["tc"], "whoosh1"), (st + q["td"], "pop")]


def _e2(v, c, st):
    q = b2c(c)
    return [(st + q["tb"], "pop"), (st + q["tb"] + 0.1, "rubber"), (st + q["tmv"], "pop"), (st + q["tmv"] + 0.1, "boing"), (st + q["tdata"], "blip"), (st + q["tdata"] + 0.25, "blip"),
            (st + q["tdata"] + 0.5, "pop"), (st + q["tbm"], "whoosh1"), (st + q["tbm"] + 0.5, "pop"), (st + q["tlas"], "pop"), (st + q["tlas"] + 0.1, "boing"), (st + q["tsend"], "pew"), (st + q["tlt"], "sparkle")]


def _e3(v, c, st):
    q = b3c(c)
    return [(st + 0.1, "pop"), (st + q["tcop"], "tick"), (st + q["tlt"] - 0.05, "snap"), (st + q["tlt"] + 0.05, "pew"), (st + q["tprop"] - 0.05, "whoosh1"), (st + q["tprop"] + 0.1, "bell"),
            (st + q["tprop"] + 0.2, "sparkle"), (st + q["tall"], "stamp")]


def _e4(v, c, st):
    q = b4c(c)
    ev = [(st + 0.1, "pop"), (st + q["tno"], "buzz"), (st + q["tcoup"], "whoosh2")]
    ev += [(st + q["tprint"] - 0.3 + j * 0.2 + k_, "tick") for j in range(9) for k_ in (0.0,)]
    ev += [(st + q["tprint"] - 0.3 + j * 0.2 + 0.55, "coin") for j in range(0, 9, 2)]
    ev += [(st + q["town"], "stamp"), (st + q["tfour"], "ding")]
    ev += [(st + q["tfour"] + 0.25 + j * 0.25 + 0.5, "coin") for j in range(5)]
    ev += [(st + q["tcomp"], "pop"), (st + q["thun"], "cash")]
    return ev


def _e5(v, c, st):
    q = b5c(c)
    return [(st + q["tcat"], "scratch"), (st + q["tcat"] + 0.4, "stamp"), (st + q["tfall"], "wah"), (st + q["tshr"], "deflate"), (st + q["tpr"], "whoosh1"), (st + q["tdr"], "wah"),
            (st + q["t771"], "scrub"), (st + q["t771"] + 0.4, "stamp"), (st + q["tdol"], "thud")]


def _e6(v, c, st):
    q = b6c(c)
    return [(st + 0.0, "pop"), (st + q["tonerep"], "pop"), (st + q["tinv"], "rubber"), (st + q["tover"], "pop"), (st + q["tan"], "pop"), (st + q["tbel"] - 0.5, "whoosh1"),
            (st + q["tbel"] + 0.6, "coin"), (st + q["tbel"] + 2.7, "tick"), (st + q["tbel"] + 2.8, "thud")]


def _e7(v, c, st):
    q = b7c(c)
    ev = [(st + q["tw"], "pop")] + [(st + q["tfirst"] + j * 0.11, "tick") for j in range(0, 9)]
    ev += [(st + q["t28"], "stamp"), (st + q["tsh"], "pop"), (st + q["tvote"], "thud"), (st + q["tvote"] - 0.6, "yawn"), (st + q["treg"], "stamp")]
    return ev


def _e8(v, c, st):
    q = b8c(c)
    return [(st + 0.05, "whoosh2"), (st + q["tall"], "pop"), (st + q["tbuy"], "pop"), (st + q["tpr"], "stamp"), (st + q["twh"], "whoosh1"), (st + q["tcat"], "stamp"),
            (st + q["tq"], "pop"), (st + q["tq"] + 0.8, "pop"), (st + q["tend"], "whoosh1"), (st + q["tend"] + 0.25, "ding")]


SV_EVENTS = {"sb_hook": _e1, "sb_meet": _e2, "sb_light": _e3, "sb_coupons": _e4, "sb_catch": _e5, "sb_why": _e6, "sb_wait": _e7, "sb_close": _e8}
SCENES.update({"sb_hook": scene_sb_hook, "sb_meet": scene_sb_meet, "sb_light": scene_sb_light, "sb_coupons": scene_sb_coupons, "sb_catch": scene_sb_catch,
               "sb_why": scene_sb_why, "sb_wait": scene_sb_wait, "sb_close": scene_sb_close})

_base_sfx = _sfx_sv


def _sfx_sv(kind, sr, rng):
    import numpy as np
    if kind == "slide":
        n = int(0.9 * sr); tt = np.arange(n) / sr
        f = 1800 - 1300 * tt / 0.9
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 1.5) * 0.6
    if kind == "pew":
        n = int(0.35 * sr); tt = np.arange(n) / sr
        f = 2400 * np.exp(-9 * tt) + 300
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 9)
    if kind == "blip":
        n = int(0.1 * sr); tt = np.arange(n) / sr
        return np.sign(np.sin(2 * np.pi * 880 * tt)) * 0.4 * np.exp(-tt * 25)
    if kind == "buzz":
        n = int(0.35 * sr); tt = np.arange(n) / sr
        return np.sign(np.sin(2 * np.pi * 110 * tt)) * 0.5 * np.minimum(1, (0.35 - tt) / 0.03)
    if kind == "deflate":
        n = int(0.6 * sr); tt = np.arange(n) / sr
        f = 700 * np.exp(-3.2 * tt) + 120
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 4) * 0.8 + np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 12) * 0.1
    if kind == "yawn":
        n = int(1.0 * sr); tt = np.arange(n) / sr
        f = 300 + 160 * np.sin(np.pi * tt)
        x = _onepole(2 * ((np.cumsum(f) / sr) % 1.0) - 1, 700, sr)
        return x / (np.abs(x).max() + 1e-9) * np.sin(np.pi * tt) ** 1.5 * 0.7
    return _base_sfx(kind, sr, rng)
