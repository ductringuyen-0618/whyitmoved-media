"""INTEL clip timeline.  Every action is keyed to exact word times (vo_exact.json).
frame(t) -> RGBA PIL image (1080x1920).  state(t) -> (shot, cam, objects) for drawing and for the clutter check."""
import sys, os, json, math as m
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.dont_write_bytecode = True
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import stockshort_B3 as S
from stockshort_B3 import blit, put, INKB
from world import kf, seg, cl, e_s, e_o, e_i, e_io, e_sp, e_b
import chars_intel as CI
from chars_intel import RES

W, H = 1080, 1920
FPS = 30
FL = 1300               # feet line (world y)
LINE_Y = FL - 70        # thin floor line
SI, SA = 1.9, 1.3       # Intel / AMD scale
WALL = (200, 226, 246)
TAN = (214, 170, 126)
LINEC = (170, 120, 80)
POPPINS = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
NAVY = (14, 26, 54)
GOLD = (255, 200, 61)

# ------------------------------------------------------------------ voice clock
EX = json.load(open(os.path.join(HERE, "vo_exact.json")))
LN = json.load(open(os.path.join(HERE, "vo_timing.json")))["lines"]


def T(line, word, nth=0, part=None):
    key = word.strip(".,?!").lower()
    hits = [w for w in EX if w["line"] == line and w["word"].strip(".,?!").lower() == key]
    w = hits[nth]
    return w["parts"][part] if part is not None else w["start"]


def cut_after(n):
    a, b = LN[n - 1]["end"], LN[n]["start"]
    return round((a + b) / 2 * FPS) / FPS


CUTS = [cut_after(n) for n in (3, 5, 9, 14, 17)]       # 8.167 | 13.967 | 23.9 | 35.8 | 44.5 (all inside the 0.17 s gaps)
DUR = round(46.40 * FPS) / FPS
NFR = int(round(DUR * FPS))


def shot_of(t):
    k = 0
    for c in CUTS:
        if t >= c - 1e-6:
            k += 1
    return k


SHOT_NAMES = ["B1 meet Intel", "B2 gold stars", "B3 forecast + cloud", "B4 the slide", "B5 same floor", "loop"]
SHOT_RANGE = [(0.0, CUTS[0])] + [(CUTS[i], CUTS[i + 1]) for i in range(len(CUTS) - 1)] + [(CUTS[-1], DUR)]

# the ONE camera shake in the clip: the skid-bonk
HIT_B4 = T(11, "floor")


def shake(t):
    h = HIT_B4
    if h <= t < h + 0.42:
        u = (t - h) / 0.42
        a = 22 * (1 - u) ** 2
        return a * m.sin(58 * (t - h)), 0.7 * a * m.cos(47 * (t - h))
    return 0.0, 0.0


class Cam:
    def __init__(s, z=1.0, shx=0.0, shy=0.0):
        s.z, s.shx, s.shy = z, shx, shy

    def X(s, wx): return (wx - 540) * s.z + 540 + s.shx
    def Y(s, wy): return (wy - FL) * s.z + FL + s.shy


def push(t, a, b, z0=1.0, z1=1.04):
    return z0 + (z1 - z0) * cl((t - a) / (b - a))


def step(t, seq):
    v = seq[0][1]
    for t0, val in seq:
        if t >= t0:
            v = val
    return v


def lp(a, b, u):
    return a + (b - a) * u


def rot_pt(x, y, sx, sy, rot, lx, ly):
    c, sn = m.cos(m.radians(rot)), m.sin(m.radians(rot))
    vx, vy = lx * sx, ly * sy
    return x + c * vx - sn * vy, y + sn * vx + c * vy


# ------------------------------------------------------------------ object builders
def bot(who, x, y=FL, eyes="open", mouth="grin", al=8, ar=8, sx=1.0, sy=1.0, rot=0.0, dy=0.0, tumble=False, **k):
    return dict(id=who, kind="bot", grp=who, who=who, x=x, y=y + dy, s=SI if who == "intel" else SA, eyes=eyes, mouth=mouth,
                al=al, ar=ar, sx=sx, sy=sy, rot=rot, tumble=tumble, **k)


def bot_pivot(o):
    """world pivot (px,py) and tile-pivot (design units) used when drawing a bot"""
    s, sx, sy, r = o["s"], o["sx"], o["sy"], o["rot"]
    if o["tumble"]:
        ext = 144 * (abs(m.cos(m.radians(r))) * s * sy + abs(m.sin(m.radians(r))) * s * sx)
        return o["x"], o["y"] - ext, CI.CENTER
    return o["x"], o["y"], CI.FEET


def bot_hand(o, side=1):
    px, py, piv = bot_pivot(o)
    a = o["ar"] if side > 0 else o["al"]
    a = int(round(a / 10.0)) * 10
    hx, hy = CI.arm_hand_pt(side, a)
    return rot_pt(px, py, o["s"] * o["sx"], o["s"] * o["sy"], o["rot"], hx - piv[0], hy - piv[1])


def card(x, y, side="front", stamp=False, wet=False, sx=1.0, sy=1.0, rot=0.0, cid="card"):
    return dict(id=cid, kind="card", grp="prop", x=x, y=y, side=side, stamp=stamp, wet=wet, sx=sx, sy=sy, rot=rot)


def chipo(cid, cx, cy, sc, lines, fill, tc=INKB, w_pad=110):
    return dict(id=cid, kind="tchip", grp="chip", cx=cx, cy=cy, sc=sc, lines=lines, fill=fill, tc=tc)


def pop(t, t0, dur=0.26):
    return e_b(seg(t, t0, t0 + dur)) if t >= t0 else 0.0


def chip_sc(t, t_in, t_out, dur_in=0.26, dur_out=0.14):
    if t < t_in:
        return 0.0
    if t >= t_out:
        return max(0.0, 1 - seg(t, t_out, t_out + dur_out))
    return max(0.0, lp(0.3, 1.0, e_b(seg(t, t_in, t_in + dur_in))))


def puddle(w, x=540):
    return dict(id="puddle", kind="puddle", grp="weather", x=x, w=round(w, 1))


GREEN = (126, 214, 146)
ORANGE = (255, 176, 84)
LAV = (206, 196, 255)
RED = (255, 110, 96)
YELLOW = (255, 214, 64)


# ------------------------------------------------------------------ BEAT 1  (0 .. CUTS[0])  Meet Intel
IX1 = 540


def shot1(t):
    c1 = CUTS[0]
    cam = Cam(push(t, 0, c1))
    t_bow = T(2, "Intel")
    t_br = T(2, "brains")
    t_tuck = T(3, "Here's")
    t_wd = T(3, "weird")
    rot = kf(t, (t_bow, 0), (t_bow + 0.22, 12, "o"), (t_bow + 0.5, 12), (t_bow + 0.75, 0, "s"))
    rot += kf(t, (t_wd, 0), (t_wd + 0.25, -8, "o"))
    ar = kf(t, (0, 8), (t_bow, 8), (t_bow + 0.2, 130, "o"), (t_bow + 0.5, 130), (t_bow + 0.72, 8, "s"), (t_br, 8),
            (t_br + 0.25, 160, "o"), (t_tuck, 160), (t_tuck + 0.25, 8, "s"))
    eyes, mouth = step(t, [(0, ("open", "grin")), (t_bow, ("happy", "grin")), (t_bow + 0.75, ("open", "grin")), (t_br, ("wide", "open")),
                           (t_tuck, ("open", "grin")), (t_wd, ("lookr", "flat"))])
    tp = 1 if t_bow + 0.28 < t < t_bow + 0.62 else 0
    b = bot("intel", IX1, eyes=eyes, mouth=mouth, ar=ar, rot=rot, tagpulse=tp, brow=1 if t >= t_wd else 0)
    objs = [b]
    # chip from the chest
    if t_br <= t < t_tuck + 0.25:
        hx, hy = bot_hand(b, 1)
        top = (hx, hy - 70)
        chest = (IX1, b["y"] - (CI.FEET[1] - 280 - 20) * SI)
        if t < t_tuck:
            p = e_o(seg(t, t_br, t_br + 0.25))
            pos = (lp(chest[0], top[0], p), lp(chest[1], top[1], p))
            objs.append(dict(id="mchip", kind="mchip", grp="intel", x=pos[0], y=pos[1], s=lp(1.1, 2.3, p)))
        else:
            p = e_s(seg(t, t_tuck, t_tuck + 0.25))
            pos = (lp(top[0], chest[0], p), lp(top[1], chest[1], p))
            objs.append(dict(id="mchip", kind="mchip", grp="intel", x=pos[0], y=pos[1], s=lp(2.3, 1.1, p)))
    return cam, objs


# ------------------------------------------------------------------ BEAT 2  Last quarter was fine (stars)
IX2 = 350


def shot2(t):
    c0, c1 = CUTS[0], CUTS[1]
    cam = Cam(push(t, c0, c1))
    t_q = T(4, "quarter")
    t_fine = T(4, "fine")
    t_21 = T(5, "21")
    t_wh = T(5, "while")
    t_rn = T(5, "rained")
    ar = kf(t, (c0, 8), (t_q - 0.05, 8), (t_q + 0.28, 60, "o"), (t_wh, 60), (t_wh + 0.3, 160, "o"))
    eyes, mouth = step(t, [(c0, ("open", "smile")), (t_fine, ("happy", "grin")), (t_wh, ("happy", "grin"))])
    b = bot("intel", IX2, eyes=eyes, mouth=mouth, ar=ar)
    objs = [b]
    if t >= t_q:
        hx, hy = bot_hand(b, 1)
        tgt = (hx + 40, hy - 150)
        p = e_o(seg(t, t_q, t_q + 0.45))
        cx, cy = lp(tgt[0], tgt[0], p), lp(1640, tgt[1], p)
        stamped = t >= t_fine + 0.2
        objs.append(card(cx, cy, "front", stamp=stamped))
        if t_fine <= t < t_fine + 0.2:
            sc = kf(t, (t_fine, 2.6), (t_fine + 0.12, 0.85, "o"), (t_fine + 0.2, 1.0, "s"))
            objs.append(dict(id="bigstar", kind="bigstar", grp="prop", x=cx, y=cy - 5, sc=round(sc, 3)))
    s = chip_sc(t, t_21, t_wh)
    if s > 0.02:
        objs.append(chipo("chipSales", 540, 440, s, [("SALES +21%", 104)], GREEN))
    # three gold stars rain on Intel's head and bounce off
    for i, (dx, dxv) in enumerate(((-70, -1), (0, 0.3), (70, 1))):
        t0 = t_rn + i * 0.07
        if t0 <= t < t0 + 0.9:
            u = t - t0
            xs = IX2 + dx
            if u < 0.26:
                y = lp(420, 800, e_i(u / 0.26))
                x = xs
            else:
                v = u - 0.26
                y = 800 - 220 * (1 - ((v / 0.3) - 1) ** 2) if v < 0.6 else 800 + 0
                y = 800 - 230 * 4 * (v / 0.6) * (1 - v / 0.6) if v < 0.6 else 800
                x = xs + dxv * 150 * (v / 0.6) if v < 0.6 else xs + dxv * 150
            if y < 805:
                objs.append(dict(id=f"star{i}", kind="fstar", grp="stars", x=x, y=y, rot=u * 220 * (1 if dxv >= 0 else -1)))
    return cam, objs


# ------------------------------------------------------------------ BEAT 3  forecast sign, cloud, rain
IX3 = 350
CLOUD_Y = 690


def shot3(t):
    c0, c1 = CUTS[1], CUTS[2]
    cam = Cam(push(t, c0, c1))
    t_sh = T(6, "shared")
    t_qr = T(6, "quarter")
    t_lo = T(7, "Lower")
    t_st = T(8, "Storm")
    t_hd = T(8, "head")
    t_pc = T(9, "PC")
    t_end = c1 - 0.08
    ar = kf(t, (c0, 160), (t_sh, 160), (t_sh + 0.3, 140, "o"))
    eyes, mouth = step(t, [(c0, ("happy", "grin")), (t_sh, ("open", "grin")), (t_qr, ("open", "flat")), (t_lo + 0.6, ("worry", "flat")),
                           (t_st, ("wide", "o")), (t_hd, ("open", "grin"))])
    rain_on = t >= t_hd
    b = bot("intel", IX3, eyes=eyes, mouth=mouth, ar=ar, sweat=1 if rain_on else 0)
    objs = []
    if t >= t_hd:
        w = kf(t, (t_hd, 50), (t_hd + 0.6, 150, "o"), (t_end, 520, "s"))
        objs.append(puddle(w, 540))
    objs.append(b)
    hx, hy = bot_hand(b, 1)
    # held card (from B2) then tossed away on "shared"
    if t < t_sh + 0.6:
        if t < t_sh:
            objs.append(card(hx + 40, hy - 150, "front", stamp=True))
        else:
            u = (t - t_sh) / 0.6
            objs.append(card(hx + 40 + 1100 * e_i(u), hy - 150 - 260 * u + 180 * u * u, "front", stamp=True, rot=420 * u))
    # sign
    if t >= t_sh + 0.08:
        sc = pop(t, t_sh + 0.08, 0.3)
        face = "sun" if t < t_qr + 0.15 else "frown"
        u = seg(t, t_qr, t_qr + 0.3)
        fx = abs(m.cos(m.pi * u)) if 0 < u < 1 else 1.0
        objs.append(dict(id="sign", kind="sign", grp="prop", x=hx, y=hy + 34, sc=round(sc, 3), fx=round(max(0.04, fx), 3), face=face))
    s = chip_sc(t, t_lo, t_st - 0.05)
    if s > 0.02:
        objs.append(chipo("chipFc", 540, 455, s, [("FORECAST LOWER", 70), ("THAN EXPECTED", 70)], ORANGE))
    # storm cloud drops in
    if t >= t_st:
        u = seg(t, t_st, t_st + 0.4)
        cy = lp(300, CLOUD_Y, e_b(u)) if u > 0 else 300
        objs.append(dict(id="cloud", kind="cloud", grp="weather", x=IX3 + 10, y=round(cy, 1)))
    if rain_on:
        objs.append(dict(id="rain", kind="rain", grp="weather", x0=IX3 - 150, x1=IX3 + 170, y0=CLOUD_Y + 80, y1=FL + 4,
                         ph=round((t - t_hd) * 620, 1)))
    s = chip_sc(t, t_pc, t_end)
    if s > 0.02:
        objs.append(chipo("chipPc", 540, 440, s, [("PC SLOWDOWN", 96)], ORANGE))
    return cam, objs


# ------------------------------------------------------------------ BEAT 4  the slide
PUD_X = 540
CARD_FLOOR = (800, FL - 12)


def shot4(t):
    c0, c1 = CUTS[2], CUTS[3]
    z = push(t, c0, c1)
    sx_, sy_ = shake(t)
    cam = Cam(z, sx_, sy_)
    t_mem = T(10, "memory")
    t_sh = T(10, "shortage")
    t_stp = T(11, "Intel's")
    t_sl = T(11, "slid")
    t_fl = T(11, "floor")
    t_92 = T(12, "92")
    t_66 = T(12, "66")
    t_dn = T(13, "down")
    t_286 = T(13, "28.6")
    t_pct_end = T(13, "percent") + 0.55
    t_w = T(14, "worst")
    t_f = T(14, "fifty")
    # ---- Intel motion
    x = kf(t, (c0, 330), (t_stp, 330), (t_stp + 0.3, 400, "s"), (t_sl, 400), (t_sl + 0.62, 560, "o"))
    hop_step = -26 * 4 * (seg(t, t_stp, t_stp + 0.3)) * (1 - seg(t, t_stp, t_stp + 0.3)) if t_stp <= t <= t_stp + 0.3 else 0.0
    tilt = kf(t, (t_sh, 0), (t_sh + 0.2, 7, "o"), (t_stp, 7), (t_stp + 0.2, 0, "s"))
    rot = tilt
    if t >= t_sl:
        rot = kf(t, (t_sl, 0), (t_sl + 0.4, -62, "o"), (t_fl - 0.1, -80, "s"), (t_fl, -90, "i"))
    if t >= t_w:
        rot = kf(t, (t_w, -90), (t_f, 0, "s"))
    uf = seg(t, t_sl, t_fl)
    dy = -170 * 4 * uf * (1 - uf) if (t_sl <= t < t_fl) else 0.0
    sy = 1.0
    sx = 1.0
    if t_fl <= t < t_fl + 0.3:
        sy = kf(t, (t_fl, 0.86), (t_fl + 0.12, 1.07, "o"), (t_fl + 0.3, 1.0, "s"))
        sx = 1 + (1 - sy) * 0.6
    if t >= t_f - 0.2:
        sy = kf(t, (t_f - 0.2, 1.0), (t_f + 0.1, 0.93, "s"))
    ar = 8
    if t_fl <= t < t_dn:
        ar = 70
    if t_dn <= t < t_f:
        ar = kf(t, (t_dn, 70), (t_dn + 0.2, 8, "s"))
    if t >= t_f:
        ar = kf(t, (t_f, 8), (t_f + 0.35, 160, "o"))
    eyes, mouth = step(t, [(c0, ("worry", "nerv")), (t_sh, ("lookd", "nerv")), (t_stp, ("worry", "nerv")), (t_sl, ("wide", "o")),
                           (t_fl, ("x", "wob")), (t_w, ("flat", "flat")), (t_f, ("flat", "flat"))])
    tumble = t >= t_sl
    b = bot("intel", x, eyes=eyes, mouth=mouth, ar=ar, rot=rot, dy=dy + hop_step, sx=sx, sy=sy, tumble=tumble, sweat=1)
    objs = [puddle(560, PUD_X)]
    # soggy card in the puddle (static) until Intel lifts it
    if t < t_f:
        objs.append(card(CARD_FLOOR[0], CARD_FLOOR[1], "front", stamp=True, wet=True, sy=0.2, rot=3, cid="card"))
    objs.append(b)
    if t >= t_f:
        hx, hy = bot_hand(b, 1)
        tgt = (hx + 40, hy - 150)
        p = e_o(seg(t, t_f, t_f + 0.4))
        cx, cy = lp(CARD_FLOOR[0], tgt[0], p), lp(CARD_FLOOR[1], tgt[1], p)
        objs.append(card(cx, cy, "front", stamp=True, wet=True, sy=lp(0.2, 1.0, e_o(seg(t, t_f, t_f + 0.3))), rot=lp(3, 0, p), cid="card"))
        if t >= t_f + 0.5:
            u = seg(t, t_f + 0.5, t_f + 0.9)
            objs.append(dict(id="drop", kind="drop", grp="drop", x=cx + 30, y=round(lp(cy + 170, FL - 6, e_i(u)), 1)))
    # dust puff while sitting up
    if t_w + 0.1 <= t < t_w + 0.8:
        u = (t - (t_w + 0.1)) / 0.7
        objs.append(dict(id="dust", kind="dust", grp="dust", x=x - 230, y=FL - 40, u=round(u, 3)))
    # chips
    s = chip_sc(t, t_mem, T(11, "So"))
    if s > 0.02:
        objs.append(chipo("chipMem", 540, 455, s, [("REPORTS:", 74), ("MEMORY SHORTAGE", 74)], LAV))
    if t_92 <= t < t_66:
        objs.append(chipo("chipPrice", 540, 520, pop(t, t_92, 0.26) or 0.01, [("$92", 150)], YELLOW))
    elif t_66 <= t < t_dn:
        objs.append(chipo("chipPrice", 540, 520, 1.0, [("$66", 150)], YELLOW))
    elif t_dn <= t < t_dn + 0.14:
        objs.append(chipo("chipPrice", 540, 520, max(0.01, 1 - seg(t, t_dn, t_dn + 0.14)), [("$66", 150)], YELLOW))
    if t_286 <= t < t_pct_end + 0.14:
        u = seg(t, t_286, t_286 + 0.2)
        sc = lp(2.2, 1.0, e_o(u)) if t < t_pct_end else max(0.01, 1 - seg(t, t_pct_end, t_pct_end + 0.14))
        objs.append(chipo("chipPct", 540, 520, sc, [("-28.6%", 170)], RED, (255, 255, 255)))
    return cam, objs


# ------------------------------------------------------------------ BEAT 5  same floor (AMD)
def shot5(t):
    c0, c1 = CUTS[3], CUTS[4]
    cam = Cam(push(t, c0, c1))
    t_ri = T(15, "Rival")
    t_sl = T(15, "slipped")
    t_fl = T(15, "floor")
    t_4 = T(16, "4")
    t_q = T(17, "quarter")
    t_but = T(17, "but")
    ix = 300
    sy = 0.93
    if t >= t_q:
        sy = kf(t, (t_q, 0.93), (t_q + 0.3, 1.0, "o"))
    dy = -30 * 4 * seg(t, t_q, t_q + 0.3) * (1 - seg(t, t_q, t_q + 0.3)) if t_q <= t <= t_q + 0.3 else 0.0
    eyes, mouth = step(t, [(c0, ("flat", "flat")), (t_ri, ("open", "smile")), (t_sl, ("wide", "o")), (t_fl, ("open", "flat")),
                           (t_q, ("open", "smile")), (t_but + 0.15, ("flat", "flat"))])
    b = bot("intel", ix, eyes=eyes, mouth=mouth, ar=160, sy=sy, dy=dy, sweat=1, tumble=True)
    # AMD
    if t < t_sl:
        ax = lp(1320, 900, seg(t, t_ri, t_sl))
        bob = -12 * abs(m.sin(m.pi * 3.2 * (t - t_ri)))
        a = bot("amd", ax, eyes="open", mouth="smile", dy=bob, al=30 if int((t - t_ri) * 4) % 2 else 8, ar=8 if int((t - t_ri) * 4) % 2 else 30)
    else:
        u = seg(t, t_sl, t_fl)
        ax = lp(900, 790, e_o(u))
        hop = -150 * 4 * u * (1 - u)
        rot = lp(0, 90, e_s(u)) if t < t_fl else 90
        a = bot("amd", ax, eyes="wide" if t < t_fl else "x", mouth="o" if t < t_fl else "wob", al=120 if t < t_fl else 20, ar=120 if t < t_fl else 20,
                rot=rot, dy=hop, tumble=True)
        if t_fl <= t < t_fl + 0.3:
            a["sy"] = kf(t, (t_fl, 0.88), (t_fl + 0.12, 1.06, "o"), (t_fl + 0.3, 1.0, "s"))
            a["sx"] = 1 + (1 - a["sy"]) * 0.6
    objs = [puddle(560, PUD_X), a, b]
    hx, hy = bot_hand(b, 1)
    cside, cfx = "front", 1.0
    if t_but <= t < t_but + 0.34:
        u = (t - t_but) / 0.34
        cfx = max(0.04, abs(m.cos(m.pi * u)))
        cside = "front" if u < 0.5 else "back"
    elif t >= t_but + 0.34:
        cside = "back"
    objs.append(card(hx + 40, hy - 150, cside, stamp=True, wet=True, sx=round(cfx, 3)))
    s = chip_sc(t, t_4, T(17, "Last") - 0.065)
    if s > 0.02:
        objs.append(chipo("chipPeers", 540, 455, s, [("PEERS", 80), ("-4% TO -12%", 100)], ORANGE))
    return cam, objs


# ------------------------------------------------------------------ LOOP  (dry set, frame-0 composition)
def shot6(t):
    cam = Cam(1.0)
    return cam, [bot("intel", IX1)]


SHOTS = [shot1, shot2, shot3, shot4, shot5, shot6]

# ------------------------------------------------------------------ topic title card (frame 0) -> small pill -> back for the loop
TW = [("INTEL", T(1, "Intel's")), ("STOCK", T(1, "stock"))]
T_SHRINK = T(2, "who")
T_GROW = T(18, "So")
T_SLAM = T(1, "29")
LIFT0 = 42.0


def title_obj(t, hide):
    if t < T_GROW:
        u = e_io(seg(t, T_SHRINK, T_SHRINK + 0.4))
    else:
        u = 1 - e_io(seg(t, T_GROW, T_GROW + 0.6))
    act = []
    for nm, st in TW:
        act.append(round(min(1.0, (t - st) / 0.16), 3) if (st <= t < st + 0.40 and t < T_SHRINK) else -1.0)
    # chip on its spring: lifted at frame 0, slams down on "29", lifted again for the loop
    if t < T_SLAM:
        lift = LIFT0 - 10 * e_io(seg(t, 0.45, T_SLAM - 0.05)) if t > 0.45 else LIFT0
    elif t < T_SLAM + 0.5:
        lift = kf(t, (T_SLAM, 32.0), (T_SLAM + 0.07, -7, "i"), (T_SLAM + 0.2, 3, "o"), (T_SLAM + 0.5, 0, "s"))
    elif t < T_GROW + 0.2:
        lift = 0.0
    else:
        lift = LIFT0 * e_o(seg(t, T_GROW + 0.2, T_GROW + 0.6))
    flash = 1 if (T_SLAM + 0.07 <= t < T_SLAM + 0.3) else 0
    return dict(id="title", kind="title", grp="title", u=round(u, 4), act=act, lift=round(lift, 1), flash=flash, hide=hide)


BLINKS = [3.15, 6.25, 39.05, 43.95]


def state(t):
    cam, objs = SHOTS[shot_of(t)](t)
    objs = list(objs)
    if any(b0 <= t < b0 + 0.13 for b0 in BLINKS):
        for o in objs:
            if o["kind"] == "bot" and o["who"] == "intel" and o["eyes"] in ("open", "wide"):
                o["eyes"] = "blink"
    objs.append(title_obj(t, any(o["kind"] == "tchip" and o.get("sc", 1) > 0.02 for o in objs)))
    return shot_of(t), cam, objs


# ------------------------------------------------------------------ drawing
_F = {}


def pfont(size, path=POPPINS):
    k = (size, path)
    if k not in _F:
        _F[k] = ImageFont.truetype(path, size)
    return _F[k]


def bg(cam):
    im = Image.new("RGBA", (W, H), WALL + (255,))
    d = ImageDraw.Draw(im)
    fy = cam.Y(LINE_Y)
    d.rectangle((0, fy, W, H), fill=TAN + (255,))
    d.rectangle((0, fy - 3, W, fy + 3), fill=LINEC + (255,))
    return im


_TC = {}


def _title_card(act, lift, flash):
    key = (tuple(act), round(lift), flash)
    if key in _TC:
        return _TC[key]
    CWd, CHt = 1000, 400                 # tile covers screen y 330..730
    tile = Image.new("RGBA", (CWd, CHt), (0, 0, 0, 0))
    d = ImageDraw.Draw(tile)
    oy = 330
    # bar
    d.rounded_rectangle((4, 515 - oy, CWd - 4, 692 - oy), radius=44, fill=NAVY + (255,), outline=INKB + (255,), width=8)
    d.rounded_rectangle((18, 529 - oy, CWd - 18, 678 - oy), radius=34, outline=(255, 255, 255, 60), width=3)
    f = pfont(118)
    full = "INTEL STOCK"
    x = (CWd - d.textlength(full, font=f)) / 2
    for i, (nm, st) in enumerate(TW):
        a = act[i]
        col = GOLD if a >= 0 else (255, 255, 255)
        wd = d.textlength(nm, font=f)
        if a >= 0:
            sc = 1 + 0.07 * m.sin(m.pi * min(1.0, a))
            tt = Image.new("RGBA", (int(wd) + 60, 180), (0, 0, 0, 0))
            ImageDraw.Draw(tt).text((30, 90), nm, font=f, fill=col + (255,), anchor="lm")
            tt = tt.resize((int(tt.width * sc), int(tt.height * sc)), Image.BICUBIC)
            tile.alpha_composite(tt, (int(x - 30 * sc - wd * (sc - 1) / 2), int(603 - oy - tt.height / 2)))
        else:
            d.text((x, 603 - oy), nm, font=f, fill=col + (255,), anchor="lm")
        x += wd + d.textlength(" ", font=f)
    # chip on a spring
    cw, chh = 560, 125
    cyc = 449 - lift                       # centre y (screen)
    bar_top = 515
    if lift > 3:                           # spring coil
        n = 5
        for k in range(n + 1):
            yy = bar_top - 2 - (lift + 6) * k / n
            d.line((540 - 70 - 0, yy - oy, 540 + 70, yy - oy), fill=INKB + (255,), width=0) if False else None
        pts = []
        for k in range(0, 41):
            u = k / 40
            yy = (bar_top - 2) - (lift + 4) * u
            xx = 540 + 62 * m.sin(u * m.pi * 2 * 4)
            pts.append((xx, yy - oy))
        d.line(pts, fill=INKB + (255,), width=16, joint="curve")
        d.line(pts, fill=(200, 208, 224, 255), width=8, joint="curve")
    cy0 = cyc - chh / 2
    sq = 1.0
    if lift < 0:
        sq = 1 - 0.0
    fillc = (255, 150, 130) if flash else (255, 110, 96)
    d.rounded_rectangle((540 - cw / 2, cy0 - oy, 540 + cw / 2, cy0 + chh - oy + (0 if lift >= 0 else 0)), radius=34, fill=fillc + (255,), outline=INKB + (255,), width=8)
    d.text((540, cy0 + chh / 2 + 2 - oy), "-28.6%", font=pfont(96), fill=(255, 255, 255, 255), anchor="mm")
    _TC[key] = tile
    return tile


def _title_pill():
    if "pill" in _TC:
        return _TC["pill"]
    f = pfont(46)
    PW, PH = 640, 76
    tile = Image.new("RGBA", (PW, PH), (0, 0, 0, 0))
    d = ImageDraw.Draw(tile)
    d.rounded_rectangle((3, 3, PW - 3, PH - 3), radius=38, fill=NAVY + (255,), outline=INKB + (255,), width=6)
    parts = [("INTEL STOCK ", (255, 255, 255)), ("-28.6%", (255, 140, 120))]
    tw = sum(d.textlength(p, font=f) for p, _ in parts)
    x = (PW - tw) / 2
    for p, c in parts:
        d.text((x, PH / 2 + 1), p, font=f, fill=c + (255,), anchor="lm")
        x += d.textlength(p, font=f)
    _TC["pill"] = tile
    return tile


PILL_Y = 396


def draw_title(im, o):
    u = o["u"]
    CARD_CY = 330 + 200          # tile centre y on screen
    if u < 0.999:
        card = _title_card(o["act"], o["lift"], o["flash"])
        k = lp(1.0, 640 / 1000, u)
        c2 = card.resize((max(2, int(card.width * k)), max(2, int(card.height * k))), Image.BICUBIC) if u > 0 else card
        a = 1.0 if u <= 0 else 1 - min(1.0, u * 1.6)
        if a < 1.0:
            c2 = c2.copy()
            c2.putalpha(c2.getchannel("A").point(lambda v: int(v * a)))
        # the bar (not the lifted chip) travels to the pill position
        bar_c = 603
        cy = lp(CARD_CY, PILL_Y - (bar_c - CARD_CY) * k, e_io(u))
        put(im, c2, 540 - c2.width / 2, cy - c2.height / 2)
    if u > 0.0 and not o["hide"]:
        pill = _title_pill()
        a = min(1.0, max(0.0, (u - 0.35) / 0.65))
        if a > 0:
            p2 = pill if a >= 1 else pill.copy()
            if a < 1:
                p2.putalpha(p2.getchannel("A").point(lambda v: int(v * a)))
            put(im, p2, 540 - pill.width / 2, PILL_Y - pill.height / 2)


def draw_tchip(im, o):
    sc = o["sc"]
    if sc <= 0.02:
        return
    lines = o["lines"]
    fonts = [pfont(sz) for _, sz in lines]
    dd = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
    ws = [dd.textlength(txt, font=f) for (txt, _), f in zip(lines, fonts)]
    hs = [sz * 1.2 for _, sz in lines]
    pw, ph = int(max(ws) + 110), int(sum(hs) + 60)
    tile = Image.new("RGBA", (pw + 20, ph + 20), (0, 0, 0, 0))
    d = ImageDraw.Draw(tile)
    d.rounded_rectangle((10, 10, 10 + pw, 10 + ph), radius=44, fill=o["fill"] + (255,), outline=INKB + (255,), width=9)
    yy = 10 + 30
    for (txt, sz), f, w_, h_ in zip(lines, fonts, ws, hs):
        d.text((10 + pw / 2, yy + h_ / 2), txt, font=f, fill=o["tc"] + (255,), anchor="mm")
        yy += h_
    if sc != 1.0:
        tile = tile.resize((max(2, int(tile.width * sc)), max(2, int(tile.height * sc))), Image.BILINEAR)
    put(im, tile, o["cx"] - tile.width / 2, o["cy"] - tile.height / 2)


def draw_obj(im, cam, o):
    z = cam.z
    k = o["kind"]
    if k == "bot":
        tile = CI.bot_tile(o["who"], o["eyes"], o["mouth"], o["al"], o["ar"], o.get("sweat", 0), o.get("brow", 0), o.get("tagpulse", 0))
        px, py, piv = bot_pivot(o)
        s = o["s"] * z / RES
        blit(im, tile, cam.X(px), cam.Y(py), piv[0] * RES, piv[1] * RES, s * o["sx"], s * o["sy"], o["rot"])
    elif k == "puddle":
        w = o["w"] * z
        h = max(6, w * 0.15)
        cx, cy = cam.X(o["x"]), cam.Y(FL - 4)
        t = Image.new("RGBA", (int(w) + 8, int(h) + 8), (0, 0, 0, 0))
        dd = ImageDraw.Draw(t)
        dd.ellipse((2, 2, w + 2, h + 2), fill=(116, 146, 198, 255))
        dd.ellipse((w * 0.2, h * 0.18, w * 0.62, h * 0.5), fill=(150, 180, 226, 255))
        put(im, t, cx - t.width / 2, cy - t.height / 2)
    elif k == "card":
        tile = CI.card_tile(o["side"], o["stamp"], o["wet"])
        blit(im, tile, cam.X(o["x"]), cam.Y(o["y"]), CI.CARD_W * RES / 2, CI.CARD_H * RES / 2, z / RES * o["sx"], z / RES * o["sy"], o["rot"])
    elif k == "bigstar":
        tile = CI.star_tile(74)
        blit(im, tile, cam.X(o["x"]), cam.Y(o["y"] + 0), tile.width / 2, tile.height / 2, z / RES * o["sc"], z / RES * o["sc"], 0)
    elif k == "fstar":
        tile = CI.star_tile(46)
        blit(im, tile, cam.X(o["x"]), cam.Y(o["y"]), tile.width / 2, tile.height / 2, z / RES, z / RES, o["rot"])
    elif k == "sign":
        if o["sc"] > 0.02:
            tile = CI.sign_tile(o["face"])
            blit(im, tile, cam.X(o["x"]), cam.Y(o["y"]), 160 * RES, 425 * RES, z / RES * o["sc"] * o["fx"], z / RES * o["sc"], 0)
    elif k == "cloud":
        tile = CI.cloud_tile()
        blit(im, tile, cam.X(o["x"]), cam.Y(o["y"]), CI.CLOUD_W * RES / 2, CI.CLOUD_H * RES / 2, z / RES * 0.78, z / RES * 0.78, 0)
    elif k == "rain":
        d = ImageDraw.Draw(im)
        n = 9
        for i in range(n):
            x = o["x0"] + (o["x1"] - o["x0"]) * (i + 0.5) / n
            span = o["y1"] - o["y0"]
            for j in range(2):
                yy = o["y0"] + ((o["ph"] + i * 83 + j * span / 2) % span)
                ln = 46
                y2 = min(o["y1"], yy + ln)
                d.line((cam.X(x), cam.Y(yy), cam.X(x - 6), cam.Y(y2)), fill=(96, 164, 240, 255), width=max(4, int(9 * z)))
    elif k == "drop":
        tile = CI.drop_tile()
        blit(im, tile, cam.X(o["x"]), cam.Y(o["y"]), tile.width / 2, tile.height / 2, z / RES * 1.2, z / RES * 1.2, 0)
    elif k == "dust":
        u = o["u"]
        for i, (dx, dy_, r) in enumerate(((-40, 0, 38), (10, -26, 46), (56, 4, 34), (-6, 16, 30))):
            rr = r * (0.5 + 1.1 * u) * z
            a = int(230 * (1 - u))
            t = Image.new("RGBA", (int(rr * 2 + 8), int(rr * 2 + 8)), (0, 0, 0, 0))
            ImageDraw.Draw(t).ellipse((4, 4, rr * 2 + 4, rr * 2 + 4), fill=(246, 240, 230, a), outline=(150, 140, 130, a), width=4)
            put(im, t, cam.X(o["x"] + dx * (1 + u)) - t.width / 2, cam.Y(o["y"] + dy_ - 40 * u) - t.height / 2)
    elif k == "mchip":
        tile = CI.minichip_tile()
        blit(im, tile, cam.X(o["x"]), cam.Y(o["y"]), tile.width / 2, tile.height / 2, z / RES * o["s"], z / RES * o["s"], 0)
    elif k == "tchip":
        draw_tchip(im, o)
    elif k == "title":
        draw_title(im, o)


# ------------------------------------------------------------------ captions
def captions(im, t):
    cur = None
    for c in CAPS:
        if c["t0"] <= t < c["t1"]:
            cur = c
            break
    if cur is None:
        return
    d = ImageDraw.Draw(im)
    f = pfont(78)
    words = cur["words"]
    texts = [w["word"].upper() for w in words]
    full = " ".join(texts)
    maxw = 1000
    lines = [list(range(len(words)))]
    if d.textlength(full, font=f) > maxw and len(words) > 1:
        best, bi = 1e9, 1
        for k in range(1, len(words)):
            a = d.textlength(" ".join(texts[:k]), font=f)
            b = d.textlength(" ".join(texts[k:]), font=f)
            if max(a, b) < best:
                best, bi = max(a, b), k
        lines = [list(range(bi)), list(range(bi, len(words)))]
    y = 1400 if len(lines) == 1 else 1385
    for ln in lines:
        txt = " ".join(texts[i] for i in ln)
        lw = d.textlength(txt, font=f)
        x = (W - lw) / 2
        for i in ln:
            wd = texts[i]
            col = (255, 200, 61, 255) if words[i]["start"] <= t < words[i]["end2"] else (255, 255, 255, 255)
            d.text((x, y), wd, font=f, fill=col, stroke_width=11, stroke_fill=INKB + (255,))
            x += d.textlength(wd + " ", font=f)
        y += 96


def build_caps():
    out = []
    for n in range(1, 19):
        ws = [dict(w) for w in EX if w["line"] == n]
        pieces, cur = [], []
        for w in ws:
            cur.append(w)
            if w["word"][-1] in ".?,":
                pieces.append(cur)
                cur = []
        if cur:
            pieces.append(cur)
        for p in pieces:
            k = -(-len(p) // 3)
            base, extra = divmod(len(p), k)
            i = 0
            for j in range(k):
                nn = base + (1 if j < extra else 0)
                out.append(dict(words=p[i:i + nn], t0=p[i]["start"], line=n))
                i += nn
    for i, c in enumerate(out):
        ws = c["words"]
        for j, w in enumerate(ws):
            w["end2"] = ws[j + 1]["start"] if j + 1 < len(ws) else (out[i + 1]["t0"] if i + 1 < len(out) and out[i + 1]["line"] == c["line"] else w["end"])
        nxt = out[i + 1]["t0"] if i + 1 < len(out) else None
        c["t1"] = out[i + 1]["t0"] if (i + 1 < len(out) and out[i + 1]["line"] == c["line"]) else ws[-1]["end"] + 0.06
        if nxt is not None:
            c["t1"] = min(c["t1"], nxt)
    out[-1]["t1"] = min(out[-1]["t1"], LN[17]["end"])
    return out


CAPS = build_caps()


def frame(t):
    shot, cam, objs = state(t)
    im = bg(cam)
    for o in objs:
        draw_obj(im, cam, o)
    captions(im, t)
    return im


def movers(t, dt=1 / FPS):
    if shot_of(t - dt) != shot_of(t):
        return set(), False
    s1, c1, o1 = state(t - dt)
    s2, c2, o2 = state(t)
    d1 = {o["id"]: o for o in o1}
    ch = set()
    for o in o2:
        p = d1.get(o["id"])
        if p is None:
            ch.add(o["grp"]); continue
        for k, v in o.items():
            if k in ("grp", "hide"):
                continue
            pv = p.get(k)
            if isinstance(v, (int, float)) and isinstance(pv, (int, float)):
                if abs(v - pv) > (0.5 if k in ("x", "y", "cx", "cy", "x0", "x1", "y0", "y1") else 0.004):
                    ch.add(o["grp"]); break
            elif v != pv:
                ch.add(o["grp"]); break
    for o in o1:
        if o["id"] not in {q["id"] for q in o2}:
            ch.add(o["grp"])
    return ch, abs(c2.z - c1.z) > 1e-6


if __name__ == "__main__":
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    for a in sys.argv[2:]:
        t = float(a)
        frame(t).convert("RGB").save(f"{out}/f_{t:07.3f}.png")
