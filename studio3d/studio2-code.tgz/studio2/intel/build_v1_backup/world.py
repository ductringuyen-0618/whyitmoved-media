"""Camera, keyframes and the static set (far wall layer + mid set layer) for the pilot."""
import math as m
import random
from PIL import Image, ImageDraw
import numpy as np

import stockshort_B3 as S
from stockshort_B3 import SP, INKB, CRM, GLD, RED, put
from art import *

W, H = 1080, 1920

# ------------------------------------------------------------------ easing / keyframes
def cl(x, a=0.0, b=1.0):
    return a if x < a else b if x > b else x


def seg(t, a, b):
    return cl((t - a) / (b - a)) if b > a else (1.0 if t >= b else 0.0)


def e_s(u): return u * u * (3 - 2 * u)
def e_o(u): return 1 - (1 - u) ** 3
def e_i(u): return u ** 3
def e_l(u): return u
def e_b(u):
    c1 = 1.70158 * 1.4
    return 1 + (c1 + 1) * (u - 1) ** 3 + c1 * (u - 1) ** 2
def e_sp(u):  # springy settle 0->1 with overshoot
    return 1 - m.exp(-6.5 * u) * m.cos(14 * u) if u > 0 else 0.0
def e_io(u): return 0.5 * (1 - m.cos(m.pi * u))
EASE = {"s": e_s, "o": e_o, "i": e_i, "l": e_l, "b": e_b, "p": e_sp, "io": e_io}


def kf(t, *pts):
    """piecewise keyframes: (time, value[, ease]); ease is that of the segment ENDING at this key"""
    if t <= pts[0][0]:
        return pts[0][1]
    for i in range(1, len(pts)):
        if t <= pts[i][0]:
            a, b = pts[i - 1], pts[i]
            u = (t - a[0]) / max(1e-9, b[0] - a[0])
            f = EASE[b[2] if len(b) > 2 else "s"]
            return a[1] + (b[1] - a[1]) * f(u)
    return pts[-1][1]


def wob(t, t0, amp, freq, decay):
    if t < t0:
        return 0.0
    d = t - t0
    return amp * m.exp(-decay * d) * m.sin(freq * d)


def pulse(t, t0, t1):
    """0 -> 1 -> 0 triangle between t0 and t1"""
    if t <= t0 or t >= t1:
        return 0.0
    u = (t - t0) / (t1 - t0)
    return 1 - abs(2 * u - 1)


# ------------------------------------------------------------------ camera
class Cam:
    def __init__(s, L=0.0, z=1.0, fx=540.0, fy=1000.0, shx=0.0, shy=0.0, dy=0.0):
        s.L, s.z, s.fx, s.fy, s.shx, s.shy, s.dy = L, z, fx, fy, shx, shy, dy

    def X(s, wx, par=1.0):
        return (wx - s.L * par - s.fx) * s.z + s.fx + s.shx

    def Y(s, wy):
        return (wy - s.fy) * s.z + s.fy + s.shy + s.dy

    @property
    def k(s):
        return s.z


# world layout constants
WORLD_X0 = -900
WORLD_W = 3200
MARG_Y = 400
FLOORY = 1250
SHELF_X0, SHELF_X1 = 740, 1270
BOARD_TOP, BOARD_MID, BOARD_LOW = 650, 870, 1090
COUNTER_X0, COUNTER_X1 = 1330, 1680
COUNTER_Y = 1090
DOOR_X1 = 130


def _grad(h, c0, c1):
    a = np.linspace(0, 1, h)[:, None, None]
    arr = (np.array(c0)[None, None, :] * (1 - a) + np.array(c1)[None, None, :] * a)
    return arr


def build_far():
    """parallax 0.6 wall: warm mall wall, arched windows, pillars, banners, ceiling"""
    Wd = int(WORLD_W * 0.62) + 1200
    Hd = H + 2 * MARG_Y
    arr = _grad(Hd, WALL, WALL2)
    arr = np.repeat(arr, Wd, axis=1).astype(np.uint8)
    img = Image.fromarray(arr, "RGB").convert("RGBA")
    d = ImageDraw.Draw(img)
    oy = MARG_Y
    # ceiling band
    d.rectangle((0, 0, Wd, oy + 300), fill=(96, 64, 84, 255))
    d.rectangle((0, oy + 300, Wd, oy + 318), fill=(70, 44, 60, 255))
    for x in range(40, Wd, 260):
        d.rounded_rectangle((x, oy + 270, x + 140, oy + 292), radius=8, fill=(255, 244, 200, 255))
    # wainscot
    d.rectangle((0, oy + 1000, Wd, oy + 1500), fill=WALL3 + (255,))
    d.rectangle((0, oy + 996, Wd, oy + 1010), fill=(190, 140, 96, 255))
    # arched windows
    rng = random.Random(5)
    for i, x in enumerate(range(80, Wd, 430)):
        top = oy + 430
        d.rounded_rectangle((x - 10, top - 10, x + 330, oy + 960), radius=150, fill=(150, 100, 70, 255))
        d.rounded_rectangle((x, top, x + 320, oy + 950), radius=140, fill=(150, 214, 255, 255))
        d.rectangle((x + 156, top, x + 164, oy + 950), fill=(150, 100, 70, 255))
        d.rectangle((x, oy + 700, x + 320, oy + 708), fill=(150, 100, 70, 255))
        # cloud
        cx = x + 80 + rng.randint(0, 100)
        d.ellipse((cx, top + 130, cx + 110, top + 180), fill=(255, 255, 255, 255))
        # banner between windows
        bx = x + 375
        col = BOXC[i % len(BOXC)]
        d.polygon([(bx - 26, oy + 380), (bx + 26, oy + 380), (bx + 26, oy + 640), (bx, oy + 610), (bx - 26, oy + 640)], fill=col + (255,), outline=INKB + (255,))
        d.ellipse((bx - 12, oy + 440, bx + 12, oy + 464), fill=(255, 255, 255, 255))
    return img


def build_mid():
    """parallax 1.0 set: floor, door, shelf unit, counter"""
    Hd = H + 2 * MARG_Y
    img = Image.new("RGBA", (WORLD_W, Hd), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    ox, oy = -WORLD_X0, MARG_Y

    def X(x): return x + ox
    def Y(y): return y + oy

    # floor
    d.rectangle((0, Y(FLOORY), WORLD_W, Hd), fill=FLOOR1 + (255,))
    for r, yy in enumerate(range(FLOORY, H + MARG_Y + 60, 90)):
        for i, xx in enumerate(range(-180, WORLD_W, 180)):
            if (i + r) % 2 == 0:
                d.rectangle((xx + (90 if r % 2 else 0), Y(yy), xx + 180 + (90 if r % 2 else 0), Y(yy + 90)), fill=FLOOR2 + (255,))
    d.rectangle((0, Y(FLOORY - 6), WORLD_W, Y(FLOORY + 10)), fill=(120, 80, 56, 255))
    # door / outside
    dx0, dx1 = X(WORLD_X0), X(DOOR_X1)
    d.rectangle((dx0, Y(330), dx1, Y(FLOORY)), fill=(150, 214, 255, 255))
    d.ellipse((dx0 + 200, Y(480), dx0 + 420, Y(560)), fill=(255, 255, 255, 255))
    d.ellipse((dx0 + 340, Y(520), dx0 + 640, Y(610)), fill=(255, 255, 255, 255))
    # tree + pavement
    d.rectangle((dx0, Y(1200), dx1, Y(FLOORY)), fill=(176, 178, 190, 255))
    d.rectangle((dx0, Y(1196), dx1, Y(1210)), fill=(120, 124, 140, 255))
    d.rectangle((dx0 + 520, Y(860), dx0 + 560, Y(1200)), fill=(120, 80, 50, 255))
    d.ellipse((dx0 + 400, Y(620), dx0 + 700, Y(920)), fill=(96, 188, 110, 255), outline=INKB + (255,), width=6)
    # frame
    d.rectangle((dx1 - 10, Y(300), dx1 + 40, Y(FLOORY + 10)), fill=(120, 80, 56, 255), outline=INKB + (255,), width=6)
    d.rectangle((dx0, Y(300), dx1 + 40, Y(360)), fill=(120, 80, 56, 255), outline=INKB + (255,), width=6)
    # EXIT sign
    d.rounded_rectangle((dx1 - 190, Y(380), dx1 - 20, Y(440)), radius=10, fill=(60, 190, 110, 255), outline=INKB + (255,), width=5)
    d.text((dx1 - 105, Y(410)), "EXIT", font=S.font("bold", 40), fill=(255, 255, 255, 255), anchor="mm")
    # ---- shelf unit
    p = SP(d, 1)
    sx0, sx1 = X(SHELF_X0), X(SHELF_X1)
    d.rectangle((sx0, Y(560), sx1, Y(FLOORY + 40)), fill=(236, 196, 140, 255), outline=INKB + (255,), width=6)
    for by in (BOARD_TOP, BOARD_MID, BOARD_LOW):
        d.rectangle((sx0 - 14, Y(by), sx1 + 14, Y(by + 26)), fill=SHELF + (255,), outline=INKB + (255,), width=6)
        d.rectangle((sx0 - 14, Y(by + 26), sx1 + 14, Y(by + 38)), fill=SHELFD + (255,))
    for xx in (sx0 - 20, sx1 + 6):
        d.rectangle((xx, Y(540), xx + 18, Y(FLOORY + 60)), fill=SHELFD + (255,), outline=INKB + (255,), width=5)
    rng = random.Random(11)

    def boxes(by, x0, x1, hmin, hmax):
        x = x0
        while x < x1:
            w = rng.randint(54, 96)
            h = rng.randint(hmin, hmax)
            col = BOXC[rng.randrange(len(BOXC))]
            d.rounded_rectangle((X(x), Y(by - h), X(x + w), Y(by)), radius=8, fill=col + (255,), outline=INKB + (255,), width=5)
            d.rectangle((X(x) + 8, Y(by - h) + 14, X(x + w) - 8, Y(by - h) + 26), fill=(255, 255, 255, 200))
            d.ellipse((X(x) + w / 2 - 10, Y(by - h) + 38, X(x) + w / 2 + 10, Y(by - h) + 58), fill=(255, 255, 255, 220))
            x += w + 8
    boxes(BOARD_TOP, SHELF_X0 + 12, SHELF_X1 - 12, 120, 190)
    boxes(BOARD_LOW, SHELF_X0 + 12, SHELF_X1 - 12, 110, 170)
    # chips stack at floor level (left end)
    for r in range(3):
        for c in range(3):
            bx = SHELF_X0 + 14 + c * 52
            by = FLOORY + 36 - r * 60
            d.rounded_rectangle((X(bx), Y(by - 56), X(bx + 46), Y(by)), radius=6, fill=(240, 84, 70, 255), outline=INKB + (255,), width=4)
            d.ellipse((X(bx) + 10, Y(by - 40), X(bx) + 36, Y(by - 16)), fill=YEL + (255,), outline=INKB + (255,), width=3)
    # ---- counter
    cx0, cx1 = X(COUNTER_X0), X(COUNTER_X1)
    d.rectangle((cx0, Y(COUNTER_Y), cx1, Y(FLOORY + 50)), fill=(96, 140, 176, 255), outline=INKB + (255,), width=7)
    for i in range(1, 6):
        d.line((cx0 + i * (cx1 - cx0) / 6, Y(COUNTER_Y + 10), cx0 + i * (cx1 - cx0) / 6, Y(FLOORY + 40)), fill=(70, 110, 146, 255), width=4)
    d.rectangle((cx0 - 14, Y(COUNTER_Y - 14), cx1 + 14, Y(COUNTER_Y + 16)), fill=(236, 226, 206, 255), outline=INKB + (255,), width=7)
    # conveyor belt
    d.rectangle((cx0 + 8, Y(COUNTER_Y - 12), cx0 + 140, Y(COUNTER_Y + 4)), fill=(50, 54, 66, 255))
    for i in range(7):
        d.ellipse((cx0 + 16 + i * 19, Y(COUNTER_Y - 10), cx0 + 28 + i * 19, Y(COUNTER_Y + 2)), fill=(110, 116, 132, 255))
    # checkout sign (hung from the far ceiling)
    sgx = X(1545)
    d.line((sgx - 70, Y(330), sgx - 70, Y(590)), fill=INKB + (255,), width=6)
    d.line((sgx + 70, Y(330), sgx + 70, Y(590)), fill=INKB + (255,), width=6)
    d.rounded_rectangle((sgx - 110, Y(590), sgx + 110, Y(690)), radius=16, fill=(250, 190, 60, 255), outline=INKB + (255,), width=7)
    d.text((sgx, Y(640)), "1", font=S.font("bold", 70), fill=INKB + (255,), anchor="mm")
    # right wall edge: plain
    return img


class Bg:
    def __init__(s):
        s.far = build_far()
        s.mid = build_mid()

    def render(s, cam):
        z = cam.z
        out = Image.new("RGBA", (W, H))
        for img, par, ox in ((s.far, 0.6, 0.0), (s.mid, 1.0, -WORLD_X0)):
            # world x of screen column X: wx = (X-fx)/z + fx + L*par (par for layer)
            if par == 1.0:
                x0 = (0 - cam.shx - cam.fx) / z + cam.fx + cam.L + ox
                x1 = (W - cam.shx - cam.fx) / z + cam.fx + cam.L + ox
            else:
                x0 = (0 - cam.shx - cam.fx) / z + cam.fx + cam.L * par + 500
                x1 = (W - cam.shx - cam.fx) / z + cam.fx + cam.L * par + 500
            y0 = (0 - cam.shy - cam.dy - cam.fy) / z + cam.fy + MARG_Y
            y1 = (H - cam.shy - cam.dy - cam.fy) / z + cam.fy + MARG_Y
            box = (x0, y0, x1, y1)
            crop = img.transform((W, H), Image.AFFINE,
                                 ((x1 - x0) / W, 0, x0, 0, (y1 - y0) / H, y0), resample=Image.BILINEAR)
            out.alpha_composite(crop)
        return out
