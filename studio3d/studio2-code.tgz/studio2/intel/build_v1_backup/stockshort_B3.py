#!/usr/bin/env python3
"""stockshort — turn a researched stock-move script (JSON) into a 9:16 explainer short.

    python stockshort.py examples/ORCL-2026-11-02.json            # -> out/ORCL-2026-11-02.mp4 + .txt
    python stockshort.py spec.json --voice am_adam --music bed.mp3

VOICE (most natural first):
  1. ElevenLabs   if ELEVENLABS_API_KEY is set (paid)
  2. Kokoro       free neural voice that runs locally (pip install kokoro-onnx soundfile; the
                  ~350 MB model downloads once from GitHub into ~/.cache/stockshort)
  3. macOS `say` / espeak-ng   robotic fallbacks
  Kokoro voices: am_michael (default), am_adam, am_onyx, am_eric, af_heart, af_bella, bm_george ...

SYNC: every on-screen element can carry "at": a word or phrase from that beat's narration.
The element animates in at the moment that phrase is spoken. Without "at", elements are
spread evenly across the beat.

Spec: ticker, company, move_pct, title, description, hashtags, keywords, sources, and
"beats": [{"say": narration, "visual": {"type": ..., ...}}]
Visual types: hook, headline, stat, bars, compare, line, bullets, scorecard, text, outro,
question (explainer/recap opener), rank (countdown card) (see examples/). Specs without ticker/move_pct
(explainers, weekly recap) set "slug", "chip" and "topic" instead.
Extras: "loop": true makes the last line flow into the first; "tape": [...] fills the scrolling ticker
tape; sound effects and a generated music bed are synced to the same cues (--music to use your own
licensed track, --no-music for voice + effects only).
Every number on screen must come from the sources listed in the spec.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import wave
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 1080, 1920, 30
SR = 24000
C = {
    "bg1": (8, 12, 24), "bg2": (16, 24, 46), "text": (242, 245, 250), "muted": (148, 160, 184),
    "up": (30, 215, 130), "down": (255, 72, 88), "accent": (255, 200, 0),
}
THEMES = {
    "paper": dict(  # light editorial: cream paper, ink text, orange accent, Inter
        pal={"bg1": (250, 246, 238), "bg2": (237, 230, 216), "text": (20, 24, 38), "muted": (104, 108, 122),
             "up": (0, 148, 92), "down": (214, 44, 58), "accent": (255, 92, 28)},
        grid=(228, 220, 204), grid_style="lines", card_rgb=(20, 24, 38), tape_bg=(233, 225, 208, 240),
        bar_bg=(214, 206, 190), fonts=("Inter-ExtraBold.otf", "Inter-Medium.otf")),
    "neon": dict(  # near-black with hot pink + mint, dot grid, Inter
        pal={"bg1": (5, 5, 12), "bg2": (22, 8, 34), "text": (246, 244, 250), "muted": (158, 150, 178),
             "up": (0, 238, 168), "down": (255, 84, 72), "accent": (255, 52, 150)},
        grid=(44, 24, 64), grid_style="dots", card_rgb=(255, 255, 255), tape_bg=(8, 4, 16, 235),
        bar_bg=(52, 30, 74), fonts=("Inter-ExtraBold.otf", "Inter-Medium.otf")),
    "toon": dict(  # cartoon: sky, hills, outlined cards, original mascot "Wick"
        pal={"bg1": (92, 190, 255), "bg2": (200, 236, 255), "text": (24, 20, 40), "muted": (60, 70, 110),
             "up": (46, 204, 113), "down": (255, 86, 96), "accent": (255, 196, 30)},
        grid=(92, 190, 255), grid_style="none", card_rgb=(255, 255, 255), tape_bg=(24, 20, 40, 235),
        bar_bg=(24, 20, 40), fonts=("Poppins-ExtraBold.ttf", "Poppins-Medium.ttf"), tape_fg=(235, 238, 250), toon=True),
    "pizza": dict(  # flat-vector pizza-shop skit: cream, brown outlines, tomato / teal / gold
        pal={"bg1": (255, 241, 214), "bg2": (250, 228, 190), "text": (58, 36, 24), "muted": (122, 100, 88),
             "up": (24, 197, 176), "down": (232, 69, 44), "accent": (255, 200, 61)},
        grid=(250, 228, 190), grid_style="none", card_rgb=(255, 255, 255), tape_bg=(58, 36, 24, 235),
        bar_bg=(250, 228, 190), fonts=("Poppins-Bold.ttf", "Poppins-Medium.ttf"), pizza=True),
    "server": dict(  # flat-vector skit "Patch and the Rack": deep teal-navy server alley, teal / gold / red
        pal={"bg1": (11, 37, 48), "bg2": (16, 52, 66), "text": (255, 244, 220), "muted": (150, 170, 178),
             "up": (24, 197, 176), "down": (232, 69, 44), "accent": (255, 200, 61)},
        grid=(16, 52, 66), grid_style="none", card_rgb=(255, 255, 255), tape_bg=(5, 16, 24, 235),
        bar_bg=(16, 52, 66), fonts=("Poppins-Bold.ttf", "Poppins-Medium.ttf"), pizza=True, server=True),
}
CAP = {"size": 80}
CAPSTYLE = {"outline": "&H00000000", "outw": 8, "shadow": 3, "marginr": 220, "marginv": 545, "hi": "&H0000C8FF", "maxchars": 0}
THEME = {"grid": (20, 28, 48), "grid_style": "lines", "card_rgb": (255, 255, 255),
         "tape_bg": (6, 9, 18, 235), "bar_bg": (30, 40, 66)}


def apply_theme(name):
    t = THEMES.get(name or "")
    if not t:
        return
    C.update(t["pal"])
    THEME.update({k: t[k] for k in ("grid", "grid_style", "card_rgb", "tape_bg", "bar_bg")})
    THEME["tape_fg"] = t.get("tape_fg")
    THEME["toon"] = bool(t.get("toon"))
    THEME["pizza"] = bool(t.get("pizza"))
    THEME["server"] = bool(t.get("server"))
    if t.get("pizza"):
        CAPSTYLE.update(outline="&H0018243A", outw=11, shadow=0, marginr=100, marginv=500, hi="&H003DC8FF", maxchars=17)
    THEME["hdr"] = (24, 20, 40) if t.get("toon") else None
    FONT_CANDIDATES["bold"].insert(0, t["fonts"][0])
    FONT_CANDIDATES["medium"].insert(0, t["fonts"][1])
    if t.get("server"):
        CAPSTYLE.update(outline="&H00180F05", outw=11, shadow=0, marginr=100, marginv=500, hi="&H003DC8FF", maxchars=17)
    CAP["size"] = 74 if t.get("pizza") else 68
    _FC.clear()


BEAT_GAP = 0.08      # pause between beats (s)
SENT_GAP = 0.06      # pause between sentences inside a beat (s)
# Platform safe zone: TikTok/Shorts cover the top ~210px (tabs), the right ~180px from y≈700 (buttons)
# and the bottom ~400px (caption, username, nav). Scenes are drawn on a 1080x1920 canvas, then scaled
# into the safe box: canvas point (540, 800) lands at (SAFE_CX, SAFE_CY), scaled by SAFE_S.
SAFE_S, SAFE_CX, SAFE_CY = 0.86, 470, 830
CACHE = Path.home() / ".cache" / "stockshort"
KOKORO_URL = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"

# ================================================================== fonts
_FC: dict = {}
FONT_CANDIDATES = {
    "bold": ["Poppins-ExtraBold.ttf", "Poppins-Bold.ttf", "Inter-Bold.otf", "Montserrat-ExtraBold.ttf",
             "Arial Bold.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"],
    "medium": ["Poppins-Medium.ttf", "Inter-Medium.otf", "Montserrat-Medium.ttf", "Arial.ttf", "arial.ttf",
               "DejaVuSans.ttf"],
}
FONT_DIRS = ["/usr/share/fonts", "/usr/local/share/fonts", str(Path.home() / ".fonts"),
             str(Path.home() / "Library/Fonts"), "/Library/Fonts", "/System/Library/Fonts/Supplemental",
             "C:/Windows/Fonts"]


def _find_font(weight: str) -> str | None:
    for name in FONT_CANDIDATES[weight]:
        for d in FONT_DIRS:
            if Path(d).exists():
                for p in Path(d).rglob(name):
                    return str(p)
    if shutil.which("fc-match"):
        q = "Poppins:bold" if weight == "bold" else "Poppins:medium"
        out = subprocess.run(["fc-match", "-f", "%{file}", q], capture_output=True, text=True).stdout
        if out:
            return out
    return None


def font(weight: str, size: int):
    key = (weight, size)
    if key not in _FC:
        if weight + "_path" not in _FC:
            _FC[weight + "_path"] = _find_font(weight)
        path = _FC[weight + "_path"]
        _FC[key] = ImageFont.truetype(path, size) if path else ImageFont.load_default(size)
    return _FC[key]


# ================================================================== voice
_KOKORO = None


def _kokoro():
    global _KOKORO
    if _KOKORO is None:
        from kokoro_onnx import Kokoro  # noqa
        CACHE.mkdir(parents=True, exist_ok=True)
        for f in ("kokoro-v1.0.onnx", "voices-v1.0.bin"):
            p = CACHE / f
            if not p.exists() or p.stat().st_size < 1_000_000:
                print(f"  downloading voice model {f} (one time) ...", flush=True)
                urllib.request.urlretrieve(KOKORO_URL + f, p)
        _KOKORO = Kokoro(str(CACHE / "kokoro-v1.0.onnx"), str(CACHE / "voices-v1.0.bin"))
    return _KOKORO


def _have_kokoro() -> bool:
    try:
        import kokoro_onnx  # noqa
        import soundfile  # noqa
        return True
    except ImportError:
        return False


def _write_wav(path: Path, samples, sr: int):
    import numpy as np
    a = np.clip(np.asarray(samples, dtype="float32"), -1, 1)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((a * 32767).astype("<i2").tobytes())


def _read_wav(path: Path):
    import numpy as np
    with wave.open(str(path)) as w:
        sr, n, ch, sw = w.getframerate(), w.getnframes(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(n)
    a = np.frombuffer(raw, dtype="<i2" if sw == 2 else "u1").astype("float32")
    a = a / 32768 if sw == 2 else (a - 128) / 128
    if ch > 1:
        a = a.reshape(-1, ch).mean(axis=1)
    return a, sr


def synth(text: str, out_wav: Path, voice: str, speed: float) -> str:
    """Synthesize one sentence to out_wav. Returns the engine used."""
    key = os.environ.get("ELEVENLABS_API_KEY")
    if key:
        import requests
        vid = os.environ.get("ELEVENLABS_VOICE_ID", "pNInz6obpgDQGcFmaJgB")
        r = requests.post(f"https://api.elevenlabs.io/v1/text-to-speech/{vid}?output_format=pcm_24000",
                          headers={"xi-api-key": key, "Content-Type": "application/json"},
                          json={"text": text, "model_id": "eleven_multilingual_v2",
                                "voice_settings": {"stability": 0.45, "similarity_boost": 0.8, "style": 0.3}},
                          timeout=120)
        r.raise_for_status()
        with wave.open(str(out_wav), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000); w.writeframes(r.content)
        return "elevenlabs"
    if _have_kokoro():
        audio, sr = _kokoro().create(text, voice=voice, speed=speed, lang="en-us")
        _write_wav(out_wav, audio, sr)
        return "kokoro"
    if shutil.which("say"):
        aiff = out_wav.with_suffix(".aiff")
        subprocess.run(["say", "-r", "185", "-o", str(aiff), text], check=True)
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(aiff), "-ac", "1", str(out_wav)], check=True)
        return "say"
    engine = shutil.which("espeak-ng") or shutil.which("espeak")
    if not engine:
        raise SystemExit("No voice available: pip install kokoro-onnx soundfile (free), or set ELEVENLABS_API_KEY.")
    subprocess.run([engine, "-v", "en-us+m3", "-s", "172", "-w", str(out_wav), text], check=True)
    return "espeak"


def speech_bounds(a, sr) -> tuple[float, float]:
    """Start/end of actual speech (trims leading/trailing silence)."""
    import numpy as np
    hop = int(sr * 0.01)
    if len(a) < hop * 3:
        return 0.0, len(a) / sr
    frames = a[: len(a) // hop * hop].reshape(-1, hop)
    rms = np.sqrt((frames ** 2).mean(axis=1))
    thr = max(rms.max() * 0.06, 1e-4)
    idx = np.where(rms > thr)[0]
    if not len(idx):
        return 0.0, len(a) / sr
    return idx[0] * hop / sr, (idx[-1] + 1) * hop / sr


def _syllables(word: str) -> float:
    w = re.sub(r"[^a-z]", "", word.lower())
    if not w:
        return 1.0
    n = len(re.findall(r"[aeiouy]+", w))
    if w.endswith("e") and n > 1 and not w.endswith(("le", "ee")):
        n -= 1
    return max(1, n) + (0.6 if re.search(r"[,;:—–-]$", word) else 0)


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    return [p for p in parts if p]


# ================================================================== drawing helpers
def clamp01(x):
    return max(0.0, min(1.0, x))


def ease(x):
    x = clamp01(x)
    return 1 - (1 - x) ** 3


def pop(x):
    x = clamp01(x)
    return 1 + 2.70158 * (x - 1) ** 3 + 1.70158 * (x - 1) ** 2


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def text_w(d, s, f):
    return int(d.textlength(s, font=f))


def ctext(d, y, s, f, fill, x=W // 2, anchor="mm"):
    d.text((x, y), s, font=f, fill=fill, anchor=anchor)


def wrap(d, s, f, max_w):
    words, lines, cur = s.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if text_w(d, trial, f) <= max_w:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def fit_font(d, s, weight, start, max_w, min_size=40):
    size = start
    while size > min_size and text_w(d, s, font(weight, size)) > max_w:
        size -= 4
    return font(weight, size)


def card(img, box, radius=36, fill=(255, 255, 255, 16)):
    if tuple(fill[:3]) == (255, 255, 255) and THEME["card_rgb"] != (255, 255, 255):
        fill = tuple(THEME["card_rgb"]) + (min(255, int(fill[3] * 1.6)),)
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).rounded_rectangle(box, radius=radius, fill=fill)
    img.alpha_composite(layer)


def background():
    img = Image.new("RGBA", (W, H), C["bg1"] + (255,))
    d = ImageDraw.Draw(img)
    for y in range(H):
        d.line([(0, y), (W, y)], fill=mix(C["bg1"], C["bg2"], (y / H) ** 1.4) + (255,))
    g = ImageDraw.Draw(img)
    gc = tuple(THEME["grid"]) + (255,)
    if THEME["grid_style"] == "dots":
        for x in range(0, W, 60):
            for y in range(0, H, 60):
                g.ellipse((x - 2, y - 2, x + 2, y + 2), fill=gc)
    else:
        for x in range(0, W, 90):
            g.line([(x, 0), (x, H)], fill=gc)
        for y in range(0, H, 90):
            g.line([(0, y), (W, y)], fill=gc)
    return img


def colr(name, default="accent"):
    return C.get(name or default, C[default])


def move_color(p):
    return C["up"] if p >= 0 else C["down"]


def fmt_pct(p):
    return f"{'+' if p >= 0 else '−'}{abs(p):.1f}%"


def A(x):
    """alpha from 0..1"""
    return int(255 * clamp01(x))


# ================================================================== cue timing
def _norm(s):
    return re.sub(r"[^\w$%.']", "", s.lower()).strip(".'")


class Cues:
    """Maps 'at' phrases to times (seconds from beat start) using the beat's word timings."""

    def __init__(self, words: list[dict], dur: float):
        self.words, self.dur = words, dur
        self.toks = [_norm(w["word"]) for w in words]

    def at(self, phrase, default: float) -> float:
        if phrase is None:
            return default
        if isinstance(phrase, (int, float)):
            return float(phrase)
        target = [_norm(x) for x in str(phrase).split() if _norm(x)]
        if not target:
            return default
        n = len(target)
        for i in range(len(self.toks) - n + 1):
            if all(self.toks[i + k].startswith(target[k]) for k in range(n)):
                return max(0.0, self.words[i]["start"] - 0.08)  # land a hair before the word
        print(f"  ! cue '{phrase}' not found in narration; using default", file=sys.stderr)
        return default

    def spread(self, k: int, n: int, lo: float = 0.1, hi: float = 0.75) -> float:
        return self.dur * (lo + (hi - lo) * (k / max(1, n - 1) if n > 1 else 0))


# ================================================================== scenes
# each scene: f(img, v, t, spec, cues) ; t = seconds since beat start

def _candle(d, cx, top, bot, btop, bbot, w, col, a=255, wick=16):
    d.rounded_rectangle((cx - wick // 2, top, cx + wick // 2, bot), radius=wick // 2, fill=col + (a,))
    d.rounded_rectangle((cx - w // 2, btop, cx + w // 2, bbot), radius=max(4, w // 8), fill=col + (a,))


def scene_hook(img, v, t, spec, cues):
    """Frame 1 already shows the move, the candle and the question. Nothing to wait for."""
    d = ImageDraw.Draw(img)
    pct = float(v.get("move_pct", spec["move_pct"]))
    col = move_color(pct)
    ctext(d, 400, v.get("label", "TODAY").upper(), font("bold", 40), C["muted"])
    k = ease(t / 0.15)  # candle drops the last few pixels into place: frame 1 already reads clearly
    off = int((1 - k) * (-40 if pct < 0 else 40))
    _candle(d, W // 2, 700 + off, 1010 + off, 740 + off, 960 + off, 160, col, a=255, wick=24)
    f = font("bold", int(250 * (0.92 + 0.08 * pop(t / 0.3))))
    ctext(d, 540, fmt_pct(pct), f, col)  # real number from frame 1 (a count-up shows wrong values)
    q = v.get("question") or v.get("note")
    if q:
        f2 = font("bold", 76)
        parts = [x.strip() for x in re.split(r"(?<=[.?!])\s+", q.upper()) if x.strip()]
        lines = [ln for part in parts for ln in wrap(d, part, f2, 980)]
        # keep the whole question above the caption band (captions start near y 1290)
        for i, line in enumerate(lines):
            ctext(d, 1070 + i * 88, line, f2, C["text"] if i < len(lines) - 1 else C["accent"])
    if v.get("to") is not None:
        tp = cues.at(v.get("price_at"), 0.6)
        if t > tp:
            fr = f"${float(v['from']):,.2f} → " if v.get("from") is not None else "now "
            ctext(d, 1060, f"{fr}${float(v['to']):,.2f}", font("medium", 50), C["muted"] + (A((t - tp) / 0.25),))


def scene_headline(img, v, t, spec, cues):
    """A recreated news headline (text only, never a screenshot) with a marker sweep on the key phrase."""
    t0 = cues.at(v.get("at"), 0.0)
    if t < t0:
        return
    p = ease((t - t0) / 0.35)
    d = ImageDraw.Draw(img)
    ctext(d, 420, v.get("kicker", "THE NEWS").upper(), font("bold", 40), C["muted"] + (A(p),))
    x0, y0 = 80, 500 + int((1 - p) * 80)
    fh = font("bold", 68)
    lines = wrap(d, v["headline"], fh, 840)
    hgt = 210 + 84 * len(lines)
    card(img, (x0, y0, W - 80, y0 + hgt), radius=30, fill=(245, 247, 251, A(p)))
    d = ImageDraw.Draw(img)
    src = v.get("source", "")
    d.rounded_rectangle((x0 + 50, y0 + 46, x0 + 50 + text_w(d, src.upper(), font("bold", 32)) + 40, y0 + 100),
                        radius=12, fill=(16, 24, 46, A(p)))
    d.text((x0 + 70, y0 + 73), src.upper(), font=font("bold", 32), fill=(255, 255, 255, A(p)), anchor="lm")
    if v.get("date"):
        d.text((W - 130, y0 + 73), v["date"], font=font("medium", 32), fill=(110, 120, 140, A(p)), anchor="rm")
    hl = (v.get("highlight") or "").lower()
    th = cues.at(v.get("highlight_at"), t0 + 0.6)
    yy = y0 + 150
    for line in lines:
        if hl and hl in line.lower() and t > th:
            i = line.lower().index(hl)
            pre_w = text_w(d, line[:i], fh)
            hw = text_w(d, line[i:i + len(hl)], fh)
            sweep = ease((t - th) / 0.3)
            d.rectangle((x0 + 50 + pre_w - 6, yy + 6, x0 + 50 + pre_w + int((hw + 12) * sweep), yy + 80),
                        fill=C["accent"] + (A(p),))
        d.text((x0 + 50, yy), line, font=fh, fill=(14, 18, 30, A(p)))
        yy += 84
    if v.get("sub"):
        ts = cues.at(v.get("sub_at"), t0 + 1.0)
        for i, line in enumerate(wrap(d, v["sub"], font("medium", 48), 900)):
            ctext(d, y0 + hgt + 80 + i * 60, line, font("medium", 48), C["text"] + (A((t - ts) / 0.3),))


def scene_stat(img, v, t, spec, cues):
    d = ImageDraw.Draw(img)
    color = colr(v.get("color"), "text")
    t0 = cues.at(v.get("at"), 0.05)
    s = t - t0
    if s > 0:
        f = fit_font(d, str(v["value"]), "bold", int(290 * max(0.3, pop(s / 0.4))), 980)
        ctext(d, 650, str(v["value"]), f, color)
    if v.get("label"):
        tl = cues.at(v.get("label_at"), t0 + 0.35)
        for i, line in enumerate(wrap(d, v["label"], font("bold", 70), 940)):
            ctext(d, 880 + i * 84 + int(30 * (1 - ease((t - tl) / 0.3))), line, font("bold", 70),
                  C["text"] + (A((t - tl) / 0.3),))
    if v.get("sub"):
        ts = cues.at(v.get("sub_at"), t0 + 0.7)
        for i, line in enumerate(wrap(d, v["sub"], font("medium", 48), 900)):
            ctext(d, 1080 + i * 60, line, font("medium", 48), C["muted"] + (A((t - ts) / 0.3),))


def scene_bars(img, v, t, spec, cues):
    d = ImageDraw.Draw(img)
    items = v["items"][:4]
    if v.get("title"):
        ctext(d, 420, v["title"], fit_font(d, v["title"], "bold", 66, 980), C["text"])
    mx = max(float(i["value"]) for i in items) or 1
    for k, it in enumerate(items):
        tk = cues.at(it.get("at"), cues.spread(k, len(items), 0.05, 0.55))
        if t < tk:
            continue
        p = ease((t - tk) / 0.5)
        y = 560 + k * 190
        d.text((90, y), it["label"], font=font("medium", 52), fill=C["muted"] + (A((t - tk) / 0.2),))
        bw = int(740 * float(it["value"]) / mx * p)
        d.rounded_rectangle((90, y + 70, 90 + max(bw, 8), y + 150), radius=20, fill=colr(it.get("color")))
        if p > 0.2:
            d.text((90 + bw + 24, y + 110), it.get("display", str(it["value"])), font=font("bold", 62),
                   fill=C["text"], anchor="lm")


def scene_compare(img, v, t, spec, cues):
    d = ImageDraw.Draw(img)
    if v.get("title"):
        for i, line in enumerate(wrap(d, v["title"], font("bold", 64), 980)):
            ctext(d, 420 + i * 76, line, font("bold", 64), C["text"])
    shown = 0
    for k, side in enumerate(("left", "right")):
        it = v[side]
        tk = cues.at(it.get("at"), cues.spread(k, 2, 0.05, 0.45))
        if t < tk:
            continue
        shown += 1
        p = ease((t - tk) / 0.35)
        x0, y0 = 70 + k * 500 + int((1 - p) * (-80 if k == 0 else 80)), 600
        card(img, (x0, y0, x0 + 440, y0 + 470), fill=(255, 255, 255, int(22 * p)))
        d = ImageDraw.Draw(img)
        ctext(d, y0 + 110, it["label"].upper(), font("bold", 40), C["muted"] + (A(p),), x=x0 + 220)
        ctext(d, y0 + 260, it["value"], fit_font(d, it["value"], "bold", int(120 * (0.8 + 0.2 * pop((t - tk) / 0.4))), 400),
              colr(it.get("color"), "text") + (A(p),), x=x0 + 220)
        for i, line in enumerate(wrap(d, it.get("sub", ""), font("medium", 38), 380)):
            ctext(d, y0 + 370 + i * 46, line, font("medium", 38), C["muted"] + (A(p),), x=x0 + 220)
    if shown == 2:
        ctext(ImageDraw.Draw(img), 835, "vs", font("bold", 56), C["accent"])


def scene_line(img, v, t, spec, cues):
    d = ImageDraw.Draw(img)
    pts = v["points"]
    vals = [float(p["value"]) for p in pts]
    if v.get("title"):
        ctext(d, 400, v["title"], fit_font(d, v["title"], "bold", 64, 980), C["text"])
    lo, hi = min(vals), max(vals)
    pad = (hi - lo) * 0.18 or 1
    lo, hi = lo - pad, hi + pad
    x0, x1, y0, y1 = 190, 890, 520, 1120
    for gy in range(5):
        yy = y0 + (y1 - y0) * gy / 4
        d.line([(x0, yy), (x1, yy)], fill=(40, 52, 80, 255), width=2)
    xy = [(x0 + (x1 - x0) * i / max(1, len(pts) - 1), y1 - (y1 - y0) * (vals[i] - lo) / (hi - lo))
          for i in range(len(pts))]
    times = [cues.at(p.get("at"), cues.spread(i, len(pts), 0.05, 0.7)) for i, p in enumerate(pts)]
    drawn = [xy[0]] if t >= times[0] else []
    for i in range(1, len(xy)):
        if t >= times[i]:
            drawn.append(xy[i])
        elif t > times[i] - 0.5 and drawn:
            f = ease((t - (times[i] - 0.5)) / 0.5)
            drawn.append((xy[i - 1][0] + (xy[i][0] - xy[i - 1][0]) * f, xy[i - 1][1] + (xy[i][1] - xy[i - 1][1]) * f))
            break
        else:
            break
    col = move_color(vals[-1] - vals[0])
    if len(drawn) > 1:
        layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(layer).polygon(drawn + [(drawn[-1][0], y1), (drawn[0][0], y1)], fill=col + (40,))
        img.alpha_composite(layer)
        d = ImageDraw.Draw(img)
        d.line(drawn, fill=col, width=10, joint="curve")
    pre = v.get("prefix", "$")
    for i, (x, y) in enumerate(xy):
        if t >= times[i]:
            a = A((t - times[i]) / 0.25)
            r = 14 * (0.6 + 0.4 * pop((t - times[i]) / 0.3))
            d.ellipse((x - r, y - r, x + r, y + r), fill=C["text"] + (a,))
            lab = f"{pre}{vals[i]:,.0f}" if vals[i] >= 100 else f"{pre}{vals[i]:,.2f}"
            d.text((x, y - 52 if y > y0 + 80 else y + 60), lab, font=font("bold", 50), fill=C["text"] + (a,), anchor="mm")
            d.text((x, y1 + 50), pts[i]["label"], font=font("medium", 40), fill=C["muted"] + (a,), anchor="mm")


def scene_bullets(img, v, t, spec, cues):
    d = ImageDraw.Draw(img)
    if v.get("title"):
        ctext(d, 410, v["title"], fit_font(d, v["title"], "bold", 66, 980), C["text"])
    items = [i if isinstance(i, dict) else {"text": i} for i in v["items"][:4]]
    times = [cues.at(it.get("at"), cues.spread(k, len(items), 0.12, 0.7)) for k, it in enumerate(items)]
    active = max([k for k, tk in enumerate(times) if t >= tk], default=-1)
    y = 540
    for k, it in enumerate(items):
        lines = wrap(d, it["text"], font("bold", 56), 800)
        hgt = 40 + 68 * len(lines)
        if t >= times[k]:
            p = ease((t - times[k]) / 0.35)
            x = 90 - int((1 - p) * 60)
            on = k == active
            card(img, (x, y, x + 900, y + hgt), radius=28, fill=(255, 255, 255, int((30 if on else 14) * p)))
            d = ImageDraw.Draw(img)
            d.ellipse((x + 34, y + 38, x + 62, y + 66), fill=(C["accent"] if on else C["muted"]) + (A(p),))
            for i, line in enumerate(lines):
                d.text((x + 92, y + 22 + i * 68), line, font=font("bold", 56),
                       fill=(C["text"] if on else C["muted"]) + (A(p),))
        y += hgt + 34


VERDICT = {"good": "up", "bad": "down", "unknown": "accent", "beat": "up", "miss": "down", "inline": "accent"}


def _mark(d, cx, cy, r, kind, scale=1.0, alpha=255):
    col = C[VERDICT.get(kind, "accent")]
    r = int(r * scale)
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=col + (alpha,))
    w = max(6, int(r * 0.2))
    ink = (10, 14, 26, alpha)
    if kind in ("good", "beat"):
        d.line([(cx - r * 0.42, cy + r * 0.02), (cx - r * 0.1, cy + r * 0.34), (cx + r * 0.45, cy - r * 0.3)], fill=ink, width=w, joint="curve")
    elif kind in ("bad", "miss"):
        k = r * 0.36
        d.line([(cx - k, cy - k), (cx + k, cy + k)], fill=ink, width=w)
        d.line([(cx - k, cy + k), (cx + k, cy - k)], fill=ink, width=w)
    else:
        d.text((cx, cy + 2), "?" if kind == "unknown" else "=", font=font("bold", int(r * 1.3)), fill=ink, anchor="mm")


def scene_scorecard(img, v, t, spec, cues):
    """Signature format: each line stamps a verdict (good / bad / unknown) as it's spoken."""
    d = ImageDraw.Draw(img)
    title = v.get("title", "THE SCORECARD")
    ctext(d, 405, title.upper(), fit_font(d, title.upper(), "bold", 72, 900), C["text"])
    d.rounded_rectangle((W // 2 - 70, 455, W // 2 + 70, 465), radius=5, fill=C["accent"])
    items = v["items"][:4]
    for k, it in enumerate(items):
        tk = cues.at(it.get("at"), cues.spread(k, len(items), 0.1, 0.75))
        y = 520 + k * 175
        if t < tk:
            card(img, (70, y, W - 70, y + 150), radius=26, fill=(255, 255, 255, 8))
            continue
        p = ease((t - tk) / 0.25)
        card(img, (70, y, W - 70, y + 150), radius=26, fill=(255, 255, 255, int(10 + 12 * p)))
        d = ImageDraw.Draw(img)
        d.text((120, y + 50), it["label"], font=font("bold", 56), fill=C["text"] + (A(p),), anchor="lm")
        if it.get("detail"):
            d.text((120, y + 108), it["detail"], font=font("medium", 38), fill=C["muted"] + (A(p),), anchor="lm")
        ts = t - tk - 0.12  # the stamp lands just after the label
        if ts > 0:
            sc = 1 + 1.2 * (1 - ease(ts / 0.18))
            _mark(d, W - 160, y + 75, 50, it.get("verdict", "unknown"), scale=sc, alpha=A(ts / 0.1))


def scene_text(img, v, t, spec, cues):
    d = ImageDraw.Draw(img)
    t0 = cues.at(v.get("at"), 0.0)
    s = t - t0
    if s <= 0:
        return
    f = font("bold", int(96 * (0.85 + 0.15 * pop(s / 0.4))))
    lines = wrap(d, v["big"], f, 960)
    y = 700 - (len(lines) - 1) * 60
    th = cues.at(v.get("highlight_at") or v.get("highlight"), t0)
    for i, line in enumerate(lines):
        hl = v.get("highlight") and v["highlight"].lower() in line.lower()
        col = mix(C["text"], C["accent"], ease((t - th) / 0.3)) if hl else C["text"]
        ctext(d, y + i * 118, line, f, col + (A(s / 0.25),))
    if v.get("small"):
        ts = cues.at(v.get("small_at"), t0 + 0.5)
        for i, line in enumerate(wrap(d, v["small"], font("medium", 50), 900)):
            ctext(d, y + len(lines) * 118 + 40 + i * 62, line, font("medium", 50), C["muted"] + (A((t - ts) / 0.3),))


def scene_outro(img, v, t, spec, cues):
    scene_text(img, {k: v.get(k) for k in ("big", "highlight", "highlight_at", "at")}, t, spec, cues)
    tc = cues.at(v.get("cta_at"), cues.dur * 0.5)
    if t > tc:
        d = ImageDraw.Draw(img)
        p = pop((t - tc) / 0.4)
        cta = v.get("cta") or f"Follow {spec.get('brand', '')}".strip()
        f = font("bold", 54)
        w = text_w(d, cta, f) + 90
        x0 = (W - w) // 2
        d.rounded_rectangle((x0, 1060, x0 + w, 1060 + int(110 * max(0.2, p))), radius=55, fill=C["accent"])
        if p > 0.5:
            ctext(d, 1115, cta, f, (10, 10, 10))
        if v.get("cta_sub") and t > tc + 0.25:
            fs = font("medium", 44)
            ctext(d, 1215, v["cta_sub"], fs, C["muted"] + (A((t - tc - 0.25) / 0.3),))


def scene_question(img, v, t, spec, cues):
    """Opener for explainers and recaps: a big question/promise readable on frame 1."""
    d = ImageDraw.Draw(img)
    if v.get("kicker"):
        ctext(d, 420, v["kicker"].upper(), font("bold", 40), C["muted"])
    f = font("bold", int(108 * (0.94 + 0.06 * pop(t / 0.3))))
    lines = wrap(d, v["big"], font("bold", 108), 960)
    y = 700 - (len(lines) - 1) * 66
    hl = (v.get("highlight") or "").lower()
    for i, line in enumerate(lines):
        ctext(d, y + i * 128, line, f, C["accent"] if hl and hl in line.lower() else C["text"])
    if v.get("sub"):
        ts = cues.at(v.get("sub_at"), 0.8)
        for i, line in enumerate(wrap(d, v["sub"], font("medium", 50), 920)):
            ctext(d, y + len(lines) * 128 + 50 + i * 62, line, font("medium", 50), C["muted"] + (A((t - ts) / 0.3),))


def scene_rank(img, v, t, spec, cues):
    """Countdown card: rank, ticker, move and the one-line reason (weekly recap)."""
    d = ImageDraw.Draw(img)
    pct = float(v["move_pct"])
    col = move_color(pct)
    p = ease(t / 0.25)
    ctext(d, 430, f"#{v['rank']}", font("bold", int(150 * (0.8 + 0.2 * pop(t / 0.35)))), C["accent"])
    fk = font("bold", 76)
    chip_w = text_w(d, v["ticker"], fk) + 70
    x0 = (W - chip_w) // 2
    card(img, (x0, 540, x0 + chip_w, 650), radius=26, fill=col + (int(80 * p),))
    d = ImageDraw.Draw(img)
    ctext(d, 595, v["ticker"], fk, C["text"] + (A(p),))
    ctext(d, 700, v.get("company", ""), font("bold", 54), C["text"] + (A(p),))
    tm = cues.at(v.get("move_at"), 0.25)
    if t > tm:
        ctext(d, 840, fmt_pct(pct), font("bold", int(170 * (0.85 + 0.15 * pop((t - tm) / 0.35)))), col)
    if v.get("reason"):
        tr = cues.at(v.get("reason_at"), cues.dur * 0.4)
        for i, line in enumerate(wrap(d, v["reason"], font("medium", 52), 920)):
            ctext(d, 1000 + i * 64, line, font("medium", 52), C["text"] + (A((t - tr) / 0.3),))
    if v.get("when"):
        ctext(d, 1180, v["when"], font("medium", 38), C["muted"] + (A(p),))


def _arrow_down(d, x, y0, y1, prog, col, width=8):
    """Vertical arrow drawn from y0 toward y1 by prog (0..1)."""
    if prog <= 0:
        return
    ye = y0 + (y1 - y0) * prog
    d.line([(x, y0), (x, ye)], fill=col, width=width)
    if prog > 0.85:
        h = 22
        d.polygon([(x - h, ye - h), (x + h, ye - h), (x, ye + 4)], fill=col)


def scene_chain(img, v, t, spec, cues):
    """Cause -> effect domino. Each link drops in when spoken; the arrow draws just before it."""
    d = ImageDraw.Draw(img)
    if v.get("title"):
        ctext(d, 410, v["title"].upper(), fit_font(d, v["title"].upper(), "bold", 60, 960), C["muted"])
    items = v["items"][:4]
    n = len(items)
    hgt, gap = 132, 72 if n == 4 else 96
    y = 480 if n == 4 else 520
    times = [cues.at(it.get("at"), cues.spread(k, n, 0.05, 0.75)) for k, it in enumerate(items)]
    active = max([k for k, tk in enumerate(times) if t >= tk], default=-1)
    for k, it in enumerate(items):
        tk = times[k]
        if k > 0:
            _arrow_down(ImageDraw.Draw(img), W // 2, y - gap + 8, y - 10, ease((t - (tk - 0.3)) / 0.3), C["muted"] + (255,))
        if t >= tk:
            p = ease((t - tk) / 0.3)
            sc = 0.9 + 0.1 * pop((t - tk) / 0.35)
            last = k == n - 1
            fillc = colr(it.get("color")) if it.get("color") else None
            bw = int(880 * sc)
            x0 = (W - bw) // 2
            if fillc:
                card(img, (x0, y, x0 + bw, y + hgt), radius=32, fill=fillc + (int(235 * p),))
            else:
                card(img, (x0, y, x0 + bw, y + hgt), radius=32, fill=(255, 255, 255, int((34 if k == active else 16) * p)))
            d = ImageDraw.Draw(img)
            if k == active and not fillc:
                d.rounded_rectangle((x0, y, x0 + bw, y + hgt), radius=32, outline=C["accent"] + (A(p),), width=5)
            ink = (10, 14, 26) if fillc else C["text"]
            f = fit_font(d, it["text"], "bold", 64 if last else 58, bw - 80)
            ctext(d, y + hgt // 2, it["text"], f, ink + (A(p),))
        y += hgt + gap


def scene_beatmiss(img, v, t, spec, cues):
    """Expected vs actual. The 'actual' number and the verdict stamp land when spoken."""
    d = ImageDraw.Draw(img)
    title = v.get("title", "Expected vs. actual")
    ctext(d, 410, title.upper(), fit_font(d, title.upper(), "bold", 64, 960), C["text"])
    d.rounded_rectangle((W // 2 - 70, 455, W // 2 + 70, 465), radius=5, fill=C["accent"])
    items = v["items"][:3]
    for k, it in enumerate(items):
        tk = cues.at(it.get("at"), cues.spread(k, len(items), 0.05, 0.6))
        y = 510 + k * 245
        if t < tk:
            continue
        p = ease((t - tk) / 0.25)
        card(img, (70, y, W - 70, y + 215), radius=28, fill=(255, 255, 255, int(10 + 12 * p)))
        d = ImageDraw.Draw(img)
        d.text((115, y + 48), it["label"], font=font("bold", 54), fill=C["text"] + (A(p),), anchor="lm")
        d.text((115, y + 112), "EXPECTED", font=font("bold", 30), fill=C["muted"] + (A(p),), anchor="lm")
        d.text((115, y + 160), it["expected"], font=fit_font(d, it["expected"], "bold", 56, 300), fill=C["muted"] + (A(p),), anchor="lm")
        ta = cues.at(it.get("actual_at"), tk + 0.6)
        verdict = it.get("verdict", "inline")
        if t >= ta:
            q = t - ta
            col = C[VERDICT.get(verdict, "accent")]
            d.text((470, y + 112), "ACTUAL", font=font("bold", 30), fill=C["muted"] + (A(q / 0.2),), anchor="lm")
            f = fit_font(d, it["actual"], "bold", int(64 * (0.85 + 0.15 * pop(q / 0.35))), 300)
            d.text((470, y + 160), it["actual"], font=f, fill=col + (A(q / 0.2),), anchor="lm")
            ts = q - 0.12
            if ts > 0:
                sc = 1 + 1.2 * (1 - ease(ts / 0.18))
                _mark(d, W - 165, y + 108, 52, verdict, scale=sc, alpha=A(ts / 0.1))


def scene_timeline(img, v, t, spec, cues):
    """Clock-stamped sequence of events (after-hours stories, multi-day slides)."""
    d = ImageDraw.Draw(img)
    if v.get("title"):
        ctext(d, 410, v["title"].upper(), fit_font(d, v["title"].upper(), "bold", 60, 960), C["muted"])
    items = v["items"][:4]
    n = len(items)
    times = [cues.at(it.get("at"), cues.spread(k, n, 0.05, 0.75)) for k, it in enumerate(items)]
    row = 250
    y0 = 540
    lx = 150
    # spine grows to the newest visible item
    shown = [k for k in range(n) if t >= times[k]]
    if shown:
        k = shown[-1]
        grow = ease((t - times[k]) / 0.3)
        yend = y0 + 40 + row * (k - 1) + row * grow if k > 0 else y0 + 40
        d.line([(lx, y0 + 40), (lx, yend)], fill=(70, 84, 120, 255), width=8)
    active = shown[-1] if shown else -1
    for k, it in enumerate(items):
        if t < times[k]:
            continue
        p = ease((t - times[k]) / 0.3)
        y = y0 + k * row
        on = k == active
        col = colr(it.get("color")) if it.get("color") else (C["accent"] if on else C["muted"])
        r = int(22 * (0.7 + 0.3 * pop((t - times[k]) / 0.3)))
        d.ellipse((lx - r, y + 40 - r, lx + r, y + 40 + r), fill=col + (A(p),))
        x = 220 + int((1 - p) * 50)
        d.text((x, y + 40), it["time"].upper(), font=font("bold", 48), fill=col + (A(p),), anchor="lm")
        for i, line in enumerate(wrap(d, it["text"], font("bold", 62), 760)[:2]):
            d.text((x, y + 112 + i * 70), line, font=font("bold", 62),
                   fill=(C["text"] if on else C["muted"]) + (A(p),), anchor="lm")


def scene_peers(img, v, t, spec, cues):
    """Who else moved: ticker tiles tinted by move, the subject outlined."""
    d = ImageDraw.Draw(img)
    title = v.get("title", "Who else moved")
    ctext(d, 410, title.upper(), fit_font(d, title.upper(), "bold", 60, 960), C["text"])
    items = v["items"][:6]
    n = len(items)
    cols = 2
    tw, th, gx, gy = 430, 210, 40, 36
    x_start = (W - (cols * tw + (cols - 1) * gx)) // 2
    rows = (n + 1) // 2
    y_start = 500 if rows == 3 else 560
    for k, it in enumerate(items):
        tk = cues.at(it.get("at"), cues.spread(k, n, 0.05, 0.6))
        if t < tk:
            continue
        p = ease((t - tk) / 0.25)
        sc = 0.85 + 0.15 * pop((t - tk) / 0.35)
        pct = float(it["pct"])
        col = move_color(pct)
        inten = 0.35 + 0.65 * min(1.0, abs(pct) / 12)
        cx = x_start + (k % cols) * (tw + gx) + tw // 2
        cy = y_start + (k // cols) * (th + gy) + th // 2
        w2, h2 = int(tw * sc) // 2, int(th * sc) // 2
        card(img, (cx - w2, cy - h2, cx + w2, cy + h2), radius=28, fill=col + (int(200 * inten * p),))
        d = ImageDraw.Draw(img)
        if it.get("main"):
            d.rounded_rectangle((cx - w2, cy - h2, cx + w2, cy + h2), radius=28, outline=C["accent"] + (A(p),), width=7)
        d.text((cx, cy - 40), it["ticker"], font=font("bold", 64), fill=C["text"] + (A(p),), anchor="mm")
        d.text((cx, cy + 45), fmt_pct(pct), font=font("bold", 56), fill=C["text"] + (A(p),), anchor="mm")
    if v.get("sub"):
        ts = cues.at(v.get("sub_at"), cues.dur * 0.7)
        yy = y_start + rows * (th + gy) + 30
        for i, line in enumerate(wrap(d, v["sub"], font("medium", 48), 920)):
            ctext(d, yy + i * 60, line, font("medium", 48), C["muted"] + (A((t - ts) / 0.3),))


def _strike(d, x0, x1, y, prog, col, width=10):
    if prog > 0:
        d.line([(x0, y), (x0 + (x1 - x0) * prog, y)], fill=col, width=width)


def scene_mythfact(img, v, t, spec, cues):
    """MYTH card gets struck through, then the FACT card slides in. Contrast hook + payoff."""
    d = ImageDraw.Draw(img)
    tm = cues.at(v.get("myth_at"), 0.0)
    tf = cues.at(v.get("fact_at"), cues.dur * 0.45)
    fm, ff = font("bold", 60), font("bold", 60)
    # MYTH
    pm = ease((t - tm) / 0.3)
    if t >= tm:
        lines = wrap(d, v["myth"], fm, 800)
        hgt = 150 + 74 * len(lines)
        y0 = 450
        dim = 1 - 0.5 * ease((t - tf) / 0.3)
        card(img, (70, y0, W - 70, y0 + hgt), radius=32, fill=C["down"] + (int(60 * pm * dim),))
        d = ImageDraw.Draw(img)
        d.text((120, y0 + 55), "MYTH", font=font("bold", 44), fill=C["down"] + (A(pm * dim),), anchor="lm")
        for i, line in enumerate(lines):
            d.text((120, y0 + 130 + i * 74), line, font=fm, fill=C["text"] + (A(pm * dim),), anchor="lm")
            _strike(d, 120, 120 + text_w(d, line, fm), y0 + 130 + i * 74, ease((t - tf + 0.1) / 0.25), C["down"] + (255,))
        ybottom = y0 + hgt
    else:
        return
    # FACT
    if t >= tf:
        pf = ease((t - tf - 0.1) / 0.3)
        lines = wrap(d, v["fact"], ff, 800)
        hgt2 = 150 + 74 * len(lines)
        y1 = ybottom + 60 + int((1 - pf) * 70)
        card(img, (70, y1, W - 70, y1 + hgt2), radius=32, fill=C["up"] + (int(70 * pf),))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle((70, y1, W - 70, y1 + hgt2), radius=32, outline=C["up"] + (A(pf),), width=5)
        d.text((120, y1 + 55), "FACT", font=font("bold", 44), fill=C["up"] + (A(pf),), anchor="lm")
        for i, line in enumerate(lines):
            d.text((120, y1 + 130 + i * 74), line, font=ff, fill=C["text"] + (A(pf),), anchor="lm")
        if v.get("sub"):
            ts = cues.at(v.get("sub_at"), tf + 1.0)
            for i, line in enumerate(wrap(d, v["sub"], font("medium", 46), 900)):
                ctext(d, y1 + hgt2 + 70 + i * 58, line, font("medium", 46), C["muted"] + (A((t - ts) / 0.3),))


def scene_quiz(img, v, t, spec, cues):
    """Guess-then-reveal. Options appear on their words; at the reveal the right one lights up."""
    d = ImageDraw.Draw(img)
    fq = font("bold", 66)
    qlines = wrap(d, v["question"], fq, 940)
    for i, line in enumerate(qlines):
        ctext(d, 440 + i * 80, line, fq, C["text"])
    opts = v["options"][:3]
    n = len(opts)
    tr = cues.at(v.get("reveal_at"), cues.dur * 0.7)
    y = 440 + len(qlines) * 80 + 60
    for k, o in enumerate(opts):
        tk = cues.at(o.get("at"), cues.spread(k, n, 0.12, 0.5))
        if t < tk:
            y += 190
            continue
        p = ease((t - tk) / 0.25)
        correct = k == int(v["answer"])
        rev = t >= tr
        col = C["up"] if (rev and correct) else C["muted"]
        a = 1.0 if not rev else (1.0 if correct else 0.45)
        fillc = (C["up"] + (int(70 * p),)) if (rev and correct) else (255, 255, 255, int(16 * p))
        card(img, (70, y, W - 70, y + 160), radius=30, fill=fillc)
        d = ImageDraw.Draw(img)
        if rev and correct:
            d.rounded_rectangle((70, y, W - 70, y + 160), radius=30, outline=C["up"] + (255,), width=6)
        d.ellipse((115, y + 40, 195, y + 120), fill=(col if rev and correct else C["accent"]) + (A(p * a),))
        d.text((155, y + 80), "ABC"[k], font=font("bold", 50), fill=(10, 14, 26, A(p * a)), anchor="mm")
        d.text((235, y + 80), o["text"], font=fit_font(d, o["text"], "bold", 54, 640), fill=C["text"] + (A(p * a),), anchor="lm")
        if rev and correct:
            q = t - tr - 0.1
            if q > 0:
                _mark(d, W - 165, y + 80, 46, "good", scale=1 + 1.2 * (1 - ease(q / 0.18)), alpha=A(q / 0.1))
        y += 190
    if v.get("reveal_sub") and t >= tr:
        for i, line in enumerate(wrap(d, v["reveal_sub"], font("medium", 48), 920)):
            ctext(d, y + 40 + i * 60, line, font("medium", 48), C["muted"] + (A((t - tr - 0.2) / 0.3),))


def scene_poll(img, v, t, spec, cues):
    """Either/or opinion prompt that ends on a comment call-to-action. No advice, no 'would you buy'."""
    d = ImageDraw.Draw(img)
    fq = font("bold", 70)
    for i, line in enumerate(wrap(d, v["question"], fq, 940)):
        ctext(d, 470 + i * 84, line, fq, C["text"] + (A(t / 0.25),))
    tl = cues.at(v["left"].get("at"), 0.4)
    tr = cues.at(v["right"].get("at"), 0.9)
    for k, (side, tk) in enumerate((("left", tl), ("right", tr))):
        if t < tk:
            continue
        it = v[side]
        p = ease((t - tk) / 0.3)
        sc = 0.9 + 0.1 * pop((t - tk) / 0.35)
        w2, h2 = int(430 * sc), int(480 * sc)
        cx = 70 + 220 + k * 500
        cy = 880
        col = colr(it.get("color"), "accent")
        card(img, (cx - w2 // 2, cy - h2 // 2, cx + w2 // 2, cy + h2 // 2), radius=36, fill=(255, 255, 255, int(24 * p)))
        d = ImageDraw.Draw(img)
        d.ellipse((cx - 44, cy - h2 // 2 + 30, cx + 44, cy - h2 // 2 + 118), fill=col + (A(p),))
        d.text((cx, cy - h2 // 2 + 74), "AB"[k], font=font("bold", 56), fill=(10, 14, 26, A(p)), anchor="mm")
        f = fit_font(d, it["label"], "bold", 64, 380)
        for i, line in enumerate(wrap(d, it["label"], f, 380)[:2]):
            ctext(d, cy + 10 + i * 70, line, f, C["text"] + (A(p),), x=cx)
        for i, line in enumerate(wrap(d, it.get("sub", ""), font("medium", 42), 395)[:3]):
            ctext(d, cy + 118 + i * 50, line, font("medium", 42), C["muted"] + (A(p),), x=cx)
    if t >= min(tl, tr) + 0.4:
        ctext(ImageDraw.Draw(img), 880 - 240 + 74, "OR", font("bold", 40), C["accent"] + (A((t - tr) / 0.2),))
    tc = cues.at(v.get("cta_at"), cues.dur * 0.65)
    if t > tc:
        p = pop((t - tc) / 0.4)
        cta = v.get("cta", "Comment A or B")
        f = font("bold", 56)
        w = text_w(d, cta, f) + 100
        x0 = (W - w) // 2
        d = ImageDraw.Draw(img)
        d.rounded_rectangle((x0, 1200, x0 + w, 1200 + int(116 * max(0.2, p))), radius=58, fill=C["accent"])
        if p > 0.5:
            ctext(d, 1258, cta, f, (10, 10, 10))


def scene_decoder(img, v, t, spec, cues):
    """Jargon decoder: term -> plain English. The explainer beat that non-investors save and share."""
    d = ImageDraw.Draw(img)
    title = v.get("title", "In plain English")
    ctext(d, 420, title.upper(), fit_font(d, title.upper(), "bold", 60, 960), C["muted"])
    items = v["items"][:3]
    n = len(items)
    y = 500
    for k, it in enumerate(items):
        tk = cues.at(it.get("at"), cues.spread(k, n, 0.05, 0.7))
        tp = cues.at(it.get("plain_at"), tk + 0.7)
        if t < tk:
            y += 270
            continue
        p = ease((t - tk) / 0.3)
        card(img, (70, y, W - 70, y + 240), radius=32, fill=(255, 255, 255, int(18 * p)))
        d = ImageDraw.Draw(img)
        d.text((120, y + 62), it["term"].upper(), font=fit_font(d, it["term"].upper(), "bold", 58, 860), fill=C["accent"] + (A(p),), anchor="lm")
        if t >= tp:
            q = ease((t - tp) / 0.3)
            d.text((120, y + 128), "=", font=font("bold", 50), fill=C["muted"] + (A(q),), anchor="lm")
            for i, line in enumerate(wrap(d, it["plain"], font("bold", 50), 760)[:2]):
                d.text((180, y + 128 + i * 56), line, font=font("bold", 50), fill=C["text"] + (A(q),), anchor="lm")
        y += 270


def scene_shift(img, v, t, spec, cues):
    """Before -> after: two big numbers with an arrow. The 'what changed' beat."""
    d = ImageDraw.Draw(img)
    if v.get("title"):
        ctext(d, 440, v["title"].upper(), fit_font(d, v["title"].upper(), "bold", 52, 960), C["muted"] + (A(t / 0.25),))
    t0 = cues.at(v["from"].get("at"), 0.05)
    t1 = cues.at(v["to"].get("at"), cues.dur * 0.5)
    y0, h = 560, 400
    boxes = ((70, 470, v["from"], t0, "muted"), (610, 1010, v["to"], t1, v["to"].get("color", "accent")))
    for k, (x0, x1, it, tk, c) in enumerate(boxes):
        if t < tk:
            continue
        p = ease((t - tk) / 0.3)
        sc = 0.92 + 0.08 * pop((t - tk) / 0.35)
        cx, cy = (x0 + x1) // 2, y0 + h // 2
        w2, h2 = int((x1 - x0) * sc), int(h * sc)
        col = colr(c, "muted") if k == 0 else colr(c, "accent")
        card(img, (cx - w2 // 2, cy - h2 // 2, cx + w2 // 2, cy + h2 // 2), radius=36,
             fill=(col + (int(46 * p),)) if k else (255, 255, 255, int(20 * p)))
        d = ImageDraw.Draw(img)
        if k:
            d.rounded_rectangle((cx - w2 // 2, cy - h2 // 2, cx + w2 // 2, cy + h2 // 2), radius=36, outline=col + (A(p),), width=5)
        val = str(it["value"])
        ctext(d, cy - 30, val, fit_font(d, val, "bold", 130, (x1 - x0) - 50), (C["text"] if k else C["muted"]) + (A(p),), x=cx)
        for i, line in enumerate(wrap(d, it.get("label", ""), font("medium", 40), (x1 - x0) - 60)[:2]):
            ctext(d, cy + 90 + i * 50, line, font("medium", 40), C["muted"] + (A(p),), x=cx)
    if t >= t1:
        q = ease((t - t1 + 0.15) / 0.25)
        ax = 540
        d = ImageDraw.Draw(img)
        d.polygon([(ax - 38, y0 + h // 2 - 36), (ax + 14, y0 + h // 2 - 36), (ax + 14, y0 + h // 2 - 62),
                   (ax + 60, y0 + h // 2), (ax + 14, y0 + h // 2 + 62), (ax + 14, y0 + h // 2 + 36),
                   (ax - 38, y0 + h // 2 + 36)], fill=C["accent"] + (A(q),))
    if v.get("sub"):
        ts = cues.at(v.get("sub_at"), t1 + 0.9)
        for i, line in enumerate(wrap(d, v["sub"], font("bold", 54), 940)):
            ctext(d, y0 + h + 110 + i * 68, line, font("bold", 54), C["text"] + (A((t - ts) / 0.3),))


def scene_receipts(img, v, t, spec, cues):
    """'What the sources say': up to 3 source cards with a check mark. Builds trust in the sourcing."""
    d = ImageDraw.Draw(img)
    title = v.get("title", "What the sources say")
    ctext(d, 430, title.upper(), fit_font(d, title.upper(), "bold", 56, 960), C["muted"] + (A(t / 0.25),))
    items = v["items"][:3]
    n = len(items)
    y = 510
    for k, it in enumerate(items):
        tk = cues.at(it.get("at"), cues.spread(k, n, 0.05, 0.7))
        if t < tk:
            y += 270
            continue
        p = ease((t - tk) / 0.3)
        card(img, (70, y + int((1 - p) * 40), W - 70, y + 240 + int((1 - p) * 40)), radius=32, fill=(255, 255, 255, int(20 * p)))
        d = ImageDraw.Draw(img)
        yy = y + int((1 - p) * 40)
        src = it["source"].upper()
        fs = font("bold", 34)
        d.rounded_rectangle((110, yy + 28, 110 + text_w(d, src, fs) + 40, yy + 82), radius=14, fill=(245, 247, 251, A(p)))
        d.text((130, yy + 55), src, font=fs, fill=(14, 18, 30, A(p)), anchor="lm")
        fb = font("bold", 48)
        for i, line in enumerate(wrap(d, it["fact"], fb, 700)[:2]):
            d.text((110, yy + 128 + i * 56), line, font=fb, fill=C["text"] + (A(p),), anchor="lm")
        q = t - tk - 0.25
        if q > 0:
            _mark(d, W - 150, yy + 120, 44, "good", scale=1 + 1.2 * (1 - ease(q / 0.18)), alpha=A(q / 0.1))
        y += 270


def scene_qa(img, v, t, spec, cues):
    """Question / answer pairs (generic labels, never invented people). 1-2 pairs."""
    d = ImageDraw.Draw(img)
    y = 430
    fq, fa = font("bold", 44), font("bold", 44)
    for k, it in enumerate(v["items"][:2]):
        tq = cues.at(it.get("q_at"), cues.spread(k, len(v["items"][:2]), 0.05, 0.6))
        ta = cues.at(it.get("a_at"), tq + 1.0)
        ql = wrap(d, it["q"], fq, 760)
        al = wrap(d, it["a"], fa, 760)
        hq, ha = 100 + 52 * len(ql), 100 + 52 * len(al)
        if t >= tq:
            p = ease((t - tq) / 0.3)
            card(img, (70, y, 70 + 880, y + hq), radius=32, fill=(255, 255, 255, int(20 * p)))
            d = ImageDraw.Draw(img)
            d.text((110, y + 40), "THE QUESTION", font=font("bold", 30), fill=C["muted"] + (A(p),), anchor="lm")
            for i, line in enumerate(ql):
                d.text((110, y + 82 + i * 52), line, font=fq, fill=C["text"] + (A(p),), anchor="lm")
        y += hq + 24
        if t >= ta:
            p = ease((t - ta) / 0.3)
            card(img, (130, y, W - 70, y + ha), radius=32, fill=C["accent"] + (int(46 * p),))
            d = ImageDraw.Draw(img)
            d.rounded_rectangle((130, y, W - 70, y + ha), radius=32, outline=C["accent"] + (A(p),), width=4)
            d.text((170, y + 40), "THE ANSWER", font=font("bold", 30), fill=C["accent"] + (A(p),), anchor="lm")
            for i, line in enumerate(al):
                d.text((170, y + 82 + i * 52), line, font=fa, fill=C["text"] + (A(p),), anchor="lm")
        y += ha + 36


SCENES = {"hook": scene_hook, "headline": scene_headline, "stat": scene_stat, "bars": scene_bars, "compare": scene_compare,
          "line": scene_line, "bullets": scene_bullets, "scorecard": scene_scorecard,
          "text": scene_text, "outro": scene_outro, "question": scene_question, "rank": scene_rank,
          "chain": scene_chain, "beatmiss": scene_beatmiss, "timeline": scene_timeline, "peers": scene_peers,
          "mythfact": scene_mythfact, "quiz": scene_quiz, "poll": scene_poll, "decoder": scene_decoder, "shift": scene_shift, "receipts": scene_receipts, "qa": scene_qa}


# ================================================================== TOON theme: original cartoon mascot "Wick"
import math as _m

INK = (24, 20, 40)
MASCOT = {"style": "wick"}


def _ss(w, h, fn, scale=2):
    """Draw at scale x on a small RGBA tile (anti-aliased cartoon shapes), return the downsampled tile."""
    tile = Image.new("RGBA", (w * scale, h * scale), (0, 0, 0, 0))
    fn(ImageDraw.Draw(tile), scale)
    return tile.resize((w, h), Image.LANCZOS)


def stroke_text(d, xy, s, f, fill, sw=8, anchor="mm", ink=INK):
    d.text(xy, s, font=f, fill=fill, anchor=anchor, stroke_width=sw, stroke_fill=ink + (fill[3] if len(fill) > 3 else 255,))


def draw_wick(img, cx, base, h, mood="happy", t=0.0, color=None, look=0.0, arms=None, alpha=255, style=None, glasses=None):
    """Original mascot: a candlestick with a face. cx = centre x, base = y of the feet. h = total height."""
    style = style or MASCOT["style"]
    col = color or C["up"]
    if style == "chip":
        col = (74, 90, 150)
    elif style == "analyst":
        col = (150, 154, 172)
    s = h / 400.0
    W2, H2 = int(520 * s) + 40, int(h + 120 * s) + 40
    ox, oy = W2 // 2, H2 - 20
    bounce = {"happy": abs(_m.sin(t * 5.0)) * 26 * s, "shock": abs(_m.sin(t * 14.0)) * 8 * s,
              "sad": 0.0, "think": abs(_m.sin(t * 2.5)) * 8 * s, "wave": abs(_m.sin(t * 5.0)) * 12 * s}.get(mood, 0)
    sq = 1 + (0.06 * _m.sin(t * 10) if mood == "shock" else 0.0)

    def draw(d, k):
        X = lambda v: int((ox + v * s) * k)
        Y = lambda v: int((oy - bounce * 0 + v * s) * k)
        lw = max(6, int(9 * s * k))
        top = -h / s + 0  # in character units (feet at 0, up negative)
        # legs
        for sx in (-62, 62):
            d.rounded_rectangle((X(sx - 22), Y(-60 - bounce / s), X(sx + 22), Y(-6 - bounce / s)), radius=int(16 * s * k), fill=INK)
            d.ellipse((X(sx - 42), Y(-30 - bounce / s), X(sx + 42), Y(10 - bounce / s)), fill=(255, 255, 255), outline=INK, width=lw)
        by = -bounce / s
        # wick (top and bottom), body
        bt, bb = -330 * sq + by, -60 + by
        if style == "chip":
            for px_ in (-90, -30, 30, 90):
                d.rectangle((X(px_ - 14), Y(bt - 40), X(px_ + 14), Y(bt + 20)), fill=(200, 200, 212), outline=INK, width=max(3, int(5 * s * k)))
            for py_ in (-210, -150, -90):
                for sx_ in (-1, 1):
                    d.rectangle((X(sx_ * 150 + (0 if sx_ > 0 else -34)), Y(py_ - 12 + by), X(sx_ * 150 + (34 if sx_ > 0 else 0)), Y(py_ + 12 + by)), fill=(200, 200, 212), outline=INK, width=max(3, int(5 * s * k)))
        elif style != "analyst":
            d.rounded_rectangle((X(-14), Y(bt - 70), X(14), Y(bt + 30)), radius=int(12 * s * k), fill=col, outline=INK, width=lw)
        d.rounded_rectangle((X(-150), Y(bt), X(150), Y(bb)), radius=int(46 * s * k), fill=col, outline=INK, width=lw)
        # highlight + belly shine
        d.rounded_rectangle((X(-122), Y(bt + 26), X(-96), Y(bt + 120)), radius=int(12 * s * k), fill=tuple(min(255, c + 70) for c in col))
        # arms
        ang = {"happy": (-70, -70), "shock": (-95, -95), "sad": (-20, -20), "think": (-30, -105), "wave": (25, -85)}.get(mood, (-30, -30))
        if arms:
            ang = arms
        for side, a in ((-1, ang[0]), (1, ang[1])):
            a_r = _m.radians(a)
            wob = 8 * _m.sin(t * 9 + side) if mood in ("happy", "wave") else 0
            sx0, sy0 = side * 146, (bt + bb) / 2 - 10
            ex = sx0 + side * 100 * _m.cos(a_r)
            ey = sy0 + 100 * _m.sin(a_r) * -1 + wob
            ey = sy0 + 100 * _m.sin(a_r) * -1
            d.line((X(sx0), Y(sy0), X(ex), Y(ey)), fill=INK, width=int(26 * s * k))
            d.line((X(sx0), Y(sy0), X(ex), Y(ey)), fill=col, width=int(12 * s * k))
            d.ellipse((X(ex - 24), Y(ey - 24), X(ex + 24), Y(ey + 24)), fill=(255, 255, 255), outline=INK, width=lw)
        # face
        ey_c = bt + 100
        blink = 0.12 if (t % 3.2) > 3.05 else 1.0
        for sx in (-62, 62):
            r = 46
            d.ellipse((X(sx - r), Y(ey_c - r * blink), X(sx + r), Y(ey_c + r * blink)), fill=(255, 255, 255), outline=INK, width=lw)
            pr = 20 if mood != "shock" else 11
            px = sx + look * 16
            py = ey_c + (6 if mood != "think" else -8)
            if blink > 0.5:
                d.ellipse((X(px - pr), Y(py - pr), X(px + pr), Y(py + pr)), fill=INK)
                d.ellipse((X(px - pr * 0.35 + 6), Y(py - pr * 0.5), X(px + 6 + pr * 0.1), Y(py - pr * 0.05)), fill=(255, 255, 255))
        # brows (tilt>0 = worried, <0 = angry, 0 = flat); raise = how high
        bro = {"happy": (0, 10), "shock": (0, 24), "sad": (18, 6), "think": (0, 8), "wave": (0, 10)}.get(mood, (0, 6))
        for sx in (-62, 62):
            tilt, rise = bro
            if mood == "think" and sx > 0:
                rise += 12
            yb = ey_c - 62 - rise
            outer = sx + (-34 if sx < 0 else 34)
            inner = sx + (34 if sx < 0 else -34)
            d.line((X(outer), Y(yb + tilt * 0.5), X(inner), Y(yb - tilt * 0.5)), fill=INK, width=int(11 * s * k))
        my = ey_c + 92
        if mood in ("happy", "wave"):
            d.pieslice((X(-48), Y(my - 40), X(48), Y(my + 44)), 0, 180, fill=INK)
            d.pieslice((X(-26), Y(my + 8), X(26), Y(my + 44)), 0, 180, fill=(255, 110, 130))
        elif mood == "shock":
            d.ellipse((X(-30), Y(my - 26), X(30), Y(my + 42)), fill=INK)
            d.ellipse((X(-16), Y(my + 8), X(16), Y(my + 36)), fill=(255, 110, 130))
        elif mood == "sad":
            d.arc((X(-44), Y(my - 6), X(44), Y(my + 56)), 200, 340, fill=INK, width=int(11 * s * k))
        else:
            d.line((X(-30), Y(my + 12), X(30), Y(my), ), fill=INK, width=int(11 * s * k))
        if style == "analyst":
            go = glasses if glasses is not None else 0.0
            gy = ey_c - go * 150 * 1.0
            gx = go * 40
            for sx in (-62, 62):
                d.ellipse((X(sx - 58 + gx), Y(gy - 58), X(sx + 58 + gx), Y(gy + 58)), outline=INK, width=int(9 * s * k))
            d.line((X(-6 + gx), Y(gy), X(6 + gx), Y(gy)), fill=INK, width=int(9 * s * k))
            d.polygon([(X(0), Y(bb - 90)), (X(-26), Y(bb - 40)), (X(0), Y(bb)), (X(26), Y(bb - 40))], fill=(220, 60, 70), outline=INK)
        # cheeks
        for sx in (-104, 104):
            d.ellipse((X(sx - 20), Y(my - 30), X(sx + 20), Y(my - 4)), fill=(255, 150, 150))

    tile = _ss(W2, H2, draw)
    if alpha < 255:
        tile.putalpha(tile.getchannel("A").point(lambda a: int(a * alpha / 255)))
    img.alpha_composite(tile, (int(cx - ox), int(base - oy)))


def starburst(d, cx, cy, r1, r2, n, rot, fill, sw=8):
    pts = []
    for i in range(n * 2):
        r = r2 if i % 2 == 0 else r1
        a = rot + _m.pi * i / n
        pts.append((cx + r * _m.cos(a), cy + r * _m.sin(a)))
    d.polygon(pts, fill=fill, outline=INK, width=sw)


def bubble(img, box, tail=(0, 0), fill=(255, 255, 255, 255)):
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    ld.rounded_rectangle(box, radius=44, fill=fill, outline=INK, width=7)
    x0, y0, x1, y1 = box
    tx, ty = tail
    ld.polygon([(tx, ty), (max(x0 + 50, min(x1 - 110, tx - 40)), y1 - 4), (max(x0 + 120, min(x1 - 40, tx + 60)), y1 - 4)], fill=fill)
    ld.line([(max(x0 + 50, min(x1 - 110, tx - 40)), y1 - 4), (tx, ty), (max(x0 + 120, min(x1 - 40, tx + 60)), y1 - 4)], fill=INK, width=7)
    img.alpha_composite(layer)


def toon_prop(img, kind, cx, cy, size, t, col=None):
    """Cartoon props drawn with thick outlines."""
    w = int(size * 1.4)
    col = col or C["up"]

    def draw(d, k):
        X = lambda v: int((w / 2 + v * size / 300) * k)
        Y = lambda v: int((w / 2 + v * size / 300) * k)
        lw = int(8 * k)
        if kind == "report":
            d.rounded_rectangle((X(-120), Y(-160), X(120), Y(160)), radius=int(20 * k), fill=(255, 255, 255), outline=INK, width=lw)
            for i, hh in enumerate((50, 90, 130)):
                d.rectangle((X(-90 + i * 62), Y(100 - hh), X(-50 + i * 62), Y(100)), fill=col, outline=INK, width=int(5 * k))
            d.line((X(-90), Y(-110), X(60), Y(-110)), fill=INK, width=int(8 * k))
            d.line((X(-90), Y(-70), X(20), Y(-70)), fill=INK, width=int(8 * k))
            d.ellipse((X(40), Y(-150), X(120), Y(-70)), fill=C["accent"], outline=INK, width=lw)
            d.line((X(58), Y(-108), X(76), Y(-90), X(104), Y(-130)), fill=INK, width=int(9 * k))
        elif kind == "chip":
            for i in range(5):
                for sx in (-1, 1):
                    d.rectangle((X(sx * 150 - (14 if sx > 0 else 14) - 6 * sx), Y(-100 + i * 50), X(sx * 150 + 14), Y(-80 + i * 50)), fill=(190, 190, 200), outline=INK, width=int(4 * k))
                d.rectangle((X(-100 + i * 50), Y(-150), X(-80 + i * 50), Y(-120)), fill=(190, 190, 200), outline=INK, width=int(4 * k))
                d.rectangle((X(-100 + i * 50), Y(120), X(-80 + i * 50), Y(150)), fill=(190, 190, 200), outline=INK, width=int(4 * k))
            d.rounded_rectangle((X(-130), Y(-130), X(130), Y(130)), radius=int(24 * k), fill=(70, 80, 120), outline=INK, width=lw)
            d.rounded_rectangle((X(-70), Y(-70), X(70), Y(70)), radius=int(14 * k), fill=C["accent"], outline=INK, width=lw)
            d.line((X(-30), Y(0), X(-8), Y(24), X(34), Y(-26)), fill=INK, width=int(12 * k))
        elif kind == "rocket":
            d.polygon([(X(-60), Y(90)), (X(-130), Y(150)), (X(-60), Y(30))], fill=C["down"], outline=INK)
            d.polygon([(X(60), Y(90)), (X(130), Y(150)), (X(60), Y(30))], fill=C["down"], outline=INK)
            d.ellipse((X(-70), Y(-170), X(70), Y(100)), fill=(245, 245, 250), outline=INK, width=lw)
            d.pieslice((X(-70), Y(-170), X(70), Y(-20)), 180, 360, fill=C["down"], outline=INK, width=lw)
            d.ellipse((X(-32), Y(-50), X(32), Y(14)), fill=(120, 200, 255), outline=INK, width=lw)
            fl = 1 + 0.25 * _m.sin(t * 25)
            d.polygon([(X(-44), Y(104)), (X(0), Y(104 + 110 * fl)), (X(44), Y(104))], fill=C["accent"], outline=INK)
        elif kind == "money":
            d.ellipse((X(-130), Y(-40), X(130), Y(150)), fill=(80, 190, 120), outline=INK, width=lw)
            d.polygon([(X(-60), Y(-30)), (X(-40), Y(-100)), (X(40), Y(-100)), (X(60), Y(-30))], fill=(80, 190, 120), outline=INK)
            d.rounded_rectangle((X(-52), Y(-120), X(52), Y(-90)), radius=int(10 * k), fill=(60, 150, 95), outline=INK, width=int(6 * k))
            d.text((X(0), Y(55)), "$", font=font("bold", int(150 * k * size / 300)), fill=(255, 255, 255), anchor="mm", stroke_width=int(6 * k), stroke_fill=INK)
        elif kind == "anvil":
            d.polygon([(X(-140), Y(-60)), (X(140), Y(-60)), (X(100), Y(0)), (X(60), Y(20)), (X(60), Y(80)), (X(100), Y(130)), (X(-100), Y(130)), (X(-60), Y(80)), (X(-60), Y(20)), (X(-100), Y(0))], fill=(90, 96, 120), outline=INK)
            d.line((X(-140), Y(-60), X(140), Y(-60)), fill=INK, width=lw)
        elif kind in ("chart_up", "chart_down"):
            up = kind == "chart_up"
            d.rounded_rectangle((X(-150), Y(-130), X(150), Y(130)), radius=int(24 * k), fill=(255, 255, 255), outline=INK, width=lw)
            pts = [(-110, 70), (-50, 20), (-10, 50), (50, -20), (100, -70)] if up else [(-110, -70), (-50, -20), (-10, -50), (50, 20), (100, 70)]
            d.line([(X(a), Y(b)) for a, b in pts], fill=C["up"] if up else C["down"], width=int(18 * k), joint="curve")
            ex, ey = pts[-1]
            d.ellipse((X(ex - 18), Y(ey - 18), X(ex + 18), Y(ey + 18)), fill=C["accent"], outline=INK, width=int(6 * k))

    tile = _ss(w, w, draw)
    img.alpha_composite(tile, (int(cx - w // 2), int(cy - w // 2)))


def _toon_label(d, y, s, size=40, color=None):
    f = font("bold", size)
    stroke_text(d, (W // 2, y), s.upper(), f, color or (255, 255, 255), sw=7)


def scene_toon_hook(img, v, t, spec, cues):
    d = ImageDraw.Draw(img)
    pct = float(v.get("move_pct", spec["move_pct"]))
    col = move_color(pct)
    _toon_label(d, 372, v.get("label", "TODAY"), 40)
    pp = pop(t / 0.35)
    r2 = int(250 * (0.6 + 0.4 * pp))
    starburst(d, 540, 660, int(r2 * 0.78), r2, 14, t * 0.5, C["accent"] + (255,))
    f = font("bold", int(170 * (0.85 + 0.15 * pp)))
    stroke_text(d, (540, 660), fmt_pct(pct).replace("−", "-"), f, col, sw=12)
    up = pct >= 0
    draw_wick(img, 540, 1090, 400, mood="shock" if abs(pct) >= 8 else ("happy" if up else "sad"), t=t, color=col, look=0.0)
    q = v.get("question")
    if q:
        f2 = font("bold", 64)
        lines = [ln for part in re.split(r"(?<=[.?!])\s+", q.upper()) if part.strip() for ln in wrap(d, part, f2, 960)]
        for i, line in enumerate(lines):
            stroke_text(d, (540, 1150 + i * 78), line, f2, (255, 255, 255) if i < len(lines) - 1 else C["accent"], sw=8)


def scene_toon_story(img, v, t, spec, cues):
    """Mascot beside a cartoon prop, with a speech bubble that carries the one line on screen."""
    d = ImageDraw.Draw(img)
    t0 = cues.at(v.get("at"), 0.15)
    mood = v.get("mood", "happy")
    col = {"up": C["up"], "down": C["down"]}.get(v.get("color", "up"), C["up"])
    pcx, pcy = 300, 820
    if t >= t0:
        p = pop((t - t0) / 0.4)
        sz = int(420 * max(0.05, p))
        wob = 5 * _m.sin(t * 4)
        toon_prop(img, v.get("prop", "report"), pcx, pcy + wob, sz, t, col)
    else:
        p = 0
    draw_wick(img, 770, 1090, 330, mood=mood, t=t, color=col, look=-0.8)
    txt = v.get("text", "")
    if txt:
        tt = cues.at(v.get("text_at"), 0.0)
        if t >= tt:
            a = ease((t - tt) / 0.25)
            f = fit_font(d, txt, "bold", 56, 800)
            lines = wrap(d, txt, f, 820)
            hh = 60 + 70 * len(lines)
            y0 = 420 - int((1 - a) * 30)
            bubble(img, (110, y0, 970, y0 + hh), tail=(700, y0 + hh + 70))
            dd = ImageDraw.Draw(img)
            for i, line in enumerate(lines):
                dd.text((540, y0 + 38 + 70 * i + 32), line, font=f, fill=INK, anchor="mm")
    if v.get("sub"):
        ts = cues.at(v.get("sub_at"), 0.8)
        if t >= ts:
            a = ease((t - ts) / 0.25)
            _toon_label(ImageDraw.Draw(img), 1190, v["sub"], 44, C["accent"])


def scene_toon_steps(img, v, t, spec, cues):
    """Cause -> effect as a staircase. The mascot jumps up one step per spoken link."""
    d = ImageDraw.Draw(img)
    items = v["items"][:4]
    n = len(items)
    if v.get("title"):
        _toon_label(d, 398, v["title"], 44)
    times = [cues.at(it.get("at"), cues.spread(k, n, 0.05, 0.75)) for k, it in enumerate(items)]
    sh, sw_ = 150, 70
    base_y = 1130
    pos = []
    for k in range(n):
        x0 = 40 + k * 60
        y0 = base_y - (k + 1) * sh + 40
        pos.append((x0, y0))
    active = -1
    for k, tk in enumerate(times):
        if t >= tk:
            active = k
    for k, it in enumerate(items):
        x0, y0 = pos[k]
        tk = times[k]
        if t < tk:
            d.rounded_rectangle((x0, y0, x0 + 680, y0 + sh - 10), radius=26, fill=(255, 255, 255, 70), outline=INK + (110,), width=5)
            continue
        p = ease((t - tk) / 0.25)
        last = k == n - 1
        fillc = (C["up"] if v.get("end", "up") == "up" else C["down"]) if last else (255, 255, 255)
        d.rounded_rectangle((x0, y0, x0 + 680, y0 + sh - 10), radius=26, fill=fillc + (255,), outline=INK, width=7)
        f = fit_font(d, it["text"], "bold", 52, 610, 30)
        ink = (255, 255, 255) if last else INK
        d.text((x0 + 28, y0 + (sh - 10) // 2), it["text"], font=f, fill=ink, anchor="lm", stroke_width=5 if last else 0, stroke_fill=INK)
        d.ellipse((x0 + 640, y0 - 18, x0 + 696, y0 + 38), fill=C["accent"], outline=INK, width=6)
        d.text((x0 + 668, y0 + 10), str(k + 1), font=font("bold", 34), fill=INK, anchor="mm")
    # mascot hops to the active step
    if active >= 0:
        ax, ay = pos[active][0] + 570, pos[active][1]
        prev = pos[active - 1] if active > 0 else (pos[0][0] - 100, pos[0][1] + sh)
        hop = clamp01((t - times[active]) / 0.4)
        px, py = prev[0] + 570, prev[1]
        x = px + (ax - px) * ease(hop)
        y = py + (ay - py) * ease(hop) - _m.sin(_m.pi * hop) * 120
        mood = "happy" if (last := active == n - 1) and v.get("end", "up") == "up" else ("sad" if active == n - 1 and v.get("end") == "down" else "think")
        draw_wick(img, x, y + 6, 200, mood=mood, t=t, color=C["up"] if v.get("end", "up") == "up" else C["down"], look=0.8)


def scene_toon_outro(img, v, t, spec, cues):
    d = ImageDraw.Draw(img)
    up = float(spec.get("move_pct", 1) or 1) >= 0
    draw_wick(img, 540, 1010, 300, mood="wave", t=t, color=C["up"] if up else C["down"], look=0.0)
    big = v["big"]
    f = fit_font(d, big, "bold", 70, 800, 46)
    lines = wrap(d, big, f, 800)
    hh = 70 + 80 * len(lines)
    y0 = 420
    ta = ease(t / 0.3)
    layer_box = (90, y0, 990, y0 + hh)
    bubble(img, layer_box, tail=(560, y0 + hh + 70))
    dd = ImageDraw.Draw(img)
    hl = (v.get("highlight") or "").lower()
    for i, line in enumerate(lines):
        dd.text((540, y0 + 40 + 80 * i + 36), line, font=f, fill=C["accent"] if hl and hl in line.lower() else INK, anchor="mm")
    if v.get("cta"):
        tc = cues.at(v.get("cta_at"), 1.0)
        if t >= tc:
            p = pop((t - tc) / 0.4)
            fb = font("bold", 56)
            w = text_w(dd, v["cta"], fb) + 100
            x0 = 540 - w // 2
            h2 = int(120 * max(0.2, p))
            dd.rounded_rectangle((x0, 1120, x0 + w, 1120 + h2), radius=60, fill=C["accent"], outline=INK, width=7)
            if p > 0.7:
                dd.text((540, 1120 + h2 // 2), v["cta"], font=fb, fill=INK, anchor="mm")
            if v.get("cta_sub") and t > tc + 0.25:
                stroke_text(dd, (540, 1275), v["cta_sub"], font("bold", 38), (255, 255, 255), sw=6)



def _dumbbell(img, cx, cy, w, label, t, col, label_y=None):
    h = int(w * 0.5)

    def draw(d, k):
        X = lambda v: int(v * k)
        d.rounded_rectangle((X(w * 0.18), X(h * 0.45), X(w * 0.82), X(h * 0.58)), radius=int(8 * k), fill=(190, 190, 205), outline=INK, width=int(6 * k))
        for a in (0.04, 0.8):
            d.rounded_rectangle((X(w * a), X(h * 0.08), X(w * (a + 0.16)), X(h * 0.95)), radius=int(14 * k), fill=col, outline=INK, width=int(7 * k))
    tile = _ss(w, h, draw)
    img.alpha_composite(tile, (int(cx - w / 2), int(cy - h / 2)))
    d = ImageDraw.Draw(img)
    stroke_text(d, (cx, label_y if label_y is not None else cy - h * 0.8), label, font("bold", 52), (255, 255, 255), sw=8)


def scene_toon_gag(img, v, t, spec, cues):
    """Comedy: the analyst expects a small number, the chip lifts a huge one, the analyst's glasses fly off."""
    d = ImageDraw.Draw(img)
    ta = cues.at(v.get("expect_at"), 0.2)
    tl = cues.at(v.get("lift_at"), 1.5)
    tr = tl + 0.8
    # analyst (left) with the small weight
    gl = clamp01((t - tr) / 0.5)
    mood_a = "shock" if t >= tr else "think"
    draw_wick(img, 270, 1090, 330, mood=mood_a, t=t, style="analyst", glasses=ease(gl) if gl > 0 else 0.0, look=0.8)
    if t >= ta:
        _dumbbell(img, 270, 1000, 230, v.get("expect", "$293M est."), t, (160, 160, 175), label_y=690)
    # chip (right) lifts the big weight
    lift = ease((t - tl) / 0.7) if t >= tl else 0.0
    draw_wick(img, 790, 1090, 360, mood="happy" if t >= tl else "think", t=t, style="chip", look=-0.8, arms=(-80, -80))
    if t >= ta:
        by = 1040 - lift * 420 + (_m.sin(t * 18) * 6 if 0 < lift < 1 else 0)
        _dumbbell(img, 790, by, 400, v.get("lift", "$335M forecast"), t, C["accent"])
    if t >= tl + 0.6:
        a = ease((t - tl - 0.6) / 0.25)
        stroke_text(d, (540, 1170), v.get("punch", "WHOA."), font("bold", 96), C["accent"] + (255,), sw=12)
        for i in range(5):
            ang = -_m.pi / 2 + (i - 2) * 0.35
            d.line((270 + 200 * _m.cos(ang) + 40, 800 + 200 * _m.sin(ang), 270 + 250 * _m.cos(ang) + 40, 800 + 250 * _m.sin(ang)), fill=INK, width=8)
    if v.get("sub"):
        ts = cues.at(v.get("sub_at"), 2.5)
        if t >= ts:
            _toon_label(ImageDraw.Draw(img), 1245, v["sub"], 32, (255, 255, 255))


SCENES_TOON = {"toon_gag": scene_toon_gag, "toon_hook": scene_toon_hook, "toon_story": scene_toon_story, "toon_steps": scene_toon_steps, "toon_outro": scene_toon_outro}
SCENES.update(SCENES_TOON)


# ================================================================== PIZZA theme: "The Pizza Shop Forecast" (flat vector skit)
import random as _rnd

BR = (58, 36, 24)            # outline brown
CREAM = (255, 241, 214)
CREAM2 = (250, 228, 190)
TOM = (232, 69, 44)
TEAL = (24, 197, 176)
GOLD = (255, 200, 61)
SLATE = (112, 134, 168)
WOODT = (206, 142, 86)       # counter top
WOODF = (170, 108, 62)       # counter front
FLOORC = (112, 72, 48)
PINK = (255, 168, 168)
CT = 1120                    # counter top y
CHEF_X, CHEF_Y = 760, 1196
CRIT_X = (130, 310)
CRIT_Y = 1280
STACK_X = 560
BOXH = 38
CAM = {"z": 1.0, "px": 540.0, "py": 960.0, "dx": 0.0, "dy": 0.0, "rot": 0.0}


def spr(t, f=16.0, dm=7.0):
    """damped spring 0 -> 1 with overshoot"""
    if t <= 0:
        return 0.0
    return 1 - _m.exp(-dm * t) * _m.cos(f * t)


def lerp(a, b, u):
    return a + (b - a) * u


def put(img, tile, x, y):
    x, y = int(round(x)), int(round(y))
    w, h = tile.size
    x0, y0 = max(0, -x), max(0, -y)
    x1, y1 = min(w, img.width - x), min(h, img.height - y)
    if x1 <= x0 or y1 <= y0:
        return
    if (x0, y0, x1, y1) != (0, 0, w, h):
        tile = tile.crop((x0, y0, x1, y1))
    img.alpha_composite(tile, (x + x0, y + y0))


def blit(img, tile, px, py, ox, oy, sx=1.0, sy=1.0, rot=0.0):
    """Draw tile with its pivot (ox,oy) at (px,py), scaled (sx,sy), rotated rot degrees clockwise."""
    if sx <= 0.001 or sy <= 0.001:
        return
    if abs(rot) < 0.01 and abs(sx - 1) < 1e-3 and abs(sy - 1) < 1e-3:
        put(img, tile, px - ox, py - oy)
        return
    w, h = tile.size
    c, s = _m.cos(_m.radians(rot)), _m.sin(_m.radians(rot))
    xs, ys = [], []
    for cx_, cy_ in ((0, 0), (w, 0), (w, h), (0, h)):
        vx, vy = (cx_ - ox) * sx, (cy_ - oy) * sy
        xs.append(px + c * vx - s * vy)
        ys.append(py + s * vx + c * vy)
    rx0, ry0 = max(0, int(min(xs)) - 2), max(0, int(min(ys)) - 2)
    rx1, ry1 = min(img.width, int(max(xs)) + 3), min(img.height, int(max(ys)) + 3)
    rw, rh = rx1 - rx0, ry1 - ry0
    if rw <= 0 or rh <= 0:
        return
    a = c / sx
    b = s / sx
    cc = ox + (c * (rx0 - px) + s * (ry0 - py)) / sx
    d_ = -s / sy
    e = c / sy
    f = oy + (-s * (rx0 - px) + c * (ry0 - py)) / sy
    t2 = tile.convert("RGBa").transform((rw, rh), Image.AFFINE, (a, b, cc, d_, e, f), resample=Image.BICUBIC).convert("RGBA")
    img.alpha_composite(t2, (rx0, ry0))


class Pen:
    def __init__(s, d, k):
        s.d, s.k = d, k

    def _b(s, box):
        return [int(v * s.k) for v in box]

    def rr(s, box, r, fill=None, w=8, out=BR):
        if box[2] <= box[0] or box[3] <= box[1]:
            return
        s.d.rounded_rectangle(s._b(box), radius=int(r * s.k), fill=fill, outline=out if w else None, width=int(w * s.k) if w else 0)

    def el(s, box, fill=None, w=8, out=BR):
        if box[2] <= box[0] or box[3] <= box[1]:
            return
        s.d.ellipse(s._b(box), fill=fill, outline=out if w else None, width=int(w * s.k) if w else 0)

    def ln(s, pts, w=8, fill=BR):
        k = s.k
        P = [(x * k, y * k) for x, y in pts]
        s.d.line(P, fill=fill, width=int(w * k), joint="curve")
        r = w * k / 2
        for x, y in (P[0], P[-1]):
            s.d.ellipse((x - r, y - r, x + r, y + r), fill=fill)

    def poly(s, pts, fill, w=7, out=BR):
        k = s.k
        s.d.polygon([(x * k, y * k) for x, y in pts], fill=fill)
        if w:
            s.ln(list(pts) + [pts[0]], w, out)

    def arc(s, box, a0, a1, w=8, fill=BR):
        s.d.arc(s._b(box), a0, a1, fill=fill, width=int(w * s.k))

    def pie(s, box, a0, a1, fill, w=7, out=BR):
        s.d.pieslice(s._b(box), a0, a1, fill=fill, outline=out if w else None, width=int(w * s.k) if w else 0)

    def txt(s, xy, text, size, fill=BR, anchor="mm"):
        s.d.text((xy[0] * s.k, xy[1] * s.k), text, font=font("bold", int(size * s.k)), fill=fill, anchor=anchor)


_TC = {}


def _cached(key, w, h, fn):
    if key not in _TC:
        if len(_TC) > 400:
            _TC.clear()
        _TC[key] = _ss(w, h, fn)
    return _TC[key]


# ---------------------------------------------------------------- characters
def chef_tile(mood="smile", eye="dot", al=20, ar=20, hat=0.0, tag="LSCC"):
    key = ("chef", mood, eye, int(al), int(ar), round(hat, 1), tag)
    SK = (255, 222, 185)

    def fn(d, k):
        p = Pen(d, k)
        hy = hat * 8
        p.el((105, 596, 200, 634), (80, 56, 44), 7)
        p.el((200, 596, 295, 634), (80, 56, 44), 7)
        p.rr((128, 520, 272, 610), 24, (96, 108, 136), 8)
        p.rr((88, 262, 312, 560), 78, TEAL, 9)
        p.rr((128, 372, 272, 566), 34, (255, 255, 255), 8)
        p.rr((142, 396, 258, 446), 12, GOLD, 7)
        p.txt((200, 421), tag, 31, BR)

        def arm(sx, sy, ang, side, ln=128):
            a = _m.radians(ang)
            hx, hy2 = sx + side * _m.sin(a) * ln, sy + _m.cos(a) * ln
            p.ln([(sx, sy), (hx, hy2)], 48, BR)
            p.ln([(sx, sy), (hx, hy2)], 33, TEAL)
            p.el((hx - 28, hy2 - 28, hx + 28, hy2 + 28), SK, 7)
        arm(110, 336, al, -1)
        arm(290, 336, ar, +1)
        # hat puffs, head, band
        p.el((110, 38 + hy, 206, 132 + hy), (255, 255, 255), 8)
        p.el((194, 38 + hy, 290, 132 + hy), (255, 255, 255), 8)
        p.el((148, 6 + hy, 252, 108 + hy), (255, 255, 255), 8)
        p.el((100, 85, 300, 285), SK, 9)
        p.rr((116, 94 + hy * 0.5, 284, 154 + hy * 0.5), 16, (255, 255, 255), 8)
        # cheeks
        p.el((124, 198, 166, 228), (255, 170, 150), 0)
        p.el((234, 198, 276, 228), (255, 170, 150), 0)
        # eyes
        if eye == "joy":
            p.arc((146, 150, 186, 190), 200, 340, 8)
            p.arc((214, 150, 254, 190), 200, 340, 8)
        elif eye == "wide":
            for ex in (166, 234):
                p.el((ex - 24, 148, ex + 24, 196), (255, 255, 255), 7)
                p.el((ex - 8, 164, ex + 8, 182), BR, 0)
        elif eye == "lid":
            for ex in (166, 234):
                p.el((ex - 20, 156, ex + 20, 194), (255, 255, 255), 6)
                p.el((ex - 8, 168, ex + 8, 186), BR, 0)
                p.rr((ex - 24, 150, ex + 24, 172), 4, SK, 0)
                p.ln([(ex - 22, 172), (ex + 22, 172)], 7)
        else:
            for ex in (166, 234):
                p.el((ex - 12, 152, ex + 12, 190), BR, 0)
                p.el((ex - 6, 158, ex + 2, 168), (255, 255, 255), 0)
        # mouth then mustache
        if mood == "grin":
            p.pie((160, 224, 240, 284), 0, 180, (150, 40, 40), 7)
            p.el((180, 258, 220, 280), (240, 110, 110), 0)
        elif mood == "smug":
            p.ln([(166, 252), (214, 252), (236, 238)], 8)
        elif mood == "wow":
            p.el((180, 240, 220, 282), (150, 40, 40), 7)
        else:
            p.arc((164, 218, 236, 270), 20, 160, 8)
        p.el((136, 206, 202, 242), (74, 46, 30), 0)
        p.el((198, 206, 264, 242), (74, 46, 30), 0)
    return _cached(key, 400, 640, fn)


def critic_tile(which, mood="smug", jaw=0.0, glass=0.0, leg=0.0, clip="", snap=0.0, sweat=0.0, brow=0.0):
    key = ("crit", which, mood, round(jaw, 1), round(glass, 1), round(leg, 1), clip, round(snap, 1), round(sweat, 1), round(brow, 1))
    SUIT = SLATE if which == 0 else (150, 122, 172)
    SKIN = (244, 208, 170) if which == 0 else (186, 128, 92)

    def fn(d, k):
        p = Pen(d, k)
        up1, up2 = max(0, leg) * 16, max(0, -leg) * 16
        p.rr((112, 520, 162, 596 - up1), 14, (78, 84, 112), 8)
        p.rr((182, 520, 232, 596 - up2), 14, (78, 84, 112), 8)
        p.el((94, 584 - up1, 170, 612 - up1), (60, 48, 56), 7)
        p.el((174, 584 - up2, 250, 612 - up2), (60, 48, 56), 7)
        p.rr((78, 284, 262, 552), 52, SUIT, 9)
        p.poly([(138, 286), (202, 286), (170, 356)], (255, 255, 255), 6)
        if which == 0:
            p.poly([(162, 304), (178, 304), (186, 350), (170, 394), (154, 350)], TOM, 5)
        else:
            p.poly([(170, 322), (136, 304), (136, 344)], GOLD, 5)
            p.poly([(170, 322), (204, 304), (204, 344)], GOLD, 5)
            p.el((160, 312, 180, 332), GOLD, 5)
        # left arm + pencil
        p.ln([(92, 330), (70, 438)], 44, BR)
        p.ln([(92, 330), (70, 438)], 30, SUIT)
        if snap < 0.5:
            p.poly([(56, 380), (74, 374), (90, 470), (72, 474)], (255, 214, 70), 6)
            p.poly([(72, 474), (90, 470), (80, 498)], (240, 190, 130), 5)
            p.poly([(56, 380), (74, 374), (76, 362), (59, 367)], PINK, 5)
        else:
            p.poly([(66, 426), (82, 422), (90, 470), (72, 474)], (255, 214, 70), 6)
            p.poly([(72, 474), (90, 470), (80, 498)], (240, 190, 130), 5)
        p.el((50, 424, 92, 462), SKIN, 7)
        # head
        if which == 1:
            p.el((132, 66, 210, 128), (70, 50, 90), 8)
        p.el((88, 118, 252, 282 + jaw * 34), SKIN, 9)
        if which == 0:
            p.el((82, 176, 112, 234), (206, 206, 216), 6)
            p.el((228, 176, 258, 234), (206, 206, 216), 6)
        else:
            p.pie((84, 106, 256, 260), 180, 360, (70, 50, 90), 8)
        # brows
        by = -brow * 20
        if mood == "worry":
            p.ln([(108, 182 + by), (158, 166 + by)], 9)
            p.ln([(232, 182 + by), (182, 166 + by)], 9)
        elif mood == "shock":
            p.ln([(106, 168 + by), (160, 160 + by)], 9)
            p.ln([(234, 168 + by), (180, 160 + by)], 9)
        else:
            p.ln([(106, 170), (160, 188)], 10)
            p.ln([(234, 170), (180, 188)], 10)
        # eyes / glasses
        gy = -glass * 150
        if glass > 0.3 or mood == "shock":
            for ex in (136, 204):
                p.el((ex - 25, 192, ex + 25, 246 + jaw * 4), (255, 255, 255), 7)
                p.el((ex - 5, 214, ex + 5, 226), BR, 0)
        else:
            for ex in (136, 204):
                p.el((ex - 7, 206, ex + 7, 224), BR, 0)
        # mouth
        my = 252
        if jaw > 0.05:
            wdt, hgt = 26 + jaw * 20, 8 + jaw * 60
            p.el((170 - wdt / 2, my - 4, 170 + wdt / 2, my - 4 + hgt), (150, 40, 40), 7)
            if jaw > 0.6:
                p.el((170 - wdt / 3, my + hgt - 26, 170 + wdt / 3, my + hgt - 6), (240, 110, 110), 0)
        elif mood == "worry":
            p.ln([(140, 262), (152, 252), (164, 262), (176, 252), (188, 262), (200, 252)], 7)
        else:
            p.ln([(140, 262), (170, 254), (200, 262)], 8)
        # mustache for critic 0
        if which == 0 and jaw < 0.3:
            p.el((132, 232, 172, 256), (120, 110, 112), 0)
            p.el((168, 232, 208, 256), (120, 110, 112), 0)
        # glasses (drawn last so they can pop above the head)
        lens = (228, 244, 255)
        p.rr((106, 184 + gy, 164, 242 + gy), 14, lens if glass > 0.3 else lens, 8)
        p.rr((176, 184 + gy, 234, 242 + gy), 14, lens, 8)
        p.ln([(164, 206 + gy), (176, 206 + gy)], 7)
        if glass <= 0.3 and mood != "shock":
            for ex in (136, 204):
                p.el((ex - 7, 206, ex + 7, 224), BR, 0)
        # clipboard + right arm
        p.ln([(248, 330), (244, 424)], 44, BR)
        p.ln([(248, 330), (244, 424)], 30, SUIT)
        p.rr((186, 372, 298, 524), 10, (196, 146, 92), 8)
        p.rr((196, 392, 288, 514), 4, (255, 255, 255), 5)
        p.rr((222, 362, 262, 392), 8, (170, 176, 192), 6)
        for yy in (410, 432):
            p.ln([(206, yy), (278, yy)], 5, (176, 176, 186))
        if clip:
            p.txt((242, 480), clip, 24, TOM)
        else:
            p.ln([(206, 462), (270, 462)], 5, (176, 176, 186))
        p.el((180, 440, 214, 474), SKIN, 7)
        if sweat > 0:
            sy = 150 + sweat * 40
            p.poly([(262, sy), (252, sy + 26), (262, sy + 40), (272, sy + 26)], (140, 210, 255), 5)
    return _cached(key, 340, 620, fn)


def cust_tile(i, hop=0.0):
    key = ("cust", i % 8)
    cols = [TOM, (255, 183, 60), (120, 100, 200), (60, 170, 230), (240, 110, 170), (90, 190, 110), (250, 140, 70), (70, 90, 160)]
    skins = [(255, 222, 185), (217, 160, 120), (170, 115, 80), (247, 200, 160), (120, 80, 56), (236, 190, 150), (255, 214, 175), (196, 140, 100)]
    hairs = [(70, 44, 30), (30, 30, 40), (200, 120, 50), (60, 40, 80)]

    def fn(d, k):
        p = Pen(d, k)
        n = i % 8
        col, sk = cols[n], skins[n]
        p.el((22, 184, 52, 200), (60, 48, 56), 5)
        p.el((58, 184, 88, 200), (60, 48, 56), 5)
        p.rr((8, 108, 28, 156), 9, col, 5)
        p.rr((82, 108, 102, 156), 9, col, 5)
        p.rr((20, 98, 90, 176), 24, col, 6)
        v = n % 4
        if v == 2:
            p.el((74, 36, 108, 76), hairs[2], 5)
        p.el((16, 30, 94, 106), sk, 6)
        if v == 0:
            p.pie((14, 26, 96, 100), 180, 360, hairs[0], 6)
        elif v == 1:
            p.pie((14, 22, 96, 96), 180, 360, col, 6)
            p.el((45, 8, 65, 28), (255, 255, 255), 5)
        elif v == 2:
            p.pie((14, 26, 96, 100), 180, 360, hairs[2], 6)
        else:
            p.pie((14, 26, 96, 100), 180, 360, (60, 60, 70), 6)
            p.rr((52, 40, 104, 52), 6, (60, 60, 70), 5)
        p.el((38, 62, 48, 78), BR, 0)
        p.el((62, 62, 72, 78), BR, 0)
        p.el((46, 82, 64, 98), (150, 40, 40), 4)
        p.el((50, 90, 60, 98), (240, 110, 110), 0)
    return _cached(key, 110, 204, fn)


def pizza_tile(r=260):
    key = ("pizza", r)
    S = 2 * r + 40

    def fn(d, k):
        p = Pen(d, k)
        c = S / 2
        p.el((c - r, c - r, c + r, c + r), (236, 172, 72), 11)
        p.el((c - r * 0.86, c - r * 0.86, c + r * 0.86, c + r * 0.86), (236, 80, 48), 0)
        p.el((c - r * 0.80, c - r * 0.80, c + r * 0.80, c + r * 0.80), (255, 214, 92), 0)
        rnd = _rnd.Random(5)
        for ang, rad, size in ((10, .5, .17), (80, .55, .15), (140, .5, .17), (200, .58, .16), (265, .5, .15), (320, .56, .17), (0, 0.0, .17), (45, .24, .12), (225, .27, .12)):
            a = _m.radians(ang)
            x, y = c + _m.cos(a) * rad * r, c + _m.sin(a) * rad * r
            rr_ = size * r
            p.el((x - rr_, y - rr_, x + rr_, y + rr_), (200, 48, 40), 6)
            p.el((x - rr_ * 0.4, y - rr_ * 0.5, x + rr_ * 0.1, y - rr_ * 0.1), (226, 96, 80), 0)
        for ang in (30, 120, 250):
            a = _m.radians(ang)
            x, y = c + _m.cos(a) * r * 0.38, c + _m.sin(a) * r * 0.38
            p.el((x - r * .07, y - r * .04, x + r * .07, y + r * .04), (80, 170, 80), 4)
        for ang in (0, 60, 120):
            a = _m.radians(ang)
            p.ln([(c - _m.cos(a) * r * 0.9, c - _m.sin(a) * r * 0.9), (c + _m.cos(a) * r * 0.9, c + _m.sin(a) * r * 0.9)], 4, (200, 130, 50))
        p.arc((c - r * 0.93, c - r * 0.93, c + r * 0.93, c + r * 0.93), 200, 250, 9, (255, 236, 190))
    return _cached(key, S, S, fn)


def box_tile(w=210, h=BOXH + 6):
    key = ("box", w)

    def fn(d, k):
        p = Pen(d, k)
        p.rr((4, 4, w - 4, h - 3), 9, (226, 172, 98), 7)
        p.rr((12, 9, w - 12, 17), 3, (244, 202, 130), 0)
        p.rr((w * 0.34, 20, w * 0.66, h - 9), 5, TOM, 0)
        p.el((w * 0.5 - 8, 22, w * 0.5 + 8, 38), (255, 255, 255), 0)
    return _cached(key, w, h, fn)


# ---------------------------------------------------------------- text helpers
def ptext(img, xy, s, size, fill, sw=8, rot=0.0, sc=1.0, ink=BR, alpha=1.0):
    f = font("bold", max(10, int(size * sc)))
    sw2 = max(1, int(sw * sc)) if sw else 0
    if abs(rot) < 0.01 and alpha >= 1:
        ImageDraw.Draw(img).text(xy, s, font=f, fill=tuple(fill) + (255,), anchor="mm", stroke_width=sw2, stroke_fill=ink + (255,))
        return
    probe = ImageDraw.Draw(Image.new("L", (4, 4)))
    bb = probe.textbbox((0, 0), s, font=f, anchor="lt", stroke_width=sw2)
    tw, th = bb[2] - bb[0] + 12, bb[3] - bb[1] + 24
    tile = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    ImageDraw.Draw(tile).text((tw // 2, th // 2), s, font=f, fill=tuple(fill) + (255,), anchor="mm", stroke_width=sw2, stroke_fill=ink + (255,))
    if alpha < 1:
        tile.putalpha(tile.getchannel("A").point(lambda a: int(a * alpha)))
    blit(img, tile, xy[0], xy[1], tw / 2, th / 2, 1, 1, rot)


def pill(img, cx, cy, s, size, fill, tc=(255, 255, 255), padx=34, h=None, rot=0.0, sc=1.0, sw=0, w_min=0):
    f = font("bold", size)
    probe = ImageDraw.Draw(Image.new("L", (4, 4)))
    tw = int(probe.textlength(s, font=f))
    w = max(w_min, tw + 2 * padx)
    hh = h or int(size * 1.7)
    T = _ss(w + 24, hh + 24, lambda d, k: Pen(d, k).rr((10, 10, w + 10, hh + 10), hh // 2.4, fill, 7))
    ImageDraw.Draw(T).text(((w + 24) // 2, (hh + 24) // 2 + 1), s, font=f, fill=tuple(tc) + (255,), anchor="mm", stroke_width=sw, stroke_fill=BR + (255,))
    blit(img, T, cx, cy, (w + 24) / 2, (hh + 24) / 2, sc, sc, rot)


def confetti(img, t, x, y, n, seed, speed=620, g=1500, life=1.9, cols=None, spread=1.0):
    if t < 0 or t > life:
        return
    rnd = _rnd.Random(seed)
    cols = cols or [TOM, GOLD, TEAL, (255, 255, 255), (120, 100, 200)]
    d = ImageDraw.Draw(img)
    for i in range(n):
        ang = rnd.uniform(-_m.pi * 0.96, -_m.pi * 0.04)
        sp = rnd.uniform(0.35, 1.0) * speed
        px = x + _m.cos(ang) * sp * t * spread
        py = y + _m.sin(ang) * sp * t + 0.5 * g * t * t
        rot = rnd.uniform(0, 6.28) + t * rnd.uniform(-9, 9)
        w, h = rnd.uniform(9, 17), rnd.uniform(5, 9)
        fade = clamp01((life - t) / 0.5)
        w, h = w * fade, h * fade
        col = rnd.choice(cols)
        pts = [(px + _m.cos(rot) * a - _m.sin(rot) * b, py + _m.sin(rot) * a + _m.cos(rot) * b) for a, b in ((-w, -h), (w, -h), (w, h), (-w, h))]
        d.polygon(pts, fill=col + (255,))


def rays(img, cx, cy, r0, r1, n, rot, c1, c2=None, frac=0.5):
    d = ImageDraw.Draw(img)
    step = 2 * _m.pi / n
    for i in range(n):
        if c2 is None and i % 2:
            continue
        a0 = rot + i * step
        a1 = a0 + step * frac
        col = c1 if (c2 is None or i % 2 == 0) else c2
        d.polygon([(cx + _m.cos(a0) * r0, cy + _m.sin(a0) * r0), (cx + _m.cos(a0) * r1, cy + _m.sin(a0) * r1),
                   (cx + _m.cos(a1) * r1, cy + _m.sin(a1) * r1), (cx + _m.cos(a1) * r0, cy + _m.sin(a1) * r0)], fill=col + (255,))


def burst(img, cx, cy, r1, r2, n, rot, fill, sw=8, alpha=1.0):
    T = int(r2 * 2 + 30)
    def fn(d, k):
        pts = []
        for i in range(n * 2):
            r = r2 if i % 2 == 0 else r1
            a = rot + _m.pi * i / n
            pts.append(((T / 2 + r * _m.cos(a)) * k, (T / 2 + r * _m.sin(a)) * k))
        d.polygon(pts, fill=fill, outline=BR, width=int(sw * k))
    tile = _ss(T, T, fn)
    if alpha < 1:
        tile.putalpha(tile.getchannel('A').point(lambda a: int(a * alpha)))
    put(img, tile, cx - T / 2, cy - T / 2)


def dim(img, a):
    if a > 0:
        img.alpha_composite(Image.new("RGBA", img.size, CREAM + (int(255 * clamp01(a)),)))


def flash(img, a):
    if a > 0.01:
        img.alpha_composite(Image.new("RGBA", img.size, (255, 255, 255, int(255 * clamp01(a)))))


def shake(amp, t, hz=38):
    return (_m.sin(t * hz * 1.3) * amp, _m.cos(t * hz) * amp)


# ---------------------------------------------------------------- shop set (cached layers)
WIN = (160, 548, 920, 1010)      # window glass box
_SHOP = {}


def shop_cache():
    if _SHOP:
        return _SHOP
    # --- static wall + floor (opaque)
    st = Image.new("RGBA", (W, H), CREAM + (255,))
    d = ImageDraw.Draw(st)
    for x in range(0, W, 120):
        d.rectangle((x, 0, x + 60, 1120), fill=CREAM2 + (255,))
    # brick wainscot behind counter
    d.rectangle((0, 1000, W, 1130), fill=(206, 56, 36, 255))
    for row, y in enumerate(range(1000, 1130, 32)):
        d.line([(0, y), (W, y)], fill=BR + (255,), width=4)
        for x in range((row % 2) * 48 - 96, W, 96):
            d.line([(x, y), (x, y + 32)], fill=BR + (255,), width=4)
    d.rectangle((0, 992, W, 1004), fill=BR + (255,))
    # floor
    d.rectangle((0, 1270, W, H), fill=FLOORC + (255,))
    for y in range(1300, H, 70):
        d.line([(0, y), (W, y)], fill=(98, 62, 40, 255), width=4)
    for y in range(1270, H, 140):
        for x in range(((y // 140) % 2) * 100, W, 200):
            d.line([(x, y), (x, y + 70)], fill=(98, 62, 40, 255), width=4)
    for r_ in range(0, 12):
        for c_ in range(0, 10):
            if (r_ + c_) % 2 == 0:
                d.rectangle((c_ * 120, 1290 + r_ * 120, c_ * 120 + 120, 1290 + r_ * 120 + 120), fill=(122, 80, 54, 255))
    # wall lamp string (decor)
    d.line([(0, 300), (540, 330), (1080, 300)], fill=BR + (255,), width=5)
    _SHOP["static"] = st
    # --- window sky (cached)
    ww, wh = WIN[2] - WIN[0], WIN[3] - WIN[1]
    sky = Image.new("RGBA", (ww, wh), (0, 0, 0, 255))
    sd = ImageDraw.Draw(sky)
    for y in range(wh):
        sd.line([(0, y), (ww, y)], fill=mix((120, 200, 255), (214, 242, 255), y / wh) + (255,))
    # far buildings
    brng = _rnd.Random(11)
    x = -20
    while x < ww:
        bw, bh = brng.randint(90, 150), brng.randint(110, 230)
        col = brng.choice([(255, 196, 150), (190, 170, 230), (150, 220, 200), (255, 170, 170)])
        sd.rectangle((x, wh - 120 - bh, x + bw, wh - 100), fill=col + (255,), outline=BR + (255,), width=5)
        for wy in range(wh - 100 - bh + 24, wh - 130, 44):
            for wx in range(x + 18, x + bw - 24, 36):
                sd.rectangle((wx, wy, wx + 16, wy + 22), fill=(255, 245, 190, 255))
        x += bw + brng.randint(4, 24)
    sd.rectangle((0, wh - 112, ww, wh - 40), fill=(206, 206, 216, 255))          # sidewalk
    sd.line([(0, wh - 112), (ww, wh - 112)], fill=BR + (255,), width=5)
    sd.rectangle((0, wh - 40, ww, wh), fill=(84, 88, 110, 255))                   # road
    sd.line([(0, wh - 40), (ww, wh - 40)], fill=BR + (255,), width=5)
    for x in range(10, ww, 120):
        sd.rectangle((x, wh - 18, x + 60, wh - 10), fill=(255, 230, 120, 255))
    _SHOP["sky"] = sky
    # cloud tile
    def cl(d, k):
        for a, b, c in ((10, 40, 70), (50, 6, 90), (110, 36, 76), (40, 40, 110)):
            d.ellipse((a * k, b * k, (a + c) * k, (b + c * 0.75) * k), fill=(255, 255, 255), outline=BR, width=4 * k)
        for a, b, c in ((18, 48, 56), (58, 14, 74), (118, 44, 62), (48, 48, 94)):
            d.ellipse((a * k, b * k, (a + c) * k, (b + c * 0.75) * k), fill=(255, 255, 255))
    _SHOP["cloud"] = _ss(230, 130, cl)
    # window frame overlay
    fr = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    # build frame with a mask so the shine is translucent
    ft = Image.new("RGBA", (W * 2, 520 * 2), (0, 0, 0, 0))
    fd = ImageDraw.Draw(ft)
    k = 2
    x0, y0, x1, y1 = WIN
    oy = y0 - 40
    fd.rounded_rectangle((int((x0 - 26) * k), int((y0 - 26 - oy) * k), int((x1 + 26) * k), int((y1 + 26 - oy) * k)), radius=int(26 * k), outline=(176, 108, 62), width=int(26 * k))
    fd.rounded_rectangle((int((x0 - 26) * k), int((y0 - 26 - oy) * k), int((x1 + 26) * k), int((y1 + 26 - oy) * k)), radius=int(26 * k), outline=BR, width=int(9 * k))
    fd.rounded_rectangle((int(x0 * k), int((y0 - oy) * k), int(x1 * k), int((y1 - oy) * k)), radius=int(4 * k), outline=BR, width=int(7 * k))
    ft = ft.resize((W, 520), Image.LANCZOS)
    shine = Image.new("RGBA", (W, 520), (0, 0, 0, 0))
    sdr = ImageDraw.Draw(shine)
    for ox_ in (120, 230):
        sdr.polygon([(x0 + ox_, y0 - oy), (x0 + ox_ + 46, y0 - oy), (x0 + ox_ - 70, y0 - oy + 190), (x0 + ox_ - 116, y0 - oy + 190)], fill=(255, 255, 255, 90))
    shine.alpha_composite(ft)
    _SHOP["winframe"] = (shine, oy)
    # awning (RGBA) y 380..530
    AH = 170
    def aw(d, k):
        sw_ = 90
        for i in range(-1, W // sw_ + 2):
            col = TOM if i % 2 == 0 else (255, 255, 255)
            x0 = i * sw_
            d.rectangle((x0 * k, 0, (x0 + sw_) * k, 118 * k), fill=col)
            d.pieslice((x0 * k, (118 - sw_ / 2) * k, (x0 + sw_) * k, (118 + sw_ / 2) * k), 0, 180, fill=col)
        for i in range(-1, W // sw_ + 2):
            x0 = i * sw_
            d.arc((x0 * k, (118 - sw_ / 2) * k, (x0 + sw_) * k, (118 + sw_ / 2) * k), 0, 180, fill=BR, width=7 * k)
        d.rectangle((0, 0, W * k, 14 * k), fill=BR)
        d.line([(0, 118 * k), (0, 118 * k)], fill=BR)
    _SHOP["awning"] = _ss(W, AH, aw)
    # sign
    def sg(d, k):
        p = Pen(d, k)
        p.ln([(60, 0), (60, 40)], 7)
        p.ln([(240, 0), (240, 40)], 7)
        p.rr((8, 38, 292, 150), 26, TEAL, 10)
        p.rr((20, 50, 280, 138), 18, None, 4, (255, 255, 255))
        p.txt((150, 94), "LSCC PIZZA", 44, (255, 255, 255))
    _SHOP["sign"] = _ss(300, 160, sg)
    # counter overlay (RGBA) from y=CT-4 to 1275
    CH = 1275 - (CT - 6)
    def ctr(d, k):
        p = Pen(d, k)
        p.rr((-40, 0, W + 40, 52), 14, WOODT, 9)
        p.rr((-40, 40, W + 40, CH + 20), 0, WOODF, 9)
        for x in range(60, W, 180):
            p.ln([(x, 66), (x, CH - 16)], 5, (150, 92, 52))
        p.rr((-40, CH - 22, W + 40, CH + 20), 0, (140, 86, 48), 9)
        p.rr((8, 8, W - 8, 20), 6, (232, 176, 124), 0)
    _SHOP["counter"] = (_ss(W, CH, ctr), CT - 6)
    return _SHOP


def window_img(tw, queue):
    """queue: list of (index, age) ; draws sky, drifting clouds and the customers."""
    sh = shop_cache()
    img = sh["sky"].copy()
    ww, wh = img.size
    for i, cx0 in enumerate((40, 330, 620)):
        x = (cx0 + tw * (14 + 7 * i)) % (ww + 300) - 230
        put(img, sh["cloud"], x, 30 + 40 * (i % 2))
    for idx, age in sorted(queue, key=lambda q: (q[0] % 2 == 0, q[0])):
        if age < 0:
            continue
        back = idx % 2 == 1
        sc = 0.72 if back else 0.82
        hop = abs(_m.sin(tw * 5 + idx * 1.3)) * 7 if age > 0.6 else 0
        u = age / 0.42
        pp = pop(u) if u < 1 else 1.0
        dropy = (1 - clamp01(u)) * -90
        x = 60 + (idx // 2) * 118 + (58 if back else 0)
        base = wh - 76 + dropy - hop - (16 if back else 0)
        tile = cust_tile(idx)
        blit(img, tile, x, base, 55, 196, sc * pp * (1 + 0.1 * (1 - clamp01(u))), sc * pp * (1 - 0.12 * (1 - clamp01(u))), _m.sin(tw * 5 + idx) * 3)
    return img


def shop_back(layer, tw, queue=(), awn=1.0, sign_t=99.0, build=1.0):
    """wall, floor, window with queue, awning and swinging sign. build<1 slides the awning down."""
    sh = shop_cache()
    layer.paste(sh["static"], (0, 0))
    wi = window_img(tw, queue)
    layer.paste(wi, (WIN[0], WIN[1]))
    fr, oy = sh["winframe"]
    put(layer, fr, 0, oy)
    ay = 372 - (1 - awn) * 330
    put(layer, sh["awning"], 0, ay)
    # sign swings from the awning
    if sign_t >= 0:
        drop = spr(sign_t, 11, 6)
        sy = 468 + (drop - 1) * 240
        sw = _m.exp(-3.0 * sign_t) * _m.sin(sign_t * 9) * 9 + _m.sin(tw * 1.7) * 1.2
        blit(layer, sh["sign"], 238, sy - 4, 150, 0, 0.9, 0.9, sw)


def shop_counter(layer, rise=1.0):
    sh = shop_cache()
    im, y0 = sh["counter"]
    put(layer, im, 0, y0 + (1 - rise) * 320)


def put_chef(layer, now, mood="smile", eye="dot", al=24, ar=24, dy=0.0, sx=1.0, sy=1.0, rot=0.0, hat=0.0, x=CHEF_X, sc=0.95):
    tile = chef_tile(mood, eye, al, ar, hat)
    bob = _m.sin(now * 3.1) * 3
    blit(layer, tile, x, CHEF_Y + dy + bob, 200, 630, sc * sx, sc * sy, rot)


def put_critic(layer, i, x, now, mood="smug", jaw=0.0, glass=0.0, leg=0.0, clip="", snap=0.0, sweat=0.0, brow=0.0,
               sx=1.0, sy=1.0, rot=0.0, dy=0.0, sc=0.85, flip=False):
    tile = critic_tile(i, mood, jaw, glass, int(round(leg * 4)) / 4.0, clip, snap, sweat, brow)
    if flip:
        tile = tile.transpose(Image.FLIP_LEFT_RIGHT)
    blit(layer, tile, x, CRIT_Y + dy, 170, 610, sc * sx, sc * sy, rot)


def draw_boxes(layer, n_done, extra=None, wob=0.0, x=STACK_X, sink=0.0):
    """n_done boxes resting; extra = list of (i, y_offset, squash)"""
    bt = box_tile()
    for i in range(n_done):
        ox = _m.sin(i * 1.9) * 6 + _m.sin(wob * 14 + i * 0.7) * 3.0 * min(1.0, i / 6)
        put(layer, bt, x - 105 + ox, CT - BOXH * (i + 1) - 2 + sink)
    for i, yo, sq in (extra or []):
        ox = _m.sin(i * 1.9) * 6
        blit(layer, bt, x + ox, CT - BOXH * i - 2 + yo + sink, 105, BOXH + 3, 1 + sq * 0.12, 1 - sq * 0.2, 0)


def draw_pizza(layer, cx, cy, r, rot, flat=1.0):
    tile = pizza_tile(260)
    # pre-rotated in blit; sy flatten for the countertop pose
    blit(layer, tile, cx, cy, tile.width / 2, tile.height / 2, r / 260.0, r / 260.0 * flat, rot)


def pz_arm_pose(t):
    return 0


def tri(x):
    x = x % 1.0
    return 1 - abs(2 * x - 1) * 2 if False else abs(2 * x - 1)


# ---------------------------------------------------------------- hook art (frame 1 and the loop end)
def hook_art(layer, t, tf, spin_t0=0.0, flying=None, pizza_pos=None, show_text=True, fade_out=0.0):
    """Sunburst, +14% slam, spinning pizza and the 'because of a pizza shop?' line."""
    # sunburst bg
    layer.paste(Image.new("RGBA", (W, H), CREAM + (255,)), (0, 0))
    rays(layer, 540, 940, 0, 2400, 22, t * 0.16, (255, 228, 168), None, 0.5)
    d = ImageDraw.Draw(layer)
    # pizza
    bob = _m.sin(t * 5.5) * 8
    r = 225 * (1 + 0.025 * _m.sin(t * 5.5))
    hop = 0.0
    if t >= tf:
        k = t - tf
        hop = -60 * _m.sin(clamp01(k / 0.35) * _m.pi) if k < 0.35 else 0
    cx, cy = 540, 950 + bob + hop
    return cx, cy, r


def draw_plus14(layer, cx, cy, t, tf, alpha=1.0, size=250):
    sc = 0.55 + 0.45 * pop(t / 0.3)
    rot = -3.0
    if t >= tf:
        k = t - tf
        sc = lerp(1.32, 1.0, spr(k, 14, 6)) if k < 0.9 else 1.0
        rot = -3.0 + _m.sin(k * 20) * 5 * _m.exp(-4 * k)
        if k < 0.6:
            e = ease(k / 0.3)
            burst(layer, cx, cy, 170 + 90 * e, 260 + 120 * e, 12, k * 0.6, (255, 214, 92, 255), 8, alpha=clamp01(1 - k / 0.6) * alpha)
    ptext(layer, (cx, cy), "+14%", size, GOLD, sw=18, rot=rot, sc=sc, alpha=alpha)


def up_arrows(img, k):
    d = ImageDraw.Draw(img)
    for i in range(11):
        sp = 300 + 40 * (i % 4)
        y = 1250 - ((k * sp + i * 131) % 980)
        x = 70 + i * 94 + _m.sin(k * 2 + i) * 14
        a = clamp01(k / 0.3) * clamp01((y - 380) / 150)
        if a <= 0.02:
            continue
        s_ = 26 + 8 * (i % 3)
        col = TEAL if i % 2 == 0 else GOLD
        pts = [(x, y - s_), (x + s_, y), (x + s_ * 0.45, y), (x + s_ * 0.45, y + s_), (x - s_ * 0.45, y + s_), (x - s_ * 0.45, y), (x - s_, y)]
        d.polygon(pts, fill=col + (255,), outline=BR + (255,))


def scene_pz_hook(img, v, t, spec, cues):
    tf = cues.at("fourteen", 1.0)
    tbf = cues.at("before", 2.2)
    tp = cues.at("pizza", 4.0)
    fly = 0.62
    tl = tp + fly
    hook_art(img, t, tf)
    if t >= tf and t < tp + 0.3:
        up_arrows(img, t - tf)
    now_cx, now_cy, r = 540, 950 + _m.sin(t * 5.5) * 8, 225 * (1 + 0.025 * _m.sin(t * 5.5))
    # --- shop reveal (iris) from the pizza as it flies
    if t >= tp:
        k = clamp01((t - tp) / 0.8)
        shop = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        shop_back(shop, t, awn=spr(t - tp - 0.1, 13, 6.5), sign_t=t - tl - 0.05)
        shop_counter(shop, rise=clamp01(spr(t - tp - 0.1, 12, 6.5)) if t - tp > 0.1 else 0.0)
        mask = Image.new("L", (W, H), 0)
        rr_ = int(1700 * ease(k))
        ImageDraw.Draw(mask).ellipse((660 - rr_, 1060 - rr_, 660 + rr_, 1060 + rr_), fill=255)
        img.paste(shop, (0, 0), mask)
        # ring outline of the iris
        if k < 1:
            ImageDraw.Draw(img).ellipse((660 - rr_, 1060 - rr_, 660 + rr_, 1060 + rr_), outline=BR + (255,), width=10)
    # --- pizza trajectory
    if t < tp:
        u = 0.0
        cx, cy, rad, flat = 540, now_cy + (-60 * _m.sin(clamp01((t - tf) / 0.35) * _m.pi) if t >= tf else 0), r, 1.0
        rot = t * 2.2
        if tp - t < 0.18:                                # anticipation: squash down
            a = (0.18 - (tp - t)) / 0.18
            flat = 1 - 0.14 * a
            cy += 18 * a
    else:
        u = clamp01((t - tp) / fly)
        e = ease(u)
        cx = lerp(540, 650, e)
        cy = lerp(950, CT - 20, e) - 330 * _m.sin(_m.pi * e)
        rad = lerp(225, 78, e)
        flat = lerp(1.0, 0.42, clamp01((u - 0.55) / 0.45))
        rot = t * 2.2 + u * 14
        if t > tl:
            k = t - tl
            flat = 0.42 * (1 - 0.18 * _m.exp(-9 * k) * _m.cos(18 * k))
            cx, cy, rad = 650, CT - 20 - 2, 78
            rot = t * 2.2 + 14 + k * 1.5
    draw_pizza(img, cx, cy, rad, rot, flat)
    # landing dust
    if t > tl:
        k = t - tl
        for j in range(6):
            a = j / 6 * 2 * _m.pi
            rr2 = 20 + 120 * ease(k / 0.5)
            if k < 0.5:
                dx_, dy_ = _m.cos(a) * rr2, _m.sin(a) * rr2 * 0.3
                s_ = int(18 * (1 - k / 0.5)) + 2
                ImageDraw.Draw(img).ellipse((650 + dx_ - s_, CT + 6 + dy_ - s_, 650 + dx_ + s_, CT + 6 + dy_ + s_), fill=(255, 255, 255, 255), outline=BR + (255,), width=3)
        confetti(img, k, 650, CT - 30, 22, 4, speed=520, life=1.5)
    # --- +14% (frame 1) and ribbon
    fade = 1.0
    ox_ = 0
    if t >= tp - 0.05:
        k = clamp01((t - tp + 0.05) / 0.3)
        fade = 1 - k
    if fade > 0.02:
        cy14 = 530 - (1 - fade) * 90
        draw_plus14(img, 540, cy14, t, tf, alpha=fade, size=240)
        if t >= tbf and fade > 0.5:
            p = pop((t - tbf) / 0.3)
            pill(img, 540, 676, "BEFORE THE OPEN", 46, TOM, sc=p, sw=0)
    # --- bottom line
    if t >= 0.2 and t < tp + 0.2:
        a = pop((t - 0.2) / 0.3)
        out = clamp01((t - tp) / 0.25)
        ptext(img, (540, 1205 - out * 160), "...BECAUSE OF A", 54, (255, 255, 255), sw=10, sc=a * (1 - out) + 0.01)
        ptext(img, (540, 1268 - out * 160), "PIZZA SHOP?", 92, TOM, sw=14, sc=a * (1 - out) + 0.01, rot=-2)
    # --- camera: slam shake at "fourteen"
    if t >= tf and t < tf + 0.35:
        sx_, sy_ = shake(14 * (1 - (t - tf) / 0.35), t)
        CAM["dx"], CAM["dy"] = sx_, sy_
        CAM["z"] = 1 + 0.05 * _m.sin(clamp01((t - tf) / 0.35) * _m.pi)
    if t >= tl and t < tl + 0.3:
        sx_, sy_ = shake(10 * (1 - (t - tl) / 0.3), t)
        CAM["dx"], CAM["dy"] = sx_, sy_


# ---------------------------------------------------------------- shared bits for the story beats
def crit_walk(i, t, tc):
    d0 = tc + 0.3 * i
    dur = 1.15
    u = clamp01((t - d0) / dur)
    x = lerp(-200, CRIT_X[i], ease(u))
    walking = 0 < u < 1
    ph = t * 15
    leg = _m.sin(ph) if walking else 0.0
    dy = -abs(_m.sin(ph)) * 11 if walking else 0.0
    rot = _m.sin(ph) * 3 if walking else 0.0
    sq = 0.0
    if u >= 1:
        k = t - (d0 + dur)
        sq = 0.09 * _m.exp(-8 * k) * _m.cos(18 * k)
    return x, leg, dy, rot + _m.sin(t * 2 + i) * 1.0, sq


def big_card_base():
    def fn(d, k):
        p = Pen(d, k)
        p.rr((6, 6, 594, 394), 30, (196, 146, 92), 10)
        p.rr((30, 40, 570, 376), 16, (255, 255, 255), 7)
        p.rr((220, 8, 380, 64), 16, (170, 176, 192), 8)
        p.el((282, 22, 318, 52), (120, 126, 140), 5)
    return _cached(("bigcard",), 600, 400, fn)


def big_card(layer, cx, cy, sc, rot, title, num, numcol, num_tile_mask=None, extra=None):
    base = big_card_base().copy()
    d = ImageDraw.Draw(base)
    d.text((300, 106), title, font=font("bold", 50), fill=(120, 120, 136, 255), anchor="mm")
    if num is not None:
        d.text((300, 252), num, font=font("bold", 150), fill=numcol + (255,), anchor="mm", stroke_width=0)
    if extra:
        extra(base)
    blit(layer, base, cx, cy, 300, 200, sc, sc, rot)
    return base


def pencil_half(kind):
    def fn(d, k):
        p = Pen(d, k)
        if kind == 0:
            p.poly([(6, 6), (22, 2), (30, 60), (12, 62)], (255, 214, 70), 5)
            p.poly([(6, 6), (22, 2), (24, -10), (8, -6)], PINK, 5)
        else:
            p.poly([(6, 2), (24, 0), (28, 40), (10, 44)], (255, 214, 70), 5)
            p.poly([(10, 44), (28, 40), (18, 66)], (240, 190, 130), 5)
    return _cached(("pen", kind), 44, 80, fn)


def eraser_tile():
    def fn(d, k):
        p = Pen(d, k)
        p.rr((6, 6, 214, 114), 22, PINK, 9)
        p.rr((92, 6, 214, 114), 22, (90, 140, 230), 9)
        p.rr((6, 6, 96, 114), 22, PINK, 0)
        p.ln([(94, 10), (94, 110)], 8)
    return _cached(("eraser",), 220, 120, fn)


def stack_state(t, tsold, span, n=14):
    landed, extra = 0, []
    for j in range(n):
        ti = tsold + 0.25 + j * span / n
        u = (t - ti) / 0.26
        if u < 0:
            continue
        if u < 1:
            extra.append((j, -560 * (1 - u) ** 2, 0.0))
        else:
            kk = t - ti - 0.26
            if kk < 0.3:
                extra.append((j, 0.0, _m.exp(-10 * kk) * _m.cos(24 * kk)))
            else:
                landed += 1
    return landed, extra


def dashed(img, x0, x1, y, col, prog, w=8, on=30, off=20):
    d = ImageDraw.Draw(img)
    xe = x0 + (x1 - x0) * prog
    x = x0
    while x < xe:
        d.rounded_rectangle((x, y - w // 2, min(x + on, xe), y + w // 2), radius=w // 2, fill=col + (255,))
        x += on + off


def pz_zoom(z, px, py):
    CAM["z"] = max(CAM["z"], z) if z > 1 else CAM["z"]
    CAM["px"], CAM["py"] = px, py


# ---------------------------------------------------------------- BEAT 2: critics vs the owner's sales
def scene_pz_sales(img, v, t, spec, cues):
    tc = cues.at("critics", 0.1)
    twall = cues.at("Wall", 1.3)
    t256 = cues.at("two hundred fifty-six", 3.2)
    tsold = cues.at("sold", 5.2)
    t91 = cues.at("ninety-one", 5.8)
    tend = t91 + 0.95
    span = max(0.9, tend - tsold - 0.25)
    shop_back(img, t, awn=1, sign_t=3 + t)
    landed, extra = stack_state(t, tsold, span)
    started = landed + len(extra)
    cheering = t >= tsold
    ca = 150 + _m.sin(t * 15) * 18 if cheering else 24
    put_chef(img, t, "grin" if cheering else "smile", "joy" if cheering else "dot", ca, ca,
             dy=-abs(_m.sin(t * 7)) * 10 if cheering and t < tend + 0.5 else 0, hat=_m.sin(t * 14) * 0.6 if cheering else 0)
    shop_counter(img)
    # pizza waits on the counter, then hops into the first box
    if t < tsold + 0.3:
        hopk = clamp01((t - tsold) / 0.3)
        draw_pizza(img, lerp(650, STACK_X, hopk), CT - 22 - 120 * _m.sin(_m.pi * hopk), lerp(78, 30, hopk), t * 1.5, 0.42 + 0.3 * hopk)
    draw_boxes(img, landed, extra, wob=t)
    # label on top of the stack
    if started > 0:
        top = CT - BOXH * landed - 62
        if extra:
            top = min(top, CT - BOXH * (landed + 1) - 62)
        val = int(291 * clamp01((t - tsold - 0.25) / span))
        lab = f"${val}M SOLD" if val < 291 else "$291M SOLD"
        pop_ = pop((t - tsold - 0.25) / 0.3)
        pill(img, STACK_X + 10, top, lab, 62, TEAL, sc=pop_, sw=0, w_min=420)
    # guess line
    yg = CT - BOXH * 14 * 256 / 291
    tl_ = t256 + 0.85
    if t >= tl_:
        pr = ease((t - tl_) / 0.5)
        dashed(img, 30, 880, yg, TOM, pr)
        pill(img, 120, yg - 36, "GUESS", 44, (255, 255, 255), tc=TOM, sc=pop((t - tl_) / 0.3), sw=0)
    # critics
    over = landed >= 12
    for i in (1, 0):
        x, leg, dy, rot, sq = crit_walk(i, t, tc)
        clip = "$256M" if t >= t256 + 0.3 else ""
        put_critic(img, i, x, t, "worry" if over else "smug", leg=leg, clip=clip, sx=1 + sq, sy=1 - sq, rot=rot, dy=dy,
                   sweat=(t - tend + 0.3) if over else 0.0)
    if t >= twall:
        p = pop((t - twall) / 0.3)
        pill(img, 290, 770, "WALL STREET ANALYSTS", 34, (255, 255, 255), tc=BR, sc=p, sw=0)
        ImageDraw.Draw(img).polygon([(200, 800), (260, 800), (214, 836)], fill=(255, 255, 255, 255), outline=BR + (255,))
    # the clipboard close-up for the guess
    if t >= t256 and t < tsold - 0.05:
        k = t - t256
        out = clamp01((t - (tsold - 0.45)) / 0.4)
        e = ease(out)
        u = spr(k, 13, 7)
        sc = lerp(0.3, 1.0, min(1.15, u)) * (1 - e) + 0.3 * e
        cx = lerp(165, 500, min(1.1, u)) * (1 - e) + 165 * e
        cy = lerp(1140, 720, min(1.1, u)) * (1 - e) + 1140 * e
        val = int(256 * ease(k / 0.7))
        big_card(img, cx, cy, sc, lerp(-14, -2, min(1, u)) * (1 - e), "ANALYSTS' GUESS", f"${val}M", TOM)
    if t >= tend:
        confetti(img, t - tend, STACK_X, CT - 480, 34, 2)
    # camera push
    CAM["z"] = 1 + 0.045 * ease(t / 7.0)
    CAM["px"], CAM["py"] = 520, 900
    if t >= tsold + 0.2 and t < tend + 0.4:
        CAM["dy"] = _m.sin(t * 33) * 2.5


# ---------------------------------------------------------------- BEAT 3: shock, BUT WAIT, the owner's plan
def scene_pz_shock(img, v, t, spec, cues):
    tsh = cues.at("Shocked", 0.05)
    tbut = cues.at("But", 1.5)
    tow = cues.at("owner", 3.0)
    tsh2 = cues.at("shares", tow + 0.5)
    tg = cues.at("guidance", 6.0)
    t335 = cues.at("three hundred", 7.6)
    s = t - tsh
    shop_back(img, t + 8, awn=1, sign_t=9 + t)
    boardk = t - tsh2
    chef_up = boardk >= 0
    put_chef(img, t, "grin" if chef_up else "smug", "joy" if chef_up else "lid",
             165 if chef_up else 24, (110 + _m.sin(t * 9) * 14) if chef_up else 24, hat=_m.sin(t * 10) * 0.5 if chef_up else 0)
    shop_counter(img)
    # stack sinks behind the counter when the owner talks
    sink = ease((t - (tow - 0.05)) / 0.45) if t > tow - 0.05 else 0.0
    if sink < 1:
        tmp = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        draw_boxes(tmp, 14, None, wob=0, sink=sink * 620)
        fade = 1 - sink
        yg = CT - BOXH * 14 * 256 / 291
        if sink < 0.4:
            dashed(tmp, 30, 880, yg, TOM, 1.0)
            pill(tmp, STACK_X + 10, CT - BOXH * 14 - 62 + sink * 620, "$291M SOLD", 62, TEAL, sw=0, w_min=420)
        img.alpha_composite(tmp.crop((0, 0, W, CT + 4)), (0, 0))
    # critics reaction
    shock = s >= 0
    for i in (0, 1):
        jaw = min(1.0, spr(s - 0.0 - 0.02 * i, 15, 9)) if shock else 0.0
        gl = clamp01(spr(s - 0.06 - 0.03 * i, 12, 8)) if shock else 0.0
        trem = _m.sin(t * 70 + i) * 1.3 if (shock and t < tbut + 0.4) else 0.0
        kick = 0.0
        if shock and s < 0.5:
            kick = 0.06 * _m.exp(-7 * s) * _m.cos(20 * s)
        put_critic(img, i, CRIT_X[i], t, "shock" if shock else "smug", jaw=jaw, glass=gl, clip="$256M", snap=1.0 if (i == 1 and s > 0.12) else 0.0,
                   brow=0.9 * ease(s / 0.2) if shock else 0.0, sx=1 - kick, sy=1 + kick, rot=trem, sweat=0)
        if shock and s > 0.14:
            pm = pop((s - 0.14 - 0.05 * i) / 0.25)
            ptext(img, (CRIT_X[i] + 40, 735 + 10 * (1 - pm)), "!", 120, TOM, sw=12, sc=pm + 0.01, rot=-8 + 16 * i)
    # snapped pencil halves fly
    if s > 0.12:
        k = s - 0.12
        for hi, (vx, vy, sp) in enumerate(((-250, -430, -8), (120, -520, 11))):
            if k < 1.3:
                px_ = 205 + vx * k
                py_ = 1140 + vy * k + 0.5 * 1700 * k * k
                blit(img, pencil_half(hi), px_, py_, 22, 40, 1.3, 1.3, k * sp * 60)
        if k < 0.25:
            d = ImageDraw.Draw(img)
            for a in range(7):
                ang = a / 7 * 6.28
                r0, r1 = 24 + k * 120, 54 + k * 220
                d.line([(205 + _m.cos(ang) * r0, 1140 + _m.sin(ang) * r0), (205 + _m.cos(ang) * r1, 1140 + _m.sin(ang) * r1)], fill=BR + (255,), width=7)
    # camera: punch in on the critics, hold, release at BUT WAIT
    if shock and t < tbut:
        zin = 1 + 0.17 * ease(s / 0.14)
        CAM["z"], CAM["px"], CAM["py"] = zin, 190, 930
        if s < 0.5:
            CAM["dx"], CAM["dy"] = shake(16 * (1 - s / 0.5), t)
    else:
        CAM["z"] = 1 + 0.17 * (1 - ease((t - tbut) / 0.3)) if t < tbut + 0.3 and t >= tbut else 1.0 + 0.04 * ease((t - tow) / 4.0)
        CAM["px"], CAM["py"] = (190, 930) if t < tbut + 0.3 else (440, 700)
    # whiteboard
    if boardk >= 0:
        rise = spr(boardk, 11, 6.5)
        by = lerp(1250, 590, min(1.12, rise))
        brot = lerp(-8, -2.5, min(1, rise))
        board_draw(img, 420, by, brot, t, tg, t335)
    # BUT WAIT overlay
    if t >= tbut and t < tow + 0.1:
        k = t - tbut
        out = clamp01((t - (tow - 0.12)) / 0.2)
        dim(img, 0.5 * (1 - out))
        rays(img, 540, 650, 120, 1800, 30, k * 0.25, (255, 214, 92), (255, 246, 214), 0.4)
        sc = (lerp(2.6, 1.0, min(1.1, spr(k, 16, 9)))) * (1 - out) + 0.001
        ptext(img, (540, 560), "BUT", 210, TOM, sw=18, sc=sc, rot=-7)
        ptext(img, (540, 760), "WAIT!", 250, TOM, sw=20, sc=sc, rot=-7)
        flash(img, 0.85 * (1 - k / 0.16))
        if k < 0.4:
            CAM["dx"], CAM["dy"] = shake(12 * (1 - k / 0.4), t)
    if t >= t335 + 0.8:
        confetti(img, t - t335 - 0.8, 150, 470, 16, 3, speed=500)
        confetti(img, t - t335 - 0.8, 700, 470, 16, 5, speed=500)


def board_draw(img, cx, cy, rot, t, tg, t335):
    def fn(d, k):
        p = Pen(d, k)
        p.rr((8, 8, 572, 352), 22, (255, 255, 255), 11)
        p.rr((0, 340, 580, 380), 12, (170, 176, 192), 9)
        p.rr((60, 330, 160, 346), 6, TOM, 0)
    base = _cached(("board",), 580, 384, fn).copy()
    d = ImageDraw.Draw(base)
    d.text((290, 60), "NEXT QUARTER", font=font("bold", 60), fill=BR + (255,), anchor="mm")
    d.text((290, 118), "PLAN:", font=font("bold", 60), fill=BR + (255,), anchor="mm")
    val = int(335 * ease((t - t335) / 0.8)) if t >= t335 else None
    if val is not None:
        sc_ = 1.0
        d.text((290, 244), f"${val}M", font=font("bold", 148), fill=TEAL + (255,), anchor="mm", stroke_width=6, stroke_fill=BR + (255,))
    else:
        d.text((290, 244), "$ ? M", font=font("bold", 120), fill=(200, 196, 190, 255), anchor="mm")
    blit(img, base, cx, cy, 290, 192, 1, 1, rot)
    if t >= tg:
        p = pop((t - tg) / 0.3)
        pill(img, cx + 190, cy + 238, "= GUIDANCE", 54, TOM, sc=p, rot=3, sw=0)
        pill(img, cx + 190, cy + 308, "THE OWNER'S OWN FORECAST", 32, GOLD, tc=BR, sc=p, rot=3, sw=0)


# ---------------------------------------------------------------- BEAT 4: consensus vs guidance cards
def card_tile(w, h, fill, desk=640):
    def fn(d, k):
        p = Pen(d, k)
        p.rr((6, 6, w - 6, h - 6), 40, fill, 10)
    return _cached(("card", w, h, fill), w, h, fn)


def desk_tile(w, h):
    def fn(d, k):
        p = Pen(d, k)
        p.rr((6, 0, w - 6, h - 6), 36, WOODF, 10)
        p.rr((6, 0, w - 6, 30), 20, WOODT, 8)
    return _cached(("desk", w, h), w, h, fn)


def scene_pz_contrast(img, v, t, spec, cues):
    tavg = cues.at("average", 0.5)
    tcons = cues.at("consensus", 1.6)
    tonly = cues.at("only", 2.6)
    t293 = cues.at("two hundred ninety-three", 3.1)
    shop_back(img, t + 20, awn=1, sign_t=9 + t)
    put_chef(img, t, "grin", "joy", 24, 24)
    shop_counter(img)
    dim(img, 0.72)
    # LEFT: critics' average (grey)
    u = spr(t - tavg, 12, 7)
    shr = ease((t - tonly) / 0.4)
    lw, lh = 380, 700
    L = Image.new("RGBA", (lw, lh), (0, 0, 0, 0))
    L.alpha_composite(card_tile(lw, lh, (214, 216, 228)))
    cr = critic_tile(0, "worry" if t > tonly else "smug", clip="", sweat=(t - tonly) if t > tonly else 0.0)
    blit(L, cr, 190, 684, 170, 610, 0.78, 0.78, 0)
    L.alpha_composite(desk_tile(lw, 130), (0, lh - 130))
    ld = ImageDraw.Draw(L)
    ld.text((190, 56), "CRITICS'", font=font("bold", 46), fill=BR + (255,), anchor="mm")
    ld.text((190, 104), "AVERAGE", font=font("bold", 46), fill=BR + (255,), anchor="mm")
    if t >= t293:
        val = int(293 * ease((t - t293) / 0.6))
        ptext(L, (190, 244), f"${val}M", 94, (255, 255, 255), sw=9)
    else:
        ptext(L, (190, 244), "$ ? M", 94, (255, 255, 255), sw=9)
    if t >= tcons:
        pill(L, 190, 172, "= CONSENSUS", 34, (255, 255, 255), tc=BR, sc=pop((t - tcons) / 0.3), sw=0, padx=22)
    lsc = (1.0 - 0.2 * shr)
    lrot = -4 * shr
    lx = lerp(-300, 40 + lw / 2, min(1.1, u))
    if t >= tavg - 0.05:
        blit(img, L, lx, 1200, lw / 2, lh, lsc, lsc, lrot)
    # RIGHT: owner's plan (teal), arrives first from the right
    ur = spr(t + 0.05, 12, 7)
    gro = 1 + 0.09 * spr(t - tonly, 11, 5.5)
    rw, rh = 440, 700
    R = Image.new("RGBA", (rw, rh), (0, 0, 0, 0))
    R.alpha_composite(card_tile(rw, rh, TEAL))
    blit(R, chef_tile("grin", "joy", 150 + _m.sin(t * 12) * 14, 150 + _m.sin(t * 12 + 1) * 14, _m.sin(t * 10) * 0.5), 220, 684, 200, 630, 0.62, 0.62, 0)
    R.alpha_composite(desk_tile(rw, 130), (0, rh - 130))
    ptext(R, (220, 56), "OWNER'S PLAN", 41, (255, 255, 255), sw=7)
    pill(R, 220, 118, "= GUIDANCE", 34, GOLD, tc=BR, sw=0, padx=22)
    ptext(R, (220, 236), "$335M", 104, GOLD, sw=10)
    rx = lerp(1300, 480 + rw / 2, min(1.1, ur))
    blit(img, R, rx, 1200, rw / 2, rh, gro, gro, 2 * (1 - min(1, ur)))
    if t >= tavg + 0.2:
        pill(img, 462, 520, "VS", 52, GOLD, tc=BR, sc=pop((t - tavg - 0.2) / 0.3), sw=0, padx=24, h=90)
    if t >= tonly:
        confetti(img, t - tonly, 700, 560, 18, 9, speed=420, life=1.4, cols=[GOLD, (255, 255, 255)])
    CAM["z"] = 1 + 0.03 * ease(t / 4.0)
    CAM["px"], CAM["py"] = 470, 800
    if t >= tonly and t < tonly + 0.3:
        CAM["dx"], CAM["dy"] = shake(7 * (1 - (t - tonly) / 0.3), t)


# ---------------------------------------------------------------- BEAT 5: erase, queue, jump
def scene_pz_erase(img, v, t, spec, cues):
    te = cues.at("erase", 0.5)
    tcu = cues.at("Customers", 2.4)
    tline = cues.at("line", 3.1)
    tblock = cues.at("block", 4.0)
    tj = cues.at("jumps", 4.6)
    queue = []
    n = 8
    for i in range(n):
        if i < 3:
            ta = tcu + 0.05 + i * 0.16
        else:
            ta = tline + (i - 3) * max(0.12, (tblock + 0.5 - tline) / 5)
        queue.append((i, t - ta))
    shop_back(img, t + 30, queue=queue, awn=1, sign_t=9 + t)
    jumping = t >= tj
    jk = t - tj
    put_chef(img, t, "grin", "joy", 160 + _m.sin(t * 14) * 14 if (jumping or t > tcu) else 40, 160 + _m.sin(t * 14 + 1) * 14 if (jumping or t > tcu) else 40,
             dy=-abs(_m.sin(jk * 6)) * 90 * _m.exp(-0.5 * jk) if jumping else 0, hat=_m.sin(t * 12) * 0.7)
    shop_counter(img)
    for i in (0, 1):
        put_critic(img, i, CRIT_X[i], t, "worry", clip="$293M" if t < te + 0.8 else "HIGHER", sweat=t * 0.9 % 1.4,
                   rot=_m.sin(t * 40 + i) * 1.5 if jumping and jk < 0.6 else 0, brow=0.3)
    # clipboard close-up with the eraser
    if t < tcu - 0.05:
        pk = pop(t / 0.25)
        out = ease((t - (tcu - 0.5)) / 0.4)
        dim(img, 0.5 * (1 - out))
        sc = pk * (1 - out) + 0.25 * out
        cx = lerp(500, 165, out)
        cy = lerp(700, 1140, out)
        edge = ease((t - te) / 0.7) * 560 if t >= te else 0.0

        def extra(base, t=t, te=te, edge=edge):
            dd = ImageDraw.Draw(base)
            if t < te + 0.75:
                num = Image.new("RGBA", (600, 400), (0, 0, 0, 0))
                ImageDraw.Draw(num).text((300, 252), "$293M", font=font("bold", 150), fill=TOM + (255,), anchor="mm")
                ex = int(20 + edge)
                if ex < 600:
                    base.alpha_composite(num.crop((ex, 0, 600, 400)), (ex, 0))
                # smudge where the eraser has been
                if t >= te and edge > 4:
                    dd.rectangle((24, 190, 24 + int(edge), 316), fill=(255, 244, 240, 255))
            if t >= te + 0.75:
                k = t - te - 0.75
                pp = pop(k / 0.3)
                ptext(base, (300, 262), "HIGHER", int(104), TEAL, sw=8, sc=pp + 0.01, rot=-3)
                arr = [(520, 330), (556, 290), (534, 290), (534, 236), (506, 236), (506, 290), (484, 290)]
                sa = min(1.0, pp)
                ax, ay = 520, 285
                dd.polygon([(ax + (x - ax) * sa, ay + (y - ay) * sa) for x, y in arr], fill=(80, 200, 120, 255), outline=BR + (255,))
            if te <= t < te + 0.75:
                ex2 = 20 + edge + _m.sin((t - te) * 36) * 46
                blit(base, eraser_tile(), ex2, 262 + _m.sin((t - te) * 18) * 8, 110, 60, 0.8, 0.8, -14 + _m.sin((t - te) * 36) * 5)
        big_card(img, cx, cy, sc, lerp(-2, -14, out), "ANALYSTS' NUMBER", None, TOM, extra=extra)
        if te <= t < te + 1.1:
            # flying eraser crumbs
            k = t - te
            rnd = _rnd.Random(8)
            d = ImageDraw.Draw(img)
            for q in range(26):
                a = rnd.uniform(-2.9, -0.2)
                spd = rnd.uniform(160, 420)
                st = rnd.uniform(0, 0.9)
                kk = k - st
                if 0 < kk < 0.6:
                    px_ = 230 + rnd.uniform(0, 540) * clamp01(st / 0.9) + _m.cos(a) * spd * kk
                    py_ = 700 + _m.sin(a) * spd * kk + 900 * kk * kk
                    r_ = rnd.randint(5, 10)
                    d.ellipse((px_ - r_, py_ - r_, px_ + r_, py_ + r_), fill=rnd.choice([PINK, (255, 210, 210), (230, 230, 240)]) + (255,), outline=BR + (255,), width=2)
    # +14% rises on "jumps"
    if jumping:
        e = min(1.1, spr(jk, 11, 6))
        cy = lerp(1000, 690, e)
        sc = 0.5 + 0.5 * min(1.1, e)
        burst(img, 540, cy, 120 * min(1.0, sc) + 40, 210 * min(1.0, sc) + 50, 12, jk * 1.2, (255, 220, 100, 255), 8)
        ptext(img, (540, cy), "+14%", 200, GOLD, sw=15, sc=min(1.0, sc), rot=-3 + _m.sin(jk * 7) * 2)
        confetti(img, jk, 540, 700, 40, 6, speed=700)
    # camera: slow push into the window as the queue grows, small bounce on jump
    if t >= tcu - 0.3:
        z = 1 + 0.2 * ease((t - tcu + 0.3) / 1.0)
        CAM["z"], CAM["px"], CAM["py"] = z, 540, 840
    if jumping and jk < 0.3:
        CAM["dx"], CAM["dy"] = shake(9 * (1 - jk / 0.3), t)


# ---------------------------------------------------------------- BEAT 6: the lesson, then back to the pizza (loop)
def scene_pz_close(img, v, t, spec, cues):
    tfc = cues.at("forecast", 0.2)
    tq = cues.at("quarter", 3.3)
    tcta = cues.at("expectations", 1.0)
    tth = cues.at("that's", 4.9)
    img.paste(Image.new("RGBA", (W, H), CREAM + (255,)), (0, 0))
    rays(img, 540, 960, 0, 2400, 18, t * 0.1, (255, 233, 186), None, 0.5)
    d = ImageDraw.Draw(img)
    # floating mini pizzas (parallax)
    for j in range(5):
        px_ = (j * 230 + 80 + t * (20 + 8 * j)) % 1300 - 110
        py_ = (430 + (j % 2) * 70 if j < 3 else 1060 + (j % 2) * 110) + _m.sin(t * 1.6 + j) * 18
        draw_pizza(img, px_, py_, 38 + 8 * (j % 3), t * 0.8 + j, 1.0)
    LINES = [["THE", "PLAN", "CAN"], ["MATTER", "MORE"], ["THAN", "TODAY'S"], ["SALES"]]
    HL = {0: (0, 1, TEAL, tfc), 2: (1, 1, (196, 198, 210), tq), 3: (0, 0, (196, 198, 210), tq)}
    size = 92
    f = font("bold", size)
    gap = 28
    outk = clamp01((t - (tth - 0.1)) / 0.25)
    for li, words in enumerate(LINES):
        tl_ = 0.35 + 0.12 * li
        if t < tl_:
            continue
        widths = [int(d.textlength(w_, font=f)) for w_ in words]
        total = sum(widths) + gap * (len(words) - 1)
        pk = max(0.01, pop((t - tl_) / 0.3) * (1 - ease(outk)))
        y = 600 + li * 126
        xs = []
        x = 500 - total / 2
        for wi in range(len(words)):
            xs.append(x)
            x += widths[wi] + gap
        if li in HL and t >= HL[li][3]:
            a_, b_, col, tcue = HL[li]
            pr = ease((t - tcue) / 0.28)
            x0m, x1m = xs[a_] - 16, xs[b_] + widths[b_] + 16
            ph = 114 * pk
            ImageDraw.Draw(img).rounded_rectangle((x0m, y - ph / 2, x0m + (x1m - x0m) * pr, y + ph / 2), radius=28, fill=col + (255,), outline=BR + (255,), width=6)
        for wi, w_ in enumerate(words):
            ptext(img, (xs[wi] + widths[wi] / 2, y), w_, size, BR, sw=0, sc=pk)
    # follow pill
    if t >= tcta and t < tth + 0.1:
        pk = pop((t - tcta) / 0.3) * (1 - outk)
        pill(img, 470, 1190, "FOLLOW @whyitmoved", 46, GOLD, tc=BR, sc=max(0.01, pk), sw=0)
    # wipe in from the previous scene (tomato disc closing)
    if t < 0.5:
        rr_ = int(1800 * (1 - ease(t / 0.5)))
        dd = ImageDraw.Draw(img)
        dd.ellipse((540 - rr_, 960 - rr_, 540 + rr_, 960 + rr_), fill=TOM + (255,), outline=BR + (255,), width=12)
    # loop: back to frame one
    if t >= tth:
        k = t - tth
        hk = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        tt_ = k + 0.05
        cx, cy, r = hook_art(hk, tt_, 99)
        pk = pop(k / 0.35)
        draw_pizza(hk, 540, 950, 225 * pk, k * 3.0 + 1.0, 1.0)
        draw_plus14(hk, 540, 540, tt_, 0.12)
        a = pop((k - 0.1) / 0.3)
        ptext(hk, (540, 1205), "...BECAUSE OF A", 54, (255, 255, 255), sw=10, sc=a + 0.01)
        ptext(hk, (540, 1268), "PIZZA SHOP?", 92, TOM, sw=14, sc=a + 0.01, rot=-2)
        mask = Image.new("L", (W, H), 0)
        rr2 = int(1700 * ease(k / 0.35))
        ImageDraw.Draw(mask).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), fill=255)
        img.paste(hk, (0, 0), mask)
        if k < 0.35:
            ImageDraw.Draw(img).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), outline=BR + (255,), width=10)
        if k < 0.3:
            CAM["dx"], CAM["dy"] = shake(10 * (1 - k / 0.3), t)


# ---------------------------------------------------------------- frame furniture, camera, sfx cues, music
def cam_apply(layer):
    z, px, py, dx, dy, rot = CAM["z"], CAM["px"], CAM["py"], CAM["dx"], CAM["dy"], CAM["rot"]
    if abs(z - 1) < 1e-4 and abs(dx) < 0.05 and abs(dy) < 0.05 and abs(rot) < 1e-4:
        return layer
    c, s = _m.cos(_m.radians(rot)), _m.sin(_m.radians(rot))
    qx, qy = px + dx, py + dy
    a, b = c / z, s / z
    cc = px + (c * (-qx) + s * (-qy)) / z
    d_, e = -s / z, c / z
    f = py + (-s * (-qx) + c * (-qy)) / z
    return layer.transform((W, H), Image.AFFINE, (a, b, cc, d_, e, f), resample=Image.BILINEAR)


def pz_header(img, spec, now, total):
    d = ImageDraw.Draw(img)
    d.rectangle((0, 0, W, 366), fill=CREAM + (255,))
    d.rectangle((0, 366, W, 374), fill=BR + (255,))
    d.rectangle((0, 214, W, 222), fill=CREAM2 + (255,))
    d.rectangle((0, 214, int(W * now / total), 222), fill=TOM + (255,))
    mv = float(spec["move_pct"])
    chip = f"{spec.get('ticker', '')} {'+' if mv >= 0 else '-'}{abs(mv):g}%"
    f = font("bold", 50)
    tw = int(d.textlength(chip, font=f))
    cw = tw + 56
    pill(img, 60 + cw / 2 - 12, 272, chip, 50, TEAL, tc=(255, 255, 255), padx=28, h=70, sw=3)
    d = ImageDraw.Draw(img)
    d.text((60 + cw + 22, 272), spec.get("company", ""), font=font("bold", 32), fill=BR + (255,), anchor="lm")
    d.text((W - 60, 254), "WHY IT", font=font("bold", 30), fill=TOM + (255,), anchor="rm")
    d.text((W - 60, 288), "MOVED?", font=font("bold", 30), fill=BR + (255,), anchor="rm")
    d.text((60, 326), "ANALOGY - NOT REAL QUOTES", font=font("bold", 30), fill=(122, 100, 88, 255), anchor="lm")
    d.text((60, 354), "Educational only - not financial advice", font=font("medium", 24), fill=(140, 118, 104, 255), anchor="lm")


def pz_frame(spec, b, tb, now, total, kw_times):
    CAM.update(z=1.0, px=540.0, py=960.0, dx=0.0, dy=0.0, rot=0.0)
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    SCENES[b["visual"]["type"]](layer, b["visual"], tb, spec, b["cues"])
    punch = max([0.0] + [max(0.0, 1 - abs(now - kt - 0.08) / 0.14) for kt in kw_times if -0.1 < now - kt < 0.3])
    CAM["z"] *= 1 + 0.016 * punch
    layer = cam_apply(layer)
    base = Image.new("RGBA", (W, H), CREAM + (255,))
    base.alpha_composite(layer)
    pz_header(base, spec, now, total)
    return base


def _sfx_pz(kind, sr, rng):
    import numpy as np
    def env(n, k):
        return np.exp(-np.arange(n) / sr * k)
    if kind == "bell":
        n = int(1.0 * sr); tt = np.arange(n) / sr
        return (np.sin(2 * np.pi * 2093 * tt) * np.exp(-5 * tt) + 0.6 * np.sin(2 * np.pi * 3136 * tt) * np.exp(-7 * tt) + 0.3 * np.sin(2 * np.pi * 1568 * tt) * np.exp(-4 * tt))
    if kind == "ding":
        n = int(0.9 * sr); tt = np.arange(n) / sr
        return (np.sin(2 * np.pi * 2637 * tt) * np.exp(-6 * tt) + 0.5 * np.sin(2 * np.pi * 3951 * tt) * np.exp(-9 * tt)
                + np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 200) * 0.2)
    if kind == "scratch":
        n = int(0.5 * sr); tt = np.arange(n) / sr
        f = 1500 * np.exp(-3.2 * tt) + 120
        saw = 2 * ((np.cumsum(f) / sr) % 1.0) - 1
        noise = _onepole(rng.standard_normal(n), 2500, sr) * 0.6
        e = np.minimum(1, tt / 0.01) * np.exp(-tt * 3.0)
        return (saw * 0.7 + noise) * e
    if kind == "snap":
        n = int(0.22 * sr); tt = np.arange(n) / sr
        crack = np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 90)
        thump = np.sin(2 * np.pi * 180 * tt) * np.exp(-tt * 40) * 0.6
        tick = np.zeros(n); i2 = int(0.07 * sr)
        tick[i2:i2 + 400] = np.diff(rng.standard_normal(401)) * np.exp(-np.arange(400) / 60.0)
        return crack * 0.9 + thump + tick * 0.5
    if kind == "scrub":
        n = int(1.0 * sr); tt = np.arange(n) / sr
        x = np.diff(rng.standard_normal(n + 1))
        x = _onepole(x, 3500, sr)
        am = 0.35 + 0.65 * np.abs(np.sin(2 * np.pi * 5.5 * tt))
        return x / (np.abs(x).max() + 1e-9) * am * np.minimum(1, tt / 0.04) * np.minimum(1, (1 - tt) / 0.1)
    if kind == "boing":
        n = int(0.55 * sr); tt = np.arange(n) / sr
        f = 1300 * np.exp(-3.4 * tt) + 160 + 25 * np.sin(2 * np.pi * 14 * tt)
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.minimum(1, tt / 0.01) * np.exp(-tt * 3.2)
    if kind == "wah":
        n = int(0.8 * sr); tt = np.arange(n) / sr
        f = np.where(tt < 0.4, 262 - 40 * tt, 220 - 110 * (tt - 0.4)) * (1 + 0.012 * np.sin(2 * np.pi * 7 * tt))
        saw = 2 * ((np.cumsum(f) / sr) % 1.0) - 1
        x = _onepole(saw, 700, sr)
        return x / (np.abs(x).max() + 1e-9) * np.minimum(1, tt / 0.02) * np.minimum(1, (0.8 - tt) / 0.15)
    if kind == "sparkle":
        n = int(0.7 * sr); out = np.zeros(n)
        for j, fq in enumerate((1568, 2093, 2637, 3136, 3951)):
            s0 = int(j * 0.055 * sr); m = n - s0
            tt = np.arange(m) / sr
            out[s0:] += np.sin(2 * np.pi * fq * tt) * np.exp(-9 * tt) * 0.6
        return out
    if kind == "thud":
        n = int(0.16 * sr); tt = np.arange(n) / sr
        return np.sin(2 * np.pi * np.cumsum(150 - 400 * tt) / sr) * np.exp(-tt * 30) + np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 200) * 0.15
    return _sfx_sv(kind, sr, rng)


def music_bed_pz(total, sr, rng):
    """Bouncy pizzeria-ish bed: pluck bass + plinky arpeggio + soft shaker, 120 bpm, C Am F G."""
    import numpy as np
    n = int(total * sr)
    out = np.zeros(n)
    hz = lambda m: 440 * 2 ** ((m - 69) / 12)
    chords = [(48, [60, 64, 67, 72]), (45, [57, 60, 64, 69]), (41, [57, 60, 65, 69]), (43, [59, 62, 67, 71])]
    beat = 0.5
    def note(t0, fq, dur, amp, kind):
        s0 = int(t0 * sr)
        if s0 >= n:
            return
        m = min(n - s0, int(dur * sr))
        tt = np.arange(m) / sr
        if kind == "bass":
            w = np.sin(2 * np.pi * fq * tt) + 0.3 * np.sin(2 * np.pi * 2 * fq * tt)
            e = np.exp(-tt * 7) * np.minimum(1, tt / 0.004)
        else:
            w = np.sin(2 * np.pi * fq * tt) + 0.4 * np.sin(2 * np.pi * 2 * fq * tt) + 0.15 * np.sin(2 * np.pi * 3 * fq * tt)
            e = np.exp(-tt * 12) * np.minimum(1, tt / 0.003)
        out[s0:s0 + m] += w * e * amp
    nb = int(total / beat) + 2
    for b in range(nb):
        bar, bt = divmod(b, 4)
        root, tones = chords[bar % 4]
        t0 = b * beat
        if bt in (0, 2):
            note(t0, hz(root - 12), 0.4, 0.9, "bass")
        elif bt == 3:
            note(t0 + beat * 0.5, hz(root - 5 - 12 + 7), 0.3, 0.5, "bass")
        for h in range(2):
            idx = (b * 2 + h) % 4
            note(t0 + h * beat / 2, hz(tones[idx]), 0.25, 0.32, "pluck")
        # shaker on offbeats
        s0 = int((t0 + beat / 2) * sr)
        m = min(n - s0, int(0.05 * sr))
        if m > 0:
            out[s0:s0 + m] += np.diff(rng.standard_normal(m + 1)) * np.exp(-np.arange(m) / (0.012 * sr)) * 0.12
    return out / (np.abs(out).max() + 1e-9)


def _ev_hook(v, c, st):
    tf, tp = c.at("fourteen", 1.0), c.at("pizza", 4.0)
    return [(st + 0.0, "impact"), (st + tf, "stamp"), (st + c.at("before", 2.2), "pop"), (st + tp, "whoosh1"),
            (st + tp + 0.62, "thud"), (st + tp + 0.65, "sparkle"), (st + 0.25, "pop")]


def _ev_sales(v, c, st):
    tc, t256, tsold, t91 = c.at("critics", 0.1), c.at("two hundred fifty-six", 3.2), c.at("sold", 5.2), c.at("ninety-one", 5.8)
    tend = t91 + 0.95
    span = max(0.9, tend - tsold - 0.25)
    ev = [(st + tc, "bell"), (st + c.at("Wall", 1.3), "pop"), (st + t256, "whoosh1"), (st + t256 + 0.85, "pop"),
          (st + tsold, "boing")]
    for j in range(14):
        ev.append((st + tsold + 0.25 + j * span / 14 + 0.26, "thud"))
    ev += [(st + tend, "sparkle"), (st + tend, "ding")]
    return ev


def _ev_shock(v, c, st):
    tsh, tbut, tow = c.at("Shocked", 0.05), c.at("But", 1.5), c.at("owner", 3.0)
    tsh2 = c.at("shares", tow + 0.5)
    return [(st + tsh, "boing"), (st + tsh + 0.12, "snap"), (st + tsh + 0.2, "stamp"), (st + tbut, "scratch"),
            (st + tow - 0.1, "whoosh1"), (st + tsh2, "whoosh2"), (st + c.at("guidance", 6.0), "pop"),
            (st + c.at("three hundred", 7.6), "pop"), (st + c.at("three hundred", 7.6) + 0.8, "sparkle")]


def _ev_contrast(v, c, st):
    tavg, tcons, tonly = c.at("average", 0.5), c.at("consensus", 1.6), c.at("only", 2.6)
    return [(st + 0.05, "stamp"), (st + tavg, "whoosh1"), (st + tavg + 0.2, "pop"), (st + tcons, "pop"), (st + tonly, "wah"),
            (st + tonly + 0.05, "sparkle"), (st + c.at("two hundred ninety-three", 3.1), "pop")]


def _ev_erase(v, c, st):
    te, tcu, tl, tb, tj = c.at("erase", 0.5), c.at("Customers", 2.4), c.at("line", 3.1), c.at("block", 4.0), c.at("jumps", 4.6)
    ev = [(st + 0.02, "pop"), (st + te, "scrub"), (st + te + 0.75, "pop"), (st + tcu - 0.4, "whoosh2")]
    for i in range(8):
        ta = tcu + 0.05 + i * 0.16 if i < 3 else tl + (i - 3) * max(0.12, (tb + 0.5 - tl) / 5)
        ev.append((st + ta, "pop"))
    ev += [(st + tj, "ding"), (st + tj, "stamp"), (st + tj + 0.1, "sparkle")]
    return ev


def _ev_close(v, c, st):
    return [(st + 0.05, "whoosh2"), (st + c.at("forecast", 0.2), "pop"), (st + c.at("expectations", 1.0), "pop"),
            (st + c.at("quarter", 3.3), "pop"), (st + c.at("that's", 4.9), "stamp"), (st + c.at("that's", 4.9) + 0.05, "sparkle")]


PZ_EVENTS = {"pz_hook": _ev_hook, "pz_sales": _ev_sales, "pz_shock": _ev_shock, "pz_contrast": _ev_contrast,
             "pz_erase": _ev_erase, "pz_close": _ev_close}
SCENES_PZ = {"pz_hook": scene_pz_hook, "pz_sales": scene_pz_sales, "pz_shock": scene_pz_shock,
             "pz_contrast": scene_pz_contrast, "pz_erase": scene_pz_erase, "pz_close": scene_pz_close}
SCENES.update(SCENES_PZ)


def toon_background():
    img = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    d = ImageDraw.Draw(img)
    for y in range(H):
        d.line([(0, y), (W, y)], fill=mix((92, 190, 255), (200, 236, 255), (y / 1400.0) ** 0.9 if y < 1400 else 1) + (255,))
    # sun
    d.ellipse((780, 330, 960, 510), fill=(255, 226, 90), outline=INK, width=7)
    # hills
    d.ellipse((-300, 1180, 700, 1700), fill=(110, 210, 120), outline=INK, width=8)
    d.ellipse((380, 1230, 1500, 1800), fill=(86, 190, 110), outline=INK, width=8)
    d.rectangle((0, 1440, W, H), fill=(86, 190, 110))
    return img


def cloud_strip(width, height):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    import random
    rnd = random.Random(7)
    x = 60
    while x < width - 200:
        cy = rnd.randint(30, 200)
        s = rnd.uniform(0.8, 1.5)
        tile = _ss(int(360 * s), int(180 * s), lambda dd, k, s=s: [
            dd.ellipse((int(a * s * k), int(b * s * k), int((a + c) * s * k), int((b + c * 0.8) * s * k)), fill=(255, 255, 255), outline=INK, width=int(6 * k))
            for a, b, c in ((20, 70, 120), (110, 20, 150), (210, 60, 120), (80, 70, 190))] and [
            dd.ellipse((int(a * s * k), int(b * s * k), int((a + c) * s * k), int((b + c * 0.8) * s * k)), fill=(255, 255, 255))
            for a, b, c in ((30, 80, 100), (120, 30, 130), (220, 70, 100), (90, 80, 170))])
        img.alpha_composite(tile, (x, cy))
        x += int(rnd.uniform(520, 820))
    return img


# ================================================================== frame furniture
def candle_strip(seed: str, width: int, height: int):
    """Faint scrolling candlestick chart behind the content."""
    import random
    rnd = random.Random(seed)
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    price, xs = 100.0, 0
    vals = []
    while xs < width:
        o = price
        c = o + rnd.gauss(0, 2.2)
        hi, lo = max(o, c) + abs(rnd.gauss(0, 1.2)), min(o, c) - abs(rnd.gauss(0, 1.2))
        vals.append((xs, o, c, hi, lo))
        price = c
        xs += 40
    allp = [v for _, o, c, hi, lo in vals for v in (hi, lo)]
    pmin, pmax = min(allp), max(allp)
    sy = lambda p: int(height - 20 - (p - pmin) / (pmax - pmin + 1e-6) * (height - 40))
    for x, o, c, hi, lo in vals:
        col = C["up"] if c >= o else C["down"]
        d.line([(x + 13, sy(hi)), (x + 13, sy(lo))], fill=col + (60,), width=4)
        d.rectangle((x, sy(max(o, c)), x + 26, max(sy(min(o, c)), sy(max(o, c)) + 4)), fill=col + (60,))
    return img


def tape_strip(items: list[str]):
    """Scrolling ticker tape; each item measured and placed on its own, dot separators drawn."""
    f = font("medium", 34)
    probe = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    gap = 90
    widths = [text_w(probe, it, f) for it in items]
    uw = sum(widths) + gap * len(items)
    reps = max(2, (W * 2) // max(1, uw) + 2)
    img = Image.new("RGBA", (uw * reps, 60), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    x = 0
    for _ in range(reps):
        for it, w in zip(items, widths):
            d.text((x, 30), it, font=f, fill=tuple(THEME.get("tape_fg") or C["muted"]) + (255,), anchor="lm")
            x += w + gap
            d.ellipse((x - gap // 2 - 5, 25, x - gap // 2 + 5, 35), fill=C["accent"] + (255,))
    return img, uw


def header(img, spec, now, total):
    d = ImageDraw.Draw(img)
    has_move = spec.get("ticker") and spec.get("move_pct") is not None
    pct = float(spec["move_pct"]) if has_move else 0.0
    col = move_color(pct) if has_move else C["accent"]
    chip = spec["ticker"] if has_move else spec.get("chip", "EXPLAINED")
    f = font("bold", 60 if has_move else 44)
    chip_w = text_w(d, chip, f) + 64
    y0 = 236
    card(img, (60, y0, 60 + chip_w, y0 + 90), radius=22, fill=col + (70 if has_move else 255,))
    d = ImageDraw.Draw(img)
    d.text((60 + chip_w // 2, y0 + 45), chip, font=f, fill=C["text"] if has_move else (10, 14, 26), anchor="mm")
    d.text((88 + chip_w, y0 + 22), spec.get("company") or spec.get("topic", ""), font=font("bold", 44), fill=C["text"], anchor="lm")
    sub = f"{fmt_pct(pct)}  ·  {spec.get('date_label', '')}" if has_move else spec.get("date_label", "")
    d.text((88 + chip_w, y0 + 70), sub, font=font("medium", 36), fill=col if has_move else C["muted"], anchor="lm")
    d.text((W - 60, y0 + 24), "WHY IT", font=font("bold", 32), fill=tuple(THEME.get("hdr") or C["accent"]), anchor="rm")
    d.text((W - 60, y0 + 62), "MOVED?", font=font("bold", 32), fill=tuple(THEME.get("hdr") or C["accent"]), anchor="rm")
    d.text((60, y0 + 122), "Educational only · not financial advice", font=font("medium", 26), fill=C["muted"], anchor="lm")
    d.rectangle((0, 214, W, 220), fill=tuple(THEME["bar_bg"]))
    d.rectangle((0, 214, int(W * now / total), 220), fill=C["accent"])


def brand_sting(img, now):
    """0.0–0.9s: WHY IT MOVED? stamps in, then flies to the corner."""
    if now > 0.9:
        return
    d = ImageDraw.Draw(img)
    if now < 0.55:
        p = pop(now / 0.3)
        a = 255
        cx, cy, sc = W // 2, 930, 1.0
    else:
        k = ease((now - 0.55) / 0.35)
        a = int(255 * (1 - k))
        cx, cy, sc = int(W // 2 + (W - 220 - W // 2) * k), int(930 + (170 - 930) * k), 1 - 0.7 * k
        p = 1
    size = int(150 * sc * (0.7 + 0.3 * p))
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    if now < 0.55:
        ld.rectangle((0, 0, W, H), fill=(6, 9, 18, int(200 * (1 - now / 0.55))))
    ld.text((cx, cy - size * 0.55), "WHY IT", font=font("bold", size), fill=C["text"] + (a,), anchor="mm")
    ld.text((cx, cy + size * 0.55), "MOVED?", font=font("bold", size), fill=C["accent"] + (a,), anchor="mm")
    img.alpha_composite(layer)


# ================================================================== sound design (generated, royalty-free)
def _onepole(x, cut, sr):
    import numpy as np
    y = np.empty_like(x)
    acc = 0.0
    cut = np.broadcast_to(np.asarray(cut, dtype="float64"), x.shape)
    a = 1 - np.exp(-2 * np.pi * cut / sr)
    for i in range(len(x)):
        acc += a[i] * (x[i] - acc)
        y[i] = acc
    return y


def sfx(kind: str, sr: int, rng):
    import numpy as np
    if kind.startswith("whoosh"):
        var = int(kind[-1]) if kind[-1].isdigit() else 0
        dur, peak = [(0.42, 3800), (0.3, 5200), (0.5, 2600)][var % 3]
        n = int(dur * sr); tt = np.linspace(0, 1, n)
        cut = 300 + peak * np.sin(np.pi * tt) ** 2
        x = _onepole(rng.standard_normal(n), cut, sr)
        return (x / (np.abs(x).max() + 1e-9)) * np.sin(np.pi * tt) ** 1.5
    if kind == "pop":
        n = int(0.09 * sr); tt = np.arange(n) / sr
        f = 1100 - 4500 * tt
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 45)
    if kind == "stamp":
        n = int(0.28 * sr); tt = np.arange(n) / sr
        thump = np.sin(2 * np.pi * np.cumsum(95 - 150 * tt) / sr) * np.exp(-tt * 18)
        click = np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 160) * 0.35
        return thump + click
    if kind == "impact":
        n = int(0.7 * sr); tt = np.arange(n) / sr
        boom = np.sin(2 * np.pi * np.cumsum(62 - 40 * tt) / sr) * np.exp(-tt * 6)
        rumble = _onepole(rng.standard_normal(n), 400, sr)
        rumble = rumble / (np.abs(rumble).max() + 1e-9) * np.exp(-tt * 9) * 0.5
        return boom + rumble
    if kind == "riser":
        n = int(1.1 * sr); tt = np.linspace(0, 1, n)
        x = _onepole(rng.standard_normal(n), 300 + 5000 * tt ** 2, sr)
        x = x / (np.abs(x).max() + 1e-9)
        tone = np.sin(2 * np.pi * np.cumsum(220 + 900 * tt ** 2) / sr) * 0.3
        return (x * 0.7 + tone) * tt ** 2
    return _sfx_pz(kind, sr, rng)


def music_bed(total: float, sr: int, rng):
    """Low, tense synth pad + soft pulse, ~100 bpm. Royalty-free (generated)."""
    import numpy as np
    n = int(total * sr)
    out = np.zeros(n)
    bar = 2.4
    chords = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]]  # Am F C G
    hz = lambda m: 440 * 2 ** ((m - 69) / 12)
    t_all = np.arange(n) / sr
    for i in range(int(total / bar) + 1):
        s0, s1 = int(i * bar * sr), min(n, int((i + 1) * bar * sr) + int(0.3 * sr))
        if s0 >= n:
            break
        tt = t_all[s0:s1] - i * bar
        env = np.minimum(1, tt / 0.35) * np.minimum(1, np.maximum(0, (bar + 0.3 - tt) / 0.5))
        seg = np.zeros(s1 - s0)
        for m in chords[i % 4]:
            for det in (-0.08, 0.08):
                seg += np.sin(2 * np.pi * hz(m - 12) * (1 + det / 100) * tt)
            seg += 0.25 * np.sin(2 * np.pi * hz(m) * tt)
        seg += 0.6 * np.sin(2 * np.pi * hz(chords[i % 4][0] - 24) * tt)  # bass
        out[s0:s1] += seg * env
    # soft pulse on every beat
    beat = 0.6
    for b in range(int(total / beat)):
        s0 = int(b * beat * sr)
        m = min(n - s0, int(0.12 * sr))
        if m <= 0:
            break
        tt = np.arange(m) / sr
        out[s0:s0 + m] += 1.4 * np.sin(2 * np.pi * (60 - 120 * tt) * tt) * np.exp(-tt * 30)
    out = _onepole(out, 1800, sr) if n < sr * 120 else out
    return out / (np.abs(out).max() + 1e-9)


def collect_events(beats: list[dict]) -> list[tuple[float, str]]:
    """Sound effects synced to the same cues that drive the visuals."""
    ev = []
    for i, b in enumerate(beats):
        v, cues, st = b["visual"], b["cues"], b["start"]
        if i > 0:
            ev.append((st - 0.1, f"whoosh{i % 3}"))
        kind = v["type"]
        if kind.startswith("sv_"):
            ev += SV_EVENTS[kind](v, cues, st)
            continue
        if kind.startswith("pz_"):
            ev += PZ_EVENTS[kind](v, cues, st)
            continue
        if kind.startswith("toon_"):
            if kind == "toon_hook":
                ev.append((0.0, "impact"))
            elif kind == "toon_steps":
                for k, it in enumerate(v["items"][:4]):
                    ev.append((st + cues.at(it.get("at"), cues.spread(k, len(v["items"][:4]), 0.05, 0.75)), "pop"))
            elif kind == "toon_gag":
                ev.append((st + cues.at(v.get("expect_at"), 0.2), "pop"))
                ev.append((st + cues.at(v.get("lift_at"), 1.5), "whoosh1"))
                ev.append((st + cues.at(v.get("lift_at"), 1.5) + 0.7, "stamp"))
            elif kind == "toon_story":
                ev.append((st + cues.at(v.get("at"), 0.15), "pop"))
            elif kind == "toon_outro" and v.get("cta_at"):
                ev.append((st + cues.at(v["cta_at"], 1.0), "stamp"))
            continue
        if kind == "hook":
            ev.append((0.0, "impact"))
            if v.get("price_at"):
                ev.append((st + cues.at(v["price_at"], 0.6), "pop"))
            continue
        if kind == "question":
            if i == 0:
                ev.append((0.0, "impact"))
            if v.get("sub_at"):
                ev.append((st + cues.at(v["sub_at"], 0.8), "pop"))
            continue
        if kind == "rank":
            ev.append((st + 0.02, "pop"))
            ev.append((st + cues.at(v.get("move_at"), 0.25) + 0.05, "stamp"))
            continue
        if kind == "headline":
            ev.append((st + cues.at(v.get("at"), 0.0), "whoosh1"))
            if v.get("highlight_at"):
                ev.append((st + cues.at(v["highlight_at"], 0.6), "pop"))
            continue
        if kind == "beatmiss":
            ev.append((st - 1.1, "riser"))
            for k, it in enumerate(v["items"]):
                tk = cues.at(it.get("at"), cues.spread(k, len(v["items"]), 0.05, 0.6))
                ev.append((st + tk, "pop"))
                ev.append((st + cues.at(it.get("actual_at"), tk + 0.6) + 0.12, "stamp"))
            continue
        if kind == "mythfact":
            ev.append((st + cues.at(v.get("myth_at"), 0.0), "pop"))
            tf = cues.at(v.get("fact_at"), cues.dur * 0.45)
            ev.append((st + tf, "whoosh1"))
            ev.append((st + tf + 0.2, "stamp"))
            continue
        if kind == "quiz":
            ev.append((st - 0.9, "riser"))
            for k, o in enumerate(v["options"][:3]):
                ev.append((st + cues.at(o.get("at"), cues.spread(k, len(v["options"][:3]), 0.12, 0.5)), "pop"))
            ev.append((st + cues.at(v.get("reveal_at"), cues.dur * 0.7) + 0.1, "stamp"))
            continue
        if kind == "poll":
            for side in ("left", "right"):
                ev.append((st + cues.at(v[side].get("at"), 0.4 if side == "left" else 0.9), "pop"))
            if v.get("cta_at"):
                ev.append((st + cues.at(v["cta_at"], cues.dur * 0.65), "pop"))
            continue
        if kind == "shift":
            ev.append((st + cues.at(v["from"].get("at"), 0.05), "pop"))
            t1 = cues.at(v["to"].get("at"), cues.dur * 0.5)
            ev.append((st + t1, "whoosh1"))
            ev.append((st + t1 + 0.2, "stamp"))
            continue
        if kind == "qa":
            for k, it in enumerate(v["items"][:2]):
                tq = cues.at(it.get("q_at"), cues.spread(k, len(v["items"][:2]), 0.05, 0.6))
                ev.append((st + tq, "pop"))
                ev.append((st + cues.at(it.get("a_at"), tq + 1.0), "stamp"))
            continue
        if kind == "receipts":
            for k, it in enumerate(v["items"][:3]):
                tk = cues.at(it.get("at"), cues.spread(k, len(v["items"][:3]), 0.05, 0.7))
                ev.append((st + tk, "pop"))
                ev.append((st + tk + 0.3, "stamp"))
            continue
        if kind == "decoder":
            for k, it in enumerate(v["items"][:3]):
                tk = cues.at(it.get("at"), cues.spread(k, len(v["items"][:3]), 0.05, 0.7))
                ev.append((st + tk, "pop"))
                ev.append((st + cues.at(it.get("plain_at"), tk + 0.7), "stamp"))
            continue
        if kind in ("chain", "timeline", "peers"):
            items = v["items"]
            lo, hi = (0.05, 0.6) if kind == "peers" else (0.05, 0.75)
            for k, it in enumerate(items):
                ev.append((st + cues.at(it.get("at"), cues.spread(k, len(items), lo, hi)), "pop"))
            if kind == "chain" and items:
                ev.append((st + cues.at(items[-1].get("at"), cues.spread(len(items) - 1, len(items), lo, hi)) + 0.05, "stamp"))
            continue
        if kind == "scorecard":
            ev.append((st - 1.1, "riser"))
            for k, it in enumerate(v["items"]):
                ev.append((st + cues.at(it.get("at"), cues.spread(k, len(v["items"]), 0.1, 0.75)) + 0.12, "stamp"))
            continue
        for key in ("at", "label_at"):
            if key in v and kind != "hook":
                ev.append((st + cues.at(v[key], 0.05), "pop"))
        for coll in ("items", "points"):
            for k, it in enumerate(v.get(coll, []) if isinstance(v.get(coll), list) else []):
                if isinstance(it, dict) and it.get("at"):
                    ev.append((st + cues.at(it["at"], 0.1), "pop"))
        for side in ("left", "right"):
            if isinstance(v.get(side), dict) and v[side].get("at"):
                ev.append((st + cues.at(v[side]["at"], 0.1), "pop"))
        if kind == "outro" and v.get("cta_at"):
            ev.append((st + cues.at(v["cta_at"], 0.5), "pop"))
    return sorted((max(0.0, t), k) for t, k in ev)


# ==== SV BEGIN
# ---------------------------------------------------------------- "Patch and the Rack" (server theme)
INKB = (5, 16, 24)
NAVY = (11, 37, 48)
NAVY2 = (17, 55, 70)
NAVY3 = (26, 78, 96)
CRM = (255, 244, 220)
TLP = (24, 197, 176)
TLD = (10, 104, 100)
TLL = (110, 236, 218)
GLD = (255, 200, 61)
GLDD = (214, 150, 30)
RED = (232, 69, 44)
GRY = (150, 158, 170)
GRYD = (98, 106, 120)
GRYL = (200, 207, 216)
RKC = (70, 60, 150)
RKL = (106, 96, 188)
RKD = (38, 32, 92)
BOTC = (112, 138, 176)
BOTL = (146, 172, 208)
BOT2 = (156, 134, 190)
WINC = (8, 48, 56)
PINC = (214, 220, 230)
DIMC = (150, 170, 178)


class SP(Pen):
    """Pen with the dark-ink outline used in the server set."""
    def rr(s, box, r, fill=None, w=8, out=INKB):
        Pen.rr(s, box, r, fill, w, out)

    def el(s, box, fill=None, w=8, out=INKB):
        Pen.el(s, box, fill, w, out)

    def ln(s, pts, w=8, fill=INKB):
        Pen.ln(s, pts, w, fill)

    def poly(s, pts, fill, w=7, out=INKB):
        Pen.poly(s, pts, fill, w, out)

    def arc(s, box, a0, a1, w=8, fill=INKB):
        Pen.arc(s, box, a0, a1, w, fill)

    def pie(s, box, a0, a1, fill, w=7, out=INKB):
        Pen.pie(s, box, a0, a1, fill, w, out)


_SC = {}


def _svc(key, w, h, fn):
    if key not in _SC:
        if len(_SC) > 260:
            _SC.clear()
        _SC[key] = _ss(w, h, fn)
    return _SC[key]


def stext(img, xy, s, size, fill=CRM, sw=8, rot=0.0, sc=1.0, alpha=1.0, ink=INKB):
    if sc <= 0.02:
        return
    ptext(img, xy, s, size, fill, sw=sw, rot=rot, sc=sc, ink=ink, alpha=alpha)


def spill(img, cx, cy, s, size, fill, tc=CRM, padx=34, h=None, rot=0.0, sc=1.0, w_min=0, alpha=1.0, ow=7):
    if sc <= 0.02:
        return
    f = font("bold", size)
    probe = ImageDraw.Draw(Image.new("L", (4, 4)))
    tw = int(probe.textlength(s, font=f))
    w = max(w_min, tw + 2 * padx)
    hh = h or int(size * 1.7)
    T = _ss(w + 24, hh + 24, lambda d, k: SP(d, k).rr((10, 10, w + 10, hh + 10), hh // 2.4, fill, ow))
    ImageDraw.Draw(T).text(((w + 24) // 2, (hh + 24) // 2 + 1), s, font=f, fill=tuple(tc) + (255,), anchor="mm")
    if alpha < 1:
        T.putalpha(T.getchannel("A").point(lambda a: int(a * alpha)))
    blit(img, T, cx, cy, (w + 24) / 2, (hh + 24) / 2, sc, sc, rot)


def sburst(img, cx, cy, r1, r2, n, rot, fill, sw=8, alpha=1.0):
    T = int(r2 * 2 + 30)

    def fn(d, k):
        pts = []
        for i in range(n * 2):
            r = r2 if i % 2 == 0 else r1
            a = rot + _m.pi * i / n
            pts.append(((T / 2 + r * _m.cos(a)) * k, (T / 2 + r * _m.sin(a)) * k))
        d.polygon(pts, fill=fill, outline=INKB, width=int(sw * k))
    tile = _ss(T, T, fn)
    if alpha < 1:
        tile.putalpha(tile.getchannel('A').point(lambda a: int(a * alpha)))
    put(img, tile, cx - T / 2, cy - T / 2)


def tint(img, col, a):
    if a > 0.01:
        img.alpha_composite(Image.new("RGBA", img.size, tuple(col) + (int(255 * clamp01(a)),)))


def speed_lines(img, cx, cy, t, n=22, r0=380, r1=1000, col=(255, 255, 255), a=200, seed=1, width=9):
    rnd = _rnd.Random(seed)
    d = ImageDraw.Draw(img)
    for i in range(n):
        ang = rnd.uniform(0, 2 * _m.pi)
        ra = r0 + rnd.uniform(0, 160) + (t * 900) % 120
        rb = r1
        wdt = rnd.uniform(0.012, 0.03)
        pts = [(cx + _m.cos(ang - wdt) * rb, cy + _m.sin(ang - wdt) * rb), (cx + _m.cos(ang + wdt) * rb, cy + _m.sin(ang + wdt) * rb),
               (cx + _m.cos(ang) * ra, cy + _m.sin(ang) * ra)]
        d.polygon(pts, fill=col + (a,))


def blink_at(t, seed=0.0, per=3.1):
    ph = (t + seed * 0.77) % per
    return ph < 0.13


def swob(t, f=1.0, a=1.0):
    return _m.sin(t * f * 6.283) * a


# ---------------------------------------------------------------- icons
def draw_icon(p, kind, cx, cy, s=1.0, col=CRM, bg=WINC):
    if kind == "wrench":
        p.ln([(cx - 28 * s, cy + 24 * s), (cx + 14 * s, cy - 18 * s)], 13 * s, col)
        p.el((cx + 5 * s, cy - 44 * s, cx + 41 * s, cy - 8 * s), col, 0)
        p.poly([(cx + 20 * s, cy - 28 * s), (cx + 50 * s, cy - 30 * s), (cx + 32 * s, cy - 54 * s)], bg, 0)
    elif kind == "magnifier":
        p.el((cx - 30 * s, cy - 32 * s, cx + 12 * s, cy + 10 * s), None, 8 * s, col)
        p.ln([(cx + 8 * s, cy + 6 * s), (cx + 32 * s, cy + 30 * s)], 12 * s, col)
    elif kind == "shield":
        p.poly([(cx, cy - 34 * s), (cx + 28 * s, cy - 22 * s), (cx + 26 * s, cy + 6 * s), (cx, cy + 34 * s),
                (cx - 26 * s, cy + 6 * s), (cx - 28 * s, cy - 22 * s)], GLD, 0)
        p.ln([(cx - 12 * s, cy - 2 * s), (cx - 2 * s, cy + 10 * s), (cx + 14 * s, cy - 12 * s)], 8 * s, bg)
    elif kind in ("gear", "gear_dim"):
        c = col if kind == "gear" else (122, 130, 146)
        pts = []
        for k_ in range(8):
            a = _m.radians(k_ * 45)
            for da, rr_ in ((-13, 25), (-8, 36), (8, 36), (13, 25)):
                pts.append((cx + _m.cos(a + _m.radians(da)) * rr_ * s, cy + _m.sin(a + _m.radians(da)) * rr_ * s))
        p.poly(pts, c, 0)
        p.el((cx - 11 * s, cy - 11 * s, cx + 11 * s, cy + 11 * s), bg, 0)
    elif kind == "arrow":
        p.poly([(cx, cy - 36 * s), (cx + 34 * s, cy), (cx + 12 * s, cy), (cx + 12 * s, cy + 34 * s),
                (cx - 12 * s, cy + 34 * s), (cx - 12 * s, cy), (cx - 34 * s, cy)], col, 0)
    else:  # traces
        c = (30, 120, 120)
        p.ln([(cx - 46 * s, cy + 12 * s), (cx - 14 * s, cy + 12 * s), (cx - 4 * s, cy - 10 * s), (cx + 30 * s, cy - 10 * s)], 6 * s, c)
        p.ln([(cx - 30 * s, cy - 16 * s), (cx - 6 * s, cy - 16 * s)], 6 * s, c)
        p.el((cx + 30 * s, cy - 18 * s, cx + 46 * s, cy - 2 * s), c, 0)
        p.el((cx + 18 * s, cy + 6 * s, cx + 32 * s, cy + 20 * s), c, 0)


# ---------------------------------------------------------------- PATCH (hero chip)
def _arm(p, side, a, col, hand):
    sx = 94 if side < 0 else 306
    sy = 194
    ar = _m.radians(a)
    L = 64
    hx, hy = sx + side * _m.sin(ar) * L, sy + _m.cos(ar) * L
    p.ln([(sx, sy), (hx, hy)], 28, INKB)
    p.ln([(sx, sy), (hx, hy)], 17, col)
    p.el((hx - 17, hy - 17, hx + 17, hy + 17), hand, 7)


def patch_tile(icon="none", eyes="open", mouth="smile", al=0, ar=0, cheeks=0, sweat=0):
    al, ar = int(round(al / 15.0)) * 15, int(round(ar / 15.0)) * 15
    key = ("patch", icon, eyes, mouth, al, ar, cheeks, sweat)

    def fn(d, k):
        p = SP(d, k)
        for i in range(4):
            cx = 90 + 220 * (i + 0.5) / 4
            p.rr((cx - 9, 40, cx + 9, 78), 5, PINC, 6)
            p.rr((cx - 9, 282, cx + 9, 324), 5, PINC, 6)
        for i in range(4):
            cy = 70 + 220 * (i + 0.5) / 4
            p.rr((56, cy - 9, 98, cy + 9), 5, PINC, 6)
            p.rr((302, cy - 9, 344, cy + 9), 5, PINC, 6)
        _arm(p, -1, al, TLP, TLL)
        _arm(p, 1, ar, TLP, TLL)
        p.rr((90, 70, 310, 290), 40, TLP, 10)
        p.rr((106, 82, 250, 96), 7, TLL, 0)
        p.ln([(106, 270), (150, 270), (160, 280)], 5, TLD)
        p.ln([(294, 270), (258, 270), (250, 280)], 5, TLD)
        p.rr((130, 88, 270, 160), 16, WINC, 7)
        draw_icon(p, icon, 200, 124, 0.9)
        if cheeks:
            p.el((112, 232, 140, 252), (255, 150, 140), 0)
            p.el((260, 232, 288, 252), (255, 150, 140), 0)
        cy = 208
        for sg, ex in ((-1, 158), (1, 242)):
            if eyes in ("open", "lookl", "lookr", "lookup", "worry", "sad"):
                lx = {"lookl": -7, "lookr": 7}.get(eyes, 0)
                ly = -8 if eyes == "lookup" else 0
                p.el((ex - 22, cy - 24, ex + 22, cy + 24), (255, 255, 255), 6)
                p.el((ex - 10 + lx, cy - 11 + ly, ex + 10 + lx, cy + 13 + ly), INKB, 0)
                p.el((ex - 5 + lx, cy - 9 + ly, ex + 3 + lx, cy - 1 + ly), (255, 255, 255), 0)
                if eyes == "worry":
                    p.ln([(ex - sg * 20, cy - 36 - (8 if sg < 0 else 0) + (8 if sg < 0 else 0)), (ex + sg * 20, cy - 50)] if False else
                         [(ex + (-20 if sg < 0 else 20), cy - 34 - 0), (ex + (20 if sg < 0 else -20), cy - 48)], 8)
            elif eyes == "blink":
                p.ln([(ex - 18, cy + 4), (ex + 18, cy + 4)], 8)
            elif eyes == "happy":
                p.arc((ex - 19, cy - 10, ex + 19, cy + 26), 200, 340, 8)
            elif eyes == "wide":
                p.el((ex - 27, cy - 32, ex + 27, cy + 32), (255, 255, 255), 6)
                p.el((ex - 6, cy - 6, ex + 6, cy + 8), INKB, 0)
            elif eyes == "squint":
                if sg < 0:
                    p.ln([(ex - 18, cy - 14), (ex + 10, cy + 2), (ex - 18, cy + 18)], 8)
                else:
                    p.ln([(ex + 18, cy - 14), (ex - 10, cy + 2), (ex + 18, cy + 18)], 8)
        if mouth == "grin":
            p.pie((166, 232, 234, 284), 0, 180, (120, 30, 40), 7)
            p.el((184, 262, 216, 280), (240, 110, 110), 0)
        elif mouth == "open":
            p.el((184, 242, 216, 278), (120, 30, 40), 7)
            p.el((190, 260, 210, 275), (240, 110, 110), 0)
        elif mouth == "o":
            p.el((190, 244, 210, 270), (120, 30, 40), 6)
        elif mouth == "flat":
            p.ln([(182, 262), (218, 262)], 7)
        elif mouth == "worry":
            p.ln([(172, 266), (186, 258), (200, 266), (214, 258), (228, 266)], 6)
        elif mouth == "smirk":
            p.ln([(178, 262), (204, 266), (228, 252)], 7)
        elif mouth == "sad":
            p.arc((176, 256, 224, 290), 200, 340, 7)
        else:
            p.arc((170, 232, 230, 274), 20, 160, 8)
        if sweat:
            p.poly([(300, 96), (288, 126), (300, 140), (312, 126)], (140, 210, 255), 5)
    return _svc(key, 400, 340, fn)


PIV_P = (200, 324)


def put_patch(layer, x, y, sc=1.0, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, patch_tile(**kw), x, y, PIV_P[0], PIV_P[1], sc * sx, sc * sy, rot)


# ---------------------------------------------------------------- FIXED FRED
def fred_tile(eyes="sad", mouth="frown", ghost=0, effort=0, sweat=0, ar=8, al=8):
    key = ("fred", eyes, mouth, ghost, round(effort, 1), sweat, int(ar / 8), int(al / 8))
    body = mix(GRY, (232, 110, 90), effort * 0.7)

    def fn(d, k):
        p = SP(d, k)
        for i in range(4):
            cx = 90 + 220 * (i + 0.5) / 4
            p.rr((cx - 9, 40, cx + 9, 78), 5, GRYL, 6)
            p.rr((cx - 9, 282, cx + 9, 324), 5, GRYL, 6)
        for i in range(4):
            cy = 70 + 220 * (i + 0.5) / 4
            p.rr((56, cy - 9, 98, cy + 9), 5, GRYL, 6)
            p.rr((302, cy - 9, 344, cy + 9), 5, GRYL, 6)
        _arm(p, -1, al, body, GRYL)
        _arm(p, 1, ar, body, GRYL)
        p.rr((90, 70, 310, 290), 40, body, 10)
        p.rr((106, 82, 250, 96), 7, mix(body, (255, 255, 255), 0.35), 0)
        p.rr((120, 84, 280, 168), 18, (66, 72, 86), 7)
        draw_icon(p, "gear", 200, 126, 1.0, (176, 184, 198), (66, 72, 86))
        if ghost:
            draw_icon(p, "wrench", 214, 128, 0.95, (255, 120, 100), (66, 72, 86))
        # plate + screws
        p.rr((60, 298, 340, 346), 12, GRYD, 8)
        for sx_ in (98, 302):
            p.el((sx_ - 15, 307, sx_ + 15, 337), GRYL, 6)
            p.ln([(sx_ - 8, 322), (sx_ + 8, 322)], 5)
            p.ln([(sx_, 314), (sx_, 330)], 5)
        cy = 212
        for sg, ex in ((-1, 158), (1, 242)):
            if eyes == "sad":
                p.el((ex - 22, cy - 22, ex + 22, cy + 22), (255, 255, 255), 6)
                p.el((ex - 9, cy + 0, ex + 9, cy + 18), INKB, 0)
                p.poly([(ex - 25, cy - 26), (ex + 25, cy - 26), (ex + 25, cy - 8 + sg * 7), (ex - 25, cy - 8 - sg * 7)], body, 0)
                p.ln([(ex - 24, cy - 8 - sg * 7), (ex + 24, cy - 8 + sg * 7)], 7)
            elif eyes == "strain":
                if sg < 0:
                    p.ln([(ex - 18, cy - 14), (ex + 10, cy + 2), (ex - 18, cy + 18)], 9)
                else:
                    p.ln([(ex + 18, cy - 14), (ex - 10, cy + 2), (ex + 18, cy + 18)], 9)
            elif eyes == "closed":
                p.arc((ex - 19, cy - 14, ex + 19, cy + 18), 20, 160, 8)
            elif eyes == "wide":
                p.el((ex - 25, cy - 28, ex + 25, cy + 28), (255, 255, 255), 6)
                p.el((ex - 6, cy - 6, ex + 6, cy + 8), INKB, 0)
            elif eyes == "squish":
                if sg < 0:
                    p.ln([(ex - 18, cy - 10), (ex + 10, cy + 4), (ex - 18, cy + 18)], 8)
                else:
                    p.ln([(ex + 18, cy - 10), (ex - 10, cy + 4), (ex + 18, cy + 18)], 8)
        if mouth == "frown":
            p.arc((166, 256, 234, 294), 200, 340, 8)
        elif mouth == "grit":
            p.rr((170, 252, 230, 280), 8, (255, 255, 255), 6)
            for xx in (185, 200, 215):
                p.ln([(xx, 253), (xx, 279)], 4)
        elif mouth == "o":
            p.el((188, 246, 212, 280), (60, 30, 40), 6)
        elif mouth == "flat":
            p.ln([(176, 264), (224, 264)], 7)
        if sweat:
            p.poly([(300, 96), (288, 126), (300, 140), (312, 126)], (140, 210, 255), 5)
    return _svc(key, 400, 350, fn)


PIV_F = (200, 342)


def put_fred(layer, x, y, sc=1.0, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, fred_tile(**kw), x, y, PIV_F[0], PIV_F[1], sc * sx, sc * sy, rot)


# ---------------------------------------------------------------- FORECASTER bots
def bot_tile(which, mood="smug", jaw=0.0, glass=0.0, clip="", snap=0, sweat=0, leg=0.0, arm=0, look=0):
    key = ("bot", which, mood, round(jaw, 1), round(glass, 1), clip, snap, sweat, round(leg * 2) / 2.0, arm, look)
    body = BOTC if which == 0 else BOT2
    head = BOTL if which == 0 else (186, 164, 214)

    def fn(d, k):
        p = SP(d, k)
        u1, u2 = max(0, leg) * 14, max(0, -leg) * 14
        p.rr((124, 520, 164, 604 - u1), 12, (70, 84, 112), 7)
        p.rr((196, 520, 236, 604 - u2), 12, (70, 84, 112), 7)
        p.el((98, 586 - u1, 172, 616 - u1), (40, 48, 64), 7)
        p.el((188, 586 - u2, 262, 616 - u2), (40, 48, 64), 7)
        # antenna
        p.ln([(180, 128), (180, 88)], 8)
        p.el((164, 66, 196, 98), RED if which == 0 else GLD, 7)
        # torso
        p.rr((92, 332, 268, 540), 44, body, 9)
        p.poly([(146, 334), (214, 334), (180, 392)], (255, 255, 255), 6)
        if which == 0:
            p.poly([(172, 366), (188, 366), (196, 416), (180, 452), (164, 416)], RED, 5)
        else:
            p.poly([(180, 372), (146, 354), (146, 394)], GLD, 5)
            p.poly([(180, 372), (214, 354), (214, 394)], GLD, 5)
            p.el((168, 360, 192, 384), GLD, 5)
        # left arm with pencil
        p.ln([(104, 380), (74, 466)], 38, INKB)
        p.ln([(104, 380), (74, 466)], 25, body)
        if snap < 1:
            p.poly([(58, 410), (76, 404), (92, 500), (74, 504)], (255, 214, 70), 6)
            p.poly([(74, 504), (92, 500), (82, 528)], (240, 190, 130), 5)
            p.poly([(58, 410), (76, 404), (78, 392), (61, 397)], (255, 168, 168), 5)
        else:
            p.poly([(66, 462), (82, 458), (92, 500), (74, 504)], (255, 214, 70), 6)
            p.poly([(74, 504), (92, 500), (82, 528)], (240, 190, 130), 5)
        p.el((54, 456, 94, 494), BOTL, 7)
        # head
        p.rr((78, 118, 282, 340), 46, head, 9)
        p.rr((60, 190, 84, 262), 8, GRYL, 6)
        p.rr((276, 190, 300, 262), 8, GRYL, 6)
        if which == 1:
            p.pie((120, 96, 240, 150), 180, 360, (70, 50, 90), 7)
        gy = -glass * 190
        # brows
        by = -glass * 10
        if mood == "worry":
            p.ln([(110, 180 + by), (160, 162 + by)], 9)
            p.ln([(250, 180 + by), (200, 162 + by)], 9)
        elif mood == "shock":
            p.ln([(112, 160 + by), (162, 150 + by)], 9)
            p.ln([(248, 160 + by), (198, 150 + by)], 9)
        else:
            p.ln([(110, 170), (160, 184)], 9)
            p.ln([(250, 170), (200, 184)], 9)
        # eyes behind glasses
        lx = look * 6
        if glass > 0.3 or mood == "shock":
            for ex in (140, 220):
                p.el((ex - 26, 190, ex + 26, 252 + jaw * 4), (255, 255, 255), 7)
                p.el((ex - 5, 214, ex + 5, 228), INKB, 0)
        else:
            for ex in (140, 220):
                p.el((ex - 8 + lx, 206, ex + 8 + lx, 228), INKB, 0)
        # mouth
        if jaw > 0.05:
            wdt, hgt = 30 + jaw * 26, 10 + jaw * 56
            p.el((180 - wdt / 2, 280, 180 + wdt / 2, 280 + hgt), (120, 30, 40), 7)
        elif mood == "worry":
            p.ln([(146, 296), (160, 288), (174, 296), (188, 288), (202, 296), (216, 288)], 7)
        elif mood == "grin":
            p.pie((148, 272, 212, 316), 0, 180, (120, 30, 40), 7)
        else:
            p.ln([(150, 296), (180, 290), (212, 280)], 8)
        # glasses
        lens = (222, 240, 255)
        p.rr((108, 186 + gy, 172, 256 + gy), 14, lens if glass > 0.3 else None, 8)
        p.rr((188, 186 + gy, 252, 256 + gy), 14, lens if glass > 0.3 else None, 8)
        p.ln([(172, 206 + gy), (188, 206 + gy)], 7)
        if glass <= 0.3 and mood != "shock":
            p.rr((112, 190, 168, 252), 10, (222, 240, 255, 255), 0)
            p.rr((192, 190, 248, 252), 10, (222, 240, 255, 255), 0)
            for ex in (140, 220):
                p.el((ex - 8 + lx, 206, ex + 8 + lx, 228), INKB, 0)
            p.rr((108, 186, 172, 256), 14, None, 8)
            p.rr((188, 186, 252, 256), 14, None, 8)
        # right arm + clipboard
        p.ln([(256, 384), (262, 470)], 38, INKB)
        p.ln([(256, 384), (262, 470)], 25, body)
        p.rr((206, 400, 352, 560), 12, (196, 146, 92), 8)
        p.rr((216, 416, 342, 550), 5, (255, 255, 255), 5)
        p.rr((250, 390, 308, 416), 8, (170, 176, 192), 6)
        if clip:
            p.txt((279, 486), clip, 34 if len(clip) < 5 else 25, RED if clip[0] != "^" else (20, 150, 90))
        else:
            for yy in (440, 468, 496):
                p.ln([(226, yy), (332, yy)], 5, (176, 176, 186))
        p.el((196, 452, 238, 494), BOTL, 7)
        if sweat:
            p.poly([(292, 150), (280, 182), (292, 196), (304, 182)], (140, 210, 255), 5)
    return _svc(key, 370, 630, fn)


PIV_B = (180, 616)


def put_bot(layer, i, x, y, sc=0.9, sx=1.0, sy=1.0, rot=0.0, flip=False, **kw):
    tile = bot_tile(i, **kw)
    if flip:
        tile = tile.transpose(Image.FLIP_LEFT_RIGHT)
    blit(layer, tile, x, y, PIV_B[0] if not flip else 370 - PIV_B[0], PIV_B[1], sc * sx, sc * sy, rot)


# ---------------------------------------------------------------- RACK (AI server)
RK_W, RK_H = 400, 920
CELL = {}
for _i in range(8):
    _c, _r = _i % 2, _i // 2
    CELL[_i] = (52 + _c * 156, 414 + _r * 116, 52 + _c * 156 + 140, 414 + _r * 116 + 104)


def rack_body():
    def fn(d, k):
        p = SP(d, k)
        p.rr((36, 40, 364, 900), 44, RKC, 10)
        p.rr((52, 52, 340, 66), 7, RKL, 0)
        p.rr((50, 70, 350, 320), 36, RKD, 8)
        p.rr((44, 330, 356, 396), 14, (30, 26, 70), 7)
        for i in range(8):
            x0, y0, x1, y1 = CELL[i]
            p.rr((x0 - 4, y0 - 4, x1 + 4, y1 + 4), 14, (28, 24, 66), 6)
        for yy in range(404, 884, 116):
            p.ln([(190, yy - 10), (210, yy - 10)], 3, RKL)
        p.rr((120, 888, 280, 910), 8, RKD, 6)
    return _svc(("rackbody",), RK_W, RK_H, fn)


def rack_label(img, sc=1.0):
    pass


def rack_compose(look=0.0, blink=0.0, mouth="worry", lights=0.0, cells=None, brow=1.0, panic=0.0, label=True, now=0.0):
    """Returns a fresh RGBA tile: body + face + slot content.  cells: {i: (kind, u)}  kind in q / ok / empty."""
    tile = rack_body().copy()
    d = ImageDraw.Draw(tile)
    # LEDs on the head panel
    for j in range(5):
        on = (_m.sin(now * (6 + 4 * panic) + j * 1.9) > 0.1)
        col = (RED if panic > 0.3 else (255, 190, 60)) if on else (70, 60, 100)
        if j % 2 and not on:
            col = (60, 54, 96)
        d.ellipse((68 + j * 24, 84, 84 + j * 24, 100), fill=col + (255,), outline=INKB + (255,), width=3)

    def face(dd, k):
        p = SP(dd, k)
        # huge eye
        ex, ey = 200, 188
        sq = 1 - 0.92 * blink
        p.el((ex - 88, ey - 88 * sq, ex + 88, ey + 88 * sq), (255, 255, 255), 8)
        if sq > 0.3:
            px, py = ex + look * 30, ey + 6
            p.el((px - 34, py - 38 * sq, px + 34, py + 38 * sq), (36, 24, 60), 0)
            p.el((px - 14, py - 26 * sq, px - 2, py - 14 * sq), (255, 255, 255), 0)
        # brow
        if brow > 0:
            p.ln([(ex - 98, ey - 78), (ex + 20, ey - 100 - 8 * brow)], 13)
        # mouth
        if mouth == "worry":
            p.ln([(150, 296), (170, 284), (190, 296), (210, 284), (230, 296), (250, 284)], 8, (230, 220, 255))
        elif mouth == "shout":
            p.rr((120, 262, 280, 316), 22, (120, 30, 40), 8)
            p.rr((150, 290, 250, 314), 12, (240, 110, 110), 0)
            p.rr((132, 266, 268, 276), 4, (255, 255, 255), 0)
        elif mouth == "relief":
            p.arc((150, 258, 250, 306), 20, 160, 8, (230, 220, 255))
        elif mouth == "o":
            p.el((180, 262, 220, 308), (120, 30, 40), 7)
        # label plate
        if label:
            p.txt((200, 363), "AI SERVER", 40, (230, 226, 255))
    t2 = _ss(RK_W, 340, lambda dd, k: face(dd, k))
    tile.alpha_composite(t2, (0, 0))
    # slot contents
    d = ImageDraw.Draw(tile)
    for i in range(8):
        x0, y0, x1, y1 = CELL[i]
        st = (cells or {}).get(i)
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        d.rounded_rectangle((x0, y0, x1, y1), radius=12, fill=(18, 16, 44, 255))
        if not st:
            continue
        kind, u = st
        if kind == "q":
            r = 38 * pop(u)
            fl = 0.5 + 0.5 * _m.sin(now * 14 + i)
            d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=mix((190, 40, 30), RED, fl) + (255,), outline=INKB + (255,), width=5)
            d.text((cx, cy + 2), "?", font=font("bold", int(56 * pop(u))), fill=(255, 255, 255, 255), anchor="mm")
        elif kind == "ok":
            # mini Patch happy + green LED
            mp = patch_tile("none", "happy", "smile", 0, 0)
            sc = 0.36 * (1 + 0.15 * _m.exp(-8 * u) * _m.cos(22 * u))
            w_, h_ = int(mp.width * sc), int(mp.height * sc)
            im = mp.resize((max(1, w_), max(1, h_)), Image.LANCZOS)
            tile.alpha_composite(im, (int(cx - 200 * sc), int(y1 - 4 - 324 * sc)))
            d.ellipse((x1 - 22, y0 + 8, x1 - 8, y0 + 22), fill=(80, 255, 140, 255), outline=INKB + (255,), width=3)
    return tile


PIV_R = (200, 900)


def put_rack(layer, x, y, sc=0.9, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, rack_compose(**kw), x, y, PIV_R[0], PIV_R[1], sc * sx, sc * sy, rot)


def rack_cell_xy(i, x, y, sc):
    x0, y0, x1, y1 = CELL[i]
    return x + ((x0 + x1) / 2 - 200) * sc, y + ((y0 + y1) / 2 - 900) * sc


# ---------------------------------------------------------------- background set
TOWERS = [(60, 210, 860), (330, 170, 760), (560, 240, 900), (850, 180, 800), (1090, 220, 880), (1330, 170, 740)]


def sv_bg(layer, now, pan=0.0, mode="hall", reveal=1.0, alert=0.0):
    d = ImageDraw.Draw(layer)
    # sky gradient
    col_top, col_bot = (8, 28, 38), (14, 46, 60)
    if getattr(sv_bg, "_g", None) is None:
        g = Image.new("RGBA", (1, H))
        gd = ImageDraw.Draw(g)
        for y in range(H):
            gd.point((0, y), fill=mix(col_top, col_bot, clamp01(y / 1300.0)) + (255,))
        sv_bg._g = g.resize((W, H))
    layer.paste(sv_bg._g, (0, 0))
    if mode == "hook":
        rays(layer, 540, 600, 0, 2400, 18, now * 0.12, (13, 52, 66), None, 0.5)
        d.ellipse((300, 380, 780, 860), fill=(16, 60, 74, 255))
    if reveal <= 0.001:
        return
    off = (1 - ease(reveal)) * 1200
    # far towers (parallax 0.25)
    for i, (x, w, h) in enumerate(TOWERS):
        xs = (x - pan * 0.25) % 1560 - 240 + off
        if xs > W or xs + w < 0:
            continue
        top = 1280 - h
        d.rounded_rectangle((xs, top, xs + w, 1290), radius=16, fill=(14, 44, 58, 255), outline=(20, 62, 80, 255), width=4)
        for r_ in range(int(h // 56)):
            yy = top + 24 + r_ * 56
            d.rounded_rectangle((xs + 14, yy, xs + w - 14, yy + 34), radius=8, fill=(11, 36, 48, 255))
            on = _m.sin(now * (1.2 + (i + r_) % 3) + i * 2.1 + r_ * 1.3) > 0.15
            c = (40, 180, 160) if on else (22, 70, 80)
            if (i + r_) % 5 == 0 and on:
                c = (255, 190, 60)
            d.ellipse((xs + 22, yy + 11, xs + 34, yy + 23), fill=c + (255,))
    # mid shelves (parallax 0.6)
    for r_, yy in enumerate((660, 820, 980, 1140)):
        d.rounded_rectangle((-20 + off, yy, W + 20 + off, yy + 120), radius=14, fill=(15, 49, 63, 255), outline=(21, 66, 84, 255), width=4)
        sh = (pan * 0.6) % 150
        for s_ in range(-1, 9):
            sx_ = s_ * 150 - sh + off
            d.rounded_rectangle((sx_ + 14, yy + 14, sx_ + 136, yy + 106), radius=10, fill=(12, 40, 52, 255))
            ph = s_ * 1.7 + r_ * 2.3 + int(pan * 0.6 / 150) * 1.7
            on = _m.sin(now * 2.4 + ph) > 0.2
            d.ellipse((sx_ + 26, yy + 26, sx_ + 40, yy + 40), fill=((60, 255, 160) if on else (24, 76, 80)) + (255,))
            d.ellipse((sx_ + 50, yy + 26, sx_ + 64, yy + 40), fill=((255, 190, 60) if (not on and (s_ + r_) % 3 == 0) else (24, 76, 80)) + (255,))
            d.line([(sx_ + 26, yy + 66), (sx_ + 120, yy + 66)], fill=(21, 66, 84, 255), width=4)
            d.line([(sx_ + 26, yy + 82), (sx_ + 100, yy + 82)], fill=(21, 66, 84, 255), width=4)
    # floor
    fy = 1280
    d.rectangle((0 + off, fy, W + off, H), fill=(11, 33, 43, 255))
    d.rectangle((0 + off, fy, W + off, fy + 10), fill=(26, 130, 128, 255))
    for k in range(-2, 40):
        x0 = k * 70 - (pan % 70) + off
        d.line([(x0, fy + 12), (x0 - 160, H)], fill=(17, 52, 66, 255), width=3)
    for k, yy in enumerate((fy + 40, fy + 100, fy + 190, fy + 300)):
        d.line([(0, yy), (W, yy)], fill=(15, 46, 58, 255), width=2)
    cabs = [((232, 69, 44), 1310, 0.0), ((255, 200, 61), 1352, 1.6), ((24, 197, 176), 1396, 3.1)]
    for col, yy, ph in cabs:
        pts = [(x_ + off, yy + _m.sin((x_ + pan) * 0.012 + ph) * 9) for x_ in range(-40, W + 60, 30)]
        d.line(pts, fill=tuple(int(c * 0.55) for c in col) + (255,), width=9, joint="curve")
    for k in range(-2, 24):
        x0 = k * 60 - (pan % 120) + off
        d.polygon([(x0, fy + 12), (x0 + 30, fy + 12), (x0 + 14, fy + 30), (x0 - 16, fy + 30)], fill=(GLD[0] // 2, GLD[1] // 2, 20, 255))
    for k in range(-1, 12):
        x0 = k * 130 - (pan % 130) + off
        d.rounded_rectangle((x0 + 8, fy + 150, x0 + 118, fy + 250), radius=10, outline=(20, 62, 78, 255), width=3)
        d.rounded_rectangle((x0 + 20, fy + 330, x0 + 106, fy + 400), radius=10, outline=(18, 56, 70, 255), width=3)
    # ceiling cables + lamps
    for k in range(4):
        cx_ = (k * 330 + 90 - pan * 0.4) % 1400 - 150 + off
        d.line([(cx_, 380), (cx_, 440 + 20 * k % 3)], fill=(30, 90, 108, 255), width=5)
        d.polygon([(cx_ - 34, 470 + 20 * k % 3), (cx_ + 34, 470 + 20 * k % 3), (cx_ + 18, 440 + 20 * k % 3), (cx_ - 18, 440 + 20 * k % 3)], fill=(46, 120, 138, 255))
    if alert > 0.01:
        tint(layer, (190, 30, 20), 0.22 * alert * (0.5 + 0.5 * _m.sin(now * 9)))


def sweepy(layer, now, pan=0.0, y=1488):
    """tiny cleaning robot rolling along the floor, bumps into the edges and turns."""
    per = 7.0
    ph = (now % per) / per
    u = 1 - abs(2 * ph - 1)
    x = lerp(120, 960, ease(clamp01(u * 1.6)) if False else u) - pan * 0.0
    face = 1 if ph < 0.5 else -1
    def fn(d, k):
        p = SP(d, k)
        p.rr((8, 24, 148, 70), 22, (200, 207, 216), 6)
        p.rr((28, 12, 128, 36), 10, (150, 158, 170), 6)
        p.el((98, 30, 132, 62), (255, 255, 255), 5)
        p.el((114, 40, 126, 54), INKB, 0)
        p.ln([(40, 12), (36, -2)], 4)
        p.el((30, -10, 42, 2), RED, 4)
        p.el((18, 60, 50, 80), (40, 48, 64), 5)
        p.el((106, 60, 138, 80), (40, 48, 64), 5)
    tile = _svc(("sweepy",), 160, 84, fn)
    if face < 0:
        tile = tile.transpose(Image.FLIP_LEFT_RIGHT)
    bob = abs(_m.sin(now * 12)) * 2
    blit(layer, tile, x, y - bob, 80, 80, 1.0, 1.0, 0)


# ---------------------------------------------------------------- frame furniture
def sv_header(img, spec, now, total):
    d = ImageDraw.Draw(img)
    d.rectangle((0, 0, W, 366), fill=(5, 18, 26, 255))
    d.rectangle((0, 366, W, 374), fill=TLP + (255,))
    d.rectangle((0, 214, W, 222), fill=(16, 52, 66, 255))
    d.rectangle((0, 214, int(W * clamp01(now / total)), 222), fill=GLD + (255,))
    mv = float(spec["move_pct"])
    chip = f"{spec.get('ticker', '')} {'+' if mv >= 0 else '-'}{abs(mv):g}%"
    f = font("bold", 50)
    tw = int(d.textlength(chip, font=f))
    cw = tw + 56
    spill(img, 60 + cw / 2 - 12, 272, chip, 50, TLP, tc=INKB, padx=28, h=70, ow=5)
    d = ImageDraw.Draw(img)
    d.text((60 + cw + 22, 272), "Lattice - morning trading", font=font("bold", 32), fill=CRM + (255,), anchor="lm")
    d.text((W - 60, 250), "WHY IT", font=font("bold", 30), fill=GLD + (255,), anchor="rm")
    d.text((W - 60, 284), "MOVED?", font=font("bold", 30), fill=CRM + (255,), anchor="rm")
    d.text((60, 313), "Educational only - not financial advice", font=font("medium", 25), fill=DIMC + (255,), anchor="lm")
    d.text((60, 346), "DRAMATIZATION - CARTOON, NOT REAL EVENTS", font=font("bold", 34), fill=(170, 186, 194, 255), anchor="lm")
    d.text((540, 1486), "DRAMATIZATION - NOT FINANCIAL ADVICE", font=font("bold", 36), fill=(120, 150, 160, 255), anchor="mm")


SV_TR = 0.42


def _sv_layer(b, tb, spec, z_extra=1.0):
    CAM.update(z=1.0, px=540.0, py=960.0, dx=0.0, dy=0.0, rot=0.0)
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    SCENES[b["visual"]["type"]](layer, b["visual"], tb, spec, b["cues"])
    CAM["z"] *= z_extra
    return cam_apply(layer)


def sv_frame(spec, beats, now, total, kw_times, dbg=False):
    bi = 0
    for i, b_ in enumerate(beats):
        if now >= b_["start"] - 1e-6:
            bi = i
    b = beats[bi]
    tb = now - b["start"]
    punch = max([0.0] + [max(0.0, 1 - abs(now - kt - 0.08) / 0.14) for kt in kw_times if -0.1 < now - kt < 0.3])
    zx = 1 + 0.014 * punch
    layer = _sv_layer(b, tb, spec, zx)
    if bi > 0 and tb < SV_TR:
        u = ease(tb / SV_TR)
        pv = beats[bi - 1]
        prev = _sv_layer(pv, (b["start"] - pv["start"]) + tb, spec, zx)
        base = Image.new("RGBA", (W, H), NAVY + (255,))
        base.paste(prev, (-int(u * W), 0))
        base.paste(layer, (int((1 - u) * W), 0))
        a = _m.sin(_m.pi * clamp01(tb / SV_TR))
        rnd = _rnd.Random(int(now * 30))
        dd = ImageDraw.Draw(base)
        for _ in range(14):
            yy = rnd.randint(400, 1500)
            x0 = rnd.randint(0, W)
            ln_ = int(rnd.uniform(200, 520) * a)
            dd.rounded_rectangle((x0 - ln_ // 2, yy, x0 + ln_ // 2, yy + 5), radius=2, fill=(220, 240, 245, int(150 * a)))
        layer = base
    sv_header(layer, spec, now, total)
    if dbg:
        dd = ImageDraw.Draw(layer)
        dd.rectangle((0, 1310, W, 1430), outline=(255, 0, 255, 255), width=3)
        dd.line([(0, 1520), (W, 1520)], fill=(255, 0, 255, 255), width=3)
    return layer


# ---------------------------------------------------------------- BEAT 1: hook
ICON_SEQ = ["wrench", "shield", "wrench", "magnifier", "shield", "wrench"]


def hook_draw(img, t, tt, tc, td, final=False):
    reveal = clamp01((t - tc) / 0.7)
    sv_bg(img, t, pan=t * 24, mode="hook", reveal=reveal)
    if reveal > 0.4:
        sweepy(img, t, t * 24)
    # rising gold chevrons after the slam
    if t >= tt:
        k = t - tt
        dd = ImageDraw.Draw(img)
        for i in range(12):
            sp_ = 260 + 40 * (i % 4)
            y = 1230 - ((k * sp_ + i * 137) % 860)
            x = 60 + i * 86 + _m.sin(k * 2 + i) * 12
            a = clamp01(k / 0.3) * clamp01((y - 420) / 120)
            if a < 0.05:
                continue
            s_ = 20 + 6 * (i % 3)
            col = TLP if i % 2 == 0 else GLD
            dd.polygon([(x, y - s_), (x + s_, y + s_ * 0.2), (x + s_ * 0.45, y + s_ * 0.2), (x + s_ * 0.45, y + s_),
                        (x - s_ * 0.45, y + s_), (x - s_ * 0.45, y + s_ * 0.2), (x - s_, y + s_ * 0.2)], fill=col + (255,), outline=INKB + (255,))
    # Patch
    cyc = 0.75
    ci = int(t / cyc)
    k = t - ci * cyc
    icon = ICON_SEQ[ci % len(ICON_SEQ)]
    sq = 0.2 * _m.exp(-11 * k) * _m.cos(30 * k) if (ci > 0 or final is False) else 0.0
    if ci == 0:
        sq = 0.0
    sx, sy = 1 + sq * 0.9, 1 - sq
    px, py = 540, 1086 - abs(_m.sin(t * 5.0)) * 8
    eyes = "lookup"
    mouth = "smile"
    al = ar = 8
    if t >= tt:
        kk = t - tt
        eyes = "wide" if kk < 0.45 else "happy"
        mouth = "grin" if kk < 3 else "open"
        al = ar = 150 + _m.sin(kk * 14) * 16 if kk < 2.2 else 40
        py -= 70 * _m.sin(clamp01(kk / 0.4) * _m.pi)
        sy *= 1 + 0.12 * _m.sin(clamp01(kk / 0.4) * _m.pi)
    elif blink_at(t, 0.3):
        eyes = "blink"
    put_patch(img, px, py, 1.6, sx, sy, 0, icon=icon, eyes=eyes, mouth=mouth, al=al, ar=ar)
    # sparkle ring on icon swap
    if ci > 0 and k < 0.35:
        rr_ = 40 + 120 * ease(k / 0.35)
        ImageDraw.Draw(img).ellipse((px - rr_, py - 300 - rr_ * 0.5, px + rr_, py - 300 + rr_ * 0.5), outline=GLD + (int(255 * (1 - k / 0.35)),), width=7)
    # +13%
    sc = 1.0 + 0.02 * _m.sin(t * 4)
    rot = -3.0
    cy13 = 520 + _m.sin(t * 2.4) * 5
    if t >= tt:
        kk = t - tt
        sc = lerp(1.4, 1.0, spr(kk, 14, 6)) if kk < 1.0 else 1.0 + 0.02 * _m.sin(t * 4)
        rot = -3.0 + _m.sin(kk * 20) * 5 * _m.exp(-4 * kk)
        if kk < 0.6:
            e = ease(kk / 0.3)
            sburst(img, 540, 520, 170 + 90 * e, 270 + 120 * e, 12, kk * 0.6, (255, 214, 92, 255), 8, alpha=clamp01(1 - kk / 0.6))
    stext(img, (540, cy13), "+13%", 250, GLD, sw=18, rot=rot, sc=sc)
    spill(img, 540, 636, "MORNING TRADING", 56, TLP, tc=INKB, padx=34, h=84, ow=6)
    # text lines
    if t < tc + 0.05:
        a = pop((t - 0.0 + 0.3) / 0.3) if not final else 1.0
        stext(img, (540, 1180), "WHY? A CHIP THAT", 60, CRM, sw=9, sc=max(0.01, a) * (1 - clamp01((t - tc) / 0.2)))
        stext(img, (540, 1250), "CHANGES JOBS.", 64, GLD, sw=9, sc=max(0.01, a) * (1 - clamp01((t - tc) / 0.2)))
    if t >= tc:
        a = pop((t - tc) / 0.3)
        stext(img, (540, 1180), "AS A CARTOON", 70, CRM, sw=10, sc=a)
    if t >= td:
        k2 = t - td
        pulse = 1 + 0.08 * _m.sin(k2 * 16) * _m.exp(-3 * k2)
        spill(img, 540, 1256, "DRAMATIZATION", 58, RED, tc=CRM, padx=40, sc=pop(k2 / 0.3) * pulse, ow=7)
    if t >= tt and t < tt + 0.35:
        sx_, sy_ = shake(14 * (1 - (t - tt) / 0.35), t)
        CAM["dx"], CAM["dy"] = sx_, sy_
        CAM["z"] = 1 + 0.05 * _m.sin(clamp01((t - tt) / 0.35) * _m.pi)


def scene_sv_hook(img, v, t, spec, cues):
    hook_draw(img, t, cues.at("thirteen", 1.0), cues.at("cartoon", 3.5), cues.at("dramatization", 4.2))


GY = 1190


def wobble_in(t, t0, dur=0.5):
    return clamp01((t - t0) / dur)


def pegboard(img, t, hot=None, used=()):
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((40, 640, 1040, 860), radius=22, fill=(22, 66, 82, 255), outline=(30, 92, 112, 255), width=6)
    for gx in range(70, 1030, 46):
        for gy in range(662, 850, 46):
            d.ellipse((gx - 3, gy - 3, gx + 3, gy + 3), fill=(14, 44, 58, 255))
    for i, (kind, x) in enumerate((("wrench", 200), ("magnifier", 540), ("shield", 880))):
        if kind in used:
            continue
        d.rounded_rectangle((x - 70, 668, x + 70, 832), radius=16, fill=(12, 40, 52, 255))
        T = _ss(160, 160, lambda dd, k, kind=kind: draw_icon(SP(dd, k), kind, 80, 84, 1.3, (176, 210, 214), (12, 40, 52)))
        put(img, T, x - 80, 664 + (-10 if hot == kind else 0))


def conveyor(img, t, y=600):
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((20, y + 30, 1060, y + 60), radius=14, fill=(20, 60, 76, 255), outline=(30, 92, 112, 255), width=4)
    for k in range(-1, 18):
        x = k * 70 + (t * 80) % 70
        d.ellipse((x - 8, y + 38, x + 8, y + 54), fill=(12, 40, 52, 255))
    for k in range(5):
        x = ((k * 260 + t * 80) % 1300) - 110
        done = x > 540
        d.rounded_rectangle((x, y - 6, x + 56, y + 32), radius=8, fill=(TLP if done else GRY) + (255,), outline=INKB + (255,), width=4)
        for q in range(3):
            d.line([(x + 12 + q * 16, y - 14), (x + 12 + q * 16, y - 6)], fill=PINC + (255,), width=4)


def card_text(img, cx, cy, w, h, lines, sizes, cols, sc=1.0, fill=(10, 36, 46)):
    T = _ss(w + 24, h + 24, lambda d, k: SP(d, k).rr((10, 10, w + 10, h + 10), 30, fill, 8))
    dd = ImageDraw.Draw(T)
    n = len(lines)
    tot = sum(sizes) * 1.12
    y = (h + 24) / 2 - tot / 2
    for ln_, sz, col in zip(lines, sizes, cols):
        y += sz * 0.56
        dd.text(((w + 24) / 2, y), ln_, font=font("bold", sz), fill=col + (255,), anchor="mm")
        y += sz * 0.56
    blit(img, T, cx, cy, (w + 24) / 2, (h + 24) / 2, sc, sc, 0)


# ---------------------------------------------------------------- BEAT 2: meet Patch and Fred
def c2(c):
    return dict(tp=c.at("Patch", 0.15), tpr=c.at("programmable", 3.0), tcu=c.at("customized", 4.3), tsw1=c.at("switch", 7.1),
                tsw2=c.at("jobs", 7.45), tfx=c.at("Fixed", 7.95), tcant=c.at("cannot", 8.5), tone=c.at("one", 9.6), tfor=c.at("Forever", 10.3),
                tlat=c.at("Lattice", 1.4))


def scene_sv_meet(img, v, t, spec, cues):
    q = c2(cues)
    sv_bg(img, t, pan=t * 18, mode="bench")
    conveyor(img, t)
    icon = "none"
    hot = None
    used = []
    if t >= q["tcu"]:
        icon = "wrench"; used = ["wrench"]; hot = None
    if t >= q["tsw1"]:
        icon = "magnifier"; used = ["magnifier"]
    if t >= q["tsw2"]:
        icon = "shield"; used = ["shield"]
    if t >= q["tfx"]:
        icon = "wrench"; used = ["wrench"]
    pegboard(img, t, hot, used)
    sweepy(img, t, t * 18)
    # swap time (latest)
    sw_ts = [x for x in (q["tcu"], q["tsw1"], q["tsw2"], q["tfx"] + 0.15) if t >= x]
    ks = t - sw_ts[-1] if sw_ts else 9.0
    sq = 0.22 * _m.exp(-10 * ks) * _m.cos(28 * ks) if ks < 1 else 0
    ent = spr(t - 0.0, 12, 5.5)
    py = GY - (1 - ent) * 700
    px = 320
    eyes = "open"; mouth = "smile"; al = ar = 8
    if blink_at(t, 0.5):
        eyes = "blink"
    if t >= q["tpr"] and t < q["tcu"] + 1.2:
        eyes = "happy"; mouth = "grin"
    if q["tsw1"] <= t < q["tfx"]:
        eyes = "wide"; mouth = "open"; al, ar = 120 + swob(t, 3, 30), 120 - swob(t, 3, 30)
    if t >= q["tfx"]:
        eyes = "lookr"; mouth = "smirk"; ar = 90
    if t >= q["tfor"]:
        mouth = "smirk"
    hop = abs(_m.sin(t * 3.2)) * 6 if t > 0.9 else 0
    put_patch(img, px, py - hop, 1.55, 1 + sq * 0.9, 1 - sq, swob(t, 0.8, 1.2), icon=icon, eyes=eyes, mouth=mouth, al=al, ar=ar, cheeks=1 if t > q["tpr"] else 0)
    if ks < 0.4:  # spark ring + tool trail
        rr_ = 30 + 130 * ease(ks / 0.4)
        ImageDraw.Draw(img).ellipse((px - rr_, py - 300 - rr_ * 0.5, px + rr_, py - 300 + rr_ * 0.5), outline=GLD + (int(255 * (1 - ks / 0.4)),), width=7)
    # name tag
    if t >= q["tp"]:
        k = t - q["tp"]
        spill(img, 320, 690, "PATCH", 62, TLP, tc=INKB, padx=34, sc=pop(k / 0.3), rot=-4 + swob(t, 0.7, 2), ow=7)
    # programmable chip
    if q["tpr"] <= t < q["tfx"] - 0.1:
        k = t - q["tpr"]
        if t < q["tcu"]:
            spill(img, 540, 500, "PROGRAMMABLE", 70, GLD, tc=INKB, padx=44, sc=pop(k / 0.3), ow=7)
        else:
            card_text(img, 540, 510, 880, 250, ["PROGRAMMABLE =", "CUSTOMIZED AFTER", "MANUFACTURING"], [60, 60, 60], [GLD, CRM, CRM], sc=pop((t - q["tcu"]) / 0.3))
    # Fred
    if t >= q["tfx"] - 0.1:
        k = t - (q["tfx"] - 0.1)
        fx = lerp(1350, 790, ease(k / 0.55))
        land = max(0.0, k - 0.55)
        fsq = 0.1 * _m.exp(-9 * land) * _m.cos(22 * land) if k > 0.55 else 0
        eff = 0.0; eyes = "sad"; mouth = "frown"; ghost = 0; jx = 0; sw_ = 0
        if q["tcant"] - 0.5 <= t < q["tone"] - 0.2:
            eff = clamp01((t - (q["tcant"] - 0.5)) / 0.4); eyes = "strain"; mouth = "grit"
            jx = _m.sin(t * 60) * 5 * eff
            ghost = 1 if int(t * 8) % 2 == 0 else 0
        if t >= q["tfor"]:
            sw_ = 1
        put_fred(img, fx + jx, GY + 14, 1.4, 1 + fsq * 0.8, 1 - fsq, 0, eyes=eyes, mouth=mouth, ghost=ghost, effort=round(eff, 1), sweat=1 if eff > 0.5 else sw_)
        if t >= q["tcant"]:
            kk = t - q["tcant"]
            if kk < 1.4:
                bubble(img, (560, 640, 1020, 790), tail=(790, 880), fill=(255, 255, 255, 255))
                stext(img, (790, 715), "CAN'T!", 84, RED, sw=0, sc=max(0.01, spr(kk, 16, 6)), rot=swob(t, 6, 3) * (1 - kk / 1.4))
        if t >= q["tone"] and t < q["tfor"] + 0.2:
            spill(img, 790, 560, "ONE JOB", 64, GLD, tc=INKB, padx=40, sc=pop((t - q["tone"]) / 0.3), ow=7)
        if t >= q["tfor"]:
            kk = t - q["tfor"]
            stext(img, (540, 520), "FOREVER.", 110, CRM, sw=12, sc=max(0.01, pop(kk / 0.3)), rot=-3)
            # drip + cobweb + spider
            sp_y = 640 + 120 * ease(kk / 0.8)
            dd = ImageDraw.Draw(img)
            dd.line([(950, 400), (950, sp_y)], fill=(210, 220, 224, 255), width=3)
            dd.ellipse((935, sp_y, 965, sp_y + 28), fill=(30, 30, 40, 255), outline=INKB + (255,))
            for lg in (-1, 1):
                for j in range(3):
                    dd.line([(950, sp_y + 14), (950 + lg * (22 + j * 6), sp_y + 4 + j * 9)], fill=(30, 30, 40, 255), width=3)
    if t < 0.5 and False:
        pass


# ---------------------------------------------------------------- BEAT 3: Rack panics, slots fill
def c3(c):
    return dict(tpan=c.at("panic", 2.0), tslot=c.at("Every", 2.55), thelp=c.at("helper", 3.8), tmg=c.at("management", 4.6),
                tmore=c.at("more", 6.3), teach=c.at("each", 7.2), trk=c.at("Rack", 0.4), tai=c.at("AI", 0.9))


RKX, RKS = 790, 0.85


def scene_sv_rack(img, v, t, spec, cues):
    q = c3(cues)
    alert = clamp01((t - q["tpan"]) / 0.5)
    sv_bg(img, t, pan=t * 22, mode="hall", alert=alert * (1 - clamp01((t - q["teach"]) / 1.0)))
    sweepy(img, t, t * 22)
    # cell timeline
    fill_t = {}
    for i in range(8):
        fill_t[i] = q["thelp"] + 0.45 + i * 0.16 if i < 2 else q["tmore"] + 0.45 + (i - 2) * 0.13
    cells = {}
    for i in range(8):
        tq_ = q["tslot"] + i * 0.1
        if t >= fill_t[i]:
            cells[i] = ("ok", t - fill_t[i])
        elif t >= tq_:
            cells[i] = ("q", t - tq_)
    ent = clamp01((t - 0.0) / 0.45)
    rx = lerp(1500, RKX, ease(ent))
    lsq = 0.0
    if t > 0.45:
        k = t - 0.45
        lsq = 0.08 * _m.exp(-7 * k) * _m.cos(20 * k)
    shk = 0.0
    if q["tpan"] <= t < q["teach"] + 0.6:
        shk = 7 * (1 - clamp01((t - q["teach"]) / 0.6))
    ox, oy = shake(shk, t, 40) if shk else (0, 0)
    panic = alert
    mouth = "worry" if t < q["teach"] else "relief"
    if t >= q["tpan"] and t < q["tslot"] + 0.3:
        mouth = "shout"
    look = -0.8 + 0.2 * _m.sin(t * 3)
    put_rack(img, rx + ox, GY + 36 + oy, RKS, 1 + lsq * 0.7, 1 - lsq, 0, look=look, blink=1.0 if blink_at(t, 0.2, 2.6) else 0.0,
             mouth=mouth, panic=panic, cells=cells, now=t, brow=1.0 if t < q["teach"] else 0.0)
    # sweat drops
    if t >= q["tpan"]:
        k = t - q["tpan"]
        rnd = _rnd.Random(3)
        dd = ImageDraw.Draw(img)
        for j in range(9):
            tj = j * 0.12
            kk = k - tj
            if kk < 0 or kk > 1.2:
                continue
            ang = rnd.uniform(-2.6, -0.5)
            sp_ = rnd.uniform(350, 620)
            x = rx - 40 + _m.cos(ang) * sp_ * kk
            y = 560 + _m.sin(ang) * sp_ * kk + 1100 * kk * kk
            dd.polygon([(x, y - 20), (x - 11, y + 8), (x, y + 18), (x + 11, y + 8)], fill=(140, 210, 255, 255), outline=INKB + (255,))
    # Patch hero
    if t >= 0.0:
        px = 250
        eyes = "lookr"; mouth = "open"; al = 20; ar = 60
        if blink_at(t, 0.9):
            eyes = "blink"
        py = GY
        sq = 0.0
        # launch squash for each clone
        for i in range(8):
            ln_ = fill_t[i] - 0.45
            if 0 <= t - ln_ < 0.3:
                sq = max(sq, 0.2 * _m.sin(_m.pi * (t - ln_) / 0.3))
        if t >= q["thelp"]:
            eyes = "happy"; mouth = "grin"; ar = 150
        put_patch(img, px, py, 1.4, 1 - sq * 0.4, 1 + sq * 0.5, 0, icon="wrench", eyes=eyes, mouth=mouth, al=al, ar=ar, cheeks=1)
    # flying copies
    for i in range(8):
        ln_ = fill_t[i] - 0.45
        u = (t - ln_) / 0.45
        if 0 <= u < 1:
            cx0, cy0 = 300, GY - 190
            tx, ty = rack_cell_xy(i, rx, GY + 36, RKS)
            e = ease(u)
            x = lerp(cx0, tx, e)
            y = lerp(cy0, ty + 20, e) - 220 * _m.sin(_m.pi * u)
            put_patch(img, x, y, 0.36, 1, 1, u * 360, icon="none", eyes="happy", mouth="grin", al=100, ar=100)
    if t >= q["tmg"]:
        card_text(img, 285, 560, 500, 270, ["MGMT SAYS:", "MORE CHIPS", "PER SERVER"], [56, 62, 62], [GLD, CRM, CRM], sc=pop((t - q["tmg"]) / 0.3) * (1 - 0 * t))
    if t >= q["tpan"] and t < q["tpan"] + 1.0:
        spill(img, 285, 560, "PANIC!", 90, RED, tc=CRM, padx=50, sc=pop((t - q["tpan"]) / 0.25), rot=-5 + swob(t, 8, 3), ow=8)
    if q["tpan"] <= t < q["tpan"] + 0.4:
        CAM["dx"], CAM["dy"] = shake(10 * (1 - (t - q["tpan"]) / 0.4), t)


# ---------------------------------------------------------------- BEAT 4: the bet and the record
def c4(c):
    return dict(tf=c.at("Forecasters", 0.2), tw=c.at("Wall", 1.3), tbet=c.at("bet", 2.6), t256=c.at("two hundred", 3.4), t56=c.at("fifty-six", 4.3),
                tsold=c.at("sold", 5.9), t91=c.at("ninety-one", 6.7), trec=c.at("record", 8.1), t118=c.at("up", 8.7), te=c.at("eighteen", 9.5))


STK_X, STK_PX = 640, 1.9


def draw_stack(img, h, wob=0.0):
    d = ImageDraw.Draw(img)
    base = GY + 6
    n = int(h // 15)
    for i in range(n):
        yy = base - (i + 1) * 15
        ox = _m.sin(i * 1.9) * 4 + _m.sin(wob * 14 + i) * 2 * min(1, i / 8)
        d.rounded_rectangle((STK_X - 90 + ox, yy, STK_X + 90 + ox, yy + 17), radius=8, fill=(GLD if i % 2 == 0 else (240, 176, 40)) + (255,), outline=INKB + (255,), width=4)
    d.rounded_rectangle((STK_X - 110, base - 4, STK_X + 110, base + 22), radius=8, fill=(60, 80, 96, 255), outline=INKB + (255,), width=5)


def scene_sv_bet(img, v, t, spec, cues):
    q = c4(cues)
    sv_bg(img, t, pan=-t * 20 + 200, mode="bay")
    sweepy(img, t, 0)
    # spotlight cone
    tint(img, (255, 230, 150), 0.0)
    gtop = lambda val: GY + 6 - val * STK_PX
    val = 0.0
    if t >= q["tsold"]:
        val = 291 * ease((t - q["tsold"]) / (q["t91"] + 0.5 - q["tsold"]))
    draw_stack(img, val * STK_PX, t)
    # bots walking in
    mood = "smug"
    for i in (0, 1):
        d0 = q["tf"] + 0.3 * i
        u = clamp01((t - d0) / 1.1)
        x = lerp(-220, (130, 350)[i], ease(u))
        walking = 0 < u < 1
        ph = t * 15
        leg = _m.sin(ph) if walking else 0
        dy = -abs(_m.sin(ph)) * 10 if walking else 0
        clip = ""
        if t >= q["tbet"]:
            clip = "$256M"
        mood = "smug"
        if t >= q["trec"]:
            mood = "worry"
        jaw = 0.0
        sq = 0.0
        if u >= 1:
            k = t - (d0 + 1.1)
            sq = 0.07 * _m.exp(-8 * k) * _m.cos(18 * k)
        put_bot(img, i, x, GY + 20 + dy, 1.05, 1 + sq, 1 - sq, _m.sin(ph) * 3 if walking else 0, mood=mood, leg=leg, clip=clip, sweat=1 if t >= q["trec"] + 0.3 else 0, jaw=0.0)
    # Patch + coin toss
    ent = clamp01((t - 0.2) / 0.4)
    pa = 8
    if q["tsold"] <= t < q["t91"] + 0.5:
        pa = 100 + swob(t, 5, 40)
    eyes, mouth = ("happy", "grin") if t >= q["tsold"] else ("open", "smile")
    sqp = 0.0
    if t >= q["trec"]:
        sqp = 0.06 * _m.sin((t - q["trec"]) * 16) * _m.exp(-(t - q["trec"]) * 2)
    put_patch(img, 910, GY + 6 - (1 - spr(t, 12, 6)) * 600, 1.2, 1 - sqp, 1 + sqp, 0, icon="wrench", eyes=eyes, mouth=mouth, al=pa, ar=8, cheeks=1)
    if q["tsold"] <= t < q["t91"] + 0.5:
        for j in range(12):
            tj = q["tsold"] + 0.08 + j * 0.1
            u = (t - tj) / 0.45
            if 0 <= u < 1:
                x = lerp(870, STK_X, ease(u))
                y = lerp(GY - 150, gtop(val) - 10, ease(u)) - 160 * _m.sin(_m.pi * u)
                ImageDraw.Draw(img).ellipse((x - 20, y - 8, x + 20, y + 10), fill=GLD + (255,), outline=INKB + (255,), width=4)
    # labels
    if q["tw"] <= t < q["tbet"]:
        spill(img, 260, 560, "ANALYST BOTS", 62, BOTC, tc=CRM, padx=40, sc=pop((t - q["tw"]) / 0.3), ow=7)
    if q["tbet"] <= t < q["trec"] - 0.05:
        n256 = int(256 * ease((t - q["t256"]) / (q["t56"] + 0.3 - q["t256"]))) if t >= q["t256"] else 0
        txt = f"${n256}M BET" if t >= q["t256"] else "THE BET"
        spill(img, 270, 560, txt, 66, CRM, tc=RED, padx=40, sc=pop((t - q["tbet"]) / 0.3), ow=7, w_min=420)
    if t >= q["t56"]:
        dashed(img, 30, 740, int(gtop(256)), RED, ease((t - q["t56"]) / 0.4), w=8)
    if val > 1:
        spill(img, STK_X + 60, max(430, gtop(val) - 70), f"${int(val)}M", 78, GLD, tc=INKB, padx=34, ow=7, sc=1.0)
    if t >= q["trec"]:
        k = t - q["trec"]
        sc = lerp(2.2, 1.0, spr(k, 16, 7)) if k < 0.8 else 1.0
        stext(img, (640, 880), "RECORD Q3", 104, RED, sw=14, rot=-12, sc=sc)
        if k < 0.5:
            CAM["dx"], CAM["dy"] = shake(12 * (1 - k / 0.5), t)
            sburst(img, 640, 880, 160 + 120 * ease(k / 0.4), 260 + 150 * ease(k / 0.4), 12, k, (255, 214, 92, 255), 8, alpha=1 - k / 0.5)
    if t >= q["t118"]:
        k = t - q["t118"]
        n118 = int(118 * ease(k / max(0.3, q["te"] + 0.3 - q["t118"]))) if k < 5 else 118
        card_text(img, 300, 470, 520, 190, [f"+{n118}%", "vs A YEAR AGO"], [92, 56], [GLD, CRM], sc=pop(k / 0.3))


# ---------------------------------------------------------------- BEAT 5: shock, but wait, the note
def c5(c):
    return dict(tsh=c.at("shocked", 0.7), tbut=c.at("But", 1.2), tpin=c.at("pins", 1.6), tnote=c.at("note", 2.0), tgu=c.at("guidance", 5.0),
                t335=c.at("three hundred", 5.9), tmil=c.at("million", 7.3))


def scene_sv_shock(img, v, t, spec, cues):
    q = c5(cues)
    FZ = 0.4
    ta = t if t < q["tbut"] else (q["tbut"] if t < q["tbut"] + FZ else t - FZ)
    sv_bg(img, ta, pan=ta * 20, mode="hall", alert=0.0)
    sweepy(img, ta, ta * 20)
    # rack (idle, worried) right
    put_rack(img, 840, GY + 36, 0.9, look=-0.6, blink=0.0, mouth="relief" if ta > q["tnote"] else "worry", cells={i: ("ok", 5.0) for i in range(8)}, now=ta, brow=0.0)
    # bots
    for i in (0, 1):
        x = (150, 360)[i]
        kk = max(0.0, ta - q["tsh"])
        jaw = spr(kk, 14, 6) * 1.0 if ta >= q["tsh"] else 0.0
        jaw = min(1.0, jaw)
        gl = clamp01(kk / 0.25) * (1 if ta >= q["tsh"] else 0)
        sn = 1 if ta >= q["tsh"] + 0.15 else 0
        hop = -abs(_m.sin(kk * 9)) * 20 * _m.exp(-kk * 2) if ta >= q["tsh"] else 0
        put_bot(img, i, x, GY + 20 + hop, 1.05, 1, 1, swob(ta, 6, 2) * _m.exp(-kk * 2) if ta >= q["tsh"] else 0, mood="shock" if ta >= q["tsh"] else "worry",
                jaw=round(jaw, 1), glass=round(gl, 1), clip="$256M" if ta < q["tsh"] else "", snap=sn, sweat=1)
    # pencil halves flying
    if t >= q["tsh"] + 0.15:
        k = t - q["tsh"] - 0.15
        if t >= q["tbut"]:
            k = q["tbut"] - q["tsh"] - 0.15 if t < q["tbut"] + FZ else k - FZ
        for sg, rot0 in ((-1, 1), (1, -1)):
            x = 100 + sg * 160 * k
            y = 900 - 420 * k + 1200 * k * k
            T = pencil_half(0 if sg < 0 else 1)
            blit(img, T, x, y, 22, 40, 2.0, 2.0, rot0 * k * 500)
    # Patch with note
    ppx = 600
    pj = 0.0
    if t >= q["tpin"] - 0.3 and t < q["tnote"] + 0.3:
        pj = 120 * _m.sin(clamp01((t - (q["tpin"] - 0.3)) / 0.6) * _m.pi)
    put_patch(img, ppx, GY - pj, 1.25, 1, 1, 0, icon="wrench", eyes="happy" if t > q["tnote"] else "lookl", mouth="grin" if t > q["tpin"] else "smirk", al=8, ar=150 if t < q["tnote"] else 60, cheeks=1)
    # BUT WAIT
    if q["tbut"] <= t < q["tbut"] + 1.0:
        k = t - q["tbut"]
        tint(img, (0, 0, 0), 0.35 * (1 - clamp01((k - FZ) / 0.4)))
        speed_lines(img, 540, 800, k, a=190)
        stext(img, (540, 760), "BUT WAIT", 150, RED, sw=16, rot=-4, sc=lerp(2.0, 1.0, spr(k, 16, 7)))
        if k < 0.3:
            CAM["dx"], CAM["dy"] = shake(12, t)
    # note
    if t >= q["tnote"]:
        k = t - q["tnote"]
        sc = lerp(2.4, 1.0, ease(k / 0.18)) if k < 0.18 else 1.0 + 0.05 * _m.exp(-12 * (k - 0.18)) * _m.cos(30 * (k - 0.18))
        T = _ss(760, 480, lambda d, kk: SP(d, kk).rr((14, 14, 746, 466), 18, (255, 226, 110), 9))
        dd = ImageDraw.Draw(T)
        dd.text((380, 96), "NEXT QUARTER,", font=font("bold", 58), fill=INKB + (255,), anchor="mm")
        dd.text((380, 164), "OUR OWN FORECAST:", font=font("bold", 58), fill=INKB + (255,), anchor="mm")
        if t >= q["t335"]:
            u = clamp01((t - q["t335"]) / 0.9)
            n = int(335 * ease(u))
            dd.text((380, 330), f"~${n}M", font=font("bold", 150), fill=(200, 40, 30, 255), anchor="mm")
        else:
            dd.text((380, 330), "~$???", font=font("bold", 150), fill=(150, 120, 60, 255), anchor="mm")
        dd.ellipse((350, 4, 410, 54), fill=RED + (255,), outline=INKB + (255,), width=6)
        blit(img, T, 540, 810, 380, 240, sc, sc, -3)
        if k < 0.4:
            ImageDraw.Draw(img).ellipse((540 - 500 * ease(k / 0.4), 810 - 200 * ease(k / 0.4), 540 + 500 * ease(k / 0.4), 810 + 200 * ease(k / 0.4)), outline=(255, 255, 255, int(255 * (1 - k / 0.4))), width=8)
    if t >= q["tgu"]:
        spill(img, 540, 1090, "= GUIDANCE", 76, GLD, tc=INKB, padx=50, sc=pop((t - q["tgu"]) / 0.3), ow=8)
    if t >= q["tmil"] - 0.05:
        k = t - q["tmil"]
        if k < 0.5:
            sburst(img, 540, 810, 300 + 150 * ease(k / 0.4), 380 + 200 * ease(k / 0.4), 14, k, (255, 214, 92, 255), 8, alpha=0.7 * (1 - k / 0.5))


# ---------------------------------------------------------------- BEAT 6: the gap (podium)
def c6(c):
    return dict(tavg=c.at("average", 0.9), tcons=c.at("consensus", 1.9), tonly=c.at("only", 2.8), t293=c.at("two hundred", 3.2), twh=c.at("Whoops", 5.0))


def pillar(img, x0, x1, top, base, col, lines, sizes, tcols, num, sc_a=1.0):
    h = base - top
    if h < 4:
        return
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((x0, top, x1, base + 20), radius=26, fill=col + (255,), outline=INKB + (255,), width=9)
    d.rounded_rectangle((x0 + 18, top + 14, x1 - 18, top + 28), radius=7, fill=mix(col, (255, 255, 255), 0.3) + (255,))
    y = top + 40
    for ln_, sz, tc in zip(lines, sizes, tcols):
        d.text(((x0 + x1) / 2, y + sz * 0.5), ln_, font=font("bold", sz), fill=tc + (255,), anchor="mm")
        y += sz * 1.12
    d.text(((x0 + x1) / 2, y + 58), num, font=font("bold", 110), fill=CRM + (255,), anchor="mm", stroke_width=8, stroke_fill=INKB + (255,))


def scene_sv_gap(img, v, t, spec, cues):
    q = c6(cues)
    sv_bg(img, t, pan=t * 20, mode="bay")
    base = 1250
    # teal pillar (guidance) already up
    th = 519 * spr(t - 0.05, 11, 6.5)
    ttop = base - th
    gk = t - q["tavg"]
    gh = 454 * spr(gk, 11, 6.5) if gk > 0 else 0
    if t >= q["tonly"]:
        gh *= 1 - 0.2 * ease((t - q["tonly"]) / 0.35)
    gtop = base - gh
    if gh > 4:
        pillar(img, 30, 510, gtop, base, (120, 140, 168), ["FORECASTERS'", "AVERAGE", "(CONSENSUS)"], [56, 56, 56], [CRM, CRM, CRM], "$293M")
    pillar(img, 570, 1050, ttop, base, TLP, ["PATCH'S", "FORECAST", "(GUIDANCE)"], [56, 56, 56], [INKB, INKB, INKB], "$335M")
    # characters
    if th > 300:
        k = max(0.0, t - 0.5)
        put_patch(img, 810, ttop + 6, 0.98, 1, 1 - 0.04 * _m.sin(t * 5), 0, icon="shield", eyes="happy" if t < q["twh"] else "open", mouth="smirk" if t > q["tonly"] else "grin", al=130 + swob(t, 2, 20), ar=8, cheeks=1)
    if gh > 60:
        slip = t >= q["twh"]
        kk = t - q["twh"]
        bs = 0.76
        put_bot(img, 0, 270 + (-30 * ease(kk / 0.5) if slip else 0), gtop + 8 + (0 if not slip else 0), bs, 1, 1, (swob(t, 5, 6) * 1 if not slip else -25 * ease(kk / 0.5)), mood="worry" if t >= q["tonly"] else "smug",
                sweat=1 if t >= q["tonly"] else 0, clip="")
    # gap bracket
    if t >= q["tcons"] + 0.6 and gh > 60:
        a = ease((t - q["tcons"] - 0.6) / 0.3)
        dd = ImageDraw.Draw(img)
        dd.line([(540, gtop), (540, ttop)], fill=GLD + (255,), width=10)
        dd.polygon([(540, ttop - 4), (524, ttop + 24), (556, ttop + 24)], fill=GLD + (255,))
        dd.polygon([(540, gtop + 4), (524, gtop - 24), (556, gtop - 24)], fill=GLD + (255,))
        stext(img, (540, ttop - 64), "GAP", 70, GLD, sw=10, sc=max(0.01, a))
    if q["tonly"] <= t < q["twh"]:
        spill(img, 300, 520, "ONLY", 90, RED, tc=CRM, padx=50, sc=pop((t - q["tonly"]) / 0.25), rot=-5 + swob(t, 8, 2), ow=8)
    if t >= q["twh"]:
        k = t - q["twh"]
        stext(img, (300, 520), "WHOOPS.", 96, CRM, sw=11, sc=max(0.01, pop(k / 0.3)), rot=-5)
        CAM["dx"], CAM["dy"] = shake(6 * _m.exp(-k * 6), t)


# ---------------------------------------------------------------- BEAT 7: erase, shout, sigh, jump
def c7(c):
    return dict(te=c.at("erase", 0.2), trk=c.at("Rack", 0.9), tsh=c.at("shouts", 1.6), tpat=c.at("Patches", 2.3), tfr=c.at("Fred", 2.95),
                tsi=c.at("sighs", 3.3), tag=c.at("Again", 3.85), tst=c.at("Shares", 4.8), tj=c.at("jumped", 5.1))


def scene_sv_erase(img, v, t, spec, cues):
    q = c7(cues)
    pan = 880 * ease((t - (q["tfr"] - 0.55)) / 0.5)
    sv_bg(img, t, pan=pan + t * 10, mode="hall", alert=0.0)
    wx = lambda x: x - pan
    sweepy(img, t, pan)
    # --- forecasters + eraser
    for i in (0, 1):
        x = wx((130, 350)[i])
        if x < -400:
            continue
        clip = "$293M" if t < q["te"] + 0.35 else ("" if t < q["te"] + 0.9 else "^")
        mood = "worry" if t < q["te"] + 0.9 else "grin"
        put_bot(img, i, x, GY + 20, 1.0, 1, 1, swob(t, 4, 2) if t >= q["te"] + 0.9 else 0, mood=mood, clip=clip, sweat=1 if t < q["te"] + 0.9 else 0, leg=0)
    if q["te"] <= t < q["te"] + 1.1 and pan < 10:
        u = (t - q["te"]) / 1.0
        ex = lerp(-100, 520, ease(u)) + _m.sin(t * 30) * 24
        ey = 1000 + _m.sin(t * 14) * 20
        blit(img, eraser_tile(), ex, ey, 110, 60, 1.4, 1.4, -12)
        rnd = _rnd.Random(11)
        dd = ImageDraw.Draw(img)
        for j in range(18):
            tj = q["te"] + j * 0.05
            kk = t - tj
            if 0 < kk < 0.8:
                x = lerp(-100, 520, ease((tj - q["te"]) / 1.0)) + rnd.uniform(-30, 30) + rnd.uniform(-200, 200) * kk
                y = 1000 + rnd.uniform(-60, 0) - 300 * kk + 1000 * kk * kk
                s_ = rnd.uniform(8, 16)
                dd.rounded_rectangle((x - s_, y - s_, x + s_, y + s_), radius=4, fill=(255, 168, 168, 255), outline=INKB + (255,), width=3)
    # --- Rack
    rx = wx(800)
    shout = q["tsh"] <= t < q["tsh"] + 1.1
    sqr = 0.1 * _m.sin(clamp01((t - q["tsh"]) / 0.4) * _m.pi) if shout else 0
    shk = shake(6, t, 40) if shout else (0, 0)
    cells = {i: ("ok", 5.0) for i in range(8)}
    put_rack(img, rx + shk[0], GY + 36 + shk[1], 0.9, 1 - sqr * 0.5, 1 + sqr, 0, look=-0.5, blink=1.0 if blink_at(t, 0.4, 2.2) else 0, mouth="shout" if shout else "worry",
             cells=cells, now=t, panic=1.0 if t < q["tsh"] + 1.1 else 0.0, brow=1.0)
    if t >= q["trk"] and t < q["tsh"]:
        for j in range(4):
            k = t - q["trk"] - j * 0.2
            if 0 < k < 1:
                x = rx - 60 + j * 22
                y = 600 + 800 * k * k - 400 * k
                ImageDraw.Draw(img).polygon([(x, y - 18), (x - 10, y + 8), (x, y + 16), (x + 10, y + 8)], fill=(140, 210, 255, 255), outline=INKB + (255,))
    if shout:
        k = t - q["tsh"]
        bubble(img, (50, 450, 690, 630), tail=(rx - 120, 720), fill=(255, 255, 255, 255))
        stext(img, (370, 540), "MORE PATCHES!", 70, RED, sw=0, sc=max(0.01, spr(k, 16, 6)))
        CAM["dx"], CAM["dy"] = shake(8 * _m.exp(-k * 4), t)
        ring = 100 + 500 * ease(k / 0.8)
        ImageDraw.Draw(img).ellipse((rx - ring, 560 - ring, rx + ring, 560 + ring), outline=(255, 255, 255, int(200 * (1 - k / 0.8))), width=8)
    # --- Patches rain
    for i in range(11):
        tj = q["tpat"] + i * 0.11
        k = t - tj
        if k < 0:
            continue
        fx = 960 + (i * 83) % 230
        fall = 0.5
        ground = GY - (i % 3) * 64
        if k < fall:
            y = lerp(380, ground, (k / fall) ** 2)
            sq = 0
        else:
            kk = k - fall
            y = ground - abs(_m.sin(kk * 7)) * 30 * _m.exp(-kk * 4)
            sq = 0.2 * _m.exp(-12 * kk) * _m.cos(30 * kk)
        put_patch(img, wx(fx), y, 0.5, 1 + sq, 1 - sq, 0, icon="none", eyes="happy" if k > fall else "wide", mouth="grin", al=40, ar=40)
    # --- Fred
    fxs = wx(1300)
    if fxs < 1500:
        hit = t - q["tfr"]
        sqf = 0.0
        eyes, mouth = "sad", "frown"
        if hit >= 0:
            sqf = 0.2 * _m.exp(-8 * hit) * _m.cos(24 * hit) if hit < 1.0 else 0
            eyes, mouth = ("squish", "frown") if hit < 0.4 else ("sad", "frown")
        if q["tsi"] <= t:
            eyes, mouth = "closed", "o"
        put_fred(img, fxs, GY + 14, 1.1, 1 + sqf * 0.8, 1 - sqf, 0, eyes=eyes, mouth=mouth)
        # a patch lands on Fred's head
        kp = t - (q["tfr"] - 0.35)
        if 0 <= kp:
            y = lerp(380, GY - 330, clamp01(kp / 0.35) ** 2) if kp < 0.35 else GY - 330 - abs(_m.sin((kp - 0.35) * 7)) * 20 * _m.exp(-(kp - 0.35) * 4)
            put_patch(img, fxs, y, 0.45, 1, 1, 0, icon="none", eyes="happy", mouth="grin", al=40, ar=40)
        for tk_, big in ((q["tsi"], 1.0), (q["tag"], 1.5)):
            k = t - tk_
            if 0 <= k < 1.3:
                u = k / 1.3
                gx = fxs + 60 + 140 * u
                gy_ = GY - 120 - 280 * u
                T = _ss(160, 160, lambda d, kk: draw_icon(SP(d, kk), "gear", 80, 80, 1.5 * big, (200, 206, 216), (11, 37, 48)))
                T.putalpha(T.getchannel("A").point(lambda a: int(a * (1 - u))))
                blit(img, T, gx, gy_, 80, 80, 0.8 + 0.6 * u, 0.8 + 0.6 * u, u * 90)
        if t >= q["tag"]:
            stext(img, (fxs + 160, 520), "AGAIN.", 100, CRM, sw=12, sc=max(0.01, pop((t - q["tag"]) / 0.3)), rot=4)
    # --- ladder + stock jump
    lx = wx(1700)
    if lx < 1500:
        dd = ImageDraw.Draw(img)
        for rail in (-90, 90):
            dd.rounded_rectangle((lx + rail - 11, 560, lx + rail + 11, 1290), radius=8, fill=(214, 220, 230, 255), outline=INKB + (255,), width=5)
        for yy in range(600, 1280, 70):
            dd.rounded_rectangle((lx - 90, yy, lx + 90, yy + 16), radius=6, fill=(160, 170, 184, 255), outline=INKB + (255,), width=4)
        if t >= q["tst"]:
            u = clamp01((t - q["tst"]) / (q["tj"] - q["tst"] - 0.05))
            step = int(u * 9)
            by = 1170 - step * 60 + abs(_m.sin(u * 9 * _m.pi)) * -20
            if t >= q["tj"]:
                k = t - q["tj"]
                by = lerp(1170 - 9 * 60, 640, ease(k / 0.35)) - 90 * _m.sin(_m.pi * clamp01(k / 0.35))
                sc = 1.0 + 0.2 * _m.sin(clamp01(k / 0.5) * _m.pi)
                if k < 0.7:
                    sburst(img, lx, 640, 160 + 80 * ease(k / 0.4), 250 + 120 * ease(k / 0.4), 12, k, (255, 214, 92, 255), 8, alpha=1 - k / 0.7)
            else:
                sc = 0.8
            spill(img, lx, by, "+13%", 96, GLD, tc=INKB, padx=38, sc=sc, ow=8)
            if t >= q["tj"]:
                stext(img, (lx, 520), "IN MORNING", 56, CRM, sw=8)
                stext(img, (lx, 584), "TRADING", 56, CRM, sw=8)


# ---------------------------------------------------------------- BEAT 8: lesson + loop
def c8(c):
    return dict(tg=c.at("guidance", 1.6), tc=c.at("consensus", 2.4), tab=c.at("above", 5.0), tit=c.at("above", 5.0) + 0.5, tth=c.at("that's", 6.0), tw=c.at("why", 6.3),
                tl0=c.at("Analysts", 0.1), th=c.at("Here,", 3.4), tcame=c.at("came", 4.2))


def scene_sv_close(img, v, t, spec, cues):
    q = c8(cues)
    img.paste(Image.new("RGBA", (W, H), NAVY + (255,)), (0, 0))
    rays(img, 540, 900, 0, 2400, 18, t * 0.1, (14, 50, 64), None, 0.5)
    for j in range(6):
        px_ = (j * 220 + 80 + t * (18 + 7 * j)) % 1300 - 110
        py_ = (470 + (j % 2) * 60 if j < 3 else 1130 + (j % 2) * 80) + _m.sin(t * 1.6 + j) * 16
        put_patch(img, px_, py_, 0.3 + 0.05 * (j % 3), 1, 1, swob(t, 0.4, 8) + j * 10, icon=("wrench", "magnifier", "shield")[j % 3], eyes="happy", mouth="smile", al=30, ar=30)
    LINES = [(["ANALYSTS", "COMPARE"], q["tl0"], None), (["GUIDANCE", "WITH"], q["tg"], (0, TLP, q["tg"])), (["CONSENSUS."], q["tc"], (0, GRY, q["tc"])),
             (["HERE,", "GUIDANCE"], q["th"], None), (["CAME", "IN", "ABOVE", "IT."], q["tcame"], (2, GLD, q["tab"]))]
    d = ImageDraw.Draw(img)
    size = 82
    f = font("bold", size)
    gap = 24
    outk = clamp01((t - (q["tth"] - 0.1)) / 0.25)
    for li, (words, tl_, hl) in enumerate(LINES):
        tl_ = max(0.1, tl_ - 0.1) if li else 0.1
        if t < tl_:
            continue
        widths = [int(d.textlength(w_, font=f)) for w_ in words]
        total = sum(widths) + gap * (len(words) - 1)
        pk = max(0.01, pop((t - tl_) / 0.3) * (1 - ease(outk)))
        y = 500 + li * 118
        x = 540 - total / 2
        xs = []
        for wi in range(len(words)):
            xs.append(x)
            x += widths[wi] + gap
        act = None
        if hl and t >= hl[2]:
            act = hl
            pr = ease((t - hl[2]) / 0.28)
            x0m, x1m = xs[hl[0]] - 14, xs[hl[0]] + widths[hl[0]] + 14
            ph = 102 * pk
            d.rounded_rectangle((x0m, y - ph / 2, x0m + (x1m - x0m) * pr, y + ph / 2), radius=26, fill=hl[1] + (255,), outline=INKB + (255,), width=6)
        for wi, w_ in enumerate(words):
            on = act is not None and wi == act[0]
            stext(img, (xs[wi] + widths[wi] / 2, y), w_, size, INKB if on else CRM, sw=0 if on else 8, sc=pk)
    if t >= q["tit"] and t < q["tth"] + 0.1:
        pk = pop((t - q["tit"]) / 0.3) * (1 - outk)
        spill(img, 470, 1130, "FOLLOW @whyitmoved", 60, RED, tc=CRM, padx=44, sc=max(0.01, pk), ow=8)
    if t < 0.5:
        rr_ = int(1800 * (1 - ease(t / 0.5)))
        ImageDraw.Draw(img).ellipse((540 - rr_, 960 - rr_, 540 + rr_, 960 + rr_), fill=TLP + (255,), outline=INKB + (255,), width=12)
    if t >= q["tth"]:
        k = t - q["tth"]
        hk = Image.new("RGBA", (W, H), (0, 0, 0, 255))
        hook_draw(hk, 0.0, 1.0, 3.5, 4.2, final=True)
        mask = Image.new("L", (W, H), 0)
        rr2 = int(1700 * ease(k / 0.35))
        ImageDraw.Draw(mask).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), fill=255)
        img.paste(hk, (0, 0), mask)
        if k < 0.35:
            ImageDraw.Draw(img).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), outline=INKB + (255,), width=10)


# ---------------------------------------------------------------- sound
def _ev2(v, c, st):
    q = c2(c)
    ev = [(st + q["tp"], "pop"), (st + q["tp"] + 0.1, "rubber"), (st + q["tpr"], "pop"), (st + q["tcu"], "sparkle"), (st + q["tsw1"], "boing"), (st + q["tsw2"], "boing"),
          (st + q["tfx"] - 0.1, "whoosh1"), (st + q["tfx"] + 0.5, "thud"), (st + q["tcant"], "scratch"), (st + q["tcant"] - 0.4, "tick"), (st + q["tone"], "stamp"), (st + q["tfor"], "trombone")]
    ev += [(st + q["tfx"] + 0.2 + j * 0.15, "tick") for j in range(0)]
    return ev


def _ev3(v, c, st):
    q = c3(c)
    ev = [(st + 0.3, "thud"), (st + q["tpan"] - 0.1, "alarm"), (st + q["tpan"] + 0.3, "alarm"), (st + q["tpan"] + 0.7, "alarm")]
    ev += [(st + q["tslot"] + i * 0.1, "pop") for i in range(8)]
    ev += [(st + q["thelp"] + 0.45 + i * 0.16, "pop") for i in range(2)]
    ev += [(st + q["tmore"] + 0.45 + i * 0.13, "pop") for i in range(6)]
    ev += [(st + q["tmg"], "stamp"), (st + q["teach"] + 0.6, "ding")]
    return ev


def _ev4(v, c, st):
    q = c4(c)
    ev = [(st + q["tf"] + 0.1, "tick"), (st + q["tw"], "pop"), (st + q["tbet"], "pop"), (st + q["t56"], "whoosh1"), (st + q["tsold"], "boing")]
    ev += [(st + q["tsold"] + 0.08 + j * 0.1 + 0.4, "coin") for j in range(12)]
    ev += [(st + q["trec"], "stamp"), (st + q["trec"], "thud"), (st + q["t118"], "pop"), (st + q["te"] + 0.3, "ding")]
    return ev


def _ev5(v, c, st):
    q = c5(c)
    return [(st + q["tsh"], "boing"), (st + q["tsh"] + 0.15, "snap"), (st + q["tbut"], "scratch"), (st + q["tbut"] + 0.4, "stamp"),
            (st + q["tnote"], "tack"), (st + q["tgu"], "pop"), (st + q["t335"], "whoosh2"), (st + q["tmil"], "sparkle")]


def _ev6(v, c, st):
    q = c6(c)
    return [(st + 0.05, "thud"), (st + q["tavg"], "whoosh1"), (st + q["tcons"] + 0.6, "pop"), (st + q["tonly"], "wah"), (st + q["twh"], "trombone")]


def _ev7(v, c, st):
    q = c7(c)
    ev = [(st + q["te"], "scrub"), (st + q["tsh"], "shout"), (st + q["tfr"] - 0.1, "whoosh1"), (st + q["tfr"], "boing"), (st + q["tsi"], "sigh"), (st + q["tag"], "sigh"),
          (st + q["tj"], "cash"), (st + q["tj"], "ding")]
    ev += [(st + q["tpat"] + i * 0.11 + 0.5, "pop") for i in range(0, 11, 2)]
    return ev


def _ev8(v, c, st):
    q = c8(c)
    return [(st + 0.05, "whoosh2"), (st + q["tg"], "pop"), (st + q["tc"], "pop"), (st + q["tit"], "stamp"), (st + q["tth"], "whoosh1"), (st + q["tth"] + 0.25, "ding")]


def _ev1(v, c, st):
    return [(st + 0.0, "impact"), (st + c.at("thirteen", 1.0), "ding"), (st + c.at("thirteen", 1.0), "stamp"), (st + 0.75, "boing"), (st + 1.5, "boing"),
            (st + c.at("cartoon", 3.5), "whoosh1"), (st + c.at("dramatization", 4.2), "pop")]


SV_EVENTS = {"sv_hook": _ev1, "sv_meet": _ev2, "sv_rack": _ev3, "sv_bet": _ev4, "sv_shock": _ev5, "sv_gap": _ev6, "sv_erase": _ev7, "sv_close": _ev8}
SCENES.update({"sv_hook": scene_sv_hook, "sv_meet": scene_sv_meet, "sv_rack": scene_sv_rack, "sv_bet": scene_sv_bet, "sv_shock": scene_sv_shock,
               "sv_gap": scene_sv_gap, "sv_erase": scene_sv_erase, "sv_close": scene_sv_close})


def _sfx_sv(kind, sr, rng):
    import numpy as np
    if kind == "trombone":
        out = np.zeros(int(1.5 * sr))
        for j, (f0, f1, st_, dur) in enumerate(((233, 220, 0.0, 0.3), (220, 207, 0.33, 0.3), (207, 196, 0.66, 0.3), (196, 150, 0.99, 0.5))):
            n = int(dur * sr); tt = np.arange(n) / sr
            f = np.linspace(f0, f1, n) * (1 + 0.015 * np.sin(2 * np.pi * 6 * tt))
            saw = 2 * ((np.cumsum(f) / sr) % 1.0) - 1
            x = _onepole(saw, 900, sr) * np.minimum(1, tt / 0.02) * np.minimum(1, (dur - tt) / 0.06)
            s0 = int(st_ * sr)
            out[s0:s0 + n] += x
        return out / (np.abs(out).max() + 1e-9)
    if kind == "alarm":
        n = int(0.3 * sr); tt = np.arange(n) / sr
        f = np.where(tt < 0.15, 880, 660)
        return np.sign(np.sin(2 * np.pi * np.cumsum(f) / sr)) * 0.5 * np.minimum(1, (0.3 - tt) / 0.03)
    if kind == "coin":
        n = int(0.4 * sr); tt = np.arange(n) / sr
        return (np.sin(2 * np.pi * 1976 * tt) * np.exp(-tt * 18) + np.sin(2 * np.pi * 2637 * np.maximum(0, tt - 0.07)) * np.exp(-np.maximum(0, tt - 0.07) * 14) * (tt > 0.07)) * 0.8
    if kind == "tack":
        n = int(0.25 * sr); tt = np.arange(n) / sr
        return np.sin(2 * np.pi * 110 * tt) * np.exp(-tt * 30) + np.sin(2 * np.pi * 3200 * tt) * np.exp(-tt * 60) * 0.5 + np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 150) * 0.3
    if kind == "shout":
        n = int(0.7 * sr); tt = np.arange(n) / sr
        f = 150 - 40 * tt + 6 * np.sin(2 * np.pi * 9 * tt)
        saw = 2 * ((np.cumsum(f) / sr) % 1.0) - 1
        x = _onepole(saw, 1100, sr) + 0.3 * _onepole(rng.standard_normal(n), 2000, sr)
        return x / (np.abs(x).max() + 1e-9) * np.minimum(1, tt / 0.03) * np.exp(-tt * 2.5)
    if kind == "sigh":
        n = int(0.9 * sr); tt = np.arange(n) / sr
        x = _onepole(rng.standard_normal(n), 900 - 500 * tt, sr)
        return x / (np.abs(x).max() + 1e-9) * np.sin(np.pi * np.minimum(1, tt / 0.9)) ** 1.5 * 0.8
    if kind == "rubber":
        n = int(0.3 * sr); tt = np.arange(n) / sr
        f = 700 + 900 * tt + 80 * np.sin(2 * np.pi * 22 * tt)
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 8)
    if kind == "tick":
        n = int(0.05 * sr); tt = np.arange(n) / sr
        return np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 140)
    if kind == "poof":
        n = int(0.3 * sr); tt = np.arange(n) / sr
        x = _onepole(rng.standard_normal(n), 1200, sr)
        return x / (np.abs(x).max() + 1e-9) * np.exp(-tt * 12)
    if kind == "cash":
        n = int(0.9 * sr); out = np.zeros(n); tt = np.arange(n) / sr
        out += np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 60) * 0.4
        for s0, fq in ((0.12, 2349), (0.22, 3136)):
            m = n - int(s0 * sr); t2 = np.arange(m) / sr
            out[int(s0 * sr):] += np.sin(2 * np.pi * fq * t2) * np.exp(-t2 * 7)
        return out
    raise ValueError(kind)


def music_bed_sv(total, sr, rng):
    """Playful techy bed: square-ish arp + bouncy bass + soft kick/hat, 124 bpm, Am F C G; builds through the panic and payoff."""
    import numpy as np
    n = int(total * sr)
    out = np.zeros(n)
    hz = lambda m: 440 * 2 ** ((m - 69) / 12)
    chords = [(45, [57, 60, 64, 69]), (41, [57, 60, 65, 69]), (48, [60, 64, 67, 72]), (43, [59, 62, 67, 71])]
    beat = 60 / 124.0

    def note(t0, fq, dur, amp, kind):
        s0 = int(t0 * sr)
        if s0 >= n:
            return
        m = min(n - s0, int(dur * sr))
        tt = np.arange(m) / sr
        if kind == "bass":
            w = np.sin(2 * np.pi * fq * tt) + 0.35 * np.sign(np.sin(2 * np.pi * fq * tt))
            e = np.exp(-tt * 6) * np.minimum(1, tt / 0.004)
        elif kind == "kick":
            w = np.sin(2 * np.pi * np.cumsum(120 * np.exp(-tt * 25) + 45) / sr)
            e = np.exp(-tt * 14)
        else:
            w = np.sign(np.sin(2 * np.pi * fq * tt)) * 0.5 + np.sin(2 * np.pi * fq * tt) * 0.5
            e = np.exp(-tt * 10) * np.minimum(1, tt / 0.003)
        out[s0:s0 + m] += w * e * amp
    nb = int(total / beat) + 2
    for b in range(nb):
        bar, bt = divmod(b, 4)
        root, tones = chords[bar % 4]
        t0 = b * beat
        tsec = t0
        inten = 0.6 + 0.4 * (1 if (16 < tsec < 34 or tsec > 44) else 0.3)
        if bt in (0, 2):
            note(t0, hz(root - 12), 0.35, 0.8, "bass")
        elif bt == 3:
            note(t0 + beat * 0.5, hz(root - 5), 0.25, 0.5, "bass")
        for h in range(2):
            idx = (b * 2 + h) % 4
            note(t0 + h * beat / 2, hz(tones[idx]), 0.2, 0.26 * inten, "pluck")
        if tsec > 3 and bt in (0, 2):
            note(t0, 60, 0.2, 0.7 * (0.6 if tsec < 16 else 1), "kick")
        s0 = int((t0 + beat / 2) * sr)
        m = min(n - s0, int(0.04 * sr))
        if m > 0 and tsec > 6:
            out[s0:s0 + m] += np.diff(rng.standard_normal(m + 1)) * np.exp(-np.arange(m) / (0.01 * sr)) * 0.14
    return out / (np.abs(out).max() + 1e-9)


# ================================================================= B3: Bram, Beam and the Coupon Swap
CYAN = (143, 243, 255)
CYAND = (70, 190, 214)
COPPER = (224, 138, 60)
REDD = (96, 26, 24)
PINK = (255, 150, 170)


def sv_header(img, spec, now, total):
    d = ImageDraw.Draw(img)
    d.rectangle((0, 0, W, 366), fill=(5, 18, 26, 255))
    d.rectangle((0, 366, W, 374), fill=TLP + (255,))
    d.rectangle((0, 214, W, 222), fill=(16, 52, 66, 255))
    d.rectangle((0, 214, int(W * clamp01(now / total)), 222), fill=GLD + (255,))
    spill(img, 215, 272, "MRVL -12.7%", 44, RED, tc=CRM, padx=24, h=66, ow=5)
    spill(img, 530, 272, "LITE -18.6%", 44, RED, tc=CRM, padx=24, h=66, ow=5)
    d = ImageDraw.Draw(img)
    d.text((700, 272), "MON CLOSE", font=font("bold", 24), fill=DIMC + (255,), anchor="lm")
    d.text((W - 50, 250), "WHY IT", font=font("bold", 30), fill=GLD + (255,), anchor="rm")
    d.text((W - 50, 284), "MOVED?", font=font("bold", 30), fill=CRM + (255,), anchor="rm")
    d.text((60, 313), "Educational only - not financial advice", font=font("medium", 25), fill=DIMC + (255,), anchor="lm")
    d.text((60, 346), "DRAMATIZATION - CARTOON, NOT REAL EVENTS", font=font("bold", 34), fill=(170, 186, 194, 255), anchor="lm")


def heart(p, cx, cy, s, col=PINK):
    p.el((cx - 18 * s, cy - 16 * s, cx, cy + 4 * s), col, 0)
    p.el((cx, cy - 16 * s, cx + 18 * s, cy + 4 * s), col, 0)
    p.poly([(cx - 17 * s, cy - 4 * s), (cx + 17 * s, cy - 4 * s), (cx, cy + 20 * s)], col, 0)


# ---------------------------------------------------------------- BRAM (chip brain)
def bram_tile(eyes="worry", mouth="nerv", al=8, ar=8, sweat=1, tie=0):
    al, ar = int(round(al / 15.0)) * 15, int(round(ar / 15.0)) * 15
    key = ("bram", eyes, mouth, al, ar, sweat, tie)

    def fn(d, k):
        p = SP(d, k)
        for i in range(3):
            cx = 90 + 220 * (i + 0.5) / 3
            p.rr((cx - 10, 42, cx + 10, 78), 5, PINC, 6)
            p.rr((cx - 10, 282, cx + 10, 324), 5, PINC, 6)
            cy = 70 + 220 * (i + 0.5) / 3
            p.rr((56, cy - 10, 98, cy + 10), 5, PINC, 6)
            p.rr((302, cy - 10, 344, cy + 10), 5, PINC, 6)
        _arm(p, -1, al, TLP, TLL)
        _arm(p, 1, ar, TLP, TLL)
        p.rr((90, 70, 310, 290), 40, TLP, 10)
        p.rr((106, 82, 250, 94), 6, TLL, 0)
        # brain window
        p.rr((122, 84, 278, 162), 26, (150, 232, 218), 7)
        p.ln([(200, 92), (200, 154)], 5, TLD)
        p.arc((134, 92, 198, 138), 170, 320, 5, TLD)
        p.arc((202, 92, 266, 138), 220, 10, 5, TLD)
        p.arc((136, 116, 198, 160), 20, 170, 5, TLD)
        p.arc((202, 116, 264, 160), 10, 160, 5, TLD)
        # coupon-pouch belt
        p.rr((90, 268, 310, 290), 8, (196, 146, 92), 7)
        p.rr((246, 252, 304, 300), 12, (170, 120, 70), 7)
        p.poly([(258, 254), (282, 238), (292, 258)], GLD, 5)
        p.poly([(266, 254), (294, 244), (298, 262)], (240, 176, 40), 5)
        if tie:
            p.poly([(200, 284), (148, 262), (148, 308)], RED, 6)
            p.poly([(200, 284), (252, 262), (252, 308)], RED, 6)
            p.el((186, 270, 214, 298), RED, 6)
        cy = 202
        for sg, ex in ((-1, 158), (1, 242)):
            if eyes in ("worry", "open", "lookr", "wide"):
                big = 26 if eyes == "wide" else 22
                lx = 8 if eyes == "lookr" else 0
                p.el((ex - big, cy - big - 2, ex + big, cy + big + 2), (255, 255, 255), 6)
                pr = 6 if eyes == "wide" else 9
                p.el((ex - pr + lx, cy - pr, ex + pr + lx, cy + pr + 4), INKB, 0)
                p.el((ex - 3 + lx, cy - 6, ex + 3 + lx, cy), (255, 255, 255), 0)
                if eyes == "worry":
                    if sg < 0:
                        p.ln([(ex - 22, cy - 38), (ex + 20, cy - 52)], 8)
                    else:
                        p.ln([(ex + 22, cy - 38), (ex - 20, cy - 52)], 8)
            elif eyes == "blink":
                p.ln([(ex - 18, cy + 4), (ex + 18, cy + 4)], 8)
            elif eyes == "happy":
                p.arc((ex - 19, cy - 10, ex + 19, cy + 26), 200, 340, 8)
            elif eyes == "heart":
                heart(p, ex, cy, 1.2)
            elif eyes == "squint":
                if sg < 0:
                    p.ln([(ex - 18, cy - 14), (ex + 10, cy + 2), (ex - 18, cy + 18)], 8)
                else:
                    p.ln([(ex + 18, cy - 14), (ex - 10, cy + 2), (ex + 18, cy + 18)], 8)
            elif eyes == "x":
                p.ln([(ex - 15, cy - 15), (ex + 15, cy + 15)], 8)
                p.ln([(ex + 15, cy - 15), (ex - 15, cy + 15)], 8)
            elif eyes in ("lid", "dead"):
                p.el((ex - 22, cy - 22, ex + 22, cy + 24), (255, 255, 255), 6)
                p.el((ex - 8, cy - 2, ex + 8, cy + 16), INKB, 0)
                p.rr((ex - 25, cy - 26, ex + 25, cy - 2), 4, TLP, 0)
                p.ln([(ex - 24, cy - 2), (ex + 24, cy - 2)], 7)
            elif eyes == "sleep":
                p.arc((ex - 19, cy - 14, ex + 19, cy + 18), 20, 160, 8)
            elif eyes == "peek":
                p.el((ex - 18, cy - 16, ex + 18, cy + 18), (255, 255, 255), 6)
                p.el((ex - 7, cy - 4, ex + 7, cy + 10), INKB, 0)
        if mouth == "wob":
            p.ln([(176, 252), (188, 242), (200, 254), (212, 242), (224, 252)], 6)
        elif mouth == "teeth":
            p.rr((172, 238, 228, 266), 8, (255, 255, 255), 6)
            p.ln([(186, 238), (186, 266)], 4); p.ln([(200, 238), (200, 266)], 4); p.ln([(214, 238), (214, 266)], 4)
        elif mouth == "nerv":
            p.ln([(172, 250), (184, 242), (196, 252), (208, 242), (220, 252), (230, 244)], 6)
        elif mouth == "grin":
            p.pie((168, 226, 232, 268), 0, 180, (120, 30, 40), 7)
        elif mouth == "smile":
            p.arc((172, 222, 228, 258), 20, 160, 8)
        elif mouth == "o":
            p.el((188, 232, 212, 262), (120, 30, 40), 6)
        elif mouth == "open":
            p.el((180, 232, 220, 264), (120, 30, 40), 7)
        elif mouth == "sad":
            p.arc((176, 240, 224, 274), 200, 340, 7)
        elif mouth == "flat":
            p.ln([(182, 252), (218, 252)], 7)
        if sweat:
            p.poly([(302, 92), (290, 122), (302, 136), (314, 122)], (140, 210, 255), 5)
        if sweat > 1:
            p.poly([(86, 120), (76, 146), (86, 158), (96, 146)], (140, 210, 255), 5)
    return _svc(key, 400, 340, fn)


def put_bram(layer, x, y, sc=1.0, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, bram_tile(**kw), x, y, 200, 324, sc * sx, sc * sy, rot)


# ---------------------------------------------------------------- BEAM (laser)
def beam_tile(eyes="lookl", mouth="smile", al=8, ar=8, glow=0.5, brow=0, blush=1):
    al, ar = int(round(al / 15.0)) * 15, int(round(ar / 15.0)) * 15
    key = ("beam", eyes, mouth, al, ar, round(glow * 2) / 2, brow, blush)

    def fn(d, k):
        p = SP(d, k)
        for sg, sx_ in ((-1, 112), (1, 288)):
            a = al if sg < 0 else ar
            ar_ = _m.radians(a)
            hx, hy = sx_ + sg * _m.sin(ar_) * 70, 330 + _m.cos(ar_) * 70
            p.ln([(sx_, 330), (hx, hy)], 28, INKB)
            p.ln([(sx_, 330), (hx, hy)], 17, CYAN)
            p.el((hx - 17, hy - 17, hx + 17, hy + 17), (230, 252, 255), 7)
        p.rr((140, 530, 192, 568), 12, CYAND, 7)
        p.rr((208, 530, 260, 568), 12, CYAND, 7)
        p.rr((110, 90, 290, 545), 90, CYAN, 10)
        p.rr((124, 410, 276, 446), 10, CYAND, 0)
        p.rr((132, 120, 152, 380), 10, (235, 253, 255), 0)
        # nozzle (left) + glow lens
        if brow == 9:   # droopy nozzle
            p.poly([(112, 150), (112, 200), (76, 262), (44, 236), (80, 150)], (110, 210, 228), 8)
            p.el((34, 232, 62, 262), (150, 160, 170), 6)
        else:
            p.rr((66, 148, 120, 206), 12, (110, 210, 228), 8)
            gl = mix((200, 240, 250), (255, 255, 255), glow)
            p.el((56, 156, 86, 198), gl, 6)
        # top dome
        p.rr((160, 64, 240, 110), 20, CYAND, 8)
        p.el((184, 72, 216, 98), mix((220, 250, 255), (255, 255, 255), glow), 0)
        cy = 252
        for sg, ex in ((-1, 162), (1, 238)):
            if eyes in ("lookl", "open", "wide"):
                big = 28 if eyes == "wide" else 24
                lx = -9 if eyes == "lookl" else 0
                p.el((ex - big, cy - big - 2, ex + big, cy + big + 2), (255, 255, 255), 6)
                p.el((ex - 9 + lx, cy - 9, ex + 9 + lx, cy + 11), INKB, 0)
                p.el((ex - 3 + lx, cy - 7, ex + 3 + lx, cy - 1), (255, 255, 255), 0)
            elif eyes == "blink":
                p.ln([(ex - 18, cy + 4), (ex + 18, cy + 4)], 8)
            elif eyes == "happy":
                p.arc((ex - 20, cy - 10, ex + 20, cy + 26), 200, 340, 8)
            elif eyes == "sleepy":
                p.el((ex - 22, cy - 18, ex + 22, cy + 22), (255, 255, 255), 6)
                p.el((ex - 8, cy + 0, ex + 8, cy + 18), INKB, 0)
                p.rr((ex - 25, cy - 22, ex + 25, cy + 2), 4, CYAN, 0)
                p.ln([(ex - 23, cy + 2), (ex + 23, cy + 2)], 7)
            elif eyes == "x":
                p.ln([(ex - 16, cy - 16), (ex + 16, cy + 16)], 8)
                p.ln([(ex + 16, cy - 16), (ex - 16, cy + 16)], 8)
            elif eyes == "wink":
                if sg < 0:
                    p.el((ex - 24, cy - 26, ex + 24, cy + 26), (255, 255, 255), 6)
                    p.el((ex - 9 - 6, cy - 9, ex + 9 - 6, cy + 11), INKB, 0)
                else:
                    p.arc((ex - 20, cy - 10, ex + 20, cy + 26), 200, 340, 8)
            elif eyes == "squish":
                if sg < 0:
                    p.ln([(ex - 18, cy - 14), (ex + 10, cy + 2), (ex - 18, cy + 18)], 8)
                else:
                    p.ln([(ex + 18, cy - 14), (ex - 10, cy + 2), (ex + 18, cy + 18)], 8)
            elif eyes == "worry":
                p.el((ex - 24, cy - 26, ex + 24, cy + 26), (255, 255, 255), 6)
                p.el((ex - 9, cy - 5, ex + 9, cy + 13), INKB, 0)
                if sg < 0:
                    p.ln([(ex - 24, cy - 36), (ex + 18, cy - 50)], 8)
                else:
                    p.ln([(ex + 24, cy - 36), (ex - 18, cy - 50)], 8)
            if brow == 1 and sg > 0 and eyes in ("lookl", "open"):
                p.ln([(ex - 22, cy - 50), (ex + 20, cy - 62)], 8)
        if blush:
            p.el((130, 286, 156, 306), PINK, 0)
            p.el((244, 286, 270, 306), PINK, 0)
        if mouth == "smile":
            p.arc((176, 284, 224, 316), 20, 160, 7)
        elif mouth == "o":
            p.el((190, 292, 210, 318), (120, 30, 40), 6)
        elif mouth == "flat":
            p.ln([(184, 304), (216, 304)], 7)
        elif mouth == "yawn":
            p.el((176, 282, 224, 336), (120, 30, 40), 7)
            p.el((186, 312, 214, 332), (240, 110, 110), 0)
        elif mouth == "sad":
            p.arc((178, 300, 222, 326), 200, 340, 7)
        elif mouth == "wob":
            p.ln([(178, 308), (190, 300), (202, 310), (214, 300), (224, 306)], 6)
    return _svc(key, 400, 580, fn)


def put_beam(layer, x, y, sc=1.0, sx=1.0, sy=1.0, rot=0.0, **kw):
    blit(layer, beam_tile(**kw), x, y, 200, 560, sc * sx, sc * sy, rot)


def beam_nozzle(x, y, sc):
    return x + (72 - 200) * sc, y + (177 - 560) * sc


def beam_line(img, p0, p1, t, thick=14, a=1.0, dots=True, speed=300, wav=10):
    """wavy cyan beam from p0 to p1 with light dots travelling along it"""
    n = 26
    pts = []
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    L = max(1.0, _m.hypot(dx, dy))
    nx, ny = -dy / L, dx / L
    for i in range(n + 1):
        u = i / n
        w = _m.sin(u * 14 - t * 16) * wav * _m.sin(_m.pi * u)
        pts.append((p0[0] + dx * u + nx * w, p0[1] + dy * u + ny * w))
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ld = ImageDraw.Draw(lay)
    for wd, al_ in ((thick * 3.2, 60), (thick * 1.8, 110), (thick, 255)):
        ld.line(pts, fill=CYAN + (int(al_ * a),), width=int(wd), joint="curve")
    ld.line(pts, fill=(255, 255, 255, int(255 * a)), width=max(2, int(thick * 0.35)), joint="curve")
    img.alpha_composite(lay)
    if dots:
        dd = ImageDraw.Draw(img)
        for j in range(6):
            u = ((t * speed / L) + j / 6.0) % 1.0
            x, y = p0[0] + dx * u, p0[1] + dy * u
            dd.rounded_rectangle((x - 11, y - 11, x + 11, y + 11), radius=4, fill=(255, 255, 255, int(255 * a)), outline=INKB + (int(255 * a),), width=3)


# ---------------------------------------------------------------- props
def coupon_tile(w=190, half=False):
    key = ("coupon", w, half)
    h = int(w * 0.56)

    def fn(d, k):
        p = SP(d, k)
        ww = w if not half else w // 2
        if half:
            p.poly([(4, 4), (ww - 4, 4), (ww - 14, h * 0.2), (ww - 2, h * 0.36), (ww - 14, h * 0.52), (ww - 2, h * 0.68), (ww - 14, h * 0.84), (ww - 4, h - 4), (4, h - 4)], (255, 150, 110), 6)
        else:
            p.rr((4, 4, ww - 4, h - 4), 14, GLD, 6)
            p.rr((14, 14, ww - 14, h - 14), 8, None, 3, GLDD)
        if half:
            pass
        if not half:
            p.txt((w / 2, h * 0.36), "BRAM", int(w * 0.17), INKB)
            p.txt((w / 2, h * 0.66), "STOCK", int(w * 0.17), INKB)
        else:
            p.txt((ww - 6, h * 0.36), "BR", int(w * 0.15), INKB, "rm")
    return _svc(key, w if not half else w // 2, h, fn)


def put_coupon(img, x, y, sc=1.0, rot=0.0, w=190, half=False, sx=1.0, sy=1.0):
    T = coupon_tile(w, half)
    blit(img, T, x, y, T.width / 2, T.height / 2, sc * sx, sc * sy, rot)


def cop_head(state="tired"):
    key = ("cop", state)

    def fn(d, k):
        p = SP(d, k)
        p.rr((6, 20, 104, 104), 22, (190, 196, 206), 8)
        p.rr((22, 6, 40, 24), 4, PINC, 5)
        p.rr((70, 6, 88, 24), 4, PINC, 5)
        for ex in (36, 72):
            if state == "tired":
                p.el((ex - 14, 40, ex + 14, 68), (255, 255, 255), 5)
                p.el((ex - 6, 54, ex + 6, 66), INKB, 0)
                p.rr((ex - 16, 36, ex + 16, 52), 3, (190, 196, 206), 0)
                p.ln([(ex - 15, 52), (ex + 15, 52)], 5)
            else:
                p.ln([(ex - 10, 44), (ex + 10, 64)], 6)
                p.ln([(ex + 10, 44), (ex - 10, 64)], 6)
        p.arc((36, 78, 72, 104), 200, 340, 6)
    return _svc(key, 110, 110, fn)


def cable_pts(x0, y0, x1, y1, sag, n=28, wig=0.0, t=0.0):
    pts = []
    for i in range(n + 1):
        u = i / n
        pts.append((lerp(x0, x1, u), lerp(y0, y1, u) + sag * 4 * u * (1 - u) + _m.sin(u * 9 + t * 5) * wig))
    return pts


def draw_cable(img, pts, w=34):
    d = ImageDraw.Draw(img)
    d.line(pts, fill=INKB + (255,), width=w + 12, joint="curve")
    d.line(pts, fill=COPPER + (255,), width=w, joint="curve")
    d.line([(x, y - w * 0.22) for x, y in pts], fill=(244, 178, 100, 255), width=max(4, w // 5), joint="curve")


def panel(img, ox=0.0, lit=0.0, t=0.0):
    d = ImageDraw.Draw(img)
    x0, x1 = 70 + ox, 1010 + ox
    d.rounded_rectangle((x0, 640, x1, 860), radius=26, fill=(22, 62, 78, 255), outline=INKB + (255,), width=8)
    d.rounded_rectangle((x0 + 30, 668, x1 - 30, 832), radius=16, fill=mix((9, 28, 38), (20, 90, 110), lit) + (255,), outline=INKB + (255,), width=6)
    for j in range(10):
        on = lit > 0.5 and _m.sin(t * 9 + j) > -0.2
        d.ellipse((x0 + 60 + j * 84, 872, x0 + 78 + j * 84, 890), fill=((CYAN if on else (40, 70, 80)) + (255,)), outline=INKB + (255,), width=3)
    for jx in (x0 + 90, x1 - 90):
        d.rounded_rectangle((jx - 30, 716, jx + 30, 764), radius=10, fill=(190, 196, 206, 255), outline=INKB + (255,), width=6)
        d.ellipse((jx - 12, 728, jx + 12, 752), fill=(20, 24, 30, 255))


def stall(img, cx, base, sc=1.0, popu=1.0):
    if popu <= 0.02:
        return
    W_, Hh = 540, 400
    def fn(d, k):
        p = SP(d, k)
        p.rr((30, 120, 52, 396), 6, (150, 110, 80), 6)
        p.rr((488, 120, 510, 396), 6, (150, 110, 80), 6)
        p.rr((20, 300, 520, 396), 14, (190, 140, 96), 8)
        p.rr((40, 316, 500, 330), 5, (216, 168, 120), 0)
        for i in range(9):
            col = RED if i % 2 == 0 else CRM
            x0 = 10 + i * 57
            p.poly([(x0, 40), (x0 + 57, 40), (x0 + 57, 120), (x0 + 28, 140), (x0, 120)], col, 6)
        p.rr((4, 20, 536, 50), 10, GLD, 7)
        for i in range(7):
            p.poly([(30 + i * 80, 4), (60 + i * 80, 4), (45 + i * 80, -2)], CYAN, 0) if False else None
    T = _svc(("stall",), W_, Hh, fn)
    blit(img, T, cx, base, W_ / 2, Hh, sc * popu, sc * popu, 0)


def register_tile():
    def fn(d, k):
        p = SP(d, k)
        p.rr((20, 250, 300, 296), 10, (70, 80, 96), 7)
        p.rr((34, 258, 286, 286), 6, (10, 20, 28), 0)
        p.rr((20, 90, 300, 252), 22, (120, 130, 152), 9)
        p.rr((50, 108, 270, 160), 10, (30, 60, 52), 7)
        p.txt((160, 134), "- - -", 34, (120, 230, 170))
        for r_ in range(2):
            for c_ in range(5):
                p.el((54 + c_ * 44, 176 + r_ * 36, 82 + c_ * 44, 200 + r_ * 36), (210, 214, 224), 5)
    return _svc(("reg",), 320, 300, fn)


def price_tag_tile(w=800, h=400):
    def fn(d, k):
        p = SP(d, k)
        p.rr((10, 10, w - 10, h - 10), 40, (255, 236, 160), 10)
        p.el((w / 2 - 22, 28, w / 2 + 22, 72), (11, 37, 48), 7)
    return _svc(("tag", w, h), w, h, fn)


def ease_io(x):
    x = clamp01(x)
    return x * x * (3 - 2 * x)


def stand_shadow(img, x, y, w=300):
    pass


def sweatdrop(img, x, y, s=1.0):
    ImageDraw.Draw(img).polygon([(x, y - 20 * s), (x - 11 * s, y + 8 * s), (x, y + 18 * s), (x + 11 * s, y + 8 * s)], fill=(140, 210, 255, 255), outline=INKB + (255,))


def hearts_up(img, x, y, t, n=5):
    for j in range(n):
        k = t - j * 0.25
        if 0 < k < 1.5:
            T = _ss(60, 60, lambda d, kk: heart(SP(d, kk), 30, 28, 1.0))
            blit(img, T, x + _m.sin(k * 5 + j) * 20 + j * 8, y - 150 * k, 30, 30, 1.0, 1.0, 0)


# ---------------------------------------------------------------- B1: hook
def b1c(c):
    return dict(tm=c.at("twelve", 1.1), tl=c.at("eighteen", 4.0), tc=c.at("cartoon", 6.1), td=c.at("cartoon", 6.1) + 0.3)


FY = 1360


def hook_b(img, t, q, final=False):
    reveal = clamp01((t - q["tc"]) / 0.7)
    sv_bg(img, t, pan=t * 24, mode="hook", reveal=reveal)
    t0s = [] if final else [0.0]
    flashes = t0s + [q["tl"]]
    fl = 0.0
    for tf_ in flashes:
        k = t - tf_
        if 0 <= k < 0.4:
            fl = max(fl, 0.32 * _m.exp(-k * 9))
    tint(img, RED, 0.07 + 0.03 * _m.sin(t * 5) + fl)
    if reveal > 0.4:
        sweepy(img, t, t * 24)
    # coupons raining down and shrinking
    rnd = _rnd.Random(8)
    for i in range(18):
        sp_ = rnd.uniform(130, 260)
        x0 = rnd.uniform(40, 1040)
        ph = rnd.uniform(0, 3000)
        y = 390 + (ph + t * sp_) % 1000
        u = (y - 390) / 1000.0
        sc = 0.55 * (1 - 0.6 * u)
        if i % 4 == 0:
            sc *= 1.0 - 0.35 * clamp01((u - 0.2) * 3)
        put_coupon(img, x0 + _m.sin(t * 2 + i) * 22, y, sc, _m.sin(t * 1.5 + i) * 30, 190)
    # numbers
    rows = ((478, "-12.7%", "MARVELL CLOSE", 0.0 if not final else -99.0, 0), (712, "-18.6%", "LUMENTUM CLOSE", q["tl"], 1))
    for yy, txt, lab, tcue, i in rows:
        if i == 1 and t < q["tl"] and not False:
            if t < q["tl"] - 0.001:
                continue
        sc = 1.0
        rot = -2.0 + 4 * i
        k = t - tcue
        if tcue > -50 and 0 <= k < 1.0:
            sc = lerp(1.55, 1.0, spr(k, 15, 6.5))
            rot += _m.sin(k * 22) * 5 * _m.exp(-4 * k)
            if k < 0.3:
                CAM["dx"], CAM["dy"] = shake(15 * (1 - k / 0.3), t)
        stext(img, (540, yy), txt, 120, RED, sw=12, rot=rot, sc=sc * (1 + 0.012 * _m.sin(t * 4)))
        spill(img, 540, yy + 108, lab, 56, REDD, tc=CRM, padx=30, h=80, ow=6, sc=pop(k / 0.3 + 0.4) if tcue > -50 and k < 0.3 else 1.0)
    # heading chain
    if t < q["tc"]:
        stext(img, (540, 935), "BOTH FELL. WHY?", 66, CRM, sw=9)
    elif t < q["td"]:
        stext(img, (540, 935), "AS A CARTOON", 70, CRM, sw=10, sc=pop((t - q["tc"]) / 0.3))
    else:
        k2 = t - q["td"]
        pulse = 1 + 0.08 * _m.sin(k2 * 16) * _m.exp(-3 * k2)
        spill(img, 540, 935, "DRAMATIZATION", 58, RED, tc=CRM, padx=40, sc=pop(k2 / 0.3) * pulse, ow=7)
    # characters: squash-drop on each number
    sq = 0.0
    for tf_ in flashes:
        k = t - tf_
        if 0 <= k < 0.7:
            sq += 0.2 * _m.exp(-8 * k) * _m.cos(22 * k)
    sh = swob(t, 6, 1.2)
    eyes_b = "blink" if blink_at(t, 0.4) else "worry"
    put_bram(img, 290, FY + abs(_m.sin(t * 7)) * -3, 0.95, 1 + sq * 0.6, 1 - sq, sh, eyes=eyes_b, mouth="nerv", al=20, ar=20, sweat=2)
    eyes_m = "blink" if blink_at(t, 1.3) else "worry"
    put_beam(img, 790, FY, 0.72, 1 + sq * 0.5, 1 - sq, -sh * 0.8, eyes=eyes_m, mouth="wob", al=20, ar=20, glow=0.3, blush=0)
    for j in range(3):
        k = (t * 1.3 + j * 0.33) % 1.0
        sweatdrop(img, 360 + j * 14, 1130 + 200 * k * k, 0.9)
        sweatdrop(img, 830 - j * 16, 1060 + 230 * k * k, 0.9)


def scene_sb_hook(img, v, t, spec, cues):
    hook_b(img, t, b1c(cues))


# ---------------------------------------------------------------- B2: meet Bram and Beam
def b2c(c):
    return dict(tb=c.at("Bram", 0.2), tmv=c.at("Marvell", 1.5), tdata=c.at("move", 2.6), tbm=c.at("Beam", 3.5), tlas=c.at("Lumentum", 4.7),
                tsend=c.at("send", 6.3), tlt=c.at("light", 7.1))


def scene_sb_meet(img, v, t, spec, cues):
    q = b2c(cues)
    sv_bg(img, t, pan=t * 18, mode="hall")
    sweepy(img, t, t * 18)
    BX, BSC = 250, 1.35
    MX, MSC = 830, 0.95
    ent = spr(t, 12, 5.5)
    by = GY - (1 - ent) * 700
    bump = 0.0
    if 0 <= t - q["tmv"] < 0.4:
        bump = 44 * _m.sin(_m.pi * (t - q["tmv"]) / 0.4)
    eyes, mouth = ("blink" if blink_at(t, 0.5) else "open"), "smile"
    if t >= q["tdata"]:
        eyes, mouth = "happy", "grin"
    if t >= q["tbm"]:
        eyes = "lookr" if eyes == "open" else eyes
    put_bram(img, BX, by - bump - abs(_m.sin(t * 3.2)) * 5, BSC, 1, 1 + 0.015 * _m.sin(t * 4), swob(t, 0.8, 1.0), eyes=eyes, mouth=mouth, al=8, ar=8, sweat=0)
    if t >= q["tb"]:
        spill(img, BX, 758, "BRAM", 62, TLP, tc=INKB, padx=34, sc=pop((t - q["tb"]) / 0.3), rot=-4 + swob(t, 0.7, 2), ow=7)
    if t >= q["tmv"]:
        k = t - q["tmv"]
        card_text(img, 270, 520 - (10 if 0.15 < k < 0.4 else 0), 500, 250, ["MARVELL =", "CHIPS THAT", "MOVE DATA"], [60, 60, 60], [GLD, CRM, CRM], sc=pop(k / 0.3))
    # data packets hop over Bram's pins
    if t >= q["tdata"]:
        dd = ImageDraw.Draw(img)
        for j in range(6):
            u = ((t - q["tdata"]) * 0.9 + j / 6.0) % 1.0
            x = lerp(30, 470, u)
            y = 800 - abs(_m.sin(u * 14)) * 36
            dd.rounded_rectangle((x - 13, y - 13, x + 13, y + 13), radius=5, fill=GLD + (255,), outline=INKB + (255,), width=4)
    # gag: a coupon with Bram's face pops out of the pouch and waves
    tg0 = q["tdata"] + 0.5
    if tg0 <= t < q["tbm"] + 0.3:
        k = t - tg0
        u = spr(k, 12, 6)
        pxx, pyy = 351, 1125 - 230 * u
        out = clamp01((t - (q["tbm"] - 0.1)) / 0.3)
        sc = 0.9 * (1 - out)
        if sc > 0.05:
            put_coupon(img, pxx, pyy, sc, swob(t, 2.2, 12), 190)
            dd = ImageDraw.Draw(img)
            for ex in (-18, 18):
                dd.ellipse((pxx + ex * sc * 1.2 - 6 * sc, pyy - 8 * sc - 6 * sc, pxx + ex * sc * 1.2 + 6 * sc, pyy - 8 * sc + 6 * sc), fill=INKB + (255,))
            dd.arc((pxx - 20 * sc, pyy - 4 * sc, pxx + 20 * sc, pyy + 22 * sc), 20, 160, fill=INKB + (255,), width=max(2, int(5 * sc)))
    # Beam
    if t >= q["tbm"] - 0.1:
        k = t - (q["tbm"] - 0.1)
        mx = lerp(1350, MX, ease(k / 0.6))
        pul = 0.5 + 0.5 * _m.sin(t * 9)
        flash_ = t >= q["tlt"]
        hop = 0.0
        if 0 <= t - q["tlas"] < 0.4:
            hop = 44 * _m.sin(_m.pi * (t - q["tlas"]) / 0.4)
        put_beam(img, mx, GY - hop, MSC, 1 + 0.03 * _m.sin(t * 6), 1 - 0.03 * _m.sin(t * 6), 0, eyes="blink" if blink_at(t, 0.9) else "lookl", mouth="smile",
                 al=8, ar=8, glow=1.0 if flash_ else pul, blush=1)
        if k > 0.5:
            spill(img, MX, 700, "BEAM", 62, CYAN, tc=INKB, padx=34, sc=pop((k - 0.5) / 0.3), rot=4 + swob(t, 0.7, 2), ow=7)
        nz = beam_nozzle(mx, GY - hop, MSC)
        if t >= q["tsend"]:
            a = clamp01((t - q["tsend"]) / 0.2)
            beam_line(img, nz, (460, 930), t, thick=14 if not flash_ else 24, a=a, speed=360)
        if t >= q["tlas"]:
            kk = t - q["tlas"]
            card_text(img, 810, 520 - (10 if 0.15 < kk < 0.4 else 0), 500, 250, ["LUMENTUM =", "LASERS: DATA", "AS LIGHT"], [56, 58, 58], [CYAN, CRM, CRM], sc=pop(kk / 0.3))
        if t >= q["tlt"] and t < q["tlt"] + 0.45:
            kk = t - q["tlt"]
            sburst(img, 460, 930, 60 + 120 * ease(kk / 0.4), 120 + 200 * ease(kk / 0.4), 12, kk * 2, (255, 255, 255, 255), 6, alpha=1 - kk / 0.45)


# ---------------------------------------------------------------- B3: copper to light, proposal
def b3c(c):
    return dict(tcop=c.at("copper", 1.8), tlt=c.at("light", 2.5), tcom=c.at("companies", 3.0), tprop=c.at("proposes", 4.4), tall=c.at("all", 5.3))


def scene_sb_light(img, v, t, spec, cues):
    q = b3c(cues)
    sv_bg(img, t, pan=t * 20, mode="hall")
    sweepy(img, t, t * 20)
    gone = clamp01((t - q["tprop"]) / 0.45)
    lit = clamp01((t - q["tlt"]) / 0.3)
    if gone < 1:
        ox = -ease_io(gone) * 1200
        panel(img, ox, lit, t)
        x0, x1 = 160 + ox, 920 + ox
        if t < q["tlt"] - 0.05:
            sag = 40 + 130 * ease((t - q["tcop"] + 0.3) / 0.6) if t > q["tcop"] - 0.3 else 40
            pts = cable_pts(x0, 740, x1, 740, sag, wig=2.0 if t < q["tcop"] else 5.0, t=t)
            draw_cable(img, pts)
            mid = pts[len(pts) // 2]
            T = cop_head("tired")
            blit(img, T, mid[0], mid[1], 55, 55, 1.6, 1.6, swob(t, 1.2, 6))
            dd = ImageDraw.Draw(img)
            for j in range(3):
                u = ((t * 0.12) + j / 3.0) % 1.0
                i0 = int(u * (len(pts) - 1))
                dd.rounded_rectangle((pts[i0][0] - 9, pts[i0][1] - 9, pts[i0][0] + 9, pts[i0][1] + 9), radius=3, fill=(255, 255, 255, 255), outline=INKB + (255,), width=3)
            if t >= q["tcop"]:
                spill(img, 540, 905, "COPPER", 56, COPPER, tc=INKB, padx=34, sc=pop((t - q["tcop"]) / 0.3), ow=6)
        else:
            k = t - (q["tlt"] - 0.05)
            xm = (x0 + x1) / 2
            dr = min(1.0, k * 1.5)
            rc = 38 * abs(_m.sin(k * 13)) * _m.exp(-k * 3.2)
            draw_cable(img, cable_pts(x0, 740, xm - 40 - 40 * dr, 740 + 330 * dr * dr - rc, 40))
            draw_cable(img, cable_pts(x1, 740, xm + 40 + 40 * dr, 740 + 330 * dr * dr - rc, 40))
            if k < 0.5:
                sburst(img, xm, 740, 40 + 80 * ease(k / 0.4), 80 + 150 * ease(k / 0.4), 10, k * 3, (255, 255, 255, 255), 6, alpha=1 - k / 0.5)
            beam_line(img, (x0, 740), (x1, 740), t, thick=16, a=clamp01(k / 0.12), speed=600, wav=6)
            if k < 0.05:
                flash(img, 0.85)
    if t >= 0.05:
        l2c = CYAN if t >= q["tlt"] else COPPER
        lines = ["AI DATA CENTERS:", "COPPER TO LIGHT", "(COMPANIES SAY)" if t >= q["tcom"] else ""]
        cols = [CRM, l2c, GLD]
        if t < q["tprop"] + 0.2:
            card_text(img, 540, 500, 800, 240, lines, [56, 62, 56], cols, sc=pop((t - 0.05) / 0.3))
    ph = t >= q["tprop"]
    put_bram(img, 230, GY, 1.15, 1, 1, swob(t, 1.0, 1.0), eyes="heart" if ph else "lookr", mouth="smile" if ph else "nerv", al=8, ar=150 if ph else 8, sweat=0 if ph else 1)
    put_beam(img, 860, GY, 0.9, 1, 1, 0, eyes="blink" if blink_at(t, 0.7) else "lookl", mouth="smile", al=8, ar=8, glow=0.5 + 0.4 * lit, blush=1)
    if ph:
        k = t - q["tprop"]
        stall(img, 540, GY + 36, 0.95, spr(k, 12, 6))
        hearts_up(img, 330, 940, k)
        sc = pop(k / 0.3)
        dd = ImageDraw.Draw(img)
        dd.ellipse((380 - 36 * sc, 930 - 36 * sc, 380 + 36 * sc, 930 + 36 * sc), outline=INKB + (255,), width=int(22 * sc) + 2)
        dd.ellipse((380 - 34 * sc, 930 - 34 * sc, 380 + 34 * sc, 930 + 34 * sc), outline=GLD + (255,), width=int(14 * sc) + 1)
        dd.polygon([(380, 880 - 14 * sc), (394, 894 - 14 * sc), (380, 904 - 14 * sc), (366, 894 - 14 * sc)], fill=CYAN + (255,), outline=INKB + (255,))
    if t >= q["tall"]:
        k = t - q["tall"]
        spill(img, 540, 560, "ALL STOCK", 104, GLD, tc=INKB, padx=50, sc=pop(k / 0.3) * (1 + 0.05 * _m.sin(k * 14) * _m.exp(-3 * k)), ow=8)


# ---------------------------------------------------------------- B4: all stock means coupons
def b4c(c):
    return dict(tno=c.at("no", 0.85), tcoup=c.at("coupons", 2.3), tprint=c.at("prints", 3.0), town=c.at("own", 4.9), tfour=c.at("Four", 5.5), tbm=c.at("Beam", 6.9),
                tcomp=c.at("companies", 7.7), thun=c.at("hundred", 10.3), tdebt=c.at("counting", 12.2))


def printer_tile():
    def fn(d, k):
        p = SP(d, k)
        p.rr((10, 40, 190, 150), 16, (170, 178, 192), 8)
        p.rr((30, 20, 170, 56), 8, (60, 68, 84), 7)
        p.rr((52, 66, 148, 76), 4, INKB, 0)
        p.el((150, 96, 170, 116), (90, 255, 150), 5)
        p.rr((40, 100, 120, 132), 6, (220, 226, 236), 5)
    return _svc(("printer",), 200, 160, fn)


def scene_sb_coupons(img, v, t, spec, cues):
    q = b4c(cues)
    sv_bg(img, t, pan=t * 16, mode="hall")
    sweepy(img, t, t * 16)
    BX, BSC, MX, MSC = 640, 1.2, 940, 0.85
    rx = 190 - ease((t - q["tfour"]) / 0.4) * 500
    if rx > -200:
        blit(img, register_tile(), rx, GY + 10, 160, 290, 1.0, 1.0, 0)
        if t >= q["tno"]:
            k = t - q["tno"]
            sc = pop(k / 0.25)
            dd = ImageDraw.Draw(img)
            for a, b in (((rx - 120, GY - 260), (rx + 120, GY - 20)), ((rx + 120, GY - 260), (rx - 120, GY - 20))):
                aa = (rx + (a[0] - rx) * sc, (GY - 140) + (a[1] - (GY - 140)) * sc)
                bb = (rx + (b[0] - rx) * sc, (GY - 140) + (b[1] - (GY - 140)) * sc)
                dd.line([aa, bb], fill=INKB + (255,), width=34)
                dd.line([aa, bb], fill=RED + (255,), width=20)
    # top zone phases
    if t < q["tcoup"] - 0.1:
        spill(img, 540, 470, "ALL STOCK", 92, GLD, tc=INKB, padx=50, sc=pop((t - 0.1) / 0.3), ow=8)
        if t >= q["tno"]:
            spill(img, 540, 585, "= NO CASH", 92, RED, tc=CRM, padx=50, sc=pop((t - q["tno"]) / 0.3), ow=8)
    elif t < q["tfour"] - 0.1:
        card_text(img, 540, 510, 780, 220, ["BRAM PAYS IN", "COUPONS"], [64, 84], [CRM, GLD], sc=pop((t - q["tcoup"]) / 0.3))
    else:
        k = t - q["tfour"]
        card_text(img, 540, 505, 820, 230, ["4.5 COUPONS", "= 1 BEAM SHARE"], [92, 62], [GLD, CRM], sc=pop(k / 0.3))
    if q["town"] <= t < q["tcomp"] - 0.1 and t < q["tfour"] - 0.1:
        k = t - q["town"]
        sc = lerp(2.0, 1.0, spr(k, 16, 7)) if k < 0.7 else 1.0
        spill(img, 540, 690, "= HIS OWN SHARES", 58, RED, tc=CRM, padx=40, sc=sc, rot=-3, ow=8)
    if q["tcomp"] <= t:
        k = t - q["tcomp"]
        stext(img, (540, 665), "COMPANIES' VALUE:", 56, CRM, sw=8, sc=pop(k / 0.3))
    if q["thun"] <= t:
        k = t - q["thun"]
        # starburst behind the chip, small and translucent
        if k < 0.7:
            sburst(img, 760, 770, 70 + 30 * ease(k / 0.4), 110 + 60 * ease(k / 0.4), 12, k, (255, 214, 92, 255), 6, alpha=0.5 * (1 - k / 0.7))
        spill(img, 540, 770, "~$115B INCL. DEBT", 72, GLD, tc=INKB, padx=44, sc=pop(k / 0.3), ow=8)
    # Bram + printer
    shout = q["tprint"] - 0.4 <= t < q["tprint"] + 1.8
    put_bram(img, BX, GY, BSC, 1, 1, swob(t, 1.0, 1.0), eyes="blink" if blink_at(t, 0.3) else "worry", mouth="grin" if shout else "nerv", al=8,
             ar=100 if shout else 8, sweat=1 if t < q["tcoup"] else 0)
    if t >= q["tcoup"] - 0.3:
        shk = _m.sin(t * 50) * 2 if shout else 0
        blit(img, printer_tile(), 370 + shk, GY + 4, 100, 160, 1.15, 1.15, 0)
    for j in range(9):
        t0 = q["tprint"] - 0.3 + j * 0.2
        u = (t - t0) / 0.55
        if u < 0:
            continue
        tx = 480 + (j % 3) * 8
        ty = GY - 18 - (j // 3) * 26
        if u < 1:
            x = lerp(370, tx, ease(u))
            y = lerp(GY - 150, ty, ease(u)) - 210 * _m.sin(_m.pi * u)
            put_coupon(img, x, y, 0.7, u * 400, 190)
        else:
            put_coupon(img, tx, ty, 0.7, (j * 37) % 40 - 20, 190)
    # Beam collects 4 + a torn half
    pose = "happy" if t >= q["tfour"] else "lookl"
    put_beam(img, MX, GY, MSC, 1, 1, 0, eyes="blink" if blink_at(t, 0.2) else pose, mouth="smile", al=8, ar=8, glow=0.5, blush=1)
    for j in range(5):
        t0 = q["tfour"] + 0.25 + j * 0.25
        u = (t - t0) / 0.5
        half = j == 4
        if u < 0:
            continue
        tx, ty = MX - 24 + (50 if half else 0), GY - 200 - j * 26
        if u < 1:
            x = lerp(500, tx, ease(u))
            y = lerp(GY - 30, ty, ease(u)) - 200 * _m.sin(_m.pi * u)
            put_coupon(img, x, y, 0.7, u * 360, 190, half)
        else:
            put_coupon(img, tx, ty, 0.7, 0, 190, half)


# ---------------------------------------------------------------- B5: the catch
def b5c(c):
    return dict(tcat=c.at("catch", 0.2), tfall=c.at("falls", 1.4), tshr=c.at("shrink", 2.6), tpr=c.at("price", 3.4), tdr=c.at("drops", 4.0), tmon=c.at("Monday's", 4.7),
                t771=c.at("seven", 5.9), tdol=c.at("dollars", 7.5))


def scene_sb_catch(img, v, t, spec, cues):
    q = b5c(cues)
    FZ = 0.35
    ta = t if t < q["tcat"] else (q["tcat"] if t < q["tcat"] + FZ else t - FZ)
    sv_bg(img, ta, pan=ta * 16, mode="hall")
    sweepy(img, ta, ta * 16)
    BX, MX = 250, 830
    fall = ease((t - q["tfall"]) / 0.5)
    sink = 0.22 * fall
    put_bram(img, BX, GY + 8 * fall, 1.1, 1 + sink * 0.5, 1 - sink, -6 * fall + swob(ta, 5, 1.5 * fall), eyes="squint" if fall > 0.5 else "worry", mouth="sad" if fall > 0.5 else "nerv",
             al=8, ar=8, sweat=2)
    if t >= q["tfall"]:
        for j in range(4):
            k = (t - q["tfall"] - j * 0.2) % 0.9
            sweatdrop(img, BX + 70 + j * 20, 880 + 280 * k * k, 1.0)
    shrink = 1.0
    if t >= q["tshr"]:
        k = t - q["tshr"]
        shrink = lerp(1.0, 0.6, ease(k / 0.3)) + 0.12 * _m.exp(-9 * k) * _m.cos(26 * k) * (1 if k < 0.8 else 0)
    brow = 1 if t >= q["tshr"] + 0.5 else 0
    put_beam(img, MX, GY, 0.82, 1, 1, 0, eyes="lookl" if t < q["tshr"] else "open", mouth="o" if t >= q["tshr"] else "smile", al=8, ar=8, glow=0.4, brow=brow, blush=1)
    dd = ImageDraw.Draw(img)
    for j in range(5):
        half = j == 4
        cx_, cy_ = MX - 24 + (50 if half else 0), GY - 190 - j * 24
        if t >= q["tshr"]:
            w_, h_ = 66, 40
            dd.rounded_rectangle((cx_ - w_ * (0.5 if half else 1.0) * 0.9, cy_ - h_ * 0.9, cx_ + w_ * (0.5 if half else 1.0) * 0.9, cy_ + h_ * 0.9), radius=8, outline=(235, 240, 244, 150), width=3)
        put_coupon(img, cx_, cy_ - (1 - shrink) * j * 24, 0.7 * shrink, 0, 190, half)
    if q["tcat"] <= t < q["tfall"] + 0.5:
        k = t - q["tcat"]
        sc = lerp(2.2, 1.0, spr(k, 16, 7)) if k < 0.8 else 1.0
        tint(img, (0, 0, 0), 0.3 * (1 - clamp01((k - FZ) / 0.4)))
        stext(img, (540, 600), "THE CATCH", 140, RED, sw=16, rot=-5, sc=sc)
        if k < 0.3:
            CAM["dx"], CAM["dy"] = shake(12, t)
    if q["tfall"] <= t < q["tpr"]:
        k = t - q["tfall"]
        card_text(img, 540, 500, 780, 210, ["BRAM STOCK FALLS", "COUPONS SHRINK"], [60, 60], [RED, CRM], sc=pop(k / 0.3))
    if t >= q["tpr"]:
        k = t - q["tpr"]
        drop = ease(k / 0.35)
        ang = _m.exp(-1.6 * k) * _m.sin(k * 7) * 9
        TW, TH = 780, 450
        T = price_tag_tile(TW, TH).copy()
        td = ImageDraw.Draw(T)
        td.text((TW // 2, 96), "OFFER VALUE PER", font=font("bold", 56), fill=INKB + (255,), anchor="mm")
        td.text((TW // 2, 158), "LUMENTUM SHARE", font=font("bold", 56), fill=INKB + (255,), anchor="mm")
        td.text((TW // 2, 232), "OCT 28: ~$1,132", font=font("bold", 64), fill=(138, 127, 102, 255), anchor="mm")
        extra = 0.0
        if t >= q["tdr"]:
            td.line([(150, 232), (630, 232)], fill=(90, 80, 60, 255), width=5)
            td.text((TW // 2, 300), "MON CLOSE:", font=font("bold", 56), fill=RED + (255,), anchor="mm")
            u = clamp01((t - q["t771"]) / 0.6)
            if u > 0:
                full = "~$771"
                f90 = font("bold", 96)
                tw = int(td.textlength(full, font=f90))
                part = Image.new("RGBA", (TW, TH), (0, 0, 0, 0))
                ImageDraw.Draw(part).text((TW // 2, 386), full, font=f90, fill=RED + (255,), anchor="mm", stroke_width=3, stroke_fill=INKB + (255,))
                part = part.crop((0, 0, int(TW // 2 - tw / 2 + tw * u + 6), TH))
                canvas = Image.new("RGBA", (TW, TH), (0, 0, 0, 0))
                canvas.paste(part, (0, 0))
                T.alpha_composite(canvas)
            if t >= q["t771"]:
                extra = 16 * _m.exp(-8 * (t - q["t771"])) * abs(_m.cos(20 * (t - q["t771"])))
        yy = 385 + (drop - 1) * 420 + (14 * ease((t - q["tdr"]) / 0.3) if t >= q["tdr"] else 0) + extra
        blit(img, T, 540, yy, TW // 2, 0, 0.98, 0.98, ang)
        if t >= q["t771"] and t < q["t771"] + 0.7:
            kk = t - q["t771"]
            sburst(img, 580, yy + 400, 110 + 40 * ease(kk / 0.4), 190 + 80 * ease(kk / 0.4), 12, kk * 2, (255, 120, 90, 255), 6, alpha=0.55 * (1 - kk / 0.7))
        if t >= q["tdr"]:
            ImageDraw.Draw(img).polygon([(935, yy + 120), (1055, yy + 120), (995, yy + 250)], fill=RED + (255,), outline=INKB + (255,))
            ImageDraw.Draw(img).line([(995, yy + 70), (995, yy + 125)], fill=INKB + (255,), width=3)


# ---------------------------------------------------------------- B6: no source confirms why
def b6c(c):
    return dict(tno=c.at("No source", 0.0), tonerep=c.at("One report", 2.0), tinv=c.at("investors", 2.8), tover=c.at("overpaying", 4.3), tan=c.at("One analyst", 5.1),
                tbel=c.at("below", 7.6), tfif=c.at("fifty", 8.0))


def scene_sb_why(img, v, t, spec, cues):
    q = b6c(cues)
    sv_bg(img, t, pan=t * 16, mode="hall")
    sweepy(img, t, t * 16)
    sink = lambda tt: 8 * ease((t - tt) / 0.5)
    squint = t >= q["tinv"]
    for i in (0, 1):
        x = (180, 390)[i]
        put_bot(img, i, x, GY + 20, 0.95, 1, 1, swob(t, 1.2, 4 if squint else 1.5), mood="worry" if squint else "smug", sweat=0)
    if q["tinv"] - 0.1 <= t < q["tinv"] + 2.0:
        spill(img, 285, 665, "INVESTORS", 56, BOTC, tc=CRM, padx=34, sc=pop((t - q["tinv"] + 0.1) / 0.3), ow=7)
    if q["tinv"] <= t < q["tan"] + 0.3:
        mx_, my_ = 560 + _m.sin(t * 3) * 14, 960 + _m.cos(t * 4) * 8
        dd = ImageDraw.Draw(img)
        dd.line([(mx_ + 54, my_ + 54), (mx_ + 130, my_ + 130)], fill=INKB + (255,), width=34)
        dd.line([(mx_ + 54, my_ + 54), (mx_ + 130, my_ + 130)], fill=(150, 110, 70, 255), width=20)
        dd.ellipse((mx_ - 78, my_ - 78, mx_ + 78, my_ + 78), fill=(214, 244, 255, 90), outline=INKB + (255,), width=16)
        dd.ellipse((mx_ - 78, my_ - 78, mx_ + 78, my_ + 78), outline=(190, 200, 214, 255), width=8)
        g = 0.5 + 0.5 * _m.sin(t * 6)
        dd.arc((mx_ - 52, my_ - 52, mx_ + 52, my_ + 52), 200, 250, fill=(255, 255, 255, int(120 + 135 * g)), width=9)
    ss = sink(q["tover"]) + (8 if t >= q["tan"] else 0)
    put_bram(img, 740, GY + ss, 0.95, 1, 1 - ss * 0.01, swob(t, 5, 1.5), eyes="squint" if t >= q["tover"] else "worry", mouth="sad" if t >= q["tover"] else "nerv", sweat=2)
    put_beam(img, 970, GY + ss, 0.72, 1, 1 - ss * 0.01, 0, eyes="worry", mouth="wob", al=8, ar=8, glow=0.3, blush=0)
    for j in range(3):
        k = (t * 1.1 + j * 0.33) % 1.0
        sweatdrop(img, 780 + j * 14, 960 + 220 * k * k, 0.9)
    if t < q["tonerep"] - 0.1:
        card_text(img, 540, 505, 900, 240, ["NO SOURCE CONFIRMS", "WHY BOTH FELL"], [58, 66], [CRM, GLD], sc=pop((t + 0.1) / 0.3))
    elif t < q["tan"] - 0.1:
        card_text(img, 540, 505, 900, 240, ["ONE REPORT: INVESTORS", "FEAR OVERPAYING"], [56, 66], [CRM, RED], sc=pop((t - q["tonerep"]) / 0.3))
    else:
        card_text(img, 540, 505, 900, 240, ["ONE ANALYST: ODDS OF", "DEAL CLOSING BELOW 50%"], [56, 52], [CRM, GLD], sc=pop((t - q["tan"]) / 0.3))
    if q["tover"] <= t < q["tan"]:
        k = t - q["tover"]
        spill(img, 600, 700, "OVERPAYING?", 60, RED, tc=CRM, padx=34, sc=pop(k / 0.3), rot=swob(t, 3, 3), ow=7)
    # coin: tumbles in, rolls/wobbles through "fifty percent", then stands on its edge
    t0c = q["tbel"] - 0.5
    if t >= t0c:
        k = t - t0c
        cx = 590
        flight = 1.1
        wob = 1.1
        coin = _svc(("coin2",), 240, 240, lambda d, kk: (SP(d, kk).el((10, 10, 230, 230), GLD, 9), SP(d, kk).el((34, 34, 206, 206), None, 6, GLDD), SP(d, kk).txt((120, 122), "50%", 78, INKB)))
        if k < flight:
            u = k / flight
            y = lerp(GY - 520, GY - 140, u * u) - 160 * _m.sin(_m.pi * u)
            fl = abs(_m.cos(u * 7 * _m.pi))
            blit(img, coin, cx, y, 120, 120, 1.0, max(0.12, fl), swob(u, 1.5, 20))
        elif k < flight + wob:
            kk = k - flight
            tilt = 0.55 + 0.4 * _m.exp(-2.0 * kk) * abs(_m.cos(kk * 11))
            blit(img, coin, cx, GY - 140 + 40 * (1 - tilt), 120, 120, 1.0, tilt * 0.9, 12 * _m.exp(-2 * kk) * _m.sin(kk * 11))
        else:
            kk = k - flight - wob
            edge = _svc(("coinedge2",), 60, 240, lambda d, k2: SP(d, k2).rr((8, 8, 52, 232), 14, GLD, 8))
            wob_ = 10 * _m.exp(-3 * kk) * _m.sin(kk * 14)
            blit(img, edge, cx, GY - 4, 30, 232, 1.0, 1.0, wob_)
            if kk < 0.6:
                for a in (-1, 1):
                    for j in range(3):
                        px_ = cx + a * (40 + 60 * kk * (1 + j * 0.4))
                        py_ = GY - 6 - 30 * kk * j
                        r_ = 14 * (1 - kk / 0.6) + 2
                        ImageDraw.Draw(img).ellipse((px_ - r_, py_ - r_, px_ + r_, py_ + r_), fill=(230, 230, 236, 255), outline=INKB + (255,), width=3)


# ---------------------------------------------------------------- B7: the long wait
def b7c(c):
    return dict(tw=c.at("wedding", 1.3), tfirst=c.at("first", 2.0), t28=c.at("twenty-eight", 3.0), tsh=c.at("shareholders", 3.7), tvote=c.at("shareholders", 3.7) + 0.2,
                treg=c.at("regulators", 4.6), tapp=c.at("approve", 5.4))


MONTHS = ["MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC", "JAN", "FEB", "MAR", "APR", "MAY", "JUN"]


def calendar(img, cx, cy, t, q):
    T = _ss(540, 360, lambda d, k: (SP(d, k).rr((10, 40, 530, 350), 22, CRM, 9), SP(d, k).rr((10, 20, 530, 100), 22, RED, 9), SP(d, k).el((100, 6, 140, 46), (200, 206, 216), 6), SP(d, k).el((400, 6, 440, 46), (200, 206, 216), 6)))
    tf = q["tfirst"]
    base = T.copy()
    dd = ImageDraw.Draw(base)
    sy = 1.0
    jit = 0.0
    if t < tf:
        dd.text((270, 70), "", font=font("bold", 40))
    elif t < q["t28"]:
        ph = ((t - tf) % 0.11) / 0.11
        n = int((t - tf) / 0.11)
        dd.text((270, 220), MONTHS[n % len(MONTHS)], font=font("bold", 120), fill=INKB + (255,), anchor="mm")
        sy = 1 - 0.28 * _m.sin(_m.pi * ph)
        jit = (ph - 0.5) * 6
    else:
        dd.text((270, 70), "H1", font=font("bold", 60), fill=CRM + (255,), anchor="mm")
        dd.text((270, 220), "2028", font=font("bold", 150), fill=RED + (255,), anchor="mm")
    k = t - q["t28"]
    sc = 0.85 + (0.1 * _m.exp(-8 * k) * _m.cos(24 * k) if t >= q["t28"] else 0)
    if t >= tf:
        blit(img, base, cx, cy, 270, 180, sc, sc * sy, jit)


def scene_sb_wait(img, v, t, spec, cues):
    q = b7c(cues)
    sv_bg(img, t, pan=t * 10, mode="hall")
    sweepy(img, t, t * 10)
    calendar(img, 540, 560, t, q)
    if t >= q["t28"]:
        k = t - q["t28"]
        dd = ImageDraw.Draw(img)
        for r_ in (40, 80, 120):
            rr_ = r_ * clamp01(k / 0.6)
            dd.arc((800 - rr_, 400 - rr_, 800 + rr_, 400 + rr_), 90, 180, fill=(230, 238, 240, 255), width=3)
        for a in (90, 125, 160):
            ar = _m.radians(a)
            dd.line([(800, 400), (800 + _m.cos(ar) * 130 * clamp01(k / 0.6), 400 + _m.sin(ar) * 130 * clamp01(k / 0.6))], fill=(230, 238, 240, 255), width=3)
        sp_y = 450 + 140 * ease(k / 1.2)
        dd.line([(760, 400), (760, sp_y)], fill=(230, 238, 240, 255), width=3)
        dd.ellipse((745, sp_y, 775, sp_y + 28), fill=(30, 30, 40, 255), outline=INKB + (255,))
    wt = t - q["tw"]
    BX, BY = 240, GY - 20
    put_bram(img, BX, BY, 1.1, 1, 1, swob(t, 0.6, 1), eyes="blink" if blink_at(t, 0.6) else ("lookr" if t < q["t28"] else "open"), mouth="smile" if t < q["tsh"] else "flat",
             al=8, ar=150 if int(t * 1.4) % 2 == 0 and t > q["t28"] else 120, sweat=0, tie=1)
    if t > q["t28"]:
        ImageDraw.Draw(img).ellipse((BX + 138 * 1.1 - 50, BY - 192, BX + 138 * 1.1 - 16, BY - 158), fill=GLD + (255,), outline=INKB + (255,), width=5)
    yawn = t >= q["tvote"] - 0.6 and t > q["t28"]
    MXX, MSC_ = 840, 0.74
    put_beam(img, MXX, BY, MSC_, 1, 1, 0, eyes="sleepy" if yawn else ("blink" if blink_at(t, 0.5) else "lookl"), mouth="yawn" if yawn else "smile", al=8, ar=8, glow=0.5, blush=1)
    veil = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    vd = ImageDraw.Draw(veil)
    vd.polygon([(MXX, BY - 392), (MXX - 150, BY - 90), (MXX + 150, BY - 90)], fill=(200, 250, 255, 100))
    vd.arc((MXX - 70, BY - 420, MXX + 70, BY - 340), 180, 360, fill=(255, 255, 255, 230), width=9)
    img.alpha_composite(veil)
    if yawn:
        k = t - (q["tvote"] - 0.6)
        for j in range(3):
            kk = k - j * 0.3
            if 0 < kk < 1.3:
                ImageDraw.Draw(img).ellipse((760 + j * 10, BY - 350 - 80 * kk - 14, 800 + 22 * kk + j * 10, BY - 350 - 80 * kk + 14 + 10 * kk), fill=(200, 250, 255, int(200 * (1 - kk / 1.3))))
    if t >= q["tw"]:
        spill(img, 240, 780, "WEDDING", 56, GLD, tc=INKB, padx=30, sc=pop(wt / 0.3), ow=6)
    if t >= q["tsh"]:
        card_text(img, 540, 815, 940, 150, ["IF SHAREHOLDERS +", "REGULATORS APPROVE"], [58, 58], [CRM, GLD], sc=pop((t - q["tsh"]) / 0.3))
    if t >= q["tvote"]:
        k = t - q["tvote"]
        for j, x in enumerate((400, 690)):
            T = _svc(("ballot2",), 170, 200, lambda d, kk: (SP(d, kk).rr((10, 50, 160, 192), 14, (200, 206, 216), 8), SP(d, kk).rr((40, 54, 130, 70), 5, INKB, 0), SP(d, kk).rr((54, 6, 116, 52), 5, CRM, 6)))
            u = k / 0.3 - j * 0.2
            sc_ = pop(u) if u > 0 else 0.01
            blit(img, T, x, GY, 85, 192, 1.0, sc_, 0)
            if u > 0:
                stext(img, (x, GY - 70 * sc_), "VOTE", 56, INKB, sw=0, sc=max(0.01, sc_) * 0.6)
    if t >= q["treg"]:
        k = t - q["treg"]
        sc = lerp(2.0, 1.0, spr(k, 16, 7)) if k < 0.8 else 1.0
        T = _ss(460, 130, lambda d, kk: SP(d, kk).rr((8, 8, 452, 122), 22, CRM, 8))
        ImageDraw.Draw(T).text((230, 66), "APPROVAL?", font=font("bold", 76), fill=RED + (255,), anchor="mm")
        sc *= 0.72
        blit(img, T, 540, 1005, 230, 65, sc, sc, -6)
        if k < 0.4:
            CAM["dx"], CAM["dy"] = shake(9 * (1 - k / 0.4), t)


# ---------------------------------------------------------------- B8: lesson, question and loop
def b8c(c):
    return dict(tall=c.at("all-stock", 0.4), tbuy=c.at("buyer's", 1.6), tpr=c.at("price", 2.6), twh=c.at("When", 3.3), toff=c.at("offer", 4.9), tcat=c.at("catch", 6.2),
                tq=c.at("Would", 6.7), tcoup=c.at("coupons", 7.2), tend=c.dur - 0.5)


def _phase_lines(img, d, lines, y0, size, t, t0, t1, hls, step=118):
    f = font("bold", size)
    gap = 24
    pin = pop((t - t0) / 0.3)
    pout = 1 - ease((t - (t1 - 0.2)) / 0.25) if t1 < 900 else 1.0
    for li, words in enumerate(lines):
        pk = max(0.01, pop((t - t0 - li * 0.08) / 0.3) * pout)
        widths = [int(d.textlength(w_, font=f)) for w_ in words]
        total = sum(widths) + gap * (len(words) - 1)
        y = y0 + li * step
        x = 540 - total / 2
        xs = []
        for wi in range(len(words)):
            xs.append(x)
            x += widths[wi] + gap
        hl = hls.get(li)
        act = None
        if hl and t >= hl[3]:
            act = hl
            pr = ease((t - hl[3]) / 0.28)
            x0m, x1m = xs[hl[0]] - 14, xs[hl[1]] + widths[hl[1]] + 14
            ph = 104 * pk
            d.rounded_rectangle((x0m, y - ph / 2, x0m + (x1m - x0m) * pr, y + ph / 2), radius=26, fill=hl[2] + (255,), outline=INKB + (255,), width=6)
        for wi, w_ in enumerate(words):
            on = act is not None and act[0] <= wi <= act[1]
            stext(img, (xs[wi] + widths[wi] / 2, y), w_, size, INKB if on else CRM, sw=0 if on else 8, sc=pk)


def scene_sb_close(img, v, t, spec, cues):
    q = b8c(cues)
    img.paste(Image.new("RGBA", (W, H), NAVY + (255,)), (0, 0))
    rays(img, 540, 900, 0, 2400, 18, t * 0.1, (14, 50, 64), None, 0.5)
    for j in range(6):
        px_ = (j * 220 + 80 + t * (18 + 7 * j)) % 1300 - 110
        py_ = (470 + (j % 2) * 60 if j < 3 else 1130 + (j % 2) * 80) + _m.sin(t * 1.6 + j) * 16
        put_coupon(img, px_, py_, 0.55 + 0.08 * (j % 3), swob(t, 0.4, 14) + j * 20, 190)
    d = ImageDraw.Draw(img)
    _phase_lines(img, d, [["IN AN"], ["ALL-STOCK", "DEAL,"], ["THE", "BUYER'S", "STOCK"], ["IS THE", "PRICE", "TAG"]], 540, 88, t, 0.1, q["twh"] - 0.1,
                 {1: (0, 0, TLP, q["tall"]), 2: (1, 2, TLP, q["tbuy"]), 3: (1, 2, GLD, q["tpr"])})
    if q["twh"] - 0.1 <= t < q["tcat"] - 0.1:
        _phase_lines(img, d, [["WHEN THE", "BUYER"], ["DROPS, THE"], ["WHOLE OFFER"], ["DROPS."]], 560, 92, t, q["twh"] - 0.1, q["tcat"] - 0.1,
                     {0: (1, 1, TLP, q["twh"] + 0.4), 3: (0, 0, RED, q["toff"])})
        k = t - q["twh"]
        ay = 1060 + 30 * _m.sin(k * 6)
        d.polygon([(480, ay - 40), (600, ay - 40), (600, ay + 20), (660, ay + 20), (540, ay + 110), (420, ay + 20), (480, ay + 20)], fill=RED + (255,), outline=INKB + (255,))
    if q["tcat"] - 0.1 <= t < q["tq"] - 0.1:
        k = t - q["tcat"]
        sc = lerp(2.2, 1.0, spr(k, 16, 7)) if k < 0.8 else 1.0
        stext(img, (540, 760), "THAT'S", 120, CRM, sw=12, sc=sc)
        stext(img, (540, 900), "THE CATCH.", 150, RED, sw=16, sc=sc, rot=-4)
    if t >= q["tq"] - 0.1 and t < q["tend"]:
        _phase_lines(img, d, [["WOULD YOU", "TAKE"], ["COUPONS FOR"], ["YOUR COMPANY?"]], 520, 84, t, q["tq"] - 0.1, 999, {1: (0, 0, GLD, q["tcoup"])}, step=124)
        pk = pop((t - q["tq"] - 0.8) / 0.3)
        spill(img, 540, 1000, "FOLLOW @whyitmoved", 72, RED, tc=CRM, padx=50, sc=max(0.01, pk), ow=9)
        stext(img, (540, 1120), "A DRAMATIZATION", 52, DIMC, sw=6, sc=max(0.01, pk))
    if t < 0.5:
        rr_ = int(1800 * (1 - ease(t / 0.5)))
        ImageDraw.Draw(img).ellipse((540 - rr_, 960 - rr_, 540 + rr_, 960 + rr_), fill=RED + (255,), outline=INKB + (255,), width=12)
    if t >= q["tend"]:
        k = t - q["tend"]
        hk = Image.new("RGBA", (W, H), (0, 0, 0, 255))
        hook_b(hk, 0.0, dict(tm=1.0, tl=4.0, tc=6.0, td=6.3), final=True)
        mask = Image.new("L", (W, H), 0)
        rr2 = int(1700 * ease(k / 0.35))
        ImageDraw.Draw(mask).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), fill=255)
        img.paste(hk, (0, 0), mask)
        if k < 0.35:
            ImageDraw.Draw(img).ellipse((540 - rr2, 960 - rr2, 540 + rr2, 960 + rr2), outline=INKB + (255,), width=10)


# ---------------------------------------------------------------- sound events
def _e1(v, c, st):
    q = b1c(c)
    return [(st + 0.0, "slide"), (st + 0.02, "thud"), (st + 0.02, "impact"), (st + q["tl"], "thud"), (st + q["tl"], "stamp"), (st + q["tc"], "whoosh1"), (st + q["td"], "pop")]


def _e2(v, c, st):
    q = b2c(c)
    return [(st + q["tb"], "pop"), (st + q["tb"] + 0.1, "rubber"), (st + q["tmv"], "pop"), (st + q["tmv"] + 0.1, "boing"), (st + q["tdata"], "blip"), (st + q["tdata"] + 0.25, "blip"),
            (st + q["tdata"] + 0.5, "pop"), (st + q["tbm"], "whoosh1"), (st + q["tbm"] + 0.5, "pop"), (st + q["tlas"], "pop"), (st + q["tlas"] + 0.1, "boing"), (st + q["tsend"], "pew"), (st + q["tlt"], "sparkle")]


def _e3(v, c, st):
    q = b3c(c)
    return [(st + 0.1, "pop"), (st + q["tcop"], "tick"), (st + q["tlt"] - 0.05, "snap"), (st + q["tlt"] + 0.05, "pew"), (st + q["tprop"] - 0.05, "whoosh1"), (st + q["tprop"] + 0.1, "bell"),
            (st + q["tprop"] + 0.2, "sparkle"), (st + q["tall"], "stamp")]


def _e4(v, c, st):
    q = b4c(c)
    ev = [(st + 0.1, "pop"), (st + q["tno"], "buzz"), (st + q["tcoup"], "whoosh2")]
    ev += [(st + q["tprint"] - 0.3 + j * 0.2 + k_, "tick") for j in range(9) for k_ in (0.0,)]
    ev += [(st + q["tprint"] - 0.3 + j * 0.2 + 0.55, "coin") for j in range(0, 9, 2)]
    ev += [(st + q["town"], "stamp"), (st + q["tfour"], "ding")]
    ev += [(st + q["tfour"] + 0.25 + j * 0.25 + 0.5, "coin") for j in range(5)]
    ev += [(st + q["tcomp"], "pop"), (st + q["thun"], "cash")]
    return ev


def _e5(v, c, st):
    q = b5c(c)
    return [(st + q["tcat"], "scratch"), (st + q["tcat"] + 0.4, "stamp"), (st + q["tfall"], "wah"), (st + q["tshr"], "deflate"), (st + q["tpr"], "whoosh1"), (st + q["tdr"], "wah"),
            (st + q["t771"], "scrub"), (st + q["t771"] + 0.4, "stamp"), (st + q["tdol"], "thud")]


def _e6(v, c, st):
    q = b6c(c)
    return [(st + 0.0, "pop"), (st + q["tonerep"], "pop"), (st + q["tinv"], "rubber"), (st + q["tover"], "pop"), (st + q["tan"], "pop"), (st + q["tbel"] - 0.5, "whoosh1"),
            (st + q["tbel"] + 0.6, "coin"), (st + q["tbel"] + 2.7, "tick"), (st + q["tbel"] + 2.8, "thud")]


def _e7(v, c, st):
    q = b7c(c)
    ev = [(st + q["tw"], "pop")] + [(st + q["tfirst"] + j * 0.11, "tick") for j in range(0, 9)]
    ev += [(st + q["t28"], "stamp"), (st + q["tsh"], "pop"), (st + q["tvote"], "thud"), (st + q["tvote"] - 0.6, "yawn"), (st + q["treg"], "stamp")]
    return ev


def _e8(v, c, st):
    q = b8c(c)
    return [(st + 0.05, "whoosh2"), (st + q["tall"], "pop"), (st + q["tbuy"], "pop"), (st + q["tpr"], "stamp"), (st + q["twh"], "whoosh1"), (st + q["tcat"], "stamp"),
            (st + q["tq"], "pop"), (st + q["tq"] + 0.8, "pop"), (st + q["tend"], "whoosh1"), (st + q["tend"] + 0.25, "ding")]


SV_EVENTS = {"sb_hook": _e1, "sb_meet": _e2, "sb_light": _e3, "sb_coupons": _e4, "sb_catch": _e5, "sb_why": _e6, "sb_wait": _e7, "sb_close": _e8}
SCENES.update({"sb_hook": scene_sb_hook, "sb_meet": scene_sb_meet, "sb_light": scene_sb_light, "sb_coupons": scene_sb_coupons, "sb_catch": scene_sb_catch,
               "sb_why": scene_sb_why, "sb_wait": scene_sb_wait, "sb_close": scene_sb_close})

_base_sfx = _sfx_sv


def _sfx_sv(kind, sr, rng):
    import numpy as np
    if kind == "slide":
        n = int(0.9 * sr); tt = np.arange(n) / sr
        f = 1800 - 1300 * tt / 0.9
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 1.5) * 0.6
    if kind == "pew":
        n = int(0.35 * sr); tt = np.arange(n) / sr
        f = 2400 * np.exp(-9 * tt) + 300
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 9)
    if kind == "blip":
        n = int(0.1 * sr); tt = np.arange(n) / sr
        return np.sign(np.sin(2 * np.pi * 880 * tt)) * 0.4 * np.exp(-tt * 25)
    if kind == "buzz":
        n = int(0.35 * sr); tt = np.arange(n) / sr
        return np.sign(np.sin(2 * np.pi * 110 * tt)) * 0.5 * np.minimum(1, (0.35 - tt) / 0.03)
    if kind == "deflate":
        n = int(0.6 * sr); tt = np.arange(n) / sr
        f = 700 * np.exp(-3.2 * tt) + 120
        return np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-tt * 4) * 0.8 + np.diff(rng.standard_normal(n + 1)) * np.exp(-tt * 12) * 0.1
    if kind == "yawn":
        n = int(1.0 * sr); tt = np.arange(n) / sr
        f = 300 + 160 * np.sin(np.pi * tt)
        x = _onepole(2 * ((np.cumsum(f) / sr) % 1.0) - 1, 700, sr)
        return x / (np.abs(x).max() + 1e-9) * np.sin(np.pi * tt) ** 1.5 * 0.7
    return _base_sfx(kind, sr, rng)
# ==== SV END


# ================================================================== captions
def _ass_time(t):
    h, rem = divmod(max(0.0, t), 3600)
    m, s = divmod(rem, 60)
    return f"{int(h)}:{int(m):02d}:{s:05.2f}"


def build_ass(words, keywords, fontname):
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{fontname},{CAP['size']},&H00FFFFFF,&H00FFFFFF,{CAPSTYLE['outline']},&H90000000,-1,0,0,0,100,100,1,0,1,{CAPSTYLE['outw']},{CAPSTYLE['shadow']},2,40,{CAPSTYLE['marginr']},{CAPSTYLE['marginv']},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    ev, chunks, cur = [], [], []
    for w in words:
        if CAPSTYLE["maxchars"] and cur and sum(len(x["word"]) + 1 for x in cur) + len(w["word"]) > CAPSTYLE["maxchars"]:
            chunks.append(cur); cur = []
        cur.append(w)
        if len(cur) == 3 or re.search(r"[.!?]$", w["word"]) or (CAPSTYLE["maxchars"] and sum(len(x["word"]) for x in cur) >= CAPSTYLE["maxchars"]):
            chunks.append(cur); cur = []
    if cur:
        chunks.append(cur)
    for ci, chunk in enumerate(chunks):
        nxt = chunks[ci + 1][0]["start"] if ci + 1 < len(chunks) else None
        for j, w in enumerate(chunk):
            st = w["start"]
            en = chunk[j + 1]["start"] if j + 1 < len(chunk) else (min(nxt, w["end"] + 0.35) if nxt else w["end"] + 0.4)
            parts = []
            for k, o in enumerate(chunk):
                txt = o["word"].upper().replace("{", "").replace("}", "")
                kw = _norm(o["word"]) in keywords
                if k == j:
                    col = CAPSTYLE["hi"] if kw else "&H00FFFFFF"
                    parts.append(f"{{\\c{col}\\fscx114\\fscy114}}{txt}{{\\c&H00FFFFFF\\fscx100\\fscy100}}")
                else:
                    parts.append(f"{{\\c{CAPSTYLE['hi']}}}{txt}{{\\c&H00FFFFFF}}" if kw else f"{{\\alpha&H40&}}{txt}{{\\alpha&H00&}}")
            anim = r"{\fscx80\fscy80\t(0,120,\fscx100\fscy100)}" if j == 0 else ""
            ev.append(f"Dialogue: 1,{_ass_time(st)},{_ass_time(max(en, st + 0.05))},Cap,,0,0,0,,{anim}{' '.join(parts)}")
    return head + "\n".join(ev) + "\n"


# ================================================================== render
OUT_SR = 48000


def _measure_loudness(path: Path):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(path),
                        "-af", "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True)
    txt = r.stderr
    try:
        return json.loads(txt[txt.rindex("{"):txt.rindex("}") + 1])
    except ValueError:
        return None


def render(spec_path: Path, out_dir: Path, music: Path | None = None, voice: str = "am_michael",
           speed: float = 1.08, no_music: bool = False) -> Path:
    import numpy as np

    spec = json.loads(spec_path.read_text())
    apply_theme(os.environ.get("STOCKSHORT_THEME") or spec.get("theme"))
    MASCOT["style"] = spec.get("char", "wick")
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = spec.get("slug") or f"{spec.get('ticker', 'clip')}-{spec.get('date', 'clip')}"
    work = Path(tempfile.mkdtemp(prefix="stockshort-"))
    voice = spec.get("voice", voice)
    loop = bool(spec.get("loop"))
    lead = 0.12  # first word starts almost immediately; frame 1 is already the hook

    # 1) voice: one take per sentence, trimmed, with measured word timings
    track = [np.zeros(int(lead * SR), dtype="float32")]
    words, beats, t, engine = [], [], lead, None
    for bi, b in enumerate(spec["beats"]):
        bstart, bwords = (0.0 if bi == 0 else t), []
        for si, sent in enumerate(split_sentences(b["say"])):
            wav = work / f"b{bi}_{si}.wav"
            import hashlib
            vc = Path(__file__).resolve().parent / ".vcache"
            vc.mkdir(exist_ok=True)
            vk = vc / (hashlib.md5(f"{sent}|{voice}|{speed}".encode()).hexdigest() + ".wav")
            if vk.exists():
                shutil.copy(vk, wav); engine = "kokoro"
            else:
                engine = synth(sent, wav, voice, speed)
                shutil.copy(wav, vk)
            a, sr = _read_wav(wav)
            if sr != SR:
                a = np.interp(np.linspace(0, len(a), int(len(a) * SR / sr), endpoint=False), np.arange(len(a)), a)
            s0, s1 = speech_bounds(a, SR)
            a = a[max(0, int((s0 - 0.03) * SR)): int((s1 + 0.06) * SR)].astype("float32")
            speak = s1 - s0
            toks = sent.split()
            wts = [_syllables(x) for x in toks]
            tot, acc = sum(wts), 0.0
            for tok, wt in zip(toks, wts):
                ws = t + 0.03 + speak * acc / tot
                acc += wt
                ent = {"word": tok, "start": round(ws, 3), "end": round(t + 0.03 + speak * acc / tot, 3)}
                words.append(ent)
                bwords.append({**ent, "start": ent["start"] - bstart, "end": ent["end"] - bstart})
            track.append(a)
            t += len(a) / SR
            gap = SENT_GAP
            track.append(np.zeros(int(gap * SR), dtype="float32"))
            t += gap
        last = bi == len(spec["beats"]) - 1
        gap = 0.0 if (last and loop) else float(b.get('pad', BEAT_GAP))
        track.append(np.zeros(int(gap * SR), dtype="float32"))
        t += gap
        beats.append({"start": bstart, "dur": t - bstart, "cues": Cues(bwords, t - bstart), **b})
    tail = 0.15 if loop else 0.5
    track.append(np.zeros(int(tail * SR), dtype="float32"))
    total = t + tail
    v24 = np.concatenate(track)
    vo = np.interp(np.linspace(0, len(v24), int(len(v24) * OUT_SR / SR), endpoint=False), np.arange(len(v24)), v24)
    vo = vo / (np.abs(vo).max() + 1e-9) * 0.9
    print(f"  voice: {engine}{' (' + voice + ')' if engine == 'kokoro' else ''}, {total:.1f}s")
    if os.environ.get("SV_TIMING"):
        tj = {"total": total, "beats": [{"start": b_["start"], "dur": b_["dur"]} for b_ in beats], "words": words}
        Path(os.environ["SV_TIMING"]).write_text(json.dumps(tj, indent=1))
    if os.environ.get("SV_FRAMES"):
        kwt = [w["start"] for w in words if _norm(w["word"]) in {_norm(k) for k in spec.get("keywords", [])}]
        outd = Path(os.environ.get("SV_OUT", "frames_dbg")); outd.mkdir(exist_ok=True)
        for tt_ in [float(x) for x in os.environ["SV_FRAMES"].split(",")]:
            fr = sv_frame(spec, beats, tt_, total, kwt, dbg=True)
            fr.convert("RGB").save(outd / f"f_{tt_:07.2f}.png")
        return None

    # 2) sound design + music, ducked under the voice
    rng = np.random.default_rng(7)
    mixd = vo.copy()
    gains = {"whoosh0": 0.2, "whoosh1": 0.16, "whoosh2": 0.13, "pop": 0.14, "stamp": 0.5, "impact": 0.45, "riser": 0.16,
             "bell": 0.3, "ding": 0.3, "scratch": 0.38, "snap": 0.5, "scrub": 0.3, "boing": 0.3, "wah": 0.32, "sparkle": 0.22, "thud": 0.26,
             "slide": 0.3, "pew": 0.3, "blip": 0.25, "buzz": 0.3, "deflate": 0.3, "yawn": 0.3, "trombone": 0.34, "alarm": 0.22, "coin": 0.3, "tack": 0.4, "shout": 0.4, "sigh": 0.3, "rubber": 0.24, "tick": 0.2, "poof": 0.3, "cash": 0.32}
    cache = {}
    for tt_, kind in collect_events(beats):
        s = cache.setdefault(kind, sfx(kind, OUT_SR, rng))
        i0 = int(tt_ * OUT_SR)
        i1 = min(len(mixd), i0 + len(s))
        if i0 < len(mixd):
            mixd[i0:i1] += s[: i1 - i0] * gains[kind]
    if music is None and not no_music and not spec.get("no_music"):
        bed = (music_bed_sv if THEME.get('server') else music_bed_pz if THEME.get('pizza') else music_bed)(total, OUT_SR, rng)
    elif music:
        tmp = work / "music.wav"
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-stream_loop", "-1", "-i", str(music), "-t", f"{total:.2f}",
                        "-ac", "1", "-ar", str(OUT_SR), str(tmp)], check=True)
        bed, _ = _read_wav(tmp)
    else:
        bed = None
    if bed is not None:
        bed = np.pad(bed, (0, max(0, len(mixd) - len(bed))))[: len(mixd)]
        envv = np.convolve(np.abs(vo), np.ones(int(0.25 * OUT_SR)) / int(0.25 * OUT_SR), mode="same")
        duck = 1 - 0.55 * np.clip(envv / 0.08, 0, 1)
        fade = np.ones(len(bed))
        if not loop:
            nf = int(1.2 * OUT_SR)
            fade[-nf:] = np.linspace(1, 0, nf)
        mixd += bed * 0.075 * duck * fade
    mixd = mixd / max(1.0, np.abs(mixd).max() / 0.98)
    audio_wav = work / "mix.wav"
    _write_wav(audio_wav, mixd, OUT_SR)

    # 3) captions
    kws = {_norm(k) for k in spec.get("keywords", [])}
    fontname = Path(_find_font("bold") or "Poppins").stem.split("-")[0]
    ass = work / "caps.ass"
    ass.write_text(build_ass(words, kws, fontname), encoding="utf-8")

    # 4) frames
    if THEME.get("pizza"):
        bg = strip = None
    else:
        bg = toon_background() if THEME.get("toon") else background()
        strip = cloud_strip(W * 3, 560) if THEME.get("toon") else candle_strip(spec.get("ticker") or stem, W * 3, 560)
    default_tape = ([f"{spec['ticker']} {fmt_pct(float(spec['move_pct']))}"] if spec.get("ticker") and spec.get("move_pct") is not None
                    else [spec.get("topic", "Why It Moved")])
    tape, tape_w = tape_strip(spec.get("tape") or default_tape)
    raw = work / "video.mp4"
    enc = subprocess.Popen([
        "ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{W}x{H}", "-r", str(FPS),
        "-i", "-", "-vf", f"ass='{ass.as_posix()}'", "-c:v", "libx264", "-preset", "veryfast", "-crf", "19",
        "-pix_fmt", "yuv420p", str(raw)], stdin=subprocess.PIPE)
    import random
    shake_rng = random.Random(3)
    bi = 0
    hook_hit = 0.0 if beats[0]["visual"]["type"] in ("hook", "question") else -9
    kw_times = [w["start"] for w in words if _norm(w["word"]) in kws]
    for n in range(int(total * FPS)):
        now = n / FPS
        while bi + 1 < len(beats) and now >= beats[bi + 1]["start"]:
            bi += 1
        b = beats[bi]
        tb = now - b["start"]
        if THEME.get("server"):
            enc.stdin.write(sv_frame(spec, beats, now, total, kw_times).tobytes())
            if n % (FPS * 5) == 0:
                print(f"  rendering {now:4.0f}s / {total:.0f}s", flush=True)
            continue
        if THEME.get("pizza"):
            enc.stdin.write(pz_frame(spec, b, tb, now, total, kw_times).tobytes())
            if n % (FPS * 5) == 0:
                print(f"  rendering {now:4.0f}s / {total:.0f}s", flush=True)
            continue
        img = bg.copy()
        # animated background: drifting candles + ticker tape (tape sits above the app's bottom text)
        off = int(now * 45) % (W * 2)
        img.alpha_composite(strip.crop((off, 0, off + W, 560)), (0, 980))
        img.alpha_composite(Image.new("RGBA", (W, 64), tuple(THEME["tape_bg"])), (0, 1440))
        toff = int(now * 110) % tape_w
        img.alpha_composite(tape.crop((toff, 0, toff + W, 60)), (0, 1442))
        layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        SCENES[b["visual"]["type"]](layer, b["visual"], tb, spec, b["cues"])
        z = 1 + 0.04 * ease(tb / max(1.0, b["dur"]))                    # slow camera push
        punch = max([0.0] + [max(0.0, 1 - abs(now - kt - 0.08) / 0.14) for kt in kw_times if -0.1 < now - kt < 0.3])
        z *= 1 + 0.035 * punch                                          # zoom punch on key words
        dx = dy = 0.0
        if bi > 0 and tb < 0.2:                                         # whip-in from the right
            dx = (1 - ease(tb / 0.2)) * 300
            layer.putalpha(layer.getchannel("A").point(lambda a, k=ease(tb / 0.2): int(a * k)))
        if 0 <= now - hook_hit < 0.28:                                  # impact shake on frame 1
            amp = 16 * (1 - (now - hook_hit) / 0.28)
            dx += shake_rng.uniform(-amp, amp); dy += shake_rng.uniform(-amp, amp)
        sc = SAFE_S * z
        cx, cy = SAFE_CX + dx, SAFE_CY + dy
        layer = layer.transform((W, H), Image.AFFINE, (1 / sc, 0, 540 - cx / sc, 0, 1 / sc, 800 - cy / sc),
                                resample=Image.BILINEAR)
        img.alpha_composite(layer)
        header(img, spec, now, total)
        enc.stdin.write(img.tobytes())
        if n % (FPS * 10) == 0:
            print(f"  rendering {now:4.0f}s / {total:.0f}s", flush=True)
    enc.stdin.close()
    enc.wait()

    # 5) mux + two-pass loudness (one even gain change, no pumping)
    out = out_dir / f"{stem}.mp4"
    limited = work / "mix_lim.wav"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(audio_wav), "-af",
                    "alimiter=limit=0.3:attack=4:release=60:level=false", str(limited)], check=True)
    audio_wav = limited
    m = _measure_loudness(audio_wav)
    norm = (f"loudnorm=I=-14:TP=-1.5:LRA=11:linear=true:measured_I={m['input_i']}:measured_TP={m['input_tp']}:"
            f"measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}"
            if m else "loudnorm=I=-14:TP=-1.5:LRA=11")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(raw), "-i", str(audio_wav), "-map", "0:v", "-map", "1:a",
                    "-af", norm, "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest",
                    "-movflags", "+faststart", str(out)], check=True)

    tags = " ".join(f"#{h}" for h in spec.get("hashtags", []))
    src = "\n".join(f"- {s['title']}: {s['url']}" for s in spec.get("sources", []))
    (out_dir / f"{stem}.txt").write_text(
        f"TITLE:\n{spec['title']}\n\nDESCRIPTION:\n{spec.get('description', '')}\n\nSources:\n{src}\n\n"
        f"Educational content only, not financial advice. Do your own research.\n\n{tags}\n\n"
        f"UPLOAD NOTE: narration is an AI voice — tick YouTube's 'altered or synthetic content' box and "
        f"TikTok's 'AI-generated' label.\n")
    shutil.rmtree(work, ignore_errors=True)
    print(f"Saved {out} ({total:.1f}s)")
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("spec", type=Path)
    ap.add_argument("--out", type=Path, default=Path("out"))
    ap.add_argument("--music", type=Path, help="licensed music track to use instead of the generated bed")
    ap.add_argument("--no-music", action="store_true", help="voice and sound effects only")
    ap.add_argument("--voice", default=os.environ.get("STOCKSHORT_VOICE", "am_michael"), help="Kokoro voice id")
    ap.add_argument("--speed", type=float, default=1.15)
    a = ap.parse_args()
    render(a.spec, a.out, a.music, a.voice, a.speed, a.no_music)


if __name__ == "__main__":
    main()
