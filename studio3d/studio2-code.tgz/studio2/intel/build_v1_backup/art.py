"""Sprite / set library for the pilot (original art, Pillow).  Reuses Bram + Beam tiles from stockshort_B3."""
import math as m
import random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops

import stockshort_B3 as S
from stockshort_B3 import (SP, _svc, blit, put, font, INKB, CRM, TLP, TLD, TLL, GLD, GLDD, RED, CYAN, CYAND,
                           PINK, GRY, GRYD, GRYL, clamp01, mix, lerp, bram_tile, beam_tile)

S.apply_theme("server")
W, H = 1080, 1920

# palette (set / props)
WALL = (252, 226, 186)
WALL2 = (244, 205, 150)
WALL3 = (230, 178, 120)
FLOOR1 = (214, 170, 126)
FLOOR2 = (196, 148, 104)
SHELF = (150, 100, 68)
SHELFD = (110, 72, 48)
SHELFL = (190, 134, 92)
PAPER = (250, 248, 240)
PAPERD = (214, 212, 204)
YEL = (255, 218, 62)
YELD = (214, 166, 20)
PIG = (150, 156, 176)
PIGD = (104, 110, 132)
PIGL = (190, 196, 214)
ORG = (255, 170, 60)
SLIME = (170, 230, 150)
BOXC = [(236, 96, 80), (86, 168, 220), (250, 190, 60), (120, 200, 130), (200, 130, 210), (250, 140, 90)]
BEAMC = CYAN

# ground
GY = 1360


def tint_hue(img, deg, sat=1.0, val=1.0):
    """hue-rotate an RGBA tile (for the queue bots)"""
    a = np.array(img.convert("RGBA"))
    rgb = Image.fromarray(a[..., :3]).convert("HSV")
    h = np.array(rgb)
    h[..., 0] = (h[..., 0].astype(int) + int(deg / 360 * 255)) % 256
    h[..., 1] = np.clip(h[..., 1] * sat, 0, 255).astype(np.uint8)
    h[..., 2] = np.clip(h[..., 2] * val, 0, 255).astype(np.uint8)
    out = np.array(Image.fromarray(h, "HSV").convert("RGB"))
    return Image.fromarray(np.dstack([out, a[..., 3]]), "RGBA")


_TT = {}


def cached(key, fn):
    if key not in _TT:
        if len(_TT) > 900:
            _TT.clear()
        _TT[key] = fn()
    return _TT[key]


def qbot_tile(i, eyes="open", mouth="smile"):
    def fn():
        t = bram_tile(eyes, mouth, 0, 0, sweat=0)
        return tint_hue(t, [-40, 28, 70][i % 3], 0.9, 1.05)
    return cached(("qbot", i, eyes, mouth), fn)


# ---------------------------------------------------------------- generic soft shapes
def radial(size, col, a_max=255, power=2.0):
    key = ("rad", size, col, a_max, power)

    def fn():
        yy, xx = np.mgrid[0:size, 0:size]
        r = np.hypot(xx - size / 2, yy - size / 2) / (size / 2)
        a = np.clip(1 - r, 0, 1) ** power * a_max
        arr = np.zeros((size, size, 4), np.uint8)
        arr[..., 0], arr[..., 1], arr[..., 2] = col
        arr[..., 3] = a.astype(np.uint8)
        return Image.fromarray(arr, "RGBA")
    return cached(key, fn)


def glow(img, x, y, r, col=(255, 250, 200), a=200, power=2.0):
    if r < 4 or a <= 0:
        return
    s = int(r * 2)
    t = radial(max(8, s // 4 * 4), col, int(a), power)
    t = t.resize((s, s), Image.BILINEAR) if t.width != s else t
    put(img, t, x - r, y - r)


def starburst(img, cx, cy, r1, r2, n, rot, fill, sw=6, ink=INKB, alpha=1.0):
    if r2 < 4:
        return
    T = int(r2 * 2 + 20)
    tile = Image.new("RGBA", (T * 2, T * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(tile)
    pts = []
    for i in range(n * 2):
        r = r2 if i % 2 == 0 else r1
        a = m.radians(rot) + i * m.pi / n
        pts.append((T + 2 * r * m.cos(a), T + 2 * r * m.sin(a)))
    d.polygon(pts, fill=tuple(fill) + (255,), outline=tuple(ink) + (255,), width=sw * 2)
    tile = tile.resize((T, T), Image.LANCZOS)
    if alpha < 1:
        tile.putalpha(tile.getchannel("A").point(lambda a: int(a * alpha)))
    put(img, tile, cx - T / 2, cy - T / 2)


def puff(img, x, y, r, a=0.8, col=(236, 236, 240)):
    if r < 3 or a <= 0:
        return
    T = int(r * 2 + 12)
    tile = S._ss(T, T, lambda d, k: SP(d, k).el((5, 5, T - 5, T - 5), col, 5, (120, 120, 140)))
    if a < 1:
        tile.putalpha(tile.getchannel("A").point(lambda v: int(v * a)))
    put(img, tile, x - T / 2, y - T / 2)


def star5(img, x, y, r, rot=0, col=YEL):
    T = int(r * 2 + 8)
    def fn(d, k):
        p = SP(d, k)
        pts = []
        for i in range(10):
            rr_ = r if i % 2 == 0 else r * 0.45
            a = m.radians(rot - 90) + i * m.pi / 5
            pts.append((T / 2 + rr_ * m.cos(a), T / 2 + rr_ * m.sin(a)))
        p.poly(pts, col, 4)
    put(img, S._ss(T, T, fn), x - T / 2, y - T / 2)


def sweat(img, x, y, s=1.0, a=1.0):
    T = int(40 * s)
    def fn(d, k):
        SP(d, k).poly([(T * .5, 2), (T * .1, T * .62), (T * .5, T - 2), (T * .9, T * .62)], (140, 210, 255), 4)
    t = S._ss(T, T, fn)
    if a < 1:
        t.putalpha(t.getchannel("A").point(lambda v: int(v * a)))
    put(img, t, x - T / 2, y - T / 2)


def feather(img, x, y, rot, s=1.0, col=PIGL, a=1.0):
    T = int(70 * s)
    def fn(d, k):
        p = SP(d, k)
        p.el((T * .15, T * .38, T * .85, T * .62), col, 4)
        p.ln([(T * .1, T * .5), (T * .9, T * .5)], 3)
    t = S._ss(T, T, fn)
    if a < 1:
        t.putalpha(t.getchannel("A").point(lambda v: int(v * a)))
    blit(img, t, x, y, T / 2, T / 2, 1, 1, rot)


def ptxt(img, xy, s, size, fill=CRM, sw=7, rot=0.0, sc=1.0, alpha=1.0, ink=INKB):
    if sc <= 0.03:
        return
    S.ptext(img, xy, s, size, fill, sw=sw, rot=rot, sc=sc, ink=ink, alpha=alpha)


def pill(img, cx, cy, s, size, fill, tc=CRM, padx=26, h=None, rot=0.0, sc=1.0, w_min=0, alpha=1.0, ow=6):
    if sc <= 0.03:
        return
    f = font("bold", size)
    probe = ImageDraw.Draw(Image.new("L", (4, 4)))
    tw = int(probe.textlength(s, font=f))
    w = max(w_min, tw + 2 * padx)
    hh = h or int(size * 1.55)
    pad = 12
    T = S._ss(w + 2 * pad, hh + 2 * pad, lambda d, k: SP(d, k).rr((pad, pad, w + pad, hh + pad), hh // 2.4, fill, ow))
    ImageDraw.Draw(T).text(((w + 2 * pad) // 2, (hh + 2 * pad) // 2 + 1), s, font=f, fill=tuple(tc) + (255,), anchor="mm")
    if alpha < 1:
        T.putalpha(T.getchannel("A").point(lambda v: int(v * alpha)))
    blit(img, T, cx, cy, (w + 2 * pad) / 2, (hh + 2 * pad) / 2, sc, sc, rot)


# ---------------------------------------------------------------- props (cached tiles)
def banana_tile():
    def fn(d, k):
        p = SP(d, k)
        p.poly([(20, 70), (100, 70), (150, 60), (190, 66), (170, 82), (30, 84)], YEL, 6)
        p.poly([(70, 66), (40, 28), (62, 16), (96, 60)], YEL, 6)
        p.poly([(110, 62), (150, 24), (176, 34), (140, 66)], YEL, 6)
        p.poly([(90, 62), (96, 14), (120, 14), (116, 62)], YEL, 6)
        p.ln([(64, 30), (82, 56)], 3, YELD); p.ln([(108, 20), (104, 54)], 3, YELD); p.ln([(158, 34), (134, 58)], 3, YELD)
        p.el((20, 66, 56, 84), (120, 80, 30), 4)
    return cached(("banana",), lambda: S._ss(210, 100, fn))


def chip_tile(col=None):
    col = col or (70, 76, 92)
    def fn(d, k):
        p = SP(d, k)
        for i in range(4):
            p.rr((6 + i * 12, 2, 12 + i * 12, 12), 2, PINC_, 3)
            p.rr((6 + i * 12, 46, 12 + i * 12, 56), 2, PINC_, 3)
        p.rr((6, 8, 58, 54), 8, col, 5)
        p.rr((18, 20, 46, 42), 4, TLP, 3)
    return cached(("chip", col), lambda: S._ss(64, 62, fn))


PINC_ = (214, 220, 230)


def bag_tile():
    def fn(d, k):
        p = SP(d, k)
        p.poly([(20, 20), (200, 20), (214, 60), (200, 270), (20, 270), (6, 60)], (240, 84, 70), 7)
        p.poly([(10, 4), (210, 4), (214, 24), (6, 24)], (250, 120, 100), 6)
        for i in range(8):
            p.ln([(14 + i * 26, 6), (18 + i * 26, 22)], 3, (190, 50, 40))
        p.el((50, 100, 170, 200), YEL, 6)
        p.txt((110, 150), "CHIPS", 30, INKB)
    return cached(("bag",), lambda: S._ss(220, 280, fn))


def bell_tile():
    def fn(d, k):
        p = SP(d, k)
        p.rr((6, 100, 134, 124), 10, (190, 140, 50), 6)
        p.pie((16, 20, 124, 128), 180, 360, (255, 205, 70), 6)
        p.ln([(36, 70), (50, 46)], 6, (255, 244, 190))
        p.rr((58, 2, 82, 22), 8, (200, 60, 50), 5)
        p.rr((66, 14, 74, 26), 2, GRYD, 3)
    return cached(("bell",), lambda: S._ss(140, 130, fn))


def wheel_tile(rot=0.0, r=34):
    rot = round(rot / 15) * 15 % 360
    def fn(d, k):
        p = SP(d, k)
        c = r + 6
        p.el((c - r, c - r, c + r, c + r), (50, 54, 66), 6)
        p.el((c - r + 10, c - r + 10, c + r - 10, c + r - 10), (170, 176, 190), 4)
        for a in (0, 60, 120):
            ar = m.radians(a + rot)
            p.ln([(c + m.cos(ar) * (r - 12), c + m.sin(ar) * (r - 12)), (c - m.cos(ar) * (r - 12), c - m.sin(ar) * (r - 12))], 4, INKB)
        p.el((c - 5, c - 5, c + 5, c + 5), INKB, 0)
    return cached(("wheel", rot, r), lambda: S._ss(2 * r + 12, 2 * r + 12, fn))


def paper_tile(folded=True):
    def fn(d, k):
        p = SP(d, k)
        p.poly([(10, 14), (150, 4), (160, 100), (18, 112)], PAPER, 6)
        p.ln([(86, 8), (90, 108)], 3, PAPERD)
        for i in range(4):
            p.ln([(24, 34 + i * 17), (72, 33 + i * 17)], 4, (120, 124, 136))
            p.ln([(100, 32 + i * 17), (146, 30 + i * 17)], 4, (120, 124, 136))
        p.rr((22, 18, 40, 26), 2, RED, 0)
    return cached(("paper",), lambda: S._ss(170, 120, fn))


def qmark_tile():
    """the big '?' balloon: glossy yellow-orange glyph with string"""
    def build():
        T = (560, 800)
        t = Image.new("RGBA", T, (0, 0, 0, 0))
        f = font("bold", 640)
        ImageDraw.Draw(t).text((280, 330), "?", font=f, fill=(255, 190, 40, 255), anchor="mm", stroke_width=26, stroke_fill=INKB + (255,))
        # shine
        hl = Image.new("RGBA", T, (0, 0, 0, 0))
        hd = ImageDraw.Draw(hl)
        hd.text((266, 316), "?", font=f, fill=(255, 238, 150, 255), anchor="mm")
        t.alpha_composite(hl)
        d = ImageDraw.Draw(t)
        d.ellipse((130, 70, 196, 130), fill=(255, 255, 255, 190))
        # knot + string
        d.polygon([(280, 640), (258, 676), (302, 676)], fill=(230, 140, 30, 255), outline=INKB + (255,))
        pts = [(280 + 22 * m.sin(i * 0.7), 676 + i * 8) for i in range(15)]
        d.line(pts, fill=INKB + (255,), width=6)
        return t
    return cached(("qmark",), build)


def peel_shadow(img, x, y, w, a=60):
    sh = Image.new("RGBA", (int(w), int(w * 0.22)), (0, 0, 0, 0))
    ImageDraw.Draw(sh).ellipse((0, 0, sh.width - 1, sh.height - 1), fill=(60, 30, 10, a))
    put(img, sh, x - w / 2, y - sh.height / 2)


def shadow(img, x, y, w, a=70):
    peel_shadow(img, x, y, w, a)


# ---------------------------------------------------------------- bulb
def bulb_tile(glow_lv=0.5, crack=0):
    gl = round(glow_lv * 4) / 4

    def fn(d, k):
        p = SP(d, k)
        # base (screw)
        p.rr((140, 470, 280, 520), 12, (150, 156, 168), 8)
        for i in range(3):
            p.ln([(146, 482 + i * 14), (274, 476 + i * 14)], 5, (96, 102, 114))
        p.rr((160, 516, 260, 548), 12, (90, 96, 108), 7)
        p.rr((184, 544, 236, 566), 8, INKB, 0)
        p.rr((126, 430, 294, 480), 14, (170, 176, 190), 8)
        # glass
        gcol = mix((200, 244, 255), (255, 255, 235), gl)
        p.el((30, 30, 390, 440), gcol, 10)
        p.poly([(130, 420), (290, 420), (270, 450), (150, 450)], gcol, 8)
        p.el((54, 60, 120, 150), (255, 255, 255), 0)
        # filament
        fc = mix((255, 200, 80), (255, 255, 200), gl)
        p.ln([(186, 430), (186, 300), (160, 260), (190, 230), (230, 260), (254, 230), (234, 300), (234, 430)], 8, INKB)
        p.ln([(186, 430), (186, 300), (160, 260), (190, 230), (230, 260), (254, 230), (234, 300), (234, 430)], 4, fc)
        # ring on top
        p.el((190, 0, 230, 40), None, 9)
        if crack:
            p.ln([(300, 80), (270, 130), (300, 160), (262, 210)], 5, INKB)
    return _svc(("bulb", gl, crack), 420, 580, fn)


BULB_PIV = (210, 566)
BULB_TOP = (210, 20)


# ---------------------------------------------------------------- pigeon
def pigeon_tile(pose="stand", wing=0.0, eye="open", bob=0.0, cape=0.0):
    wing = round(wing * 4) / 4
    key = ("pig", pose, wing, eye, round(bob), round(cape * 4))

    def fn(d, k):
        p = SP(d, k)
        # tail
        if cape:
            cp = 10 + 14 * cape
            p.poly([(112, 118), (112 - cp * 2.6, 70 + cape * 20), (112 - cp * 2.7, 190), (116, 168)], (250, 247, 232), 6)
            for q in range(3):
                p.ln([(100 - q * 24, 110 + q * 6), (100 - q * 24 - 5, 170)], 4, (185, 185, 200))
        p.poly([(38, 150), (4, 168), (14, 186), (50, 174)], PIGD, 6)
        # legs
        for lx in (90, 124):
            p.ln([(lx, 188), (lx - 2, 224)], 6, (240, 130, 140))
            p.ln([(lx - 14, 226), (lx + 12, 226)], 6, (240, 130, 140))
        # body
        p.el((30, 100, 170, 200), PIG, 8)
        p.el((120, 120, 176, 190), (210, 150, 200), 0)
        # wing
        wy = 128 + wing * -50
        if pose == "fly":
            ang = -70 + 140 * wing
            ar = m.radians(ang)
            p.poly([(70, 132), (70 + 80 * m.cos(ar) - 20, 132 + 80 * m.sin(ar)), (70 + 80 * m.cos(ar) + 30, 132 + 70 * m.sin(ar) + 10), (110, 140)], PIGD, 6)
        else:
            p.poly([(44, 128), (112, 118), (126, 156), (60, 176)], PIGD, 6)
            p.ln([(64, 146), (110, 138)], 4, PIG)
        # neck+head
        p.el((120, 62, 190, 140), PIG, 8)
        p.el((126, 40, 188, 100), PIG, 8)
        p.poly([(184, 64), (214, 74), (184, 84)], ORG, 6)
        if eye == "open":
            p.el((156, 54, 176, 76), (255, 255, 255), 5)
            p.el((164, 60, 174, 72), INKB, 0)
        elif eye == "wide":
            p.el((150, 48, 180, 80), (255, 255, 255), 5)
            p.el((161, 59, 171, 71), INKB, 0)
        elif eye == "smug":
            p.arc((152, 54, 178, 78), 10, 170, 5)
            p.ln([(150, 58), (180, 56)], 5)
        elif eye == "x":
            p.ln([(154, 56), (172, 74)], 5); p.ln([(172, 56), (154, 74)], 5)
        elif eye == "front":
            p.el((142, 50, 164, 76), (255, 255, 255), 5)
            p.el((166, 50, 188, 76), (255, 255, 255), 5)
            p.el((149, 58, 159, 70), INKB, 0)
            p.el((172, 58, 182, 70), INKB, 0)
        if bob:
            pass
    return _svc(key, 240, 240, fn)


PIG_PIV = (107, 226)


def pigeon(layer, X, Y, k, pose="stand", wing=0.0, eye="open", sx=1.0, sy=1.0, rot=0.0, flip=False, cape=0.0):
    t = pigeon_tile(pose, wing, eye, 0, cape)
    if flip:
        t = t.transpose(Image.FLIP_LEFT_RIGHT)
        piv = (240 - PIG_PIV[0], PIG_PIV[1])
    else:
        piv = PIG_PIV
    blit(layer, t, X, Y, piv[0], piv[1], sx * k * 1.0, sy * k * 1.0, rot)


# ---------------------------------------------------------------- snail
def snail_tile(eyes="open"):
    def fn(d, k):
        p = SP(d, k)
        # body
        p.poly([(40, 300), (60, 240), (240, 230), (430, 250), (500, 300), (470, 330), (60, 336)], SLIME, 8)
        p.el((380, 190, 470, 290), SLIME, 8)
        p.ln([(412, 196), (396, 126)], 9, INKB); p.ln([(412, 196), (396, 126)], 5, SLIME)
        p.ln([(444, 200), (468, 130)], 9, INKB); p.ln([(444, 200), (468, 130)], 5, SLIME)
        for ex, ey in ((396, 120), (468, 124)):
            p.el((ex - 18, ey - 18, ex + 18, ey + 18), (255, 255, 255), 6)
            p.el((ex - 5 + 4, ey - 5, ex + 7 + 4, ey + 8), INKB, 0)
        p.arc((410, 240, 462, 270), 20, 160, 6)
        # shell
        p.el((90, 80, 340, 320), (220, 150, 90), 9)
        p.el((130, 120, 300, 280), (240, 180, 120), 6)
        p.arc((160, 150, 270, 250), 20, 330, 7, (150, 90, 50))
        p.arc((190, 176, 240, 224), 40, 300, 6, (150, 90, 50))
        p.el((210, 196, 222, 208), (150, 90, 50), 0)
    return _svc(("snail", eyes), 520, 350, fn)


# ---------------------------------------------------------------- cart
def cart_tile(part="all", splay=0.0, sag=0.0, wheel_front=True, wrot=0.0, grip=0):
    splay = round(splay * 10) / 10
    sag = round(sag * 10) / 10
    wrot = round(wrot / 15) * 15 % 360
    key = ("cart", part, splay, sag, wheel_front, wrot)

    def fn(d, k):
        p = SP(d, k)
        O = (340, 420)  # local origin = ground centre
        X = lambda x: O[0] + x
        Y = lambda y: O[1] + y
        bt = -250 + 14 * sag      # basket top
        bb = -96 + 22 * sag       # basket bottom
        tw, bw = 190, 150 - 14 * sag
        steel = (196, 204, 218)
        steeld = (120, 128, 146)
        if part in ("all", "back"):
            # handle
            p.ln([(X(-tw + 6), Y(bt + 8)), (X(-tw - 40), Y(bt - 80)), (X(-tw - 110), Y(bt - 80))], 12, INKB)
            p.ln([(X(-tw + 6), Y(bt + 8)), (X(-tw - 40), Y(bt - 80)), (X(-tw - 110), Y(bt - 80))], 6, steel)
            p.ln([(X(-tw - 70), Y(bt - 80)), (X(-tw - 112), Y(bt - 80))], 14, INKB)
            p.ln([(X(-tw - 70), Y(bt - 80)), (X(-tw - 112), Y(bt - 80))], 8, RED)
            # chassis + legs
            sp_ = 60 * splay
            p.ln([(X(-bw + 10), Y(bb)), (X(-bw - 30 - sp_), Y(-40)), (X(bw - 10 + sp_ * 0.6), Y(-40)), (X(bw - 6), Y(bb))], 12, INKB)
            p.ln([(X(-bw + 10), Y(bb)), (X(-bw - 30 - sp_), Y(-40)), (X(bw - 10 + sp_ * 0.6), Y(-40)), (X(bw - 6), Y(bb))], 6, steeld)
            # back basket
            p.poly([(X(-tw), Y(bt)), (X(tw), Y(bt)), (X(bw), Y(bb)), (X(-bw), Y(bb))], (170, 178, 196), 8)
            for i in range(1, 6):
                u = i / 6
                p.ln([(X(lerp(-tw, tw, u)), Y(bt)), (X(lerp(-bw, bw, u)), Y(bb))], 3, steeld)
            # wheels
        if part in ("all", "back"):
            wx_ = -bw - 30 - 60 * splay
            ws = [(wx_, -36, 0, 0)]
            if wheel_front:
                ws.append((bw - 10 + 60 * splay * 0.6 + 30, -36, 0, 0))
            for wxx, wyy, _, _ in ws:
                c = (X(wxx), Y(wyy))
                r = 36
                p.el((c[0] - r, c[1] - r, c[0] + r, c[1] + r), (50, 54, 66), 7)
                p.el((c[0] - r + 11, c[1] - r + 11, c[0] + r - 11, c[1] + r - 11), (170, 176, 190), 4)
                for a in (0, 60, 120):
                    ar = m.radians(a + wrot)
                    p.ln([(c[0] + m.cos(ar) * (r - 14), c[1] + m.sin(ar) * (r - 14)), (c[0] - m.cos(ar) * (r - 14), c[1] - m.sin(ar) * (r - 14))], 4, INKB)
                p.el((c[0] - 6, c[1] - 6, c[0] + 6, c[1] + 6), INKB, 0)
        if part in ("all", "front"):
            # front wire face (semi-open)
            front = [(X(-tw), Y(bt)), (X(tw), Y(bt)), (X(bw), Y(bb)), (X(-bw), Y(bb))]
            p.poly(front, (200, 208, 224, 120) if part == "front" else (200, 208, 224), 8)
            for i in range(1, 8):
                u = i / 8
                p.ln([(X(lerp(-tw, tw, u)), Y(bt)), (X(lerp(-bw, bw, u)), Y(bb))], 3, steeld)
            for j in range(1, 3):
                v = j / 3
                yy = lerp(bt, bb, v)
                xx = lerp(tw, bw, v)
                p.ln([(X(-xx), Y(yy)), (X(xx), Y(yy))], 3, steeld)
            p.ln([(X(-tw), Y(bt)), (X(tw), Y(bt))], 12, INKB)
            p.ln([(X(-tw), Y(bt)), (X(tw), Y(bt))], 6, (230, 236, 246))
    return _svc(key, 700, 470, fn)


CART_PIV = (340, 420)


# ---------------------------------------------------------------- Reggie (register with eyes)
def reggie_body():
    def fn(d, k):
        p = SP(d, k)
        # drawer base
        p.rr((50, 500, 390, 640), 22, (96, 120, 150), 9)
        p.rr((78, 556, 362, 612), 12, (70, 90, 116), 6)
        p.rr((190, 574, 250, 594), 6, (200, 206, 216), 5)
        # upper unit
        p.poly([(76, 330), (364, 330), (386, 506), (54, 506)], (120, 150, 186), 9)
        # screen bezel
        p.rr((104, 346, 336, 448), 14, (40, 56, 76), 8)
        # keys
        for r in range(2):
            for c in range(6):
                x0 = 84 + c * 46
                y0 = 462 + r * 22
                p.rr((x0, y0, x0 + 38, y0 + 17), 5, mix((250, 210, 90), (255, 140, 120), (c + r) % 3 / 2.0), 4)
        # paper slot (left)
        p.rr((44, 436, 76, 456), 4, INKB, 0)
        # stalk mounts
        p.el((142, 316, 178, 342), (70, 80, 100), 6)
        p.el((262, 316, 298, 342), (70, 80, 100), 6)
    return cached(("reggie_body",), lambda: S._ss(440, 660, fn))


def reggie_screen(img_cam, ) -> None:
    pass


REG_PIV = (220, 640)


def reggie_eyes_tile(ext=0.0, lid=0.5, fog=0.0, gdrop=0.0, px=0.0, py=0.0, tw=0.0, wide=0.0):
    """eyes on springs: ext 0..1 stalk extension; returns tile 440x520 whose (220, 520) maps to reggie body (220, 330)"""
    ext = round(ext * 20) / 20
    lid = round(lid * 10) / 10
    fog = round(fog * 10) / 10
    gdrop = round(gdrop * 10) / 10
    px = round(px * 4) / 4
    py = round(py * 4) / 4
    tw = round(tw * 4) / 4
    wide = round(wide * 10) / 10
    key = ("reyes", ext, lid, fog, gdrop, px, py, tw, wide)

    def fn(d, k):
        p = SP(d, k)
        base_y = 510
        L = 60 + 190 * ext
        for ex, off in ((160, tw * 8 if tw else 0), (280, 0)):
            # spring
            n = 7 + int(ext * 6)
            pts = []
            for i in range(n * 2 + 1):
                u = i / (n * 2)
                zig = 14 * (1 if i % 2 else -1) * (0.5 if i in (0, n * 2) else 1)
                pts.append((ex + zig, base_y - L * u))
            p.ln(pts, 8, INKB)
            p.ln(pts, 4, (200, 206, 220))
            top = base_y - L
            r = 36 + 12 * wide
            ey = top - r + 8
            # eyeball
            p.el((ex - r, ey - r, ex + r, ey + r), (255, 255, 255), 7)
            pr = 11 + 4 * wide
            p.el((ex - pr + px * 12, ey - pr + py * 12, ex + pr + px * 12, ey + pr + py * 12), INKB, 0)
            p.el((ex - 4 + px * 12, ey - 8 + py * 12, ex + 2 + px * 12, ey - 2 + py * 12), (255, 255, 255), 0)
            # lid
            if lid < 0.95:
                cover = (1 - lid) * r * 2
                p.rr((ex - r - 3, ey - r - 4, ex + r + 3, ey - r + cover), 6, (120, 150, 186), 5)
            # glasses
            gy = ey + 60 * gdrop
            gr = r + 12
            p.el((ex - gr, gy - gr, ex + gr, gy + gr), None, 7)
            if fog:
                fcol = (245, 248, 252)
                d.ellipse(((ex - gr + 3) * 2, (gy - gr + 3) * 2, (ex + gr - 3) * 2, (gy + gr - 3) * 2), fill=fcol + (int(235 * fog),))
                d.arc(((ex - gr + 14) * 2, (gy - gr + 14) * 2, (ex + gr - 14) * 2, (gy + gr - 14) * 2), 200, 280, fill=(255, 255, 255, 255), width=8)
        # bridge
        gyb = base_y - L + 8 - 36 + 60 * gdrop
        p.ln([(160 + 48 + 12, gyb), (280 - 48 - 12, gyb)], 6)
    return _svc(key, 440, 600, fn)


# ---------------------------------------------------------------- misc
def stamp_tile():
    def build():
        T = Image.new("RGBA", (760, 260), (0, 0, 0, 0))
        d = ImageDraw.Draw(T)
        col = (220, 36, 52, 255)
        d.rounded_rectangle((10, 10, 750, 250), radius=30, outline=col, width=16)
        d.rounded_rectangle((34, 34, 726, 226), radius=18, outline=col, width=5)
        d.text((380, 134), "CARTOON", font=font("bold", 150), fill=col, anchor="mm")
        # ink speckle
        rng = random.Random(4)
        a = np.array(T)
        mask = np.array([[rng.random() > 0.93 for _ in range(760)] for _ in range(260)])
        a[mask, 3] = (a[mask, 3] * 0.35).astype(np.uint8)
        return Image.fromarray(a, "RGBA")
    return cached(("stamp",), build)


def stamp_handle_tile():
    def fn(d, k):
        p = SP(d, k)
        p.rr((60, 130, 240, 200), 20, (130, 80, 50), 9)
        p.rr((100, 20, 200, 140), 30, (160, 100, 60), 9)
        p.rr((120, 6, 180, 40), 14, (190, 120, 70), 8)
    return cached(("stamph",), lambda: S._ss(300, 210, fn))


def wallet_tile(open_=0.0, empty=True):
    open_ = round(open_ * 4) / 4

    def fn(d, k):
        p = SP(d, k)
        if open_ < 0.5:
            p.rr((10, 20, 190, 120), 16, (120, 78, 50), 8)
            p.rr((10, 20, 190, 56), 12, (146, 98, 62), 6)
            p.el((90, 56, 110, 76), GLD, 4)
        else:
            p.poly([(10, 40), (100, 20), (100, 120), (10, 126)], (150, 100, 66), 8)
            p.poly([(190, 40), (100, 20), (100, 120), (190, 126)], (150, 100, 66), 8)
            p.poly([(30, 50), (92, 36), (92, 110), (30, 114)], (230, 200, 160), 4)
            p.poly([(170, 50), (108, 36), (108, 110), (170, 114)], (230, 200, 160), 4)
    return cached(("wallet", open_), lambda: S._ss(200, 140, fn))


def bench_tile():
    def fn(d, k):
        p = SP(d, k)
        p.rr((20, 14, 340, 44), 8, (176, 120, 78), 8)
        p.rr((20, 80, 340, 114), 8, (176, 120, 78), 8)
        p.rr((40, 112, 66, 190), 4, SHELFD, 6)
        p.rr((294, 112, 320, 190), 4, SHELFD, 6)
        p.rr((30, 44, 52, 86), 4, SHELFD, 6)
        p.rr((308, 44, 330, 86), 4, SHELFD, 6)
    return cached(("bench",), lambda: S._ss(360, 200, fn))


def price_chip(txt, size=84, w=300, h=130, sub=None):
    def fn(d, k):
        p = SP(d, k)
        p.rr((8, 8, w - 8, h - 8), 26, (255, 214, 64), 9)
        p.rr((22, 22, w - 22, h - 22), 16, None, 4, (190, 130, 20))
        if sub:
            p.txt((w / 2, h * 0.42), txt, size, INKB)
            p.txt((w / 2, h * 0.80), sub, 34, INKB)
        else:
            p.txt((w / 2, h / 2 + 2), txt, size, INKB)
    return cached(("pchip", txt, size, sub), lambda: S._ss(w, h, fn))
