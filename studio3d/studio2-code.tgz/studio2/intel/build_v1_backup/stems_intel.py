import sys; sys.dont_write_bytecode=True
sys.path.insert(0,'/home/claude/studio2/intel/build')
import numpy as np, soundfile as sf, json, os
from sfx3 import sfx, OSR, lp, music
import anim_intel as A
os.chdir('/home/claude/studio2/intel/build/stems')
DUR=A.DUR; n=int(DUR*OSR); rng=np.random.default_rng(7)
EV=[(0.061,"pop","tick"),(1.80,"thud","hit"),(4.999,"pop","tick"),(11.069,"pop","tick"),(13.60,"plink","soft"),(16.937,"pop","tick"),
    (18.95,"thud","hit"),(28.485,"bonk","hit"),(29.084,"pop","tick"),(32.199,"pop","tick"),(37.982,"bonk","soft"),(39.833,"pop","tick")]
v,sr=sf.read('../vo.wav'); assert sr==24000
v48=np.interp(np.linspace(0,len(v),int(len(v)*OSR/24000),endpoint=False),np.arange(len(v)),v)
vo=np.zeros(n); k=min(n,len(v48)); vo[:k]=v48[:k]; vo=vo/np.abs(vo).max()*.9
sf.write('stem_voice.wav',vo,OSR,subtype='FLOAT')
evs=[];wavs=[];plan=[]
for i,(t,kind,cls) in enumerate(EV):
    w=sfx(kind,rng); evs.append(dict(t=t,kind=kind,dur=len(w)/OSR)); wavs.append(w); plan.append(dict(i=i,t=t,kind=kind,**{"class":cls}))
np.savez('sfx_event_waves.npz',*wavs); json.dump(evs,open('sfx_events.json','w'),indent=1); json.dump(plan,open('sfx_plan.json','w'),indent=1)
bed=music(DUR,rng); sf.write('stem_music.wav',bed*.07,OSR,subtype='FLOAT')
tt=np.arange(n)/OSR
pad=(np.sin(2*np.pi*110*tt)+.6*np.sin(2*np.pi*164.8*tt)+.4*np.sin(2*np.pi*220*tt))*(0.8+0.2*np.sin(2*np.pi*.25*tt))
sf.write('stem_pad.wav',pad*.012,OSR,subtype='FLOAT'); sf.write('stem_room.wav',lp(rng.standard_normal(n),900)*.02,OSR,subtype='FLOAT')
print(len(EV),'events')
