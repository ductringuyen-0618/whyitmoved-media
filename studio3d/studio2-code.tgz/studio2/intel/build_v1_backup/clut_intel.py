import sys; sys.path.insert(0,'/home/claude/studio2/intel/build')
import anim_intel as A, numpy as np
from collections import Counter
h=Counter(); bad=[]
for i in range(1,A.NFR):
    t=i/30; ch,cam=A.movers(t); h[len(ch)]+=1
    if len(ch)>3: bad.append((round(t,2),sorted(ch)))
print("mover histogram",dict(sorted(h.items())),"frames>3:",len(bad),bad[:10])
a=np.array(A.frame(0).convert("RGB")).astype(int); b=np.array(A.frame((A.NFR-1)/30).convert("RGB")).astype(int)
print("frame0==last",np.array_equal(a,b),np.abs(a-b).max(),"NFR",A.NFR,"DUR",A.DUR,"CUTS",A.CUTS)
