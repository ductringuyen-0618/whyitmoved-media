"""INTEL + AMD bot sprites and the props (report card, forecast sign, storm cloud, drop).  All text-only name tags, no logos.
Sprites are drawn at 4x and stored at 2x (tile units are 2 px per design unit) so they stay crisp when drawn at ~1.9x."""
import math as m
from PIL import Image, ImageDraw
import stockshort_B3 as S
from stockshort_B3 import SP, INKB, GLD
from art import cached

RES = 2                       # stored tile px per design unit
INK = INKB
PINC = (206, 214, 228)
PALS = {
    "intel": dict(body=(62, 122, 232), lt=(150, 196, 255), dk=(30, 70, 160), hand=(190, 220, 255), stripe=(30, 70, 160)),
    "amd": dict(body=(240, 98, 52), lt=(255, 170, 120), dk=(150, 48, 22), hand=(255, 214, 170), stripe=(150, 48, 22)),
}
CW, CH = 400, 360              # design canvas
CENTER = (200, 200)            # body centre in design units
FEET = (200, 344)              # feet pivot (bottom of pins) in design units


def hi_tile(w, h, fn, k=4):
    t = Image.new("RGBA", (w * k, h * k), (0, 0, 0, 0))
    fn(ImageDraw.Draw(t), k)
    return t.resize((w * RES, h * RES), Image.LANCZOS)


def arm_hand_pt(side, a, L=64):
    """hand centre in design-canvas units (same maths as the pilot arms, +20 y offset)"""
    sx = 94 if side < 0 else 306
    ar = m.radians(a)
    return sx + side * m.sin(ar) * L, 194 + 20 + m.cos(ar) * L


def bot_tile(who="intel", eyes="open", mouth="grin", al=8, ar=8, sweat=0, brow=0, tagpulse=0):
    al = int(round(al / 10.0)) * 10
    ar = int(round(ar / 10.0)) * 10
    key = ("bot", who, eyes, mouth, al, ar, sweat, brow, tagpulse)

    def build():
        P = PALS[who]

        def fn(d, k):
            p = SP(d, k)
            Y = lambda y: y + 20
            if who == "intel":                 # antenna tab (silhouette differs from the teal Marvell look)
                p.ln([(200, Y(72)), (200, Y(30))], 16, INK)
                p.ln([(200, Y(72)), (200, Y(30))], 8, P["lt"])
                p.rr((168, Y(4), 232, Y(32)), 9, P["lt"], 6)
                p.rr((180, Y(11), 220, Y(15)), 2, (255, 255, 255), 0)
            for i in range(3):
                cx = 90 + 220 * (i + 0.5) / 3
                p.rr((cx - 10, Y(42), cx + 10, Y(78)), 5, PINC, 6)
                p.rr((cx - 10, Y(282), cx + 10, Y(324)), 5, PINC, 6)
                cy = 70 + 220 * (i + 0.5) / 3
                p.rr((56, Y(cy - 10), 98, Y(cy + 10)), 5, PINC, 6)
                p.rr((302, Y(cy - 10), 344, Y(cy + 10)), 5, PINC, 6)
            for side, a in ((-1, al), (1, ar)):
                sx = 94 if side < 0 else 306
                hx, hy = arm_hand_pt(side, a)
                p.ln([(sx, Y(194)), (hx, hy)], 28, INK)
                p.ln([(sx, Y(194)), (hx, hy)], 17, P["lt"])
                p.el((hx - 17, hy - 17, hx + 17, hy + 17), P["hand"], 7)
            p.rr((90, Y(70), 310, Y(290)), 40, P["body"], 10)
            p.rr((106, Y(82), 250, Y(94)), 6, P["lt"], 0)
            # name tag (text only)
            p.rr((112, Y(100), 288, Y(160)), 12, (255, 255, 255), 5)
            p.rr((112, Y(100), 132, Y(160)), 10, P["stripe"], 0)
            p.txt((212, Y(131)), "INTEL" if who == "intel" else "AMD", 46 if who == "intel" else 50, INK)
            if tagpulse:
                p.rr((106, Y(94), 294, Y(166)), 16, None, 8, GLD)
            p.rr((172, Y(272), 228, Y(284)), 5, P["dk"], 4)      # chest slot
            cy = 202
            for sg, ex in ((-1, 158), (1, 242)):
                if eyes in ("worry", "open", "lookr", "wide", "lookd", "flat"):
                    big = 26 if eyes == "wide" else 22
                    lx = 8 if eyes == "lookr" else 0
                    ly = 9 if eyes == "lookd" else 0
                    p.el((ex - big, Y(cy - big - 2), ex + big, Y(cy + big + 2)), (255, 255, 255), 6)
                    pr = 6 if eyes == "wide" else 9
                    p.el((ex - pr + lx, Y(cy - pr + ly), ex + pr + lx, Y(cy + pr + 4 + ly)), INK, 0)
                    p.el((ex - 3 + lx, Y(cy - 6 + ly), ex + 3 + lx, Y(cy + ly)), (255, 255, 255), 0)
                    if eyes == "worry":
                        if sg < 0:
                            p.ln([(ex - 22, Y(cy - 38)), (ex + 20, Y(cy - 52))], 8)
                        else:
                            p.ln([(ex + 22, Y(cy - 38)), (ex - 20, Y(cy - 52))], 8)
                    if eyes == "flat":          # deadpan: heavy flat lids
                        p.rr((ex - big - 3, Y(cy - big - 6), ex + big + 3, Y(cy - 2)), 4, P["body"], 0)
                        p.ln([(ex - big - 2, Y(cy - 2)), (ex + big + 2, Y(cy - 2))], 7)
                    if brow and eyes == "lookr" and sg > 0:
                        p.ln([(ex - 20, Y(cy - 44)), (ex + 20, Y(cy - 52))], 8)
                elif eyes == "blink":
                    p.ln([(ex - 18, Y(cy + 4)), (ex + 18, Y(cy + 4))], 8)
                elif eyes == "happy":
                    p.arc((ex - 19, Y(cy - 10), ex + 19, Y(cy + 26)), 200, 340, 8)
                elif eyes == "x":
                    p.ln([(ex - 15, Y(cy - 15)), (ex + 15, Y(cy + 15))], 8)
                    p.ln([(ex + 15, Y(cy - 15)), (ex - 15, Y(cy + 15))], 8)
                elif eyes == "squint":
                    if sg < 0:
                        p.ln([(ex - 18, Y(cy - 14)), (ex + 10, Y(cy + 2)), (ex - 18, Y(cy + 18))], 8)
                    else:
                        p.ln([(ex + 18, Y(cy - 14)), (ex - 10, Y(cy + 2)), (ex + 18, Y(cy + 18))], 8)
            if mouth == "wob":
                p.ln([(176, Y(252)), (188, Y(242)), (200, Y(254)), (212, Y(242)), (224, Y(252))], 6)
            elif mouth == "nerv":
                p.ln([(172, Y(250)), (184, Y(242)), (196, Y(252)), (208, Y(242)), (220, Y(252)), (230, Y(244))], 6)
            elif mouth == "grin":
                p.pie((168, Y(226), 232, Y(268)), 0, 180, (120, 30, 40), 7)
            elif mouth == "smile":
                p.arc((172, Y(222), 228, Y(258)), 20, 160, 8)
            elif mouth == "o":
                p.el((188, Y(232), 212, Y(262)), (120, 30, 40), 6)
            elif mouth == "open":
                p.el((180, Y(232), 220, Y(264)), (120, 30, 40), 7)
            elif mouth == "sad":
                p.arc((176, Y(240), 224, Y(274)), 200, 340, 7)
            elif mouth == "flat":
                p.ln([(182, Y(252)), (218, Y(252))], 7)
            if sweat:
                p.poly([(302, Y(92)), (290, Y(122)), (302, Y(136)), (314, Y(122))], (140, 210, 255), 5)

        return hi_tile(CW, CH, fn)
    return cached(key, build)


# ----------------------------------------------------------------------------- props
def star_poly(cx, cy, r, rot=0.0):
    pts = []
    for i in range(10):
        rr_ = r if i % 2 == 0 else r * 0.45
        a = m.radians(rot - 90) + i * m.pi / 5
        pts.append((cx + rr_ * m.cos(a), cy + rr_ * m.sin(a)))
    return pts


def star_tile(r=60):
    def build():
        T = r * 2 + 16

        def fn(d, k):
            SP(d, k).poly(star_poly(T / 2, T / 2 + 2, r), (255, 208, 52), 7)
            SP(d, k).poly(star_poly(T / 2, T / 2 + 2, r * 0.55), (255, 232, 130), 0)
        return hi_tile(T, T, fn)
    return cached(("star", r), build)


CARD_W, CARD_H = 280, 350


def card_tile(side="front", stamp=False, wet=False):
    key = ("card", side, stamp, wet)

    def build():
        paper = (214, 226, 242) if wet else (250, 248, 240)
        def fn(d, k):
            p = SP(d, k)
            p.rr((10, 10, 270, 340), 18, paper, 8)
            if side == "front":
                p.rr((26, 26, 254, 80), 10, (62, 122, 232), 5)
                p.txt((140, 54), "REPORT", 34, (255, 255, 255))
                for i, x in enumerate((70, 140, 210)):
                    p.poly(star_poly(x, 130, 28), (232, 234, 240), 5)
                for i in range(3):
                    p.ln([(40, 206 + i * 34), (240 - 30 * (i == 2), 206 + i * 34)], 7, (150, 156, 172))
                if stamp:
                    p.poly(star_poly(140, 170, 74), (255, 208, 52), 8)
                    p.poly(star_poly(140, 170, 40), (255, 232, 130), 0)
            else:
                # back: a rain-cloud sticker
                cx, cy = 140, 150
                for ox, oy, rr_ in ((-52, 14, 40), (0, -12, 54), (54, 12, 42), (-8, 22, 44)):
                    p.el((cx + ox - rr_, cy + oy - rr_, cx + ox + rr_, cy + oy + rr_), (96, 104, 132), 7)
                p.rr((cx - 92, cy + 12, cx + 98, cy + 66), 24, (96, 104, 132), 0)
                for ox, oy, rr_ in ((-52, 14, 36), (0, -12, 50), (54, 12, 38), (-8, 22, 40)):
                    p.el((cx + ox - rr_, cy + oy - rr_, cx + ox + rr_, cy + oy + rr_), (96, 104, 132), 0)
                p.rr((cx - 90, cy + 14, cx + 96, cy + 62), 22, (96, 104, 132), 0)
                for x in (-50, -10, 30, 70):
                    p.ln([(cx + x, cy + 84), (cx + x - 8, cy + 114)], 8, (80, 160, 235))
                p.ln([(100, 292), (180, 292)], 7, (150, 156, 172))
            if wet:
                for (ex, ey, rw, rh) in ((60, 300, 34, 14), (214, 120, 26, 10), (150, 322, 30, 10)):
                    p.el((ex - rw, ey - rh, ex + rw, ey + rh), (150, 184, 226), 0)
        return hi_tile(CARD_W, CARD_H, fn)
    return cached(key, build)


SIGN_W, SIGN_H = 320, 440


def sign_tile(face="sun"):
    key = ("sign", face)

    def build():
        def fn(d, k):
            p = SP(d, k)
            p.rr((146, 240, 174, 432), 8, (150, 100, 68), 7)
            p.rr((10, 10, 310, 250), 28, (255, 250, 235), 9)
            cx, cy = 160, 126
            if face == "sun":
                for i in range(10):
                    a = m.radians(i * 36)
                    p.ln([(cx + 66 * m.cos(a), cy + 66 * m.sin(a)), (cx + 90 * m.cos(a), cy + 90 * m.sin(a))], 9, (240, 170, 20))
                p.el((cx - 62, cy - 62, cx + 62, cy + 62), (255, 214, 64), 8)
                p.el((cx - 28, cy - 22, cx - 14, cy - 6), INK, 0)
                p.el((cx + 14, cy - 22, cx + 28, cy - 6), INK, 0)
                p.arc((cx - 32, cy - 12, cx + 32, cy + 36), 20, 160, 8)
            else:
                p.el((cx - 62, cy - 62, cx + 62, cy + 62), (226, 200, 120), 8)
                p.ln([(cx - 36, cy - 30), (cx - 12, cy - 22)], 7)
                p.ln([(cx + 36, cy - 30), (cx + 12, cy - 22)], 7)
                p.el((cx - 28, cy - 18, cx - 14, cy - 4), INK, 0)
                p.el((cx + 14, cy - 18, cx + 28, cy - 4), INK, 0)
                p.arc((cx - 30, cy + 14, cx + 30, cy + 54), 200, 340, 8)
                p.poly([(cx + 52, cy - 52), (cx + 42, cy - 28), (cx + 52, cy - 16), (cx + 62, cy - 28)], (140, 210, 255), 5)
        return hi_tile(SIGN_W, SIGN_H, fn)
    return cached(key, build)


CLOUD_W, CLOUD_H = 520, 270


def cloud_tile():
    def build():
        col = (88, 96, 124)

        def fn(d, k):
            p = SP(d, k)
            blobs = ((120, 160, 70), (210, 120, 92), (320, 112, 96), (410, 160, 72), (265, 168, 84))
            for cx, cy, r in blobs:
                p.el((cx - r, cy - r, cx + r, cy + r), col, 8)
            p.rr((70, 150, 450, 232), 40, col, 8)
            for cx, cy, r in blobs:
                p.el((cx - r + 6, cy - r + 6, cx + r - 6, cy + r - 6), col, 0)
            p.rr((76, 156, 444, 226), 34, col, 0)
            p.rr((120, 200, 400, 232), 16, (66, 72, 98), 0)
        return hi_tile(CLOUD_W, CLOUD_H, fn)
    return cached(("cloud",), build)


def drop_tile():
    def build():
        def fn(d, k):
            SP(d, k).poly([(20, 4), (6, 34), (20, 48), (34, 34)], (110, 180, 245), 5)
        return hi_tile(40, 54, fn)
    return cached(("drop",), build)


def minichip_tile():
    def build():
        def fn(d, k):
            p = SP(d, k)
            for i in range(4):
                p.rr((6 + i * 12, 2, 12 + i * 12, 12), 2, PINC, 3)
                p.rr((6 + i * 12, 46, 12 + i * 12, 56), 2, PINC, 3)
            p.rr((6, 8, 58, 54), 8, (70, 76, 92), 5)
            p.rr((18, 20, 46, 42), 4, (150, 196, 255), 3)
        return hi_tile(64, 62, fn)
    return cached(("minichip",), build)
