"""Character canvases for PILOT v3 (copied from the pilot's anim.py; tags now read MARVELL / LUMENTUM)."""
import math as m
from PIL import Image, ImageDraw
import numpy as np
import stockshort_B3 as S
from stockshort_B3 import SP, INKB, CRM, GLD, RED, put, blit, bram_tile as mar_tile, beam_tile as lum_tile
from art import *

def rot_pt(x, y, sx, sy, rot, lx, ly):
    """local offset -> world, for a transformed (scaled/rotated) sprite with pivot at (x,y)"""
    c, sn = m.cos(m.radians(rot)), m.sin(m.radians(rot))
    vx, vy = lx * sx, ly * sy
    return x + c * vx - sn * vy, y + sn * vx + c * vy



def arm_hand(side, a, base_x, base_y, L):
    ar = m.radians(a)
    return base_x + side * m.sin(ar) * L, base_y + m.cos(ar) * L


def tagtile(txt, w, h, fs, fill=(255, 255, 255), stripe=RED):
    def fn(d, k):
        p = SP(d, k)
        p.rr((3, 3, w - 3, h - 3), 8, fill, 4)
        p.rr((3, 3, 20, h - 3), 6, stripe, 0)
        p.txt((w / 2 + 8, h / 2 + 1), txt, fs, INKB)
    return cached(("tag", txt, w, h, fs), lambda: S._ss(w, h, fn))


# ---------------------------------------------------------------- Marvell canvas
BCV_P = (260, 440)
BCV_O = (60, 116)


def subtile(txt, w, h):
    def fn(d, k):
        p = SP(d, k)
        p.rr((2, 2, w - 2, h - 2), 8, (255, 255, 255), 3)
        p.txt((w / 2, h / 2 + 1), txt, 17, INKB)
    return cached(("sub", txt, w, h), lambda: S._ss(w, h, fn))


def mar_cv(eyes="open", mouth="smile", al=8, ar=8, sweat=0, tag=0.0, thumb=False, watch=False, beard=0.0, chip=False, flip=False, bulb_hand=False):
    al = int(round(al / 15.0)) * 15
    ar = int(round(ar / 15.0)) * 15
    key = ("bcv", eyes, mouth, al, ar, sweat, round(tag), thumb, watch, round(beard * 6), chip, flip)

    def build():
        cv = Image.new("RGBA", (520, 520), (0, 0, 0, 0))
        cv.alpha_composite(mar_tile(eyes=eyes, mouth=mouth, al=al, ar=ar, sweat=sweat), BCV_O)
        ox, oy = BCV_O

        def F(x, y):
            return x + ox, y + oy
        if tag and not flip:
            cv.alpha_composite(tagtile("MARVELL", 196, 40, 25), (int(ox + 108), int(oy + 106)))
            cv.alpha_composite(subtile("CHIPS", 96, 24), (int(ox + 152), int(oy + 144)))
        if thumb:
            hx, hy = arm_hand(+1, ar, 306, 194, 64)
            T = S._ss(60, 70, lambda d, k: SP(d, k).rr((16, 6, 42, 44), 10, TLL, 5))
            cv.alpha_composite(T, (int(ox + hx - 30), int(oy + hy - 52)))
            T2 = S._ss(60, 60, lambda d, k: SP(d, k).el((12, 12, 48, 48), TLL, 6))
            cv.alpha_composite(T2, (int(ox + hx - 30), int(oy + hy - 30)))
        if watch:
            hx, hy = arm_hand(-1, al, 94, 194, 64)
            T = S._ss(50, 50, lambda d, k: SP(d, k).el((6, 6, 44, 44), (255, 255, 255), 5))
            ImageDraw.Draw(T).line((25, 25, 25, 12), fill=INKB + (255,), width=3)
            ImageDraw.Draw(T).line((25, 25, 34, 28), fill=INKB + (255,), width=3)
            cv.alpha_composite(T, (int(ox + hx - 25), int(oy + hy - 25)))
        if beard > 0.02:
            h = 8 + 60 * beard
            T = S._ss(120, 120, lambda d, k: SP(d, k).poly([(14, 4), (106, 4), (96, 4 + h * 0.5), (84, 4 + h * 0.9), (60, 4 + h), (36, 4 + h * 0.9), (22, 4 + h * 0.5)], (214, 204, 190), 5))
            cv.alpha_composite(T, (int(ox + 140), int(oy + 250)))
        if chip:
            cv.alpha_composite(chip_tile(), (int(ox + 168), int(oy + 4)))
        if flip:
            cv = cv.transpose(Image.FLIP_LEFT_RIGHT)
            if tag:
                cv.alpha_composite(tagtile("MARVELL", 196, 40, 25), (int(520 - (ox + 108) - 196), int(oy + 106)))
        return cv
    return cached(key, build)


MCV_P = (260, 640)
MCV_O = (60, 80)


def lum_cv(eyes="lookl", mouth="smile", al=8, ar=8, glow=0.5, brow=0, tag=False, hat=False, flip=False):
    al = int(round(al / 15.0)) * 15
    ar = int(round(ar / 15.0)) * 15
    key = ("mcv", eyes, mouth, al, ar, round(glow * 2), brow, tag, hat, flip)

    def build():
        cv = Image.new("RGBA", (520, 700), (0, 0, 0, 0))
        cv.alpha_composite(lum_tile(eyes=eyes, mouth=mouth, al=al, ar=ar, glow=glow, brow=brow), MCV_O)
        ox, oy = MCV_O
        if tag:
            cv.alpha_composite(tagtile("LUMENTUM", 206, 38, 23, stripe=(60, 150, 200)), (int(ox + 92), int(oy + 408)))
            cv.alpha_composite(subtile("LASERS", 110, 24), (int(ox + 146), int(oy + 450)))
        if hat:
            def fn(d, k):
                p = SP(d, k)
                p.ln([(290, 330 - 0), (306, 220), (270, 120), (234, 96)], 28, INKB)
                p.ln([(290, 330), (306, 220), (270, 120), (234, 96)], 17, CYAN)
                p.el((218, 80, 252, 112), (230, 252, 255), 7)
            cv.alpha_composite(S._ss(400, 400, fn), (ox, oy))
        if flip:
            cv = cv.transpose(Image.FLIP_LEFT_RIGHT)
        return cv
    return cached(key, build)


RCV_P = (220, 840)


def reggie_cv(ext=0.0, lid=0.5, fog=0.0, gdrop=0.0, px=0.0, py=0.0, tw=0.0, wide=0.0, chip=None, crack=0.0, chip_s=1.0, arm=None):
    ext = round(ext * 20) / 20
    key = ("rcv", ext, round(lid * 10), round(fog * 10), round(gdrop * 10), round(px * 4), round(py * 4), round(tw * 4), round(wide * 10), chip, round(crack * 5), round(chip_s * 10), arm and (round(arm[0] / 6), round(arm[1] / 6)))

    def build():
        cv = Image.new("RGBA", (440, 860), (0, 0, 0, 0))
        cv.alpha_composite(reggie_body(), (0, 200))
        if chip:
            ct = price_chip(chip)
            if chip_s != 1.0:
                ct = ct.resize((int(ct.width * chip_s), int(ct.height * chip_s)), Image.BILINEAR)
            cv.alpha_composite(ct, (int(220 - ct.width / 2), int(597 - ct.height / 2)))
        if crack:
            d = ImageDraw.Draw(cv)
            pts = [[(222, 548), (240, 580), (216, 604), (250, 640)], [(240, 580), (290, 590), (320, 640)], [(216, 604), (160, 600), (120, 650)], [(222, 548), (190, 560), (150, 548)]]
            n = max(1, int(len(pts) * crack + 0.5))
            for pp in pts[:n]:
                d.line(pp, fill=(255, 255, 255, 255), width=5)
                d.line(pp, fill=INKB + (255,), width=2)
        cv.alpha_composite(reggie_eyes_tile(ext, lid, fog, gdrop, px, py, tw, wide), (0, 20))
        if arm:
            d = ImageDraw.Draw(cv)
            sx_, sy_ = 70, 740
            d.line([(sx_, sy_), (arm[0], arm[1])], fill=INKB + (255,), width=26)
            d.line([(sx_, sy_), (arm[0], arm[1])], fill=(120, 150, 186, 255), width=16)
            d.ellipse((arm[0] - 22, arm[1] - 22, arm[0] + 22, arm[1] + 22), fill=(255, 255, 255, 255), outline=INKB + (255,), width=5)
        return cv
    return cached(key, build)


