# INTEL - SHOT LIST (Director) - timed to vo_exact.json (46.28 s, 128 words)
Rules obeyed: ONE mover per row (camera push excepted), max 3 things on screen (hero, one prop, one chip), hard cuts only in VO gaps, no slow-mo, one big hit per beat, VO never stops (every line gap 0.17 s).
Notation: `@word t` = trigger word and its start time. B1 hold = nothing moves but the 1.00 -> 1.04 camera push. I=Intel, A=AMD. Persistent **pill** "INTEL STOCK -28.6%" (frame furniture, not counted as the chip) from 4.5 s to 44.7 s.
Hard cuts (all inside gaps): **8.155 | 13.985 | 23.915 | 35.785 | 44.485**. Camera: one push per beat (1.00 -> 1.04), resets on each cut; frame 0 camera = last frame camera (1.00).

## SETS (2) and CAMERA
- **SET A "Studio"**: flat pale-sky wall (200,226,246), one tan floor band (214,170,126), one floor line. Used by B1-B5 (B5 adds nothing new).
- **SET A-wet**: same, plus the puddle (flat blue-grey ellipse, grows during B3-B4); used B3 (from 20.65) to B5. The cut at 44.485 returns to the DRY set A (= frame 0).
- Safe area y=330..1520, feet ~y=1250. Intel >= 520 px tall (single), A ~340 px, cloud ~420 px wide, forecast sign ~300 px.

## SHOT TABLE
| time (s) | spoken | THE ONE FOCAL ACTION (trigger) | freezes / leaves | expression | SFX | text |
|---|---|---|---|---|---|---|
| **BEAT 1 - A, Intel centre (hook)** |||||||
| 0.03-1.74 | Intel's stock fell almost | Title card big (y 400-900): "INTEL STOCK" with the "-28.6%" chip lifted high on its spring, slowly settling (`@fell 0.936`) | Intel idle, smiling | neutral grin | - | INTEL STOCK / -28.6% |
| 1.74-3.51 | 29 percent last Friday. | "-28.6%" chip slams down onto the title bar (`@29 1.736`), squash-and-settle, no shake | Intel | grin | soft thud | same |
| 3.57-4.50 | Meet Intel, | Intel bows and taps its INTEL tag (`@Intel 3.874`) | title | happy eyes | - | title |
| 4.50-4.99 | who makes | Title shrinks to the top pill (0.4 s ease) (`@who 4.574`) | Intel | grin | - | pill |
| 4.99-5.62 | brains for | Intel pulls a small chip from its chest and holds it up (`@brains 4.999`) | pill | open mouth | pop | pill |
| 5.62-6.91 | lots of laptops. | Hold, chip raised, camera push | all | proud | - | pill |
| 6.94-7.44 | Here's the | Chip tucks back in; hold | - | grin | - | pill |
| 7.44-8.15 | weird part. | Intel tilts head, eyes slide right (`@weird 7.44`) | pill | puzzled | - | pill |
| **BEAT 2 - cut 8.155 - A, Intel centre (SETUP: gold stars)** |||||||
| 8.29-9.42 | Its last quarter was | A report card slides up from the floor into Intel's hands (`@quarter 8.816`) | pill | calm | - | pill |
| 9.42-9.94 | actually | Hold, camera push | all | proud | - | pill |
| 9.94-10.44 | fine. | Gold star stamps onto the card (`@fine 9.941`) | Intel | beaming | - | pill |
| 10.44-11.07 | Sales grew | Hold; chip fades in at the end | Intel | beaming | - | pill |
| 11.07-12.27 | 21 percent | Chip "SALES +21%" pops beside the card (`@21 11.069`) | Intel | proud | - | SALES +21% |
| 12.27-13.34 | while gold stars | Chip leaves; Intel lifts the card high (`@while 12.269`) | chip | big smile | - | pill |
| 13.34-13.90 | rained down. | Three gold stars drop onto Intel's head and bounce off (`@rained 13.344`) = B2 hit | card | eyes closed, bliss | chime | pill |
| **BEAT 3 - cut 13.985 - A, Intel centre (HIT: the cloud)** |||||||
| 14.13-14.93 | Then Intel shared | Intel tosses the card away off-frame and lifts a sunny forecast sign (`@shared 14.984`) | pill | confident | - | pill |
| 14.98-16.38 | its forecast for next | Hold sign (sun face), camera push | all | confident | - | pill |
| 16.38-16.94 | quarter. | Sign flips to its frowning-sun side (`@quarter 16.384`) | Intel | blank | - | pill |
| 16.94-18.70 | Lower than everyone expected. | Chip "FORECAST LOWER THAN EXPECTED" slides in under the sign (`@Lower 16.937`), holds to 18.70 | Intel frozen | worry building | - | FORECAST LOWER THAN EXPECTED |
| 18.70-19.95 | Storm clouds. | Chip leaves; dark cloud drops in over Intel's head and stops with a bounce (`@Storm 18.70`) = B3 hit | Intel, sign | wide eyes | soft thump | pill |
| 19.95-20.55 | Right over | Hold | all | blank | - | pill |
| 20.55-21.02 | its head. | Rain starts, only under the cloud (`@head 20.55`); the puddle starts as a small ellipse | Intel | grim grin | - | pill |
| 21.02-21.72 | Intel says | Hold (rain falling) | - | grim grin | - | pill |
| 21.72-22.59 | PC sales | Chip "PC SLOWDOWN" appears over the sign (`@PC 21.719`) | Intel | worry | - | PC SLOWDOWN |
| 22.59-23.84 | stay slow into next year. | Hold; puddle widens slowly, camera push | all | worry | - | PC SLOWDOWN (leaves 23.84) |
| **BEAT 4 - cut 23.915 - A-wet, Intel centre, puddle at feet (HIT: the slide)** |||||||
| 24.15-25.45 | Reports tie it to a | Hold; the cloud and rain have gone, the puddle stays | Intel | worry | - | pill |
| 25.45-26.10 | memory chip | Chip "REPORTS: MEMORY SHORTAGE" slides in (`@memory 25.449`) | Intel | worry | - | REPORTS: MEMORY SHORTAGE |
| 26.10-26.76 | shortage. | Intel glances down at its feet (`@shortage 26.099`) | chip | worried glance | - | chip (leaves 26.60) |
| 26.76-27.76 | So Intel's stock | Intel takes one step toward the puddle (`@Intel's 26.935`) | puddle | uneasy | - | pill |
| 27.76-28.59 | slid on the wet | Foot hits the wet patch, Intel skids sideways and tips back (`@slid 27.76`) | puddle | wide eyes | - | pill |
| 28.59-29.18 | floor. | Intel lands flat on its back, one shake (`@floor 28.585`) = B4 hit | puddle | dazed (x eyes) | bonk | pill |
| 29.18-29.76 | From 92 | Chip "$92" pops above Intel (`@92 29.184`) | Intel flat | dazed | - | $92 |
| 29.76-30.73 | dollars down to | Hold, camera push | chip | dazed | - | $92 |
| 30.73-31.65 | 66. | Chip swaps to "$66" in one cut-frame (`@66 30.734`) | Intel flat | dazed | - | $66 |
| 31.65-32.30 | That's down | $66 leaves; Intel's arm flops down (`@down 31.974`) | - | dazed | - | pill |
| 32.30-33.32 | 28.6 | Chip "-28.6%" stamps big in red (`@28.6 32.299`) | Intel | dazed | tick | -28.6% |
| 33.32-33.84 | percent. | Hold | chip | dazed | - | -28.6% |
| 33.84-35.04 | Its worst day in about | Intel sits up slowly, dust puff, chip leaves (`@worst 34.041`) | - | tired | - | pill |
| 35.04-35.70 | fifty years. | Intel lifts the soggy card; one drop falls from it (`@fifty 35.041`) | puddle | sheepish | - | pill |
| **BEAT 5 - cut 35.785 - A-wet, Intel left, AMD enters right (CALLBACK)** |||||||
| 36.03-37.18 | Rival chip stocks | AMD walks in from the right edge toward the puddle (`@Rival 36.032`) | Intel sits, card | cheerful | - | pill |
| 37.18-38.08 | slipped on the | AMD's foot hits the puddle and he flips up (`@slipped 37.182`) | Intel frozen | wide eyes | squeak | pill |
| 38.08-38.53 | same floor. | AMD lands flat next to Intel (`@floor 38.082`) = B5 hit, no shake | Intel | dazed | bonk (soft) | pill |
| 38.53-39.78 | AMD and others fell | Hold, camera push | all | dazed | - | pill |
| 39.78-40.76 | 4 to 12 | Chip "PEERS -4% TO -12%" pops above AMD (`@4 39.933`) | both | dazed | - | PEERS -4% TO -12% |
| 40.76-41.30 | percent. | Hold | chip | dazed | - | chip (leaves 41.13) |
| 41.30-42.89 | Last quarter was fine, | Intel stands, holds up the card, gold stars face camera (`@quarter 41.62`) | AMD flat | proud | - | pill |
| 42.89-43.87 | but the forecast | Card flips to the back: a rain-cloud sticker (`@but 42.895`) | AMD | deadpan | flap | pill |
| 43.87-44.40 | was the problem. | Hold on the cloud sticker; camera push | all | deadpan | - | pill |
| **LOOP - cut 44.485 - dry Set A = frame 0** |||||||
| 44.73-45.45 | So that's why | Cut to the opening frame: Intel idle on the dry floor; pill grows back into the big title (`@So 44.729`, 0.6 s) | all else gone | grin | - | INTEL STOCK / -28.6% |
| 45.45-46.28 | Intel's stock fell. | Hold, title big, camera at 1.00, ending exactly on the frame-0 composition | all | grin | - | title |

## GAG STRUCTURE (setup -> hit -> callback)
- SETUP B2: gold-star card, stars rain, Intel at its happiest. HIT B3-B4: the cloud (18.70) then the skid-bonk (28.585). CALLBACK B5: AMD on the same puddle (37.18); the card flips to a rain cloud (42.895).
- SFX (8, soft, <0.4 s, never within 0.3 s of another): 1.736 thud | 4.999 pop | 13.344 chime | 18.70 thump | 28.585 bonk | 32.299 tick | 38.082 squeak-bonk (squeak at 37.18 optional, drop if within 0.3 s) | 42.895 flap. Rain bed: very soft, under -30 dB, 20.55-23.84 only.

## SET + CAST SHEET (reuse /home/claude/studio2/pilot2/build/chars.py, art.py)
- **INTEL**: derive from `bram_cv` / `bram_tile` (square chip bot, arms al/ar, eyes, mouth, sweat, `chip=True`), recolor with `art.tint_hue(img, +45)` to blue (chips/pins a lighter blue), tag via `tagtile("INTEL",150,40,30)` and no CHIPS sub-tag; add a flat antenna tab so the silhouette differs from Marvell/Bram. No logo.
- **AMD**: same `bram_cv`, scaled to ~340 px, tint orange-red, tag "AMD", never shows the Intel chip.
- Props: `paper_tile` (report card, with a stamped star: `stamp_tile`/`star5` in art.py), `qmark`-style sign tile for forecast sign (sun face = `glow`/`radial` disc; frown = flip mouth), storm cloud = `puff` cluster (dark grey), `shadow` puddle, rain = short vertical lines, `price_chip(txt)` for chips, `pill` for the topic pill.
- Poses, easiest first (fallback): 1 Intel idle/grin/open/blink [exists]. 2 happy/worry/wide eyes [exists]. 3 arms up holding the card [al/ar arms]. 4 head tilt + eyes right (lookr) [eyes only]. 5 sweat [sweat=1]. 6 chip-in-hand pull (chip=True) [wave arm]. 7 dazed x-eyes lying (rot 90) [x eyes standing]. 8 sitting up (rot 20 + dust puff) [stand with sag]. Hardest: skid-tip-back (rot ~-70 + squash on landing) [rotate 90 and drop], AMD flip (same) [same fallback], card flip [swap sprites front/back].
