# INTEL - SCRIPT (wall-to-wall VO, 5 beats) - Story Editor + Head Writer

## 1. THE ONE IDEA (2 sentences) + THE ONE METAPHOR
**Idea:** Intel's stock fell 28.6% on Fri Oct 30 (closed $65.76, from $92.07), but not because last quarter went badly: Q3 was fine. It fell because Intel's forecast for next quarter came in lower than expected.
**Metaphor: the weather forecast.** Intel proudly shows a report card full of gold stars (Q3 fine), then reads out its forecast and a storm cloud parks over its head. The rain makes the floor wet, so the stock literally slips, and rival chip bots slip on the SAME wet floor.
**Characters (max 3 ever, 2 used):** INTEL = blue square chip bot, tag INTEL (never the teal Marvell look, no logo). AMD = small orange-red side bot, tag AMD, beat 5 only. Props: gold-star report card, forecast sign, storm cloud, puddle.
**Hook:** title card "INTEL STOCK / -28.6%" is on screen from frame 0, first words state the topic, it shrinks to a small pill at 4.5 s and grows back at 44.7 s to loop.

## 2. VOICEOVER (18 lines, 128 words, no line over 9 words; Kokoro am_michael, speed 1.0)
Measured with `/home/claude/studio2/intel/vo_measure.py` (copy of pilot2 method), lines butted together by the natural 0.17 s pad. Files: `vo.wav`, `vo_timing.json`, exact word times `vo_exact.json`. Wording tuned (no mid-line full stops) so no in-line pause tops 0.33 s.

| # | Line | Start | End |
|---|------|-------|-----|
| 1 | Intel's stock fell almost 29 percent last Friday. | 0.03 | 3.34 |
| 2 | Meet Intel, who makes brains for lots of laptops. | 3.51 | 6.74 |
| 3 | Here's the weird part. | 6.91 | 8.07 |
| 4 | Its last quarter was actually fine. | 8.24 | 10.20 |
| 5 | Sales grew 21 percent while gold stars rained down. | 10.37 | 13.90 |
| 6 | Then Intel shared its forecast for next quarter. | 14.07 | 16.68 |
| 7 | Lower than everyone expected. | 16.85 | 18.44 |
| 8 | Storm clouds. Right over its head. | 18.61 | 20.71 |
| 9 | Intel says PC sales stay slow into next year. | 20.88 | 23.83 |
| 10 | Reports tie it to a memory chip shortage. | 24.00 | 26.43 |
| 11 | So Intel's stock slid on the wet floor. | 26.60 | 28.72 |
| 12 | From 92 dollars down to 66. | 28.89 | 31.34 |
| 13 | That's down 28.6 percent. | 31.51 | 33.53 |
| 14 | Its worst day in about fifty years. | 33.70 | 35.70 |
| 15 | Rival chip stocks slipped on the same floor. | 35.87 | 38.22 |
| 16 | AMD and others fell 4 to 12 percent. | 38.39 | 40.96 |
| 17 | Last quarter was fine, but the forecast was the problem. | 41.13 | 44.40 |
| 18 | So that's why Intel's stock fell. | 44.57 | 46.28 |

**TOTAL speech 46.28 s (wav 46.42 s), 128 words. Largest line gap 0.17 s; largest silence inside a line 0.33 s (fine|but, 42.45).** Loop: L18 "So that's why Intel's stock fell." runs into L1 "Intel's stock fell almost 29 percent..." and the picture returns to the opening frame.

## 3. THE 5 BEATS (one scene, one focal action, one gag: setup -> hit -> callback)
Gag spine: SETUP the gold-star report card (B2) -> HIT the storm cloud and the slip on the wet floor (B3-B4) -> CALLBACK the soggy card is flipped to show the rain cloud on its back, and AMD slips on the same puddle (B5).

### BEAT 1 - "Meet Intel" (L1-3, 0.03-8.07)
Visual: giant title card, then Intel (centre, big) bows, pulls a small chip from its chest ("brains"), tilts its head at "weird".
Gag setup: Intel looks proud and clean: dry floor, nothing wrong. Text: title card, then the pill.

### BEAT 2 - "Last quarter was fine" (L4-5, 8.24-13.90)
Visual: a report card slides up into Intel's hands; a gold star is stamped on it; chip "SALES +21%"; gold stars rain onto Intel's head and it beams.
Gag: SETUP, Intel at its happiest. This is the "high" the storm will fall on.

### BEAT 3 - "The forecast" (L6-9, 14.07-23.83)
Visual: Intel holds up a forecast sign with a sunny face; the sign flips to a frown with chip "FORECAST LOWER THAN EXPECTED"; a dark cloud drops over Intel's head and rain starts on Intel only; chip "PC SLOWDOWN" (Intel's own word).
Gag HIT: the cloud arrives on "clouds" and Intel's grin does not move while it rains.

### BEAT 4 - "The slide" (L10-14, 24.00-35.70)
Visual: puddle spreads under Intel; chip "REPORTS: MEMORY SHORTAGE" (hedged) shows while Intel's feet slide; on "slid" Intel skids and lands flat; price chips $92 then $66 (one at a time); then "-28.6%" stamps big; on "fifty years" Intel lifts the soggy card and a drop falls off it.
Gag HIT: the skid-and-bonk on the wet floor, the biggest hit of the clip.

### BEAT 5 - "Same floor" (L15-18, 35.87-46.28)
Visual: AMD (small, side) walks in, steps on the same puddle, slips and lands beside Intel; chip "PEERS -4% TO -12%". Intel stands, flips the soggy card (back = rain cloud) on "but the forecast". Hard cut at 44.485 to the dry opening frame, title card grows back.
Gag CALLBACK: same wet floor, same card; the reset to a dry floor is the loop.

## 4. FACT AND HEDGE CHECK (vs FACTS_INTC)
- "fell almost 29 percent last Friday" / "28.6 percent" / "92 down to 66": F2 (2 sources; Fri Oct 30 close $65.76 vs $92.07 = -28.58%).
- "Its last quarter was fine, sales grew 21 percent": F5 (Intel release; revenue +21%).
- "forecast ... lower than everyone expected": F6 (Q4 guidance $15-16bn vs ~$17bn expected; EPS $0.25 vs ~$0.43). Dollar figures left off screen on purpose (keeps max 2 numbers/sentence; the cause stays clear).
- "Intel says PC sales stay slow into next year": F7 (Intel release: slowdown continues through first half of next year). Attributed to Intel.
- "Reports tie it to a memory chip shortage": F8 (media, 2 sources). Attributed with "Reports", never stated as proven.
- "worst day in about fifty years": F4 (AP/IBTimes: only worse day was 1974). NOT "worst ever".
- "AMD and others fell 4 to 12 percent": F12 (Reuters; sympathy, timing within day not stated). Wording is "slipped on the same floor", never "Intel caused it".
- Not used (on purpose): Israel factory, analysts, cash flow, government stake, bad-planning quote, Nasdaq drop.
- No advice, no predictions, no logos, no real people, no 'cartoon' or 'not advice' wording.

## 5. NOTES FOR THE DIRECTOR
- Time every action to `vo_exact.json`; hard cuts only in line gaps (8.155 | 13.985 | 23.915 | 35.785 | 44.485).
- Keep Intel visually distinct from Marvell's Bram: blue, flatter square, antenna tab, tag INTEL.
