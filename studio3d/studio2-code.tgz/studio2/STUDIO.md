# WHY IT MOVED ANIMATION STUDIO

Mission: tiny 30-45 s cartoon clips where something FUNNY HAPPENS EVERY SECOND and a 12-year-old gets it with the sound off.

## Iron rules (Tri's feedback, Nov 3)
1. ONE idea per clip. If it needs a finance lesson, cut it. Say what happened in plain words.
2. Plain-English humor only: slapstick, reactions, simple wordplay, a clear "oh no". No jargon jokes (no "all-stock", "enterprise value", "exchange ratio").
3. ACTION first. Every second has something moving or changing. Text and voice SUPPORT the action, never carry it.
4. Facts stay sourced. No advice, no predictions, no logos, no real people. Do NOT add 'cartoon / not advice' captions, stamps or spoken lines (owner decision Nov 3); just never give advice.
5. Max 2 numbers on screen per beat. Words a kid knows.

## Added Nov 3 evening (Tri: 'too many things at the same time; voice not continuous, feels empty')
6. ONE FOCAL ACTION AT A TIME. At any moment the viewer's eye has exactly one place to look. Background stays calm and still; side characters freeze or leave the shot while the hero acts. Max 3 things on screen at once (hero, one prop, one text chip).
7. THE VOICE NEVER STOPS. Narration is wall-to-wall: no silence longer than 0.4 s from the first word to the last. The VO is written and recorded FIRST; the Director times every action to the real recorded word times, never the other way round. No slow-mo or time-warp tricks to stretch picture.
8. Fewer, bigger gags. 4-5 gags in 40 s, each given 4-6 s to land, each repeated or built on once (callback), instead of 15 small ones.
9. Hold the camera: one zoom level per scene, big characters (>= 340 px), no constant shake.

## Departments (one agent each, always in this order)
1. Story Editor   - picks the ONE plain idea, writes the 3-sentence "what happened" a kid can repeat. Kills anything complex.
2. Head Writer    - joke pass + voiceover (short sentences, <= 8 words each).
3. DIRECTOR       - owns the ACTION. Writes the shot sheet: every 1-2 seconds = what the characters DO (verb), camera, props, expression, sound effect. Rejects any shot that is just text or standing still.
4. Animation Lead - builds the clip from the shot sheet (renderer + character/set library). Pushes back on anything undoable instead of faking it.
5b. SOUND DESIGNER / MIXER - owns SFX and levels. The voice is king: SFX only on the 4-6 big hits (one per beat) plus tiny ticks for chips; no sfx under a spoken key word; music bed barely audible. Reviews every clip's mix (stems, levels, LUFS) before QA.
5. QA / Table read - three checks: (a) fact-check vs sources, (b) "kid test": explain the clip in one sentence with sound off, (c) motion check: no stretch > 1.5 s without a change.
6. Producer (me) - schedules, ships, talks to Tri.

## Shot sheet format (Director deliverable)
| t (s) | VO line | ACTION (what moves) | Expression | Props/SFX | On-screen text (<= 5 words) |
One row per 1-2 s. Must include: a HOOK ACTION in the first second, a "turn" (surprise) around the midpoint, a PAYOFF gag in the last 5 s, and a loop back.

## Pass criteria before Tri sees it
- Kid test passes. Motion check passes. Fact-check PASS. Director signs off that every row is performed on screen.

## Sound rules (Nov 3, owner: 'sound effects feel too much')
- Voice is the loudest thing always. Target: voice about -16 LUFS short-term; SFX peaks at least 9 dB under the voice; music bed at least 20 dB under the voice.
- Max ~12 SFX in a 45 s clip, soft and short (< 0.4 s); one bigger hit per beat. Never stack 2 SFX within 0.3 s. Duck music/SFX 6 dB under any spoken word.
- No harsh high-frequency stings; low-pass SFX around 6 kHz.
- OWNER OVERRIDE (Nov 3, 'very loud'): final loudness is now -20 LUFS integrated (half amplitude vs the old -14), true peak <= -3 dBTP. mix.py default updated. Relative levels (SFX >= 9 dB under voice, bed >= 20 dB under) are unchanged.
