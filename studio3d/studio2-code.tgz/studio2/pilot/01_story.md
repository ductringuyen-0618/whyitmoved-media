# PILOT 01 - Marvell x Lumentum - STORY + WRITERS' ROOM

## 1. THE ONE IDEA (what a 12-year-old repeats)
1. Marvell, a computer-chip company, agreed to buy Lumentum, a laser company, for about $115 billion (that is the companies' figure, counting debt).
2. On Monday both companies' stock prices fell: Marvell 12.7%, Lumentum 18.6%.
3. Nobody can say for sure why; one report says investors fear Marvell may be paying too much.
(Dropped: all-stock, ratio, votes, 2028 date. Only "won't finish for ages" kept, for a gag.)

## 2. METAPHOR - 3 candidates
- A) GIANT SHOPPING TRIP: Marvell is a shopper, Lumentum is a cart-busting giant item, the price is a receipt that never stops printing. Cashier gasps, queue winces.
- B) RICKETY BOAT: Marvell hauls Lumentum aboard, boat sinks low, both friends get wet.
- C) BALLOON: a price tag ties to a balloon pair; both slowly deflate, one faster.
PICK: A. "Buy" is literally shopping, so zero finance needed. The receipt is a built-in visual gag
that carries the "$115 billion" number. Both falling = two shoppers slipping, one harder (18.6 > 12.7),
readable with sound off. B and C have no natural "price" image.

## 3. GAGS (all sound-off readable). * = best 4
1. * Receipt shoots out of the register, runs down the aisle, out the door, trips a pigeon.
2. Shopper opens wallet: a moth flies out, wallet faints with a tiny squeak.
3. * Cashier's eyes pop, glasses fog, they ring the bell so hard it flies off.
4. Queue behind winces one by one like falling dominoes.
5. * Item is a huge glowing laser bulb bigger than the cart; wheels splay out, cart wobbles.
6. * Both shoppers slip on one banana peel and land side by side; the bulb-side one lands harder.
7. A big "?" floats up; everyone shrugs; the "?" grows and squashes them flat.
8. Delivery truck is a snail with the cart on its back (the "won't finish for ages" gag).

## 4. VOICEOVER (90 words = ~36 s; 2.5 words/s; each line <= 8 words)
1. Meet Marvell. It goes shopping.
2. Marvell makes computer chips.
3. Lumentum makes tiny lasers.
4. Marvell agreed to buy it.
5. The price? About 115 billion dollars.
6. The cashier gasps. Everyone stares.
7. The receipt just keeps printing.
8. Everyone in line winces.
9. Monday, Marvell's shares fell 12.7 percent.
10. Lumentum's fell 18.6 percent. Ouch.
11. Why? Nobody knows for sure.
12. One report says investors fear overpaying.
13. Maybe the cart was just too full.
14. The deal won't finish for ages.
15. Remember, this is a cartoon.
16. Not advice. Just a giant receipt.
17. Anyway, who wants to go shopping?
(Loop: line 17 cuts back to line 1, cart rolls in again.)

## 5. TITLE + DESCRIPTION
Title: Marvell Agrees to Buy Lumentum for About $115B; Both Stocks Fall
Description: Marvell agreed to buy Lumentum in a deal the companies value near $115 billion including debt; at Monday's close Marvell was down 12.7% and Lumentum 18.6%. Animated cartoon, not advice.

## NOTES FOR DIRECTOR
- Number chips: show at most "$115B" in line 5, "-12.7%" in 9, "-18.6%" in 10. "incl. debt" chip optional on line 5.
- Line 12 must show on screen as "One report says" (single source: Motley Fool).
- No logos; characters are generic shopper/giant-bulb props. Label "CARTOON" visible on line 15.
