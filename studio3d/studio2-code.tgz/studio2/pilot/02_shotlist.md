# PILOT 01 - SHOT SHEET (Director) - "The Giant Receipt" - 41.5 s, 9:16
Cast: BRAM (teal chip bot = Marvell, the shopper). BEAM (light-blue laser bottle = Lumentum, owns the giant bulb). REGGIE (new, cheap: register with eyes + glasses = cashier). QUEUE = 3 small Bram-tint bots. PIGEON (new prop char).
Always on screen: tiny bottom tag "cartoon, not advice" (6 px-ish, low contrast). VO line # in col 2 (see 01_story.md). VO is ~2.3 words/s; rows show where each line STARTS.
Camera key: SHAKE = 6-frame rattle. PUNCH = fast 1.0 to 1.25 zoom on face. WHIP = 0.15 s horizontal blur-pan. PULL = zoom out to reveal.

| t (s) | VO # | ACTION | Expression | Props / SFX | On-screen text |
|---|---|---|---|---|---|
| 0.0-0.8 | - | HOOK: cart with Bram clinging on SCREECHES in from left (WHIP in), skids, rams the shelf; bag of chips bursts out | Bram: wide eyes, o mouth | tire screech, CRASH, SHAKE | - |
| 0.8-2.2 | 1 | Bram hops out, spins, plants a name tag on chest with a slap; pops a thumbs-up | Bram: grin | slap, boing | MARVELL |
| 2.2-3.6 | 2 | Bram pulls 3 chips from his chest slot, juggles them, one lands on his head | Bram: happy, eyes track chips | pop-pop-pop, plink | - |
| 3.6-5.0 | 3 | WHIP right to Beam on a shelf; Beam fires tiny laser, zaps the juggled chip into a puff of smoke; Beam blows on his nozzle | Beam: smug smile, wink | pew, sizzle, smoke puff | LUMENTUM |
| 5.0-6.4 | 4 | Back to Bram; he points at the giant bulb on top shelf, heart eyes; Beam nods, slides the bulb down by its cord | Bram: heart eyes. Beam: proud | ding, slide whoosh | - |
| 6.4-7.8 | 4-5 | Bram heaves the bulb into the cart; cart wheels SPLAY out sideways, axle bends, cart wobbles (PUNCH on wheels) | Bram: straining, sweat. | creak, boing-boing, groan | - |
| 7.8-9.2 | 5 | Bram pushes the wobbling cart toward checkout; bulb sways, bonks the ceiling lamp, glow flickers over his face | Bram: nervous grin | clink, squeak-squeak | - |
| 9.2-10.4 | 5 | Reggie scans the bulb: laser beep, a huge price chip SLAMS onto the screen and cracks the glass | Reggie: calm then twitch | stamp THUD, glass crack | $115B |
| 10.4-11.8 | 6 | PUNCH on Reggie: eyes POP out on springs (boing-boing), glasses fog white and slide down nose | Reggie: eyes-out gasp | boing, fog hiss, gasp | - |
| 11.8-13.0 | 6 | Reggie slams the bell so hard it launches off, ricochets off Bram's head, rings away | Reggie: panic. Bram: dazed stars | DING, bonk, doppler ding, SHAKE | - |
| 13.0-14.4 | 7 | Register spits a receipt that coils across the counter; Bram flips his empty wallet inside-out, a single sweat drop falls | Bram: pale, worry | brrrrrt printer, flop, drip | - |
| 14.4-15.8 | 7 | Receipt shoots off the counter, runs down the aisle (WHIP follow) and out the door, trips the PIGEON; pigeon cartwheels, feathers | Pigeon: shocked | zip, whoosh, squawk, feather puff | - |
| 15.8-17.2 | 8 | Queue of 3 bots peers at the receipt; each winces in turn and tips into the next like dominoes | Queue: cringe, teeth-clench | ow-ow-ow rising pitch, tink-tink-tink | - |
| 17.2-18.4 | 9 | TURN 1: pigeon drops a BANANA PEEL, plops in front of Bram; Bram steps back, foot slides, flips up in the air, lands on his rear | Bram: o mouth then flat | plop, wheee slide, THUD, SHAKE | MONDAY, -12.7% |
| 18.4-19.8 | 10 | Beam rushes in to help, steps on the SAME peel, whips up, bulb falls and lands on him: crater in floor, he squashes flatter than Bram | Beam: wide eyes then squish | zip, SPLAT, bigger THUD, spring wobble | -18.6% |
| 19.8-21.0 | 10 | PULL wide: Bram and Beam lie side by side; Bram's chip chunk is small, Beam's is bigger; Beam's nozzle droops, a lone sparkle fizzles | Both: dazed, X-eye | wah-wah, fizzle | - |
| 21.0-22.4 | 11 | Both sit up and look at each other; a big "?" pops over them; Bram, Beam, Reggie, Queue all shrug in sync | All: blank shrug | pop, whoosh x4 | ? |
| 22.4-23.6 | 11 | TURN 2 (surprise): the "?" balloons huge, drops and squashes everybody flat like a pancake stack | All: squished | inflate squeak, BOOM, SHAKE | - |
| 23.6-25.0 | 12 | A folded paper flutters out of the pile and lands on the cart; Bram peels it up with one flat arm | Bram: peek, brow up | paper flutter, peel | One report says |
| 25.0-26.4 | 12 | PUNCH: Bram reads, eyes go wide, flips back at the long receipt, then at the bulb; head ping-pongs | Bram: wide, sweat | whip-whip, gulp | investors fear overpaying |
| 26.4-27.8 | 13 | PULL: cart sagging under the bulb; one wheel pops off, rolls away; the cart collapses on its knees | Bram: sheepish smile | boing, rolling clatter, creak-thud | - |
| 27.8-29.2 | 14 | Delivery truck rolls in: a SNAIL wearing the cart on its shell, leaves slime trail, Bram waits on a bench tapping foot | Bram: bored, checks wrist | slow squelch, tap-tap | - |
| 29.2-30.6 | 14 | Time-lapse: cobweb grows between Bram and Beam, Bram's tiny beard sprouts, snail still 1 cm closer; Beam napping on shelf | Both: sleepy, then wake | tick-tock x3, snore, zzz | - |
| 30.6-32.0 | 15 | STAMP slams over the scene; snail crawls away under it | all frozen for the stamp | stamp THUD, SHAKE | CARTOON |
| 32.0-33.4 | 16 | The giant receipt unrolls from the sky across the whole aisle; Bram wades through it, looks at Beam | Bram: deadpan | long paper unroll swish | - |
| 33.4-34.8 | 16 | Receipt wraps Bram and Beam together like a burrito, only their eyes peek out | Both: squint | wrap fwip, muffled squeak | - |
| 34.8-36.2 | 17 | Pop: Bram bursts out, hops in the fixed cart, hauls Beam in beside him, both point at camera | Both: big grin | pop, boing, ding | - |
| 36.2-37.6 | 17 | Cart revs: wheels spin in place, smoke puffs, Bram grips handle, Beam holds hat | Bram: grin. Beam: eek | rev, wheel-spin screech | - |
| 37.6-39.0 | - | PAYOFF: cart bursts forward, hits the SAME banana peel (still there); cart tips on two wheels, the bulb flies up in slow-mo | Bram: o mouth. Beam: o mouth | whoosh, slide wee, slow-mo stretch | - |
| 39.0-40.4 | - | PUNCH on the pigeon wearing the receipt as a cape, looks at camera and coos; bulb clonks it on the head | Pigeon: smug then bonk | coo, plink, BONK, feather | - |
| 40.4-41.5 | - | LOOP: cart (Bram clinging) WHIPs out frame-right at full speed; frame 0 whips the cart back in from left, same pose | Bram: wide eyes, o mouth | whoosh-out (match frame 0 screech) | - |

Pacing check: no row > 1.4 s; every row has motion plus an SFX. Turn 1 = banana slip (17.2), Turn 2 = "?" squashes all (22.4, the midpoint surprise). Payoff gag = peel again + pigeon cape (37.6-40.4).
Number chips: only $115B (9.2), -12.7% (17.2), -18.6% (18.4; -12.7% stays smaller so max 2 on screen). "One report says" sits on screen from 23.6 to 26.4.

# SET + CAST SHEET (for Animation Lead)
## Sets (2D flat, parallax layers, 3 only)
1. MALL AISLE (long, warm shelves, ceiling lamp, floor tiles for the receipt run; shelf for Beam, top shelf for bulb). Used 0.0-9.2 and 13.0-41.5.
2. CHECKOUT (counter + Reggie, price screen, bell, conveyor, queue behind). 9.2-17.2, can be the aisle with a counter prop layered in.
3. VOID "?" BEAT (plain floor + big ?): 21.0-24.0, reuse the aisle, dim it. No new set.

## Props to draw (cheapest first)
banana peel, "?" balloon, name tags (2), stamp CARTOON, price chip, bell, folded report paper, cobweb, beard, cart (with 2 states: normal and sagging/wheel splay), wallet (flip inside out), cart wheel, pigeon cape, giant receipt (long ribbon, drawn as a rope of segments), conveyor, giant laser bulb (glow pulse), pigeon (3 poses: standing, cartwheel, cape), snail truck (snail + shell as cart carrier), calendar-less timelapse, feather particles, smoke puffs.

## Poses / expressions to draw (ranked HARDEST first; flag problems early)
1. Bram + Beam mid-slip, rotating in air then splat, Beam crushed under bulb (squash/stretch + crater; shared prop contact). Rows 17-19, 37.6.
2. Giant receipt as a ribbon: runs across the room, wraps both characters (burrito). Rows 14, 32-34. Fallback: slide the ribbon as a scrolling strip, burrito becomes a wipe with eyes peeking.
3. "?" balloon inflates and squashes 5 characters flat. Fallback: shadow growing, then a flat-stack pancake still.
4. Cart with splayed wheels + wobble + bulb sway + wheel pop-off. Fallback: rotate cart 3 states with shake.
5. Reggie eyes on springs + fogged glasses + bell launch. Fallback: eyes scale pop, glass hides eyes with a fog overlay, bell is a flying sprite.
6. Queue domino wince chain (3 bots tip in sequence). Fallback: simple 3-frame sway.
7. Snail truck with cart on shell + time-lapse cobweb/beard. Fallback: static sprite sliding slowly.
8. Pigeon trip, cartwheel, cape bonk (3 poses + feathers).
9. Bram: wide, o mouth, grin, heart eyes, worry sweat, dazed stars, X-eye, deadpan, sleepy, sheepish smile (all use existing bram_tile eyes: worry/open/wide/blink/happy/heart/squint; mouth: nerv/grin/smile/o/open/sad/flat). NEW needed: stars, X-eye, deadpan (flat + half-lid).
10. Beam: smug smile, wink, proud, wide, squish, X-eye, sleepy, eek (existing beam_tile: open/lookl/wide/blink/happy/sleepy/worry; mouth smile/o/flat/yawn/sad/wob). NEW needed: wink, X-eye, squish.

## Director notes
- If an item is cut for time, cut in this order: time-lapse cobweb (29.2) > queue dominoes > pigeon cape. Never cut: banana peel, "?" squash, receipt run, bulb cart wobble.
- Beam's slip must look HARDER than Bram's (bigger squash, bigger thud, lower chip) because -18.6 > -12.7.
- Loop frame 0 (screech-in) and frame 41.5 (whip-out) must match speed and pose.
