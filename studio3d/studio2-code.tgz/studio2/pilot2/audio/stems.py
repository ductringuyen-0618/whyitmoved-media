import sys; sys.dont_write_bytecode=True
sys.path.insert(0,'/tmp/claude-0/b4')
import numpy as np, soundfile as sf, json
import render4 as R
from sfx3 import sfx, GAIN, OSR, lp
A=R.A
rng=np.random.default_rng(7); n=int(R.DUR*OSR)
v,sr=sf.read('/home/claude/studio2/pilot2/build/vo_v4.wav')
v48=np.interp(np.linspace(0,len(v),int(len(v)*OSR/24000),endpoint=False),np.arange(len(v)),v)
vo=np.zeros(n); k=min(n,len(v48)); vo[:k]=v48[:k]; vo=vo/np.abs(vo).max()*.9
sf.write('stem_voice.wav',vo,OSR,subtype='FLOAT')
ev=R.EV(); cache={}; wavs=[]; sfxs=np.zeros(n); evs=[]
# note: rng draw order follows render4 audio(): events processed in list order, cache by kind
for t,kind in ev:
    if kind not in cache: cache[kind]=R.EXTRA[kind](rng) if kind in R.EXTRA else sfx(kind,rng)
    s=cache[kind]*GAIN.get(kind,.3)*0.8; i=int(t*OSR); j=min(n,i+len(s))
    if i<n: sfxs[i:j]+=s[:j-i]
    evs.append(dict(t=float(t),kind=kind,dur=len(s)/OSR)); wavs.append(s.copy())
sf.write('stem_sfx.wav',sfxs,OSR,subtype='FLOAT')
bed=R.music(R.DUR,rng); envv=np.convolve(np.abs(vo),np.ones(int(.25*OSR))/int(.25*OSR),mode="same")
musicst=bed*.07*(1-.55*np.clip(envv/.08,0,1))
sf.write('stem_music.wav',musicst,OSR,subtype='FLOAT')
tt=np.arange(n)/OSR
pad=(np.sin(2*np.pi*110*tt)+.6*np.sin(2*np.pi*164.8*tt)+.4*np.sin(2*np.pi*220*tt))*(0.8+0.2*np.sin(2*np.pi*.25*tt))
room=lp(rng.standard_normal(n),900)
sf.write('stem_pad.wav',pad*.012,OSR,subtype='FLOAT'); sf.write('stem_room.wav',room*.02,OSR,subtype='FLOAT')
mix=vo+sfxs+musicst+pad*.012+room*.02
sf.write('stem_premix.wav',mix,OSR,subtype='FLOAT')
np.savez('sfx_event_waves.npz',*wavs)
json.dump(evs,open('sfx_events.json','w'),indent=1)
print(len(evs),'events; premix peak',np.abs(mix).max(), 'dur',R.DUR)
