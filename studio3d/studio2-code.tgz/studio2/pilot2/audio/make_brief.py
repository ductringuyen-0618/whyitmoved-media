import json, numpy as np
ev=json.load(open('event_verdicts_raw.json')); A=json.load(open('analysis.json')); S=A['summary']
R=json.load(open('remix_report.json')); plan=json.load(open('sfx_plan_v4.json')); C=json.load(open('compare_out.json'))
klass={ (round(p['t'],1),p['kind']):p['class'] for p in plan}
why={
 'boing':'hook gag; short 0.35 s, tonal so -3 dB trim','ding':'0.9 s ring (> 0.4 s rule), tonal, sits on a name word',
 'pop':'tiny chip tick','fwip':'noise burst, >6 kHz energy, peak only 4.8 dB under voice','plink':'duplicate chip tick on a key word; one chip tick per chip is enough',
 'gasp':'noisy breath, harsh highs, adds nothing the picture does not show','whoomp':'0.9 s riser (> 0.4 s rule) sitting on "giant"',
 'thud':'big hit for the beat; soft, LF only, 0.35 s','squeak':'stacks with the hit within 0.3 s','grunt':'extra sound for a pose the picture already shows',
 'sproing':'stacked on thud (0.2 s) + tink (0 s)','tink':'stacked with sproing/thud at 10.68; or sparkle that duplicates the picture','creak':'3 creaks 0.28 s apart (stacked train) under "wobbles"; repeated gag sound',
 'tick':'full-scale noise click, +0.7 dB OVER voice peak, 100% > 6 kHz','pew':'scan swoosh with highs; the word "scans" already says it','beep':'duplicates the spoken word "Beep." and masks it',
 'tock':'metronome-style filler, not a gag; the 5 tocks (25.59-26.87) are a busy train under the Monday line','cha':'price-reveal hit; tonal, shortened to 0.35 s, pocket EQ',
 'swhistle':'rising whistle, tonal/harsh, stacked at 39.3 and no gag value','whoosh':'noise whoosh, 6-14 dB louder than needed and with >6 kHz hiss','aooga':'stacked on boing 0.05 s later',
 'brrr':'1.3 s buzz (> 0.4 s rule), harsh, covers "receipt prints"','rev':'1.4 s engine (> 0.4 s rule), peak only 3 dB under voice','bell':'pure 2 kHz tone lands on "door"; 1-4 kHz masking test failed (-4 dB) so cut',
 'bonk':'fall hit for Bram; LF, shortened to 0.3 s','crash':'biggest hit (Beam falls); noise crash was +5.5 dB OVER voice peak, now LP 4.5 kHz and -15 dB re voice peak',
 'pdown':'0.7 s pitch-down slide; the word "harder" carries it','wah':'1.0 s sad-trombone tone under "knows for sure"; tonal and long','paper':'rustle noise, ~46 % of its energy above 6 kHz, twice',
 'drip':'tiny but redundant with "worry" chip','pop2':''}
rows=[]
nk=nl=nc=0
for e in ev:
    n=e['_n']; flags=''.join(c for c,b in (('L',e['rel_voice_peak']>-9),('K',bool(e['over_key'])),('S',bool(e['stack'])),('H',e['hf_db']>-15)) if b)
    if n:
        d=e['_d']; verdict='KEEP' if d>-8 else 'LOWER'; nk+=verdict=='KEEP'; nl+=verdict=='LOWER'
        cls=klass[(round(e['t'],1),e['kind'])]
        new=f"{cls}; peak {n['peak_dbfs']:.0f} dBFS final ({n['rel_voice_local_peak_db']:.0f} dB re voice local peak); {d:+.0f} dB vs now"
        note=why.get(e['kind'],'')
    else:
        verdict='CUT'; nc+=1; new='-'; note=why.get(e['kind'],'')
        if e['stack'] and e['kind'] in ('squeak','creak','aooga','sproing','tink','gasp','swhistle'): note+=' | in a stack cluster'
    rows.append(f"| {e['i']} | {e['t']:.2f} | {e['kind']} | {e['dur']:.2f} | {e['peak_dbfs_raw']:.1f} | {e['rel_voice_peak']:+.1f} | {flags or '-'} | **{verdict}** | {new} | {note} |")
B=C['before']; Af=C['after']
tab='\n'.join(rows)
md=f"""# MIX BRIEF - PILOT v4 (Sound Designer / Mixer)

Owner feedback: "the sound effects feel too much, and the volume needs review."
Verdict from the numbers: the SFX were as loud as the narration (SFX stem {S['sfx']['I']:.1f} LUFS vs voice {S['voice']['I']:.1f} LUFS), there were 59 of them, and the final limiter was squashing the voice every time a big hit landed. The owner is right. All figures below are measured, not listened to (I cannot listen; see "Not verified").

Files (all in `/home/claude/studio2/pilot2/audio/`): `mix.py` (reusable), `mix_v4_remix.wav`, `PILOT_v4_remix.mp4`, `remix_report.json`, `analysis.json`, `stem_*.wav`, `sfx_events.json`, `sfx_plan_v4.json`, `shipped_shortterm.csv`.

## 1. What is wrong with v4 (measured on the shipped audio and on re-generated stems)

| Measure | v4 as shipped | Target |
|---|---|---|
| Integrated loudness | {S['shipped']['I']} LUFS | -14.0 |
| True peak | {S['shipped']['TP']} dBTP | <= -1.5 |
| Short-term range (3 s) | {S['shipped']['S_min']} to {S['shipped']['S_max']} LUFS (LRA {S['shipped']['LRA']} LU) | tight, voice about -16 on the bus |
| Voice stem (before master) | {S['voice']['I']} LUFS, peak {S['voice']['peak_dbfs']:.1f} dBFS (crest ~20 dB) | needs compression |
| SFX stem | {S['sfx']['I']} LUFS (**{B['sfx_minus_voice_lu']:+.1f} LU vs voice**), peak {S['sfx']['peak_dbfs']:+.1f} dBFS | >= 9 dB under voice |
| Music / pad / room (stem LUFS) | {S['music']['I']} / {S['pad']['I']} / {S['room']['I']} ; bed sum {S['bed']['I']} (**{B['bed_minus_voice_lu']:.1f} LU vs voice**) | >= 20 under voice |
| Pre-master mix peak | {S['premix']['peak_dbfs']:+.1f} dBFS (3 dB digital over) then `alimiter=0.5`, then loudnorm | no overs |

Findings:
* **{B['sfx']} SFX in 44 s** (rule: ~12). Every one of them overlaps a spoken word (VO is wall-to-wall); {B['under_key']} overlap a key word (names, numbers, nouns I listed in `analyze.py`).
* **{B['louder_than_m9']} of 59 SFX are louder than -9 dB under the voice** (peak vs voice local peak, +/-0.4 s). Worst: crash 29.61 and 39.27 (+5.5 / +5.6 dB OVER the voice), whoosh 41.92 (+3.3), tick 13.73 (+0.7), bonk 27.46 (+0.5), whoosh 19.64 (-0.6). Median event is {B['med_rel_voice_peak']:.1f} dB re voice peak, which is about 6.6 dB ABOVE the voice's average (RMS) level in the same window (peak-to-peak comparison flatters the SFX).
* **Stacks within 0.3 s: {B['stacked']} adjacent pairs in 6 clusters**: 6.95 thud+squeak; 10.48 thud+sproing+tink; 11.64-12.29 creak x3 + squeak; 21.34 boing+aooga (0.05 s); 27.18 squeak+bonk; 39.27-39.37 crash+gasp+whistle (three within 0.1 s, the loudest cluster of the clip).
* **Harsh highs (> 3 % of the event energy above 6 kHz, i.e. hf > -15 dB): {B['harsh']} events**: tick 13.73 (all of it above 6 kHz), paper 35.95/37.05 (-3.4 dB), fwip 3.54, brrr 22.05, gasp 5.57/39.32, whoosh 19.64/23.89/41.92, crash 29.61/39.27, beep 15.01 (-12). Several generators use a one-pole low-pass (6 dB/oct) so the 'LP' does not remove highs.
* **Limiter pumping**: the master chain (`alimiter limit=0.5` after a mix that peaks +3.2 dBFS) pulls the voice down by more than 3 dB (estimated from the limiter on the re-generated premix, up to ~16 dB at its worst frame) at about 13.7, 27.4, 31.1 and 39.3 s (tick, bonk, thud and the crash/whistle/gasp stack). That is the "volume needs review" complaint: the voice level dips on every big hit.
* **Bed audible**: music+pad+room sit {abs(B['bed_minus_voice_lu']):.1f} LU under the voice overall and 7.6 to 19.6 dB under it second by second (median 15.6) - never reaching the 20 dB target in any of the 43 seconds. The `room` is constant low-passed noise (hiss) and the `pad` is 110/165/220 Hz sines right on the narrator's fundamental; the square-wave arp has HF harmonics.
* Master misses spec: -14.9 LUFS (target -14.0) and -1.2 dBTP (target -1.5).

## 2. Targets and exact settings (implemented in `mix.py`, `CFG` dict)

**Spec conflict to know about:** "voice about -16 LUFS short-term" and "final -14 LUFS integrated" cannot both hold in the delivered file, because the voice carries nearly all the loudness. Resolution used: the -16 LUFS voice level is the **mix-bus working level**; the single final linear gain (+{R['master_gain_db']:.1f} dB, applied equally to everything) brings the file to -14.0 LUFS. In the delivered file the voice reads about {R['voice']['integrated_lufs']:.1f} LUFS. If the owner wants -16 in the file, drop `final_lufs` to -16 (nothing else changes).

| Stage | Setting |
|---|---|
| Voice HPF | 80 Hz, 2nd order |
| Voice compressor | threshold -30 dBFS, ratio 4:1, knee 6 dB, attack 1 ms, release 120 ms (raw PLR was 20 dB, now 12) |
| Voice peak limiter | ceiling -4.0 dBFS at the -16 LUFS bus, 3 ms look-ahead (max gain reduction 3.5 dB, 1.4 % of samples > 1 dB) |
| Voice level | -16.0 LUFS integrated on the bus (voice peak reference "Vref" = 98th percentile of 20 ms peaks) |
| Duck | whenever voice is active (VAD: 10 ms RMS within 25 dB of speech level, hold 60 ms): SFX bus and bed bus **-6.0 dB**, attack 15 ms, release 180 ms |
| SFX classes (peak, before duck, re Vref) | tick -15 dB, soft -12 dB, hit -9 dB; tonal sounds (boing, bell, ding, cha, tink, plink, beep) a further -3 dB. After the -6 dB duck the hits sit at -15 re Vref and ticks at -21 to -24 |
| SFX shaping | max length 0.35 s, 3 ms fade-in, up-to-80 ms fade-out, HPF 60 Hz, **LPF 6 kHz 4th order (24 dB/oct)** (crash/glass 4.5 kHz), -4 dB peaking cut at 2.5 kHz Q 0.8 (voice presence pocket) |
| Bed | HPF 50 Hz, LPF 3 kHz (2nd order); music **-26 LU**, pad **-34 LU**, room **-44 LU** relative to the voice's integrated loudness (pre-duck; sum -31 LU); 0.5 s fade in/out; then the same -6 dB duck |
| Master | lookahead limiter, ceiling chosen by loop so TP <= -1.5 dBTP (ended at -2.1 dBFS sample peak, master gain +2.0 dB), linear gain to -14.0 LUFS integrated |
| Event budget | <= 12 SFX; <= 6 hits; min gap 0.3 s; nothing > 0.35 s |

Retime notes for the Animator: no event was retimed (all kept events stay on the original picture frame). Because the VO never stops, 10 of the 11 kept SFX still start under a key word; they are protected by the duck (-6 dB), the class levels, the 2.5 kHz pocket and the 6 kHz low-pass instead of by silence. If the Director wants them fully clear of words, the only free slots are the short inter-word gaps (e.g. 12.14-12.29, 13.53-13.63, 16.35-16.55), which are 0.1-0.2 s.

## 3. SFX decision table - every event (59)

Flags: L = louder than -9 dB under voice, K = overlaps a key spoken word, S = stacks within 0.3 s of another SFX, H = harsh highs (> 3 % energy above 6 kHz). "Peak" = as generated (pre-master, raw, un-gained: voice peak is -0.9). "vs voice" = peak minus voice local peak (+/-0.4 s), in dB, positive = louder than the voice.

Result: **KEEP {nk}, LOWER {nl}, CUT {nc}** (KEEP = survives with a cut of < 8 dB; LOWER = survives with a cut of >= 8 dB and trimmed/filtered; CUT = removed).

| # | t (s) | type | dur | peak dBFS | vs voice | flags | verdict | new treatment | reason |
|---|---|---|---|---|---|---|---|---|---|
{tab}

Kept (11): 5 big hits (6.95 thud bottle, 10.48 thud cart, 17.43 cha price, 27.46 bonk Bram, 29.61 crash Beam), 2 soft (21.34 boing eyes, 41.47 boing banana), 4 ticks (0.18 hook boing, 2.64 and 7.76 chip pops, 43.54 loop boing). One hit per beat: bottle, cart, price, Bram falls, Beam falls. Optional add-back if the chips on screen need it: pops at 33.3 and 34.95 as ticks (13 total, still ~12).

## 4. Before / after (same picture, same VO)

| Measure | v4 shipped | Remix |
|---|---|---|
| Integrated LUFS | {S['shipped']['I']} | {R['final']['integrated_lufs']:.1f} |
| True peak (dBTP) | {S['shipped']['TP']} | {R['final']['true_peak_dbtp']:.1f} (also {R['final']['true_peak_dbtp']:.1f} after AAC in the mp4) |
| Short-term (3 s) min / max | {S['shipped']['S_min']} / {S['shipped']['S_max']} LUFS | {R['final']['short_term_min']:.1f} / {R['final']['short_term_max']:.1f} LUFS |
| LRA | {S['shipped']['LRA']} LU | {R['final']['lra']:.1f} LU |
| SFX count | 59 | {R['sfx_count']} |
| SFX stem vs voice (integrated) | {B['sfx_minus_voice_lu']:+.1f} LU | {Af['sfx_minus_voice_lu']:+.1f} LU |
| Median SFX peak vs voice local peak | {B['med_rel_voice_peak']:+.1f} dB | {Af['med_rel']:+.1f} dB |
| Worst SFX peak vs voice local peak | {B['worst_rel']:+.1f} dB | {Af['worst_rel']:+.1f} dB |
| SFX louder than -9 dB under voice | {B['louder_than_m9']} | {Af['louder_than_m9']} |
| SFX loudest 400 ms vs voice 400 ms (momentary LUFS) | n/a (peaks above voice) | worst {R['sfx_worst_rel_voice_momentary_db']:.1f} dB |
| Stacks within 0.3 s | {B['stacked']} pairs | {Af['stacked']} |
| Harsh-high events | {B['harsh']} | {Af['harsh']} |
| SFX under a key word | {B['under_key']} of 59 | 10 of 11 (all except the 0.18 hook boing), each ducked 6 dB and 15-24 dB under the voice peak |
| Bed vs voice (integrated) | {B['bed_minus_voice_lu']:.1f} LU | {R['bed']['under_voice_lu']:.1f} LU ({R['bed']['under_voice_during_speech_lu']:.1f} dB in speech frames) |
| Silences > 0.4 s (-50 dB) | none in VO | none (also none at -35 dB / 0.25 s) |
| Voice masked? (50 ms speech frames, voice minus SFX+bed) | n/a | min {R['masking']['min_voice_over_other_db']:.1f} dB broadband, min {R['masking']['min_voice_over_other_1to4k_db']:.1f} dB in 1-4 kHz (frames where the voice has >-45 dBFS there); 5th percentile {R['masking']['p5_voice_over_other_db']:.1f} dB |

## 5. How to apply this in later builds

```
python3 /home/claude/studio2/pilot2/audio/mix.py --voice vo.wav --events sfx_events.json --sfx-npz sfx_event_waves.npz \\
   [--plan sfx_plan.json] --bed music.wav:-26 --bed pad.wav:-34 --bed room.wav:-44 \\
   --out mix.wav --video silent_or_old.mp4 --out-video final.mp4 --report mix_report.json --duration 43.97
```
* The renderer should dump each SFX event as an isolated, un-gained waveform (`wav` path per event, or one npz with `arr_<index>`), plus `t` and `kind`; drop the per-kind `GAIN` table and the final `alimiter`/`loudnorm` calls - `mix.py` owns levels and mastering.
* Without `--plan` the script auto-picks: drops long/noisy/harsh kinds (list `DROP_KINDS`), classes the rest, removes anything within 0.3 s of a higher-priority event, keeps <= 12 (<= 6 hits).
* Tell the Director: write one SFX line per beat, plus chips; if a beat needs a second sound, it is cut by the script.
* The script prints/stores the report; QA should check `final.integrated_lufs` = -14.0, `true_peak_dbtp` <= -1.5, `sfx_worst_rel_voice_local_peak_db` <= -9, `silences_over_0.4s` = [], `masking.min_voice_over_other_db` >= 3.

## 6. Not verified / caveats

* **I cannot listen.** Every judgment is numeric: loudness, peaks, spectra, envelope ratios. Whether the remaining hits are audible enough, whether the 'cha', 'boing' and 'thud' still read as jokes at -15 to -24 dB re voice peak, and whether anything sounds distorted (1 ms compressor attack, 3 ms limiter) needs a human listen. If the owner finds the hits too quiet, raise `sfx_class_db` by 2 dB at most (pre-duck hits would sit at -7, which breaks the 9 dB rule, so ask the owner first).
* The stems are **re-generated** from the build scripts (a read-only copy in the scratchpad, using `vo_v4.wav`, `vo_exact_v4.json`, `vo_v4_timing.json`, because the live `vo_exact.json` and `vo_v2.wav` in the build dir had already moved on to the next version). Checked against the shipped audio: waveform correlation 0.94, residual -9 dB (the shipped chain's limiter is non-linear), event times line up to 10 ms. Treat the "before" per-element levels as +/-1 dB, and the per-event peaks as exact only before the shipped limiter.
* The key-word list used for the "under key word" flag is my judgment (names, numbers, nouns); the others are objective.
* "Louder than -9 under the voice" is measured peak vs the voice peak in a +/-0.4 s window. If the owner means peak vs average voice level, the old mix was worse (median +6.6 dB over the voice RMS) and the new one is better (all >= 15 dB under the voice peak).
* The 1-4 kHz masking test failed once (door bell, -4 dB) which is why the bell was cut; the cha at 17.45 passes at +1.9 dB, the weakest remaining spot.
* AAC encode of the mp4 audio was measured: -14.0 LUFS, -1.5 dBTP; picture stream is bit-identical to v4 (copied, hash compared). Audio duration 43.95 s vs picture 43.97 s.
"""
open('MIX_BRIEF.md','w').write(md)
print(nk,nl,nc)
