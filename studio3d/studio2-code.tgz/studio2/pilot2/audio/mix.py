#!/usr/bin/env python3
"""
mix.py  -  Sound Designer / Mixer reference mixer for the Why It Moved studio.

Implements the Sound rules in STUDIO.md plus the Nov-3 owner feedback
("sound effects feel too much, volume needs review").  Drop it into any build:

    python3 mix.py --voice vo.wav --events sfx_events.json --sfx-npz sfx_event_waves.npz \
        --bed music.wav:-26 --bed pad.wav:-34 --bed room.wav:-44 \
        --out mix.wav [--plan sfx_plan.json] [--video in.mp4 --out-video out.mp4] \
        [--report report.json]

Inputs
  --voice      mono/stereo wav (any rate; resampled to 48 kHz).  Narration only.
  --events     JSON list [{"t": sec, "kind": "thud", "wav": "path.wav" (optional)}, ...]
               SFX audio comes from event["wav"] (isolated, un-gained) or from --sfx-npz
               (arr_<index> = waveform of events[index]).
  --plan       optional JSON list that PICKS events and sets their class:
               [{"i": 7, "class": "hit"}, {"t": 2.64, "kind": "pop", "class": "tick", "shift": 0.0}]
               Without --plan an automatic policy is used (see AUTO below).
  --bed        "path.wav:offset_LU"  -> bed level in LU relative to the voice's integrated
               loudness (negative number).  Repeatable.  Pre-duck.

What it does (all numbers live in CFG below)
  1. Voice: HPF 80 Hz, 4:1 compressor (thr -30 dBFS, 1 ms / 120 ms), soft limiter, set to -16 LUFS integrated
     (mix-bus working level; the final normalisation lifts everything together to -14).
  2. Voice-activity duck curve: SFX bus and bed bus drop 6 dB (attack 15 ms / release 180 ms)
     whenever a word is being spoken.
  3. SFX: only the picked events; each is trimmed to <= 0.35 s, 3 ms fade-in / fade-out,
     HPF 60 Hz, LPF 6 kHz (4th order), -4 dB pocket at 2.5 kHz (voice presence), then
     peak-normalised to  Vref + class_dB   (tick -15, soft -12, hit -9 dB re the voice's
     98th-percentile 20 ms peak), then ducked.
  4. Bed: HPF 50 Hz, LPF 3 kHz, fade 0.5 s in/out, level = voice LUFS + offset, ducked.
  5. Master: lookahead peak limiter, linear gain to -14 LUFS integrated, ceiling chosen so
     true peak <= -1.5 dBTP (verified with ffmpeg ebur128, loops until it holds).
  6. Writes wav (+ optional video with the picture stream copied) and a JSON report with
     LUFS, short-term range, TP, per-SFX levels vs the voice, masking check, silence check.

AUTO policy (no --plan): drop kinds in DROP_KINDS (long / noisy / harsh), map the rest to a
class via KIND_CLASS, remove anything within 0.3 s of a higher-priority event, then keep at most
MAX_SFX (12) - hits first, then soft, then ticks - with at most MAX_HITS (6) hits.
"""
import argparse, json, subprocess, sys, os, re, tempfile
import numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt, sosfiltfilt, lfilter, resample_poly
from scipy.ndimage import minimum_filter1d, uniform_filter1d

SR = 48000
CFG = dict(
    voice_hpf=80.0,
    comp_threshold_db=-30.0, comp_ratio=4.0, comp_knee_db=6.0, comp_attack_ms=1.0, comp_release_ms=120.0,
    voice_limit_dbfs=-4.0,              # bus peak ceiling at the -16 LUFS working level (PLR 12 -> -1.5 dBTP after +2 LU)
    voice_target_lufs=-16.0,            # mix-bus working level (integrated, speech dominated)
    final_lufs=-20.0, final_tp=-3.0,
    duck_db=6.0, duck_attack_ms=15.0, duck_release_ms=180.0, vad_floor_below_speech_db=25.0, vad_hold_ms=60.0,
    sfx_class_db={"tick": -15.0, "soft": -12.0, "hit": -9.0},   # peak, dB re Vref, before duck
    sfx_max_len=0.35, sfx_fade_in=0.003, sfx_fade_out_max=0.08,
    sfx_hpf=60.0, sfx_lpf=6000.0, sfx_pocket_hz=2500.0, sfx_pocket_db=-4.0, sfx_pocket_q=0.8,
    bed_hpf=50.0, bed_lpf=3000.0, bed_fade=0.5,
    min_sfx_gap=0.30, tonal_trim_db=-3.0, mask_floor_db=18.0,
)
MAX_SFX, MAX_HITS = 12, 6
KIND_CLASS = {"thud": "hit", "bonk": "hit", "crash": "hit", "stamp": "hit", "boom": "hit", "cha": "hit", "glass": "hit",
              "boing": "soft", "bell": "soft", "ding": "soft", "squeak": "soft", "sproing": "soft", "grunt": "soft", "plink": "tick",
              "pop": "tick", "tick": "tick", "tock": "tick", "tink": "tick", "beep": "tick", "drip": "tick", "pew": "tick"}
DROP_KINDS = {"brrr", "rev", "creak", "whoosh", "wah", "paper", "gasp", "sizzle", "screech", "snore", "squelch", "fwip", "whoomp",
              "swhistle", "swdown", "pdown", "dopp", "aooga", "coo", "squawk", "ow", "wah", "beep", "pew", "tick"}
TONAL_KINDS = {"bell", "ding", "cha", "tink", "plink", "beep", "boing", "sproing"}   # pure tones mask speech more than their RMS suggests
KIND_LPF = {"crash": 4500.0, "glass": 4500.0}
CLASS_PRIO = {"hit": 0, "soft": 1, "tick": 2}

db = lambda x: 20 * np.log10(max(float(x), 1e-9))
lin = lambda d: 10 ** (d / 20.0)

# ---------------------------------------------------------------- loudness (BS.1770 K-weighting @48k)
_K1 = ([1.53512485958697, -2.69169618940638, 1.19839281085285], [1.0, -1.69065929318241, 0.73248077421585])
_K2 = ([1.0, -2.0, 1.0], [1.0, -1.99004745483398, 0.99007225036621])
def kweight(x): return lfilter(*_K2, lfilter(*_K1, x))
def block_ms(x, win, hop):
    k = kweight(x); n = (len(k) - win) // hop + 1
    if n < 1: return np.array([np.mean(k ** 2) + 1e-12])
    c = np.concatenate([[0], np.cumsum(k ** 2)])
    idx = np.arange(n) * hop
    return (c[idx + win] - c[idx]) / win + 1e-12
lufs_of = lambda ms: -0.691 + 10 * np.log10(ms)
def integrated(x):
    ms = block_ms(x, int(.4 * SR), int(.1 * SR)); l = lufs_of(ms)
    g = l > -70
    if not g.any(): return -70.0
    rel = lufs_of(ms[g].mean()) - 10
    g2 = g & (l > rel)
    return float(lufs_of(ms[g2].mean()))
def momentary_max(x):  # loudest 400 ms
    return float(lufs_of(block_ms(x, int(.4 * SR), int(.05 * SR)).max()))

def ffmpeg_ebu(path):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-v", "verbose", "-i", path, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
    r = r.replace("M:-", "M: -")
    rows = [[float(m[1]), float(m[2]), float(m[3])] for m in re.finditer(r"t:\s*([\d.]+)\s+TARGET:\S+ LUFS\s+M:\s*(\S+)\s+S:\s*(\S+)", r)]
    s = r.split("Summary:")[-1]
    f = lambda p: float(re.search(p, s)[1])
    return dict(I=f(r"I:\s+([-\d.]+) LUFS"), LRA=f(r"LRA:\s+([\d.]+) LU"), TP=f(r"Peak:\s+([-\d.]+) dBFS")), np.array(rows)

# ---------------------------------------------------------------- helpers
def load_mono(path):
    x, sr = sf.read(path, always_2d=True); x = x.mean(axis=1)
    if sr != SR:
        from math import gcd
        g = gcd(sr, SR); x = resample_poly(x, SR // g, sr // g)
    return x.astype(np.float64)
def biquad_peak(f0, gain_db, q):  # RBJ peaking EQ -> (b,a)
    A = 10 ** (gain_db / 40); w = 2 * np.pi * f0 / SR; al = np.sin(w) / (2 * q); c = np.cos(w)
    b = [1 + al * A, -2 * c, 1 - al * A]; a = [1 + al / A, -2 * c, 1 - al / A]
    return np.array(b) / a[0], np.array(a) / a[0]
def smooth_env(target, attack_ms, release_ms):
    """one-pole follower, target sampled at `rate` Hz; returns same length"""
    a_att = np.exp(-1.0 / attack_ms); a_rel = np.exp(-1.0 / release_ms)   # time constants given in steps
    out = np.empty_like(target); y = target[0]
    for i, t in enumerate(target):
        c = a_att if t > y else a_rel; y = c * y + (1 - c) * t; out[i] = y
    return out
def limiter(x, ceil_db, look_ms=3.0):
    c = lin(ceil_db); look = max(1, int(look_ms * 1e-3 * SR))
    need = np.minimum(1.0, c / np.maximum(np.abs(x), 1e-9))
    g = minimum_filter1d(need, size=2 * look + 1, mode="nearest")
    g = uniform_filter1d(g, size=look + 1, mode="nearest")
    g = np.minimum(g, need)  # never exceed the instantaneous requirement
    return x * g

def process_voice(v, cfg):
    v = sosfilt(butter(2, cfg["voice_hpf"], "hp", fs=SR, output="sos"), v)
    # compressor on a 1 ms grid
    hop = SR // 1000; n = len(v) // hop
    pk = np.abs(v[:n * hop]).reshape(n, hop).max(axis=1)
    lvl = 20 * np.log10(np.maximum(pk, 1e-6)); T, R, K = cfg["comp_threshold_db"], cfg["comp_ratio"], cfg["comp_knee_db"]
    over = lvl - T
    gr = np.where(over <= -K / 2, 0.0, np.where(over >= K / 2, (1 / R - 1) * over, (1 / R - 1) * (over + K / 2) ** 2 / (2 * K)))
    # attack/release on gain reduction (negative values): attack = going more negative
    a_att = np.exp(-1 / (cfg["comp_attack_ms"])); a_rel = np.exp(-1 / (cfg["comp_release_ms"]))
    out = np.empty(n); y = 0.0
    for i in range(n):
        t = gr[i]; c = a_att if t < y else a_rel; y = c * y + (1 - c) * t; out[i] = y
    gcurve = np.interp(np.arange(len(v)), (np.arange(n) + .5) * hop, 10 ** (out / 20))
    v = v * gcurve
    v = v * lin(cfg["voice_target_lufs"] - integrated(v))
    for _ in range(4):                       # peak-limit at the bus, re-trim to the target loudness
        v = limiter(v, cfg["voice_limit_dbfs"], 3.0)
        v = v * lin(cfg["voice_target_lufs"] - integrated(v))
    if cfg.get("_debug"): print("voice bus: LUFS %.2f peak %.2f dBFS PLR %.1f" % (integrated(v), db(np.abs(v).max()), db(np.abs(v).max()) - integrated(v)))
    return v

def vad_duck_curve(v, cfg):
    """per-sample gain (1.0 = no duck, 10^(-duck/20) = ducked) following the voice envelope"""
    hop = SR // 100  # 10 ms
    n = len(v) // hop
    rms = np.sqrt((v[:n * hop].reshape(n, hop) ** 2).mean(axis=1) + 1e-12)
    ref = np.percentile(db_arr(rms), 90)
    act = (db_arr(rms) > ref - cfg["vad_floor_below_speech_db"]).astype(float)
    hold = int(round(cfg["vad_hold_ms"] / 10));
    if hold > 0: act = np.maximum.reduce([np.roll(act, s) for s in range(-hold, hold + 1)]) if hold < n else act
    env = smooth_env(act, cfg["duck_attack_ms"] / 10, cfg["duck_release_ms"] / 10)  # in 10 ms steps
    g = 1 - (1 - lin(-cfg["duck_db"])) * env
    t10 = (np.arange(n) + .5) * hop
    return np.interp(np.arange(len(v)), t10, g), act
db_arr = lambda a: 20 * np.log10(np.maximum(a, 1e-9))

def vref_of(v):
    hop = SR // 50; n = len(v) // hop
    pk = np.abs(v[:n * hop]).reshape(n, hop).max(axis=1)
    pk = pk[pk > lin(-40)]
    return db(np.percentile(pk, 98))

def shape_sfx(w, cls, kind, cfg, lpf=None, max_len=None, gain_db=0.0, vref=0.0):
    w = np.asarray(w, dtype=np.float64)
    L = int((max_len or cfg["sfx_max_len"]) * SR); w = w[:L].copy()
    fi = int(cfg["sfx_fade_in"] * SR); fo = int(min(cfg["sfx_fade_out_max"] * SR, len(w) / 3))
    if fi: w[:fi] *= np.linspace(0, 1, fi)
    if fo: w[-fo:] *= np.linspace(1, 0, fo) ** 1.5
    w = sosfilt(butter(2, cfg["sfx_hpf"], "hp", fs=SR, output="sos"), w)
    w = sosfilt(butter(4, lpf or KIND_LPF.get(kind, cfg["sfx_lpf"]), "lp", fs=SR, output="sos"), w)
    b, a = biquad_peak(cfg["sfx_pocket_hz"], cfg["sfx_pocket_db"], cfg["sfx_pocket_q"]); w = lfilter(b, a, w)
    pk = np.abs(w).max()
    if pk < 1e-9: return w
    return w / pk * lin(vref + cfg["sfx_class_db"][cls] + gain_db + (cfg["tonal_trim_db"] if kind in TONAL_KINDS else 0.0))

def auto_plan(events, cfg):
    cand = []
    for i, e in enumerate(events):
        k = e["kind"]
        if k in DROP_KINDS: continue
        cand.append(dict(i=i, **{"class": KIND_CLASS.get(k, "tick")}))
    cand.sort(key=lambda c: (CLASS_PRIO[c["class"]], events[c["i"]]["t"]))
    kept = []
    for c in cand:
        t = events[c["i"]]["t"]
        if any(abs(events[k["i"]]["t"] - t) < cfg["min_sfx_gap"] for k in kept): continue
        if c["class"] == "hit" and sum(1 for k in kept if k["class"] == "hit") >= MAX_HITS: continue
        if len(kept) >= MAX_SFX: continue
        kept.append(c)
    return sorted(kept, key=lambda c: events[c["i"]]["t"])

def resolve_plan(plan, events):
    out = []
    for p in plan:
        p = dict(p)
        if "i" not in p:
            m = [i for i, e in enumerate(events) if abs(e["t"] - p["t"]) < 0.02 and (("kind" not in p) or e["kind"] == p["kind"])]
            if not m: raise SystemExit(f"plan entry matches no event: {p}")
            p["i"] = m[0]
        out.append(p)
    return out

def build(args, cfg=CFG):
    v0 = load_mono(args.voice); n = len(v0)
    if args.duration: n = int(args.duration * SR); v0 = np.pad(v0, (0, max(0, n - len(v0))))[:n]
    v = process_voice(v0, cfg); voice_I = integrated(v); vref = vref_of(v)
    duck, act = vad_duck_curve(v, cfg)
    events = json.load(open(args.events))
    npz = np.load(args.sfx_npz) if args.sfx_npz else None
    plan = resolve_plan(json.load(open(args.plan)), events) if args.plan else auto_plan(events, cfg)
    sfx_bus = np.zeros(n); placed = []
    for p in plan:
        e = events[p["i"]]
        w = sf.read(e["wav"])[0] if e.get("wav") else npz["arr_%d" % p["i"]]
        s = shape_sfx(w, p["class"], e["kind"], cfg, p.get("lp"), p.get("max_len"), p.get("gain_db", 0.0), vref)
        t = e["t"] + p.get("shift", 0.0); a = int(round(t * SR)); b = min(n, a + len(s))
        if a >= n: continue
        sfx_bus[a:b] += s[:b - a]; placed.append(dict(i=p["i"], t=round(t, 3), kind=e["kind"], cls=p["class"], a=a, b=b, w=s[:b - a]))
    sfx_ducked = sfx_bus * duck
    bed_bus = np.zeros(n)
    for spec in (args.bed or []):
        path, off = spec.rsplit(":", 1); b = load_mono(path)[:n]; b = np.pad(b, (0, n - len(b)))
        b = sosfilt(butter(2, cfg["bed_hpf"], "hp", fs=SR, output="sos"), b)
        b = sosfilt(butter(2, cfg["bed_lpf"], "lp", fs=SR, output="sos"), b)
        b = b * lin(voice_I + float(off) - integrated(b))
        bed_bus += b
    f = int(cfg["bed_fade"] * SR); bed_bus[:f] *= np.linspace(0, 1, f); bed_bus[-f:] *= np.linspace(1, 0, f)
    bed_ducked = bed_bus * duck
    mix = v + sfx_ducked + bed_ducked
    # master: limit -> normalise to final LUFS -> verify true peak (loop)
    ceil = cfg["final_tp"] - 0.6; g = cfg["final_lufs"] - integrated(mix)
    for _ in range(10):
        out = limiter(mix * lin(g), ceil, 3.0)
        tmp = tempfile.mktemp(suffix=".wav", dir="/tmp/claude-0" if os.path.isdir("/tmp/claude-0") else None); sf.write(tmp, out, SR, subtype="PCM_24")
        s, _r = ffmpeg_ebu(tmp); os.remove(tmp)
        okI = abs(s["I"] - cfg["final_lufs"]) <= 0.15; okT = s["TP"] <= cfg["final_tp"]
        if okI and okT: break
        if not okT: ceil -= (s["TP"] - cfg["final_tp"]) + 0.1
        g += cfg["final_lufs"] - s["I"]
    master_gain = g
    stems = dict(voice=v * lin(master_gain), sfx=sfx_ducked * lin(master_gain), bed=bed_ducked * lin(master_gain), sfx_raw=sfx_bus, duck=duck)
    return out, stems, dict(placed=placed, voice_I_bus=voice_I, vref=vref, master_gain_db=master_gain, plan=plan, act=act, ceil=ceil)

def measure(out, stems, info, path_wav, cfg=CFG):
    rep = {}
    s, rows = ffmpeg_ebu(path_wav)
    ss = rows[:, 2][(rows[:, 0] > 3.5) & (rows[:, 2] > -70)]
    rep["final"] = dict(integrated_lufs=s["I"], true_peak_dbtp=s["TP"], lra=s["LRA"], short_term_min=float(ss.min()), short_term_max=float(ss.max()),
                        short_term_p10=float(np.percentile(ss, 10)), short_term_p90=float(np.percentile(ss, 90)))
    v = stems["voice"]; hop = SR // 20; nfr = len(v) // hop
    vrms = np.sqrt((v[:nfr * hop].reshape(nfr, hop) ** 2).mean(axis=1) + 1e-12); active = db_arr(vrms) > np.percentile(db_arr(vrms), 90) - cfg["mask_floor_db"]
    rep["voice"] = dict(integrated_lufs=integrated(v), speech_frames_pct=float(100 * active.mean()), vref_dbfs=db(np.percentile(np.abs(v[:nfr*hop].reshape(nfr,hop)).max(axis=1)[active], 98)))
    oth = stems["sfx"] + stems["bed"]
    ratio = db_arr(vrms) - db_arr(np.sqrt((oth[:nfr * hop].reshape(nfr, hop) ** 2).mean(axis=1) + 1e-12))
    sos = butter(4, [1000, 4000], "bp", fs=SR, output="sos"); vb = sosfilt(sos, v); ob = sosfilt(sos, oth)
    rb = db_arr(np.sqrt((vb[:nfr * hop].reshape(nfr, hop) ** 2).mean(axis=1) + 1e-12)) - db_arr(np.sqrt((ob[:nfr * hop].reshape(nfr, hop) ** 2).mean(axis=1) + 1e-12))
    rep["masking"] = dict(min_voice_over_other_db=float(ratio[active].min()), min_voice_over_other_1to4k_db=float(rb[active & (db_arr(np.sqrt((vb[:nfr*hop].reshape(nfr,hop)**2).mean(axis=1)+1e-12)) > -45)].min()),
                          p5_voice_over_other_db=float(np.percentile(ratio[active], 5)))
    rep["bed"] = dict(integrated_lufs=integrated(stems["bed"]), under_voice_lu=integrated(stems["bed"]) - integrated(v),
                      under_voice_during_speech_lu=float(db_arr(np.sqrt((stems['bed'][:nfr*hop].reshape(nfr,hop)**2).mean(axis=1)+1e-12))[active].mean() - db_arr(vrms)[active].mean()))
    rows_e = []
    vpk20 = np.abs(v[:nfr * hop].reshape(nfr, hop)).max(axis=1)
    for pl in info["placed"]:
        a, b = pl["a"], pl["b"]; ev = stems["sfx"][a:b]
        # SFX contribution of this event only, after duck+master gain
        solo = pl["w"] * stems["duck"][a:b] * lin(info["master_gain_db"]); pk = db(np.abs(solo).max())
        w0 = max(0, a - int(.4 * SR)); w1 = min(len(v), b + int(.4 * SR)); vlocal = db(np.abs(v[w0:w1]).max())
        pad = np.zeros(int(0.5 * SR)); xs = np.concatenate([pad, solo, pad]); xv = v[max(0, a - int(.5 * SR)):b + int(.5 * SR)]
        sm = momentary_max(xs); vm = momentary_max(xv)
        rows_e.append(dict(t=pl["t"], kind=pl["kind"], cls=pl["cls"], peak_dbfs=round(pk, 1), dur=round((b - a) / SR, 2), rel_voice_local_peak_db=round(pk - vlocal, 1),
                           rel_voice_momentary_lufs_db=round(sm - vm, 1), duck_gain_db=round(db(stems["duck"][a:b].mean()), 1),
                           hf_over6k_db=round(10 * np.log10((sosfilt(butter(4, 6000, 'hp', fs=SR, output='sos'), pl['w']) ** 2).sum() / ((pl['w'] ** 2).sum() + 1e-20) + 1e-12), 1)))
    rep["sfx_events"] = rows_e
    rep["sfx_count"] = len(rows_e)
    rep["sfx_worst_rel_voice_local_peak_db"] = max(r["rel_voice_local_peak_db"] for r in rows_e) if rows_e else None
    rep["sfx_worst_rel_voice_momentary_db"] = max(r["rel_voice_momentary_lufs_db"] for r in rows_e) if rows_e else None
    rep["sfx_stack_within_0.3s"] = sum(1 for x, y in zip(rows_e, rows_e[1:]) if y["t"] - x["t"] < 0.3)
    sd = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path_wav, "-af", "silencedetect=noise=-50dB:d=0.4", "-f", "null", "-"], capture_output=True, text=True).stderr
    rep["silences_over_0.4s"] = re.findall(r"silence_start: ([\d.]+)", sd)
    return rep

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--voice", required=True); ap.add_argument("--events", required=True); ap.add_argument("--sfx-npz")
    ap.add_argument("--plan"); ap.add_argument("--bed", action="append"); ap.add_argument("--out", required=True)
    ap.add_argument("--video"); ap.add_argument("--out-video"); ap.add_argument("--report"); ap.add_argument("--duration", type=float)
    args = ap.parse_args()
    out, stems, info = build(args)
    sf.write(args.out, out, SR, subtype="PCM_24")
    rep = measure(out, stems, info, args.out); rep["settings"] = CFG; rep["master_gain_db"] = info["master_gain_db"]; rep["bus_voice_lufs"] = info["voice_I_bus"]
    if args.report: json.dump(rep, open(args.report, "w"), indent=1, default=float)
    if args.video and args.out_video:
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", args.video, "-i", args.out, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-shortest", "-movflags", "+faststart", args.out_video], check=True)
    print(json.dumps({k: rep[k] for k in ("final", "voice", "masking", "bed", "sfx_count", "sfx_worst_rel_voice_local_peak_db", "sfx_worst_rel_voice_momentary_db", "silences_over_0.4s")}, indent=1, default=float))
