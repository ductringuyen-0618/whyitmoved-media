import sys; sys.dont_write_bytecode=True
import numpy as np, soundfile as sf, json, subprocess, re
from scipy.signal import butter, sosfilt
SR=48000
def rd(f): x,_=sf.read(f); return x
def ebu(path):
    r=subprocess.run(['ffmpeg','-hide_banner','-nostats','-v','verbose','-i',path,'-af','ebur128=peak=true','-f','null','-'],capture_output=True,text=True).stderr
    rows=[]; r=r.replace('M:-','M: -')
    for m in re.finditer(r't:\s*([\d.]+)\s+TARGET:\S+ LUFS\s+M:\s*(\S+)\s+S:\s*(\S+)\s+I:\s*(\S+) LUFS\s+LRA:\s*([\d.]+)',r):
        rows.append([float(m[1])]+[max(float(x),-99) for x in (m[2],m[3],m[4])]+[float(m[5])])
    summ=r.split('Summary:')[-1]
    g=lambda p: float(re.search(p,summ)[1])
    return np.array(rows),dict(I=g(r'I:\s+([-\d.]+) LUFS'),LRA=g(r'LRA:\s+([\d.]+) LU'),TP=g(r'Peak:\s+([-\d.]+) dBFS'))
db=lambda x:20*np.log10(max(x,1e-9))
if __name__=='__main__':
    vo=rd('stem_voice.wav'); sx=rd('stem_sfx.wav'); mu=rd('stem_music.wav'); pad=rd('stem_pad.wav'); room=rd('stem_room.wav')
    bed=mu+pad+room; pre=rd('stem_premix.wav')
    out={}
    for nm,x in [('voice',vo),('sfx',sx),('music',mu),('pad',pad),('room',room),('bed',bed),('premix',pre)]:
        sf.write(f'/tmp/claude-0/s_{nm}.wav',x,SR,subtype='FLOAT'); rows,s=ebu(f'/tmp/claude-0/s_{nm}.wav'); s['peak_dbfs']=db(np.abs(x).max()); out[nm]=s
    rows,s=ebu('orig_v4.wav'); out['shipped']=s
    ss=rows[:,2]; ss=ss[(rows[:,0]>1)&(ss>-70)]
    out['shipped']['S_min']=float(ss.min()); out['shipped']['S_max']=float(ss.max()); out['shipped']['S_p10']=float(np.percentile(ss,10)); out['shipped']['S_p90']=float(np.percentile(ss,90))
    np.savetxt('shipped_shortterm.csv',rows,delimiter=',',header='t,M,S,I,LRA',fmt='%.2f')
    delta=out['shipped']['I']-out['premix']['I']   # raw->shipped gain (LU), approx (limiter nonlinear)
    out['delta_raw_to_shipped_dB']=delta
    # word list
    W=json.load(open('/home/claude/studio2/pilot2/build/vo_exact_v4.json'))
    KEY={'bram','marvell','beam','lumentum','chips','laser','bottle','price','115','billion','dollars','monday','fell','12.7','18.6','percent','slipped','harder','paid','banana','peels','shopping','cashier','cashier\'s','eyes','receipt','door','beep','cart','grins','wobbles','spots','giant','investors','nobody'}
    words=[(w['start'],w['end'],w['word'].strip('.,?!').lower()) for w in W]
    evs=json.load(open('sfx_events.json'))
    n=len(vo)
    WV=np.load('sfx_event_waves.npz'); WV=[WV['arr_%d'%i] for i in range(len(evs))]
    sos=butter(4,6000,'hp',fs=SR,output='sos')
    res=[]
    # voice 10ms peak env
    for i,e in enumerate(evs):
        t=e['t']; d=e['dur']; a=int(t*SR); b=min(n,a+int(d*SR))
        # isolate: re-synthesise not needed: use sfx stem but remove neighbours by time proximity -> approximate via stem segment limited to event window
        iso=WV[i][:max(0,min(len(WV[i]),n-a))]
        pk=np.abs(iso).max()
        # isolated peak: cannot unmix perfectly; mark overlaps
        w0=max(0,int((t-.4)*SR)); w1=min(n,int((t+min(d,.5)+.4)*SR))
        vpk=np.abs(vo[w0:w1]).max()
        # voice rms in window speech frames
        vr=np.sqrt((vo[w0:w1]**2).mean())
        hf=sosfilt(sos,iso); hfe=(hf**2).sum(); toe=(iso**2).sum()+1e-20
        active=[w for w in words if w[0]<t+min(d,.5) and w[1]>t]
        keyhit=[w[2] for w in active if w[2] in KEY]
        stack=[ (evs[j]['kind'],round(evs[j]['t']-t,2)) for j in range(len(evs)) if j!=i and abs(evs[j]['t']-t)<0.3]
        res.append(dict(i=i,t=round(t,2),kind=e['kind'],dur=round(d,2),peak_dbfs_raw=round(db(pk),1),voice_peak_local_raw=round(db(vpk),1),
            rel_voice_peak=round(db(pk)-db(vpk),1),rel_voice_rms=round(db(pk)-db(vr),1),hf_db=round(10*np.log10(hfe/toe+1e-12),1),
            over_words=[w[2] for w in active],over_key=keyhit,stack=stack))
    json.dump(dict(summary=out,events=res),open('analysis.json','w'),indent=1)
    # bed vs voice per second
    gaps=[]
    for s in range(0,int(n/SR)):
        v=vo[s*SR:(s+1)*SR]; bd=bed[s*SR:(s+1)*SR]
        gaps.append((s,round(db(np.sqrt((v**2).mean())),1),round(db(np.sqrt((bd**2).mean())),1)))
    json.dump(gaps,open('bed_vs_voice.json','w'))
    print(json.dumps(out,indent=1))
