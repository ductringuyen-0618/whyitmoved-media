import sys; sys.argv=['x']; sys.dont_write_bytecode=True
sys.path.insert(0,'/home/claude/studio2/pilot2/audio')
import mix, numpy as np, json, argparse, soundfile as sf
A=json.load(open('analysis.json')); ev=A['events']; S=A['summary']
a=argparse.Namespace(voice='voice_v4_24k.wav',events='sfx_events.json',sfx_npz='sfx_event_waves.npz',plan='sfx_plan_v4.json',bed=['stem_music.wav:-26','stem_pad.wav:-34','stem_room.wav:-44'],duration=43.97)
out,st,info=mix.build(a); R=json.load(open('remix_report.json'))
bf=lambda e: e['rel_voice_peak']>-9
res=dict(
 before=dict(sfx=len(ev), louder_than_m9=sum(bf(e) for e in ev), under_key=sum(1 for e in ev if e['over_key']), over_any_word=sum(1 for e in ev if e['over_words']),
   stacked=sum(1 for x,y in zip(sorted(ev,key=lambda e:e['t']),sorted(ev,key=lambda e:e['t'])[1:]) if y['t']-x['t']<0.3), harsh=sum(1 for e in ev if e['hf_db']>-15),
   sfx_minus_voice_lu=S['sfx']['I']-S['voice']['I'], bed_minus_voice_lu=S['bed']['I']-S['voice']['I'],
   med_rel_voice_peak=float(np.median([e['rel_voice_peak'] for e in ev])), worst_rel=max(e['rel_voice_peak'] for e in ev)),
 after=dict(sfx=R['sfx_count'], louder_than_m9=sum(1 for e in R['sfx_events'] if e['rel_voice_local_peak_db']>-9), harsh=sum(1 for e in R['sfx_events'] if e['hf_over6k_db']>-15),
   sfx_minus_voice_lu=mix.integrated(st['sfx'])-mix.integrated(st['voice']), bed_minus_voice_lu=R['bed']['under_voice_lu'],
   med_rel=float(np.median([e['rel_voice_local_peak_db'] for e in R['sfx_events']])), worst_rel=R['sfx_worst_rel_voice_local_peak_db'], stacked=R['sfx_stack_within_0.3s']))
# key-word overlap after
W=json.load(open('/home/claude/studio2/pilot2/build/vo_exact_v4.json'))
print(json.dumps(res,indent=1,default=float))
