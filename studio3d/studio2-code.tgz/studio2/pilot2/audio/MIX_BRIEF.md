# MIX BRIEF - PILOT v4 (Sound Designer / Mixer)

Owner feedback: "the sound effects feel too much, and the volume needs review."
Verdict from the numbers: the SFX were as loud as the narration (SFX stem -21.4 LUFS vs voice -20.9 LUFS), there were 59 of them, and the final limiter was squashing the voice every time a big hit landed. The owner is right. All figures below are measured, not listened to (I cannot listen; see "Not verified").

Files (all in `/home/claude/studio2/pilot2/audio/`): `mix.py` (reusable), `mix_v4_remix.wav`, `PILOT_v4_remix.mp4`, `remix_report.json`, `analysis.json`, `stem_*.wav`, `sfx_events.json`, `sfx_plan_v4.json`, `shipped_shortterm.csv`.

## 1. What is wrong with v4 (measured on the shipped audio and on re-generated stems)

| Measure | v4 as shipped | Target |
|---|---|---|
| Integrated loudness | -14.9 LUFS | -14.0 |
| True peak | -1.2 dBTP | <= -1.5 |
| Short-term range (3 s) | -17.0 to -13.2 LUFS (LRA 2.0 LU) | tight, voice about -16 on the bus |
| Voice stem (before master) | -20.9 LUFS, peak -0.9 dBFS (crest ~20 dB) | needs compression |
| SFX stem | -21.4 LUFS (**-0.5 LU vs voice**), peak +2.3 dBFS | >= 9 dB under voice |
| Music / pad / room (stem LUFS) | -41.7 / -42.8 / -45.4 ; bed sum -38.3 (**-17.4 LU vs voice**) | >= 20 under voice |
| Pre-master mix peak | +3.2 dBFS (3 dB digital over) then `alimiter=0.5`, then loudnorm | no overs |

Findings:
* **59 SFX in 44 s** (rule: ~12). Every one of them overlaps a spoken word (VO is wall-to-wall); 41 overlap a key word (names, numbers, nouns I listed in `analyze.py`).
* **23 of 59 SFX are louder than -9 dB under the voice** (peak vs voice local peak, +/-0.4 s). Worst: crash 29.61 and 39.27 (+5.5 / +5.6 dB OVER the voice), whoosh 41.92 (+3.3), tick 13.73 (+0.7), bonk 27.46 (+0.5), whoosh 19.64 (-0.6). Median event is -10.4 dB re voice peak, which is about 6.6 dB ABOVE the voice's average (RMS) level in the same window (peak-to-peak comparison flatters the SFX).
* **Stacks within 0.3 s: 10 adjacent pairs in 6 clusters**: 6.95 thud+squeak; 10.48 thud+sproing+tink; 11.64-12.29 creak x3 + squeak; 21.34 boing+aooga (0.05 s); 27.18 squeak+bonk; 39.27-39.37 crash+gasp+whistle (three within 0.1 s, the loudest cluster of the clip).
* **Harsh highs (> 3 % of the event energy above 6 kHz, i.e. hf > -15 dB): 14 events**: tick 13.73 (all of it above 6 kHz), paper 35.95/37.05 (-3.4 dB), fwip 3.54, brrr 22.05, gasp 5.57/39.32, whoosh 19.64/23.89/41.92, crash 29.61/39.27, beep 15.01 (-12). Several generators use a one-pole low-pass (6 dB/oct) so the 'LP' does not remove highs.
* **Limiter pumping**: the master chain (`alimiter limit=0.5` after a mix that peaks +3.2 dBFS) pulls the voice down by more than 3 dB (estimated from the limiter on the re-generated premix, up to ~16 dB at its worst frame) at about 13.7, 27.4, 31.1 and 39.3 s (tick, bonk, thud and the crash/whistle/gasp stack). That is the "volume needs review" complaint: the voice level dips on every big hit.
* **Bed audible**: music+pad+room sit 17.4 LU under the voice overall and 7.6 to 19.6 dB under it second by second (median 15.6) - never reaching the 20 dB target in any of the 43 seconds. The `room` is constant low-passed noise (hiss) and the `pad` is 110/165/220 Hz sines right on the narrator's fundamental; the square-wave arp has HF harmonics.
* Master misses spec: -14.9 LUFS (target -14.0) and -1.2 dBTP (target -1.5).

## 2. Targets and exact settings (implemented in `mix.py`, `CFG` dict)

**Spec conflict to know about:** "voice about -16 LUFS short-term" and "final -14 LUFS integrated" cannot both hold in the delivered file, because the voice carries nearly all the loudness. Resolution used: the -16 LUFS voice level is the **mix-bus working level**; the single final linear gain (+2.0 dB, applied equally to everything) brings the file to -14.0 LUFS. In the delivered file the voice reads about -14.0 LUFS. If the owner wants -16 in the file, drop `final_lufs` to -16 (nothing else changes).

| Stage | Setting |
|---|---|
| Voice HPF | 80 Hz, 2nd order |
| Voice compressor | threshold -30 dBFS, ratio 4:1, knee 6 dB, attack 1 ms, release 120 ms (raw PLR was 20 dB, now 12) |
| Voice peak limiter | ceiling -4.0 dBFS at the -16 LUFS bus, 3 ms look-ahead (max gain reduction 3.5 dB, 1.4 % of samples > 1 dB) |
| Voice level | -16.0 LUFS integrated on the bus (voice peak reference "Vref" = 98th percentile of 20 ms peaks) |
| Duck | whenever voice is active (VAD: 10 ms RMS within 25 dB of speech level, hold 60 ms): SFX bus and bed bus **-6.0 dB**, attack 15 ms, release 180 ms |
| SFX classes (peak, before duck, re Vref) | tick -15 dB, soft -12 dB, hit -9 dB; tonal sounds (boing, bell, ding, cha, tink, plink, beep) a further -3 dB. After the -6 dB duck the hits sit at -15 re Vref and ticks at -21 to -24 |
| SFX shaping | max length 0.35 s, 3 ms fade-in, up-to-80 ms fade-out, HPF 60 Hz, **LPF 6 kHz 4th order (24 dB/oct)** (crash/glass 4.5 kHz), -4 dB peaking cut at 2.5 kHz Q 0.8 (voice presence pocket) |
| Bed | HPF 50 Hz, LPF 3 kHz (2nd order); music **-26 LU**, pad **-34 LU**, room **-44 LU** relative to the voice's integrated loudness (pre-duck; sum -31 LU); 0.5 s fade in/out; then the same -6 dB duck |
| Master | lookahead limiter, ceiling chosen by loop so TP <= -1.5 dBTP (ended at -2.1 dBFS sample peak, master gain +2.0 dB), linear gain to -14.0 LUFS integrated |
| Event budget | <= 12 SFX; <= 6 hits; min gap 0.3 s; nothing > 0.35 s |

Retime notes for the Animator: no event was retimed (all kept events stay on the original picture frame). Because the VO never stops, 10 of the 11 kept SFX still start under a key word; they are protected by the duck (-6 dB), the class levels, the 2.5 kHz pocket and the 6 kHz low-pass instead of by silence. If the Director wants them fully clear of words, the only free slots are the short inter-word gaps (e.g. 12.14-12.29, 13.53-13.63, 16.35-16.55), which are 0.1-0.2 s.

## 3. SFX decision table - every event (59)

Flags: L = louder than -9 dB under voice, K = overlaps a key spoken word, S = stacks within 0.3 s of another SFX, H = harsh highs (> 3 % energy above 6 kHz). "Peak" = as generated (pre-master, raw, un-gained: voice peak is -0.9). "vs voice" = peak minus voice local peak (+/-0.4 s), in dB, positive = louder than the voice.

Result: **KEEP 1, LOWER 10, CUT 48** (KEEP = survives with a cut of < 8 dB; LOWER = survives with a cut of >= 8 dB and trimmed/filtered; CUT = removed).

| # | t (s) | type | dur | peak dBFS | vs voice | flags | verdict | new treatment | reason |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.18 | boing | 0.45 | -12.5 | -10.5 | K | **LOWER** | tick; peak -26 dBFS final (-24 dB re voice local peak); -14 dB vs now | hook gag; short 0.35 s, tonal so -3 dB trim |
| 1 | 1.58 | ding | 0.90 | -14.6 | -11.6 | K | **CUT** | - | 0.9 s ring (> 0.4 s rule), tonal, sits on a name word |
| 2 | 2.64 | pop | 0.09 | -13.3 | -10.8 | K | **LOWER** | tick; peak -23 dBFS final (-21 dB re voice local peak); -10 dB vs now | tiny chip tick |
| 3 | 3.54 | fwip | 0.30 | -11.9 | -4.8 | LH | **CUT** | - | noise burst, >6 kHz energy, peak only 4.8 dB under voice |
| 4 | 4.65 | plink | 0.30 | -12.6 | -9.6 | K | **CUT** | - | duplicate chip tick on a key word; one chip tick per chip is enough |
| 5 | 5.57 | gasp | 0.50 | -11.4 | -8.6 | LKH | **CUT** | - | noisy breath, harsh highs, adds nothing the picture does not show |
| 6 | 6.05 | whoomp | 0.90 | -15.4 | -12.7 | K | **CUT** | - | 0.9 s riser (> 0.4 s rule) sitting on "giant" |
| 7 | 6.95 | thud | 0.40 | -4.0 | -2.6 | LKS | **LOWER** | hit; peak -17 dBFS final (-15 dB re voice local peak); -13 dB vs now | big hit for the beat; soft, LF only, 0.35 s |
| 8 | 7.25 | squeak | 0.50 | -18.4 | -17.0 | KS | **CUT** | - | stacks with the hit within 0.3 s | in a stack cluster |
| 9 | 7.76 | pop | 0.09 | -13.3 | -11.8 | K | **LOWER** | tick; peak -23 dBFS final (-21 dB re voice local peak); -10 dB vs now | tiny chip tick |
| 10 | 8.79 | ding | 0.90 | -14.6 | -7.4 | LK | **CUT** | - | 0.9 s ring (> 0.4 s rule), tonal, sits on a name word |
| 11 | 9.48 | grunt | 0.30 | -15.5 | -11.0 | K | **CUT** | - | extra sound for a pose the picture already shows |
| 12 | 10.48 | thud | 0.40 | -4.0 | -2.4 | LKS | **LOWER** | hit; peak -17 dBFS final (-15 dB re voice local peak); -13 dB vs now | big hit for the beat; soft, LF only, 0.35 s |
| 13 | 10.68 | sproing | 0.50 | -12.6 | -11.0 | KS | **CUT** | - | stacked on thud (0.2 s) + tink (0 s) | in a stack cluster |
| 14 | 10.68 | tink | 0.15 | -17.1 | -15.5 | KS | **CUT** | - | stacked with sproing/thud at 10.68; or sparkle that duplicates the picture | in a stack cluster |
| 15 | 11.64 | creak | 0.60 | -20.4 | -18.6 | KS | **CUT** | - | 3 creaks 0.28 s apart (stacked train) under "wobbles"; repeated gag sound | in a stack cluster |
| 16 | 11.92 | creak | 0.60 | -20.4 | -17.4 | KS | **CUT** | - | 3 creaks 0.28 s apart (stacked train) under "wobbles"; repeated gag sound | in a stack cluster |
| 17 | 12.20 | creak | 0.60 | -20.4 | -16.8 | KS | **CUT** | - | 3 creaks 0.28 s apart (stacked train) under "wobbles"; repeated gag sound | in a stack cluster |
| 18 | 12.29 | squeak | 0.50 | -18.4 | -14.9 | KS | **CUT** | - | stacks with the hit within 0.3 s | in a stack cluster |
| 19 | 12.96 | tink | 0.15 | -17.1 | -10.3 | K | **CUT** | - | stacked with sproing/thud at 10.68; or sparkle that duplicates the picture |
| 20 | 13.73 | tick | 0.05 | -1.5 | +0.7 | LKH | **CUT** | - | full-scale noise click, +0.7 dB OVER voice peak, 100% > 6 kHz |
| 21 | 14.19 | pew | 0.25 | -12.6 | -9.4 | H | **CUT** | - | scan swoosh with highs; the word "scans" already says it |
| 22 | 15.01 | beep | 0.12 | -12.4 | -4.5 | LKH | **CUT** | - | duplicates the spoken word "Beep." and masks it |
| 23 | 15.75 | tock | 0.06 | -13.2 | -10.4 | K | **CUT** | - | metronome-style filler, not a gag; the 5 tocks (25.59-26.87) are a busy train under the Monday line |
| 24 | 17.43 | cha | 0.62 | -16.9 | -8.4 | LK | **KEEP** | hit; peak -22 dBFS final (-20 dB re voice local peak); -5 dB vs now | price-reveal hit; tonal, shortened to 0.35 s, pocket EQ |
| 25 | 18.35 | swhistle | 0.50 | -16.8 | -15.0 | K | **CUT** | - | rising whistle, tonal/harsh, stacked at 39.3 and no gag value |
| 26 | 19.64 | whoosh | 0.35 | -6.8 | -0.6 | LH | **CUT** | - | noise whoosh, 6-14 dB louder than needed and with >6 kHz hiss |
| 27 | 20.41 | tock | 0.06 | -13.2 | -9.8 | K | **CUT** | - | metronome-style filler, not a gag; the 5 tocks (25.59-26.87) are a busy train under the Monday line |
| 28 | 20.96 | creak | 0.60 | -20.4 | -13.9 | K | **CUT** | - | 3 creaks 0.28 s apart (stacked train) under "wobbles"; repeated gag sound |
| 29 | 21.34 | boing | 0.45 | -12.5 | -6.2 | LS | **LOWER** | soft; peak -23 dBFS final (-21 dB re voice local peak); -11 dB vs now | hook gag; short 0.35 s, tonal so -3 dB trim |
| 30 | 21.39 | aooga | 0.55 | -16.8 | -10.6 | S | **CUT** | - | stacked on boing 0.05 s later | in a stack cluster |
| 31 | 22.05 | brrr | 1.30 | -13.8 | -8.5 | LKH | **CUT** | - | 1.3 s buzz (> 0.4 s rule), harsh, covers "receipt prints" |
| 32 | 22.95 | rev | 1.40 | -15.0 | -13.4 | - | **CUT** | - | 1.4 s engine (> 0.4 s rule), peak only 3 dB under voice |
| 33 | 23.89 | whoosh | 0.35 | -6.8 | -2.8 | LH | **CUT** | - | noise whoosh, 6-14 dB louder than needed and with >6 kHz hiss |
| 34 | 24.89 | bell | 0.80 | -18.4 | -16.8 | K | **CUT** | - | pure 2 kHz tone lands on "door"; 1-4 kHz masking test failed (-4 dB) so cut |
| 35 | 25.59 | tock | 0.06 | -13.2 | -11.5 | - | **CUT** | - | metronome-style filler, not a gag; the 5 tocks (25.59-26.87) are a busy train under the Monday line |
| 36 | 25.91 | tock | 0.06 | -13.2 | -9.7 | K | **CUT** | - | metronome-style filler, not a gag; the 5 tocks (25.59-26.87) are a busy train under the Monday line |
| 37 | 26.23 | tock | 0.06 | -13.2 | -11.1 | K | **CUT** | - | metronome-style filler, not a gag; the 5 tocks (25.59-26.87) are a busy train under the Monday line |
| 38 | 26.55 | tock | 0.06 | -13.2 | -11.1 | - | **CUT** | - | metronome-style filler, not a gag; the 5 tocks (25.59-26.87) are a busy train under the Monday line |
| 39 | 26.87 | tock | 0.06 | -13.2 | -11.1 | - | **CUT** | - | metronome-style filler, not a gag; the 5 tocks (25.59-26.87) are a busy train under the Monday line |
| 40 | 27.18 | squeak | 0.50 | -18.4 | -12.7 | KS | **CUT** | - | stacks with the hit within 0.3 s | in a stack cluster |
| 41 | 27.46 | bonk | 0.30 | -5.1 | +0.5 | LKS | **LOWER** | hit; peak -17 dBFS final (-15 dB re voice local peak); -12 dB vs now | fall hit for Bram; LF, shortened to 0.3 s |
| 42 | 29.31 | squeak | 0.50 | -18.4 | -14.5 | K | **CUT** | - | stacks with the hit within 0.3 s |
| 43 | 29.61 | crash | 0.70 | 1.6 | +5.5 | LKH | **LOWER** | hit; peak -17 dBFS final (-15 dB re voice local peak); -19 dB vs now | biggest hit (Beam falls); noise crash was +5.5 dB OVER voice peak, now LP 4.5 kHz and -15 dB re voice peak |
| 44 | 31.48 | thud | 0.40 | -4.0 | -1.7 | LK | **CUT** | - | big hit for the beat; soft, LF only, 0.35 s |
| 45 | 32.71 | pdown | 0.70 | -16.8 | -15.9 | K | **CUT** | - | 0.7 s pitch-down slide; the word "harder" carries it |
| 46 | 33.30 | pop | 0.09 | -13.3 | -12.4 | - | **CUT** | - | tiny chip tick |
| 47 | 34.10 | wah | 1.00 | -18.4 | -17.0 | - | **CUT** | - | 1.0 s sad-trombone tone under "knows for sure"; tonal and long |
| 48 | 34.95 | pop | 0.09 | -13.3 | -11.8 | - | **CUT** | - | tiny chip tick |
| 49 | 35.95 | paper | 0.50 | -11.9 | -8.2 | LKH | **CUT** | - | rustle noise, ~46 % of its energy above 6 kHz, twice |
| 50 | 36.50 | drip | 0.12 | -13.0 | -9.3 | - | **CUT** | - | tiny but redundant with "worry" chip |
| 51 | 37.05 | paper | 0.50 | -11.9 | -8.2 | LKH | **CUT** | - | rustle noise, ~46 % of its energy above 6 kHz, twice |
| 52 | 39.27 | crash | 0.70 | 1.6 | +5.6 | LSH | **CUT** | - | biggest hit (Beam falls); noise crash was +5.5 dB OVER voice peak, now LP 4.5 kHz and -15 dB re voice peak |
| 53 | 39.37 | swhistle | 0.50 | -16.8 | -10.6 | S | **CUT** | - | rising whistle, tonal/harsh, stacked at 39.3 and no gag value | in a stack cluster |
| 54 | 40.12 | tock | 0.06 | -13.2 | -8.2 | L | **CUT** | - | metronome-style filler, not a gag; the 5 tocks (25.59-26.87) are a busy train under the Monday line |
| 55 | 39.32 | gasp | 0.50 | -11.4 | -3.4 | LSH | **CUT** | - | noisy breath, harsh highs, adds nothing the picture does not show | in a stack cluster |
| 56 | 41.47 | boing | 0.45 | -12.5 | -8.0 | LK | **LOWER** | soft; peak -23 dBFS final (-21 dB re voice local peak); -11 dB vs now | hook gag; short 0.35 s, tonal so -3 dB trim |
| 57 | 41.92 | whoosh | 0.35 | -6.8 | +3.3 | LKH | **CUT** | - | noise whoosh, 6-14 dB louder than needed and with >6 kHz hiss |
| 58 | 43.54 | boing | 0.45 | -12.5 | -8.6 | LK | **LOWER** | tick; peak -26 dBFS final (-24 dB re voice local peak); -14 dB vs now | hook gag; short 0.35 s, tonal so -3 dB trim |

Kept (11): 5 big hits (6.95 thud bottle, 10.48 thud cart, 17.43 cha price, 27.46 bonk Bram, 29.61 crash Beam), 2 soft (21.34 boing eyes, 41.47 boing banana), 4 ticks (0.18 hook boing, 2.64 and 7.76 chip pops, 43.54 loop boing). One hit per beat: bottle, cart, price, Bram falls, Beam falls. Optional add-back if the chips on screen need it: pops at 33.3 and 34.95 as ticks (13 total, still ~12).

## 4. Before / after (same picture, same VO)

| Measure | v4 shipped | Remix |
|---|---|---|
| Integrated LUFS | -14.9 | -14.0 |
| True peak (dBTP) | -1.2 | -1.5 (also -1.5 after AAC in the mp4) |
| Short-term (3 s) min / max | -17.0 / -13.2 LUFS | -15.4 / -13.4 LUFS |
| LRA | 2.0 LU | 1.0 LU |
| SFX count | 59 | 11 |
| SFX stem vs voice (integrated) | -0.5 LU | -19.9 LU |
| Median SFX peak vs voice local peak | -10.4 dB | -21.0 dB |
| Worst SFX peak vs voice local peak | +5.6 dB | -15.0 dB |
| SFX louder than -9 dB under voice | 23 | 0 |
| SFX loudest 400 ms vs voice 400 ms (momentary LUFS) | n/a (peaks above voice) | worst -16.5 dB |
| Stacks within 0.3 s | 10 pairs | 0 |
| Harsh-high events | 14 | 0 |
| SFX under a key word | 41 of 59 | 10 of 11 (all except the 0.18 hook boing), each ducked 6 dB and 15-24 dB under the voice peak |
| Bed vs voice (integrated) | -17.4 LU | -31.2 LU (-30.9 dB in speech frames) |
| Silences > 0.4 s (-50 dB) | none in VO | none (also none at -35 dB / 0.25 s) |
| Voice masked? (50 ms speech frames, voice minus SFX+bed) | n/a | min 8.3 dB broadband, min 1.9 dB in 1-4 kHz (frames where the voice has >-45 dBFS there); 5th percentile 15.7 dB |

## 5. How to apply this in later builds

```
python3 /home/claude/studio2/pilot2/audio/mix.py --voice vo.wav --events sfx_events.json --sfx-npz sfx_event_waves.npz \
   [--plan sfx_plan.json] --bed music.wav:-26 --bed pad.wav:-34 --bed room.wav:-44 \
   --out mix.wav --video silent_or_old.mp4 --out-video final.mp4 --report mix_report.json --duration 43.97
```
* The renderer should dump each SFX event as an isolated, un-gained waveform (`wav` path per event, or one npz with `arr_<index>`), plus `t` and `kind`; drop the per-kind `GAIN` table and the final `alimiter`/`loudnorm` calls - `mix.py` owns levels and mastering.
* Without `--plan` the script auto-picks: drops long/noisy/harsh kinds (list `DROP_KINDS`), classes the rest, removes anything within 0.3 s of a higher-priority event, keeps <= 12 (<= 6 hits).
* Tell the Director: write one SFX line per beat, plus chips; if a beat needs a second sound, it is cut by the script.
* The script prints/stores the report; QA should check `final.integrated_lufs` = -14.0, `true_peak_dbtp` <= -1.5, `sfx_worst_rel_voice_local_peak_db` <= -9, `silences_over_0.4s` = [], `masking.min_voice_over_other_db` >= 3.

## 6. Not verified / caveats

* **I cannot listen.** Every judgment is numeric: loudness, peaks, spectra, envelope ratios. Whether the remaining hits are audible enough, whether the 'cha', 'boing' and 'thud' still read as jokes at -15 to -24 dB re voice peak, and whether anything sounds distorted (1 ms compressor attack, 3 ms limiter) needs a human listen. If the owner finds the hits too quiet, raise `sfx_class_db` by 2 dB at most (pre-duck hits would sit at -7, which breaks the 9 dB rule, so ask the owner first).
* The stems are **re-generated** from the build scripts (a read-only copy in the scratchpad, using `vo_v4.wav`, `vo_exact_v4.json`, `vo_v4_timing.json`, because the live `vo_exact.json` and `vo_v2.wav` in the build dir had already moved on to the next version). Checked against the shipped audio: waveform correlation 0.94, residual -9 dB (the shipped chain's limiter is non-linear), event times line up to 10 ms. Treat the "before" per-element levels as +/-1 dB, and the per-event peaks as exact only before the shipped limiter.
* The key-word list used for the "under key word" flag is my judgment (names, numbers, nouns); the others are objective.
* "Louder than -9 under the voice" is measured peak vs the voice peak in a +/-0.4 s window. If the owner means peak vs average voice level, the old mix was worse (median +6.6 dB over the voice RMS) and the new one is better (all >= 15 dB under the voice peak).
* The 1-4 kHz masking test failed once (door bell, -4 dB) which is why the bell was cut; the cha at 17.45 passes at +1.9 dB, the weakest remaining spot.
* AAC encode of the mp4 audio was measured: -14.0 LUFS, -1.5 dBTP; picture stream is bit-identical to v4 (copied, hash compared). Audio duration 43.95 s vs picture 43.97 s.
