# PILOT 2 - Marvell x Lumentum - SCRIPT v2 (wall-to-wall VO, 5 beats)

## 1. THE ONE IDEA + THE ONE METAPHOR
**Idea:** A chip company, Marvell, agreed to buy a laser company, Lumentum, for about $115 billion (incl. debt), and on Monday both stocks fell: Marvell 12.7%, Lumentum 18.6%.
Nobody knows for sure why; one report says investors worry it paid too much.

**Metaphor (kept from pilot): the shopping trip.** "Buy" is literally shopping, the price is a receipt, and falling is slipping.
**Max 3 characters ever:** Bram (teal chip bot = Marvell), Beam (light-blue laser bottle = Lumentum), the Cashier (a prop-like extra who only appears in beat 3).
Recurring prop: ONE shopping cart (the callback object in every beat).

## 2. VOICEOVER (21 lines, 116 words, no line over 9 words; Kokoro am_michael, speed 1.0)
Measured with `/home/claude/studio2/pilot2/vo_measure.py` (same synth, speech_bounds trim and word-timing method as pilot `voice()`), lines butted together with only the natural 0.17 s trim pad. Audio: `vo_v2.wav` (24 kHz mono). Timing: `vo_v2_timing.json` (per line and per word).

| # | Line | Start (s) | End (s) | Gap before (s) | Words |
|---|------|-----------|---------|----------------|-------|
| 1 | Who's going shopping? Meet Bram. | 0.03 | 1.85 | - | 5 |
| 2 | Bram is Marvell. He makes computer chips. | 2.02 | 4.67 | 0.17 | 7 |
| 3 | Today, he spots a giant laser bottle. | 4.84 | 7.22 | 0.17 | 7 |
| 4 | That's Beam. Beam is Lumentum. | 7.39 | 9.24 | 0.17 | 5 |
| 5 | Beam barely fits in the cart. | 9.41 | 10.91 | 0.17 | 6 |
| 6 | The cart wobbles. Bram just grins. | 11.08 | 13.43 | 0.17 | 6 |
| 7 | The cashier scans it. Beep. | 13.60 | 15.30 | 0.17 | 5 |
| 8 | The price? About 115 billion dollars. | 15.47 | 18.85 | 0.17 | 6 |
| 9 | That counts debt, too. | 19.02 | 20.21 | 0.17 | 4 |
| 10 | The cashier's eyes pop out. | 20.38 | 21.83 | 0.17 | 5 |
| 11 | The receipt prints. And prints. | 22.00 | 23.59 | 0.17 | 5 |
| 12 | It runs right out the door. | 23.76 | 25.22 | 0.17 | 6 |
| 13 | Then came Monday. | 25.39 | 26.31 | 0.17 | 3 |
| 14 | Bram's shares fell 12.7 percent. | 26.48 | 28.79 | 0.17 | 5 |
| 15 | Beam's fell 18.6 percent. | 28.96 | 30.98 | 0.17 | 4 |
| 16 | Both slipped. Beam slipped harder. | 31.15 | 33.15 | 0.17 | 5 |
| 17 | Why? Nobody knows for sure. | 33.32 | 34.82 | 0.17 | 5 |
| 18 | One report says investors worry it paid too much. | 34.99 | 38.02 | 0.17 | 9 |
| 19 | Maybe the cart was just too full. | 38.19 | 40.09 | 0.17 | 7 |
| 20 | Remember, this is a cartoon, not advice. | 40.26 | 42.71 | 0.17 | 7 |
| 21 | So, who's going shopping? | 42.88 | 44.18 | 0.17 | 4 |

**TOTAL speech: 44.18 s (WAV 44.32 s). 116 words. Largest gap between lines: 0.17 s (all gaps equal).** Loop: line 21 ("So, who's going shopping?") flows straight into line 1 ("Who's going shopping?").
(Trial runs: speed 1.05 gives 42.98 s, 1.1 gives about 37 s with fewer lines; 1.0 chosen for the clearest, friend-like pace.)

## 3. THE 5 BEATS (one scene, one focal action, one gag: setup -> hit -> callback)

### BEAT 1 - "The tiny cart"  (lines 1-4, 0.03-9.24 s)
VO: 1 Who's going shopping? Meet Bram. / 2 Bram is Marvell. He makes computer chips. / 3 Today, he spots a giant laser bottle. / 4 That's Beam. Beam is Lumentum.
Visual idea: Bram pushes a comically tiny cart down an empty aisle and stops in front of one huge glowing Beam.
Gag: SETUP the tiny cart (L1-2); HIT Beam towers over Bram, he looks up with his mouth open (L3-4); CALLBACK seed: the cart is the object to be overloaded in beat 2.
Chips: none (name tags on the characters only).

### BEAT 2 - "It does not fit"  (lines 5-7, 9.41-15.30 s)
VO: 5 Beam barely fits in the cart. / 6 The cart wobbles. Bram just grins. / 7 The cashier scans it. Beep.
Visual idea: Beam is wedged into the tiny cart; the cart's wheels splay out and it wobbles while Bram grins like nothing is wrong.
Gag: SETUP Bram heaves Beam in (L5); HIT the wheels splay and the cart sags and wobbles, Bram's grin never moves (L6); CALLBACK to beat 1's tiny cart. Cut to the cashier's scanner "Beep" (L7) only as the last second hand-off.
Chips: none.

### BEAT 3 - "The endless receipt"  (lines 8-12, 15.47-25.22 s)
VO: 8 The price? About 115 billion dollars. / 9 That counts debt, too. / 10 The cashier's eyes pop out. / 11 The receipt prints. And prints. / 12 It runs right out the door.
Visual idea: the register spits out one receipt that keeps growing and snakes out the door while Bram and Beam stand frozen.
Gag: SETUP the register prints the "$115B" (L8-9, chip "$115B" + small "incl. debt"); HIT the cashier's eyes pop and the receipt will not stop (L10-11); CALLBACK/payoff the receipt runs out the door and the sagging cart from beat 2 is dragged along by it (L12).
Chips: "$115B" (plus "incl. debt"). One number only.

### BEAT 4 - "Monday: one banana peel"  (lines 13-16, 25.39-33.15 s)
VO: 13 Then came Monday. / 14 Bram's shares fell 12.7 percent. / 15 Beam's fell 18.6 percent. / 16 Both slipped. Beam slipped harder.
Visual idea: outside the shop Bram and Beam both step on the same banana peel and land side by side, Beam landing harder.
Gag: SETUP the banana peel sits alone on the sidewalk (L13); HIT Bram slips, chip "-12.7%", bonk (L14); then Beam slips and lands harder, chip "-18.6%" (L15); CALLBACK (L16) the leftover cart from beat 2 rolls in and tips onto Beam.
Chips: "-12.7%" then "-18.6%" (one at a time, never both at once). Sourced: Monday's close (DU/ST).

### BEAT 5 - "Maybe it was too full"  (lines 17-21, 33.32-44.18 s)
VO: 17 Why? Nobody knows for sure. / 18 One report says investors worry it paid too much. / 19 Maybe the cart was just too full. / 20 Remember, this is a cartoon, not advice. / 21 So, who's going shopping?
Visual idea: a big "?" hangs over the two dazed friends, then the one cart, now stacked to the sky, tips over, and Bram wheels the tiny cart back in.
Gag: SETUP the "?" and a shrug from Bram (L17); HIT chip "One report says: paid too much?" while the overstuffed cart topples (L18-19); CALLBACK Bram brushes off, sets the same tiny cart upright and rolls it back into the aisle from beat 1 (L20-21), which is the loop.
Chips: "?" (L17), "One report says" (L18, single source MF), "CARTOON - NOT ADVICE" (L20).

## 4. FACT AND HEDGE CHECK (vs FACTS_MRVL)
- "Bram is Marvell ... makes computer chips" / "Beam is Lumentum" (lasers): F1, F2.
- "About 115 billion dollars ... counts debt": F3 (DU/MF/YF headline; ST says enterprise value incl. debt). The SEC email says about $100B; chip carries "~", conflict noted in facts file.
- "Monday ... fell 12.7 / 18.6 percent": F7, closes (2 sources). "shares" = stock.
- "Nobody knows for sure" and "One report says investors worry it paid too much": F11 (MF single source) + ST caveat. Not stated as proven cause.
- "Maybe the cart was just too full" is a clearly jokey aside, not a claim.
- "Cartoon, not advice": rule 4. Dropped: all-stock, ratio, votes, 2028.
- Companies named (Marvell, Lumentum) only in VO, no logos; Bram and Beam are generic characters.

## 5. NOTES FOR THE DIRECTOR
- Time every action to `vo_v2_timing.json` word times; do not stretch picture. Each beat has 5.5 to 10 s to land.
- One focal action at a time; background still; cashier appears only in beat 3, and freezes while the receipt is the star.
- Largest gap is 0.17 s; do not add music dropouts under the VO.
