# PILOT 2 - SHOT LIST v2 (Director) - timed to vo_v2_timing.json (44.18 s)
Rules obeyed: ONE mover per row (+ gentle camera push), <=3 objects on screen, hard cuts only (every cut sits in a 0.17 s VO gap, so nothing is "cut mid-word"), no slow-mo, one big shake per beat, VO never stops.
Notation: `@word t` = the trigger word and its start time; action starts on that frame. "Hold" = nothing moves except the camera push. Objects: B=Bram, M=Beam, C=cart, R=Reggie (the cashier), r=receipt.

## DIRECTOR CHANGES TO THE SCRIPT (read first)
1. Cut Beat 2 -> 3 at **13.52** (gap before line 7), not 15.4: "The cashier scans it. Beep." needs the register, so line 7 belongs to Beat 3.
2. Line 19 replaced (no cause claim). **Old:** "Maybe the cart was just too full." (7 words, 8 syll.) **NEW: "Oh well, we just have no idea."** (7 words, 9 syll.). Collapse is pinned to **"no"** (~39.55 s). Re-run vo_measure.py on the new line; if its 7 words don't each land within +-0.15 s of the old slots, fall back to "So yeah, we have no idea." and re-pin the collapse to its "no".
3. Cashier = Reggie (register-with-eyes from art.py), one object, so counter+cashier never count twice.
4. Cut: the cart being dragged by the receipt (B3), the cart tipping onto Beam (B4), the "stacked to the sky" cart (B5), name tags reading MARVELL/LUMENTUM. Tags now read BRAM / BEAM (company names stay in VO only).

## SETS (2) and CAMERA
- **SET A "Aisle"**: flat cream wall (252,226,186) + one tan floor band (214,170,126) + one thin floor line. NO shelves. Used by B1, B2, B4, B5.
- **SET B "Checkout"**: same wall + floor, one counter block (150,100,68), one door (flat teal) at far right. Used by B3 only.
- Camera: ONE gentle push per shot (1.00 -> 1.06 over the shot), no pans, no zoom jumps. Frame 0 camera = last-frame camera (see LOOP).
- Safe area: all key art/chips between y=330 and y=1520. Characters feet ~y=1250. Sizes: Bram >=480 px tall (wide shots >=340), Beam 55% of frame = ~1050 px, Reggie ~560 px, cart ~300 px.
- Hard cuts at: 9.32 | 13.52 | 15.38 | 23.68 | 25.31 | 28.88 | 31.07 | 33.23 | 38.10 | 42.80.

## SHOT TABLE
| time (s) | spoken | THE ONE FOCAL ACTION (trigger) | freezes / leaves | expression | SFX | text |
|---|---|---|---|---|---|---|
| **BEAT 1 - SET A, shot 1 (B + C only; tiny cart SETUP)** |||||||
| 0.03-1.24 | Who's going shopping? | Bram squats then hops once, cart bounces with him (`@Who's 0.03`); lands back in pose P0 by 0.55 | everything else (empty aisle) | grin, eyes open | boing | caption "(cartoon, not advice)" |
| 1.24-1.85 | Meet Bram. | Bram bows and taps his BRAM tag (`@Bram 1.547`) | cart | happy eyes, grin | ding | caption until 2.02 |
| 2.02-2.50 | Bram is | Hold, camera push only | all | grin | - | - |
| 2.50-3.22 | Marvell. | Bram thumbs himself with one hand (`@Marvell 2.502`) | cart | proud, grin | pop | - |
| 3.22-4.43 | He makes computer | Bram pulls a small chip from his chest and lifts it up high (`@makes 3.225`) | cart | open mouth, eyes up | zip | - |
| 4.43-5.65 | chips. Today, he | Chip drops into the tiny cart (`@chips 4.429`); then hold | Bram freezes | grin | plink | - |
| 5.65-6.10 | spots a | Bram's head snaps right, eyes go wide (`@spots 5.648`) | cart | wide eyes, mouth O | gasp | - |
| 6.10-6.77 | giant laser bottle. | Beam slides up into frame from the right edge to full 55% height, landing on `@bottle 6.771` | Bram frozen, cart frozen | Bram O; Beam smile | rising whoomp + hum | - |
| 6.77-7.39 | (bottle.) | Bram tilts head back to look up (`@bottle 6.771`, after Beam stops) | Beam, cart | eyes up, mouth O | gulp | - |
| 7.39-8.18 | That's Beam. | Beam waves one hand (`@Beam 7.654`), BEAM tag visible | Bram, cart | smile | boop | - |
| 8.18-9.24 | Beam is Lumentum. | Beam's glow pulses up once (`@Lumentum 8.447`) | Bram, cart | big smile | glow "wwoom" | - |
| **BEAT 2 - SET A, shot 2 (B, M, C; HIT = cart overloaded)** |||||||
| 9.41-10.16 | Beam barely | Bram lifts Beam off the floor with both arms (`@Beam 9.41`) | cart | Bram strain; Beam squish | grunt | - |
| 10.16-10.72 | fits in the | Beam drops into the cart, top half sticks out (`@fits 10.160`) | Bram | Beam squish | thunk | - |
| 10.72-11.08 | cart. | Cart wheels splay out sideways = the ONE BIG HIT (`@cart 10.722`) + one shake | everything | Beam worry, Bram open | metal "SPROING" | - |
| 11.08-11.75 | The cart | Hold (a held breath), camera push | all | Bram: grin starts | - | - |
| 11.75-12.42 | wobbles. | Cart + Beam rock left-right x3 (`@wobbles 11.751`) | Bram | Beam worry | creak-creak-creak | - |
| 12.42-13.09 | Bram just | Wobble dies to a stop (`@Bram 12.423`) | Bram | grin | squeak | - |
| 13.09-13.52 | grins. | Bram's grin stretches huge, eyes unblinking (`@grins 13.094`) | cart, Beam | giant grin | tiny sting | - |
| **BEAT 3 - SET B (B, C+M, R; HIT = cashier eyes pop, payoff = endless receipt)** |||||||
| 13.60-13.88 | The | Cut in (13.52): Bram left, cart+Beam centre, Reggie right. Hold | all | Reggie eyes closed | shop ambience | - |
| 13.88-14.45 | cashier | Reggie's eyes snap open and swivel to Beam (`@cashier 13.883`) | Bram, cart | wide eyes | snap | - |
| 14.45-15.02 | scans it. | A red scan line sweeps down Beam once (`@scans 14.450`) | Bram, Reggie | Beam flinch-eyes | laser zzzip | - |
| 15.02-15.38 | Beep. | Reggie's screen flashes green (`@Beep 15.017`) | all | Reggie smile | BEEP | - |
| 15.47-15.85 | The | Cut to tight on Reggie (Bram/cart/Beam gone). Hold | - | Reggie lids half | - | - |
| 15.85-16.97 | price? About | Reggie narrows eyes, leans in (`@price 15.846`) | - | squint | hum | - |
| 16.97-17.35 | 115 | Chip slams onto the screen area (`@115 16.972`), squash-and-settle, no shake | Reggie | smug | CHA-CHING | **$115B incl. debt** (y~450, to 20.30) |
| 17.35-18.10 | billion | Hold, camera push | all | smug | - | chip |
| 18.10-19.02 | dollars. | Reggie's glasses slide down her nose (`@dollars 18.099`) | chip | eyes over glasses | slide-whistle | chip |
| 19.02-19.54 | That counts | Hold | all | worry begins | - | chip |
| 19.54-20.30 | debt, too. | An underline wipes under "incl. debt" (`@debt 19.537`) | Reggie | worry | scribble-swish | chip, then chip leaves at 20.30 |
| 20.38-21.10 | The cashier's | Hold; Reggie's eyes drop to the empty screen (`@cashier's 20.622`, eyes only) | all | wide, mouth flat | quiet gulp | - |
| 21.10-21.35 | eyes | Eyes begin to bulge on springs (`@eyes 21.105`) | all | strain | rubber creak | - |
| 21.35-22.00 | pop out. | Eyes shoot out on springs = the ONE BIG HIT (`@pop 21.347`) + one shake | all | eyes out, mouth O | BOING-AOOGA | - |
| 22.00-22.27 | The | Hold on dangling eyes | - | - | - | - |
| 22.27-23.06 | receipt prints. | Receipt tongue slides out of the slot and drips down (`@receipt 22.265`) | Reggie frozen | eyes out | printer brrr | - |
| 23.06-23.68 | And prints. | Same receipt keeps feeding, faster, piling at the bottom (`@And 23.060`) | Reggie | eyes out | brrr up in pitch | - |
| 23.76-24.00 | It | Cut to WIDE Set B (Reggie small ~340 px, door at right). Receipt already on floor | Reggie frozen | - | - | - |
| 24.00-25.22 | runs right out the door. | Receipt ribbon zips along the floor and out the door (`@runs 24.003`), tail flicks out on `@door 24.977` | Reggie | eyes out | whoosh, door bell | - |
| **BEAT 4 - SET A, 3 shots (one slipper at a time; HIT = Bram bonk, bigger hit = Beam)** |||||||
| 25.39-25.62 | Then | Cut in: banana peel centre floor, Bram far left, small. Hold | - | grin | - | - |
| 25.62-26.48 | came Monday. | Bram strolls toward the peel, head up (`@came 25.620`) | peel | whistle-grin | tip-tap | - |
| 26.48-27.47 | Bram's shares | Bram keeps strolling, arrives next to the peel (`@Bram's 26.480`) | peel | grin | tip-tap | - |
| 27.47-27.80 | fell | Bram's foot hits the peel, body flips up level (`@fell 27.470`) | peel | wide eyes | SQUEEEK | - |
| 27.80-28.88 | 12.7 percent. | Bram lands flat on the floor, squash, no shake (`@12.7 27.800`) | peel | dazed (x eyes) | bonk | **-12.7%** (to 28.88) |
| 28.96-29.36 | Beam's | Cut: Beam alone, same peel at his feet. Hold | - | smile | - | - |
| 29.36-29.77 | fell | Beam steps on the peel, tips back (`@fell 29.364`) | peel | wide | SQUEEEK | - |
| 29.77-31.07 | 18.6 percent. | Beam falls full length = the ONE BIG HIT of B4 (`@18.6 29.768`) + one shake | peel | squish eyes | CRASH-tinkle | **-18.6%** (to 31.07) |
| 31.15-31.90 | Both slipped. | Cut to wide: Bram and Beam lie side by side; Bram's arm drops limp (`@slipped 31.400`) | Beam | Bram x eyes | flop | - |
| 31.90-32.65 | Beam slipped | Hold, camera push on Beam | all | Beam squish | - | - |
| 32.65-33.15 | harder. | Beam's glow flickers out to dim (`@harder 32.650`) | Bram | Beam dim, eyes x | power-down | - |
| **BEAT 5 - SET A, 5a tight on Bram, 5b medium with cart (gag CALLBACK + LOOP)** |||||||
| 33.32-33.53 | Why? | A "?" pops above Bram's head (`@Why 33.320`) | - | blank eyes | pop | ? (prop) |
| 33.53-34.18 | Nobody | Hold | all | blank | - | ? |
| 34.18-34.82 | knows for sure. | Bram shrugs, arms and shoulders up (`@knows 34.177`) | ? | shrug mouth flat | sad trombone | ? |
| 34.99-35.92 | One report says | "?" disappears; chip pops in at the same time (`@One 34.990`) | Bram frozen in shrug | shrug | pop | **One report says** (y~450, to 38.02) |
| 35.92-36.62 | investors | Bram pulls out a short receipt and holds it up (`@investors 35.922`) | chip | worry eyes | paper rip | chip |
| 36.62-37.32 | worry it | Sweat drop forms on Bram (`@worry 36.621`) | receipt, chip | worry, sweat | drip | chip |
| 37.32-38.02 | paid too much. | Receipt unrolls to the floor and curls (`@paid 37.321`) | Bram, chip | worry | paper unfurl | chip |
| 38.19-39.55 | Oh well, we just have | Cut 38.10 to 5b: Bram (still shrugging) + cart. Hold, camera push only | chip gone, ? gone | shrug | quiet room tone | - |
| 39.55-40.09 | no idea. | Cart collapses flat: wheels splay, handle drops (`@no ~39.55`) = the ONE BIG HIT of B5 + one shake | Bram frozen | Bram blank | CRASH + slide-whistle | - |
| 40.26-40.98 | Remember, | Bram walks to the cart (`@Remember 40.260`) | cart | sheepish grin | tip-tap | caption "(cartoon, not advice)" 40.26-44.18 |
| 40.98-41.59 | this is a | Bram bends and grabs the handle (`@this 40.983`) | cart | grin | - | caption |
| 41.59-42.11 | cartoon, | Cart springs upright (`@cartoon 41.585`) | Bram | grin | boing | caption |
| 42.11-42.71 | not advice. | Bram waves both hands "nope" (`@not 42.107`) | cart | smile | swish | caption |
| 42.88-43.72 | So, who's going | Cut 42.80 to shot-1 framing = pose P0 (Bram+cart, empty aisle); Bram squats (`@going 43.484`) | all | grin | - | caption |
| 43.72-44.18 | shopping? | Bram hops, lands in P0 at 44.10 and holds to the end (`@shopping 43.716`) | everything | grin | boing | caption |

## GAG STRUCTURES (setup -> hit -> callback; callback prop = the tiny cart)
- **B1** SETUP the tiny cart + Bram's chip dropped in it (L1-2). HIT Beam rises, Bram looks up (L3). Callback seed: cart is obviously too small.
- **B2** SETUP Beam lifted (L5). HIT cart wheels splay (L5 "cart") then wobble while Bram grins (L6). CALLBACK to B1's tiny cart.
- **B3** SETUP chip lands on 115 (L8-9). HIT eyes pop (L10). PAYOFF receipt keeps printing out the door (L11-12). Bram/cart are not on screen.
- **B4** SETUP lone banana peel (L13). HIT Bram bonks (L14), Beam crashes bigger (L15). Callback: "harder" = bigger crash + dim glow.
- **B5** SETUP "?" + shrug (L17). HIT cart collapses on "no idea" (L19, pure gag, no cause claim). CALLBACK the SAME tiny cart is stood up and wheeled back to P0 (L20-21) = the loop.

## LOOP
Last frame (44.18) = frame 0 (0.03): Set A shot-1 camera at 1.00 zoom (no push residue: push resets on the 42.80 cut and the final hold ends at push 1.00 -> use camera scale 1.00 at the last frame), Bram in pose P0 (grin, eyes open, arms down, tag BRAM), cart on his right with the B1 chip in it, empty aisle, caption "(cartoon, not advice)" visible. Frame 0 and the last frame are the same render.

## SET + CAST LIST
- Sets (2): A Aisle, B Checkout (above).
- Props (6): cart, receipt, banana peel, bulb/laser (not needed on stage: Beam's own glow does the job), register (Reggie), "?" (qmark_tile). Plus B1 chip (chip_tile).
- Characters: Bram, Beam, Reggie/cashier (B3 only).
- Sprites to REQUEST (art.py `bram_cv`, `beam_cv`, `cart_tile`, `reggie_cv`, `reggie_eyes_tile`, `chip_tile`, `qmark_tile`, `banana_tile`, `paper_tile`): scale Bram to >=480 px (old poses were smaller); Beam at 1050 px; cart 300 px; add a long receipt strip (tileable paper_tile); cart needs `splay` + a flat "collapsed" state (`sag` max); Reggie must show `gdrop` (glasses) and `ext` (eyes on springs).
- Expressions, easiest first (fallback in brackets):
  1 Bram open/grin/lookr/wide/happy/worry/blink (all exist). 2 Bram shrug via al/ar arms up [arms down + sad mouth]. 3 Beam smile/lookl/wide/worry/squish/x (exist). 4 Beam dim (glow=0.0) (exists). 5 Reggie lids/squint/ext/gdrop (exist). 6 Bram "dazed" = x eyes + rot 90 lying [dead eyes]. 7 Bram thumb-to-self (thumb flag) [wave arm]. 8 Bram sweat (sweat=1). 9 Bram bow tilt rot 20 [skip, nod]. 10 Beam wave via al/ar [static smile].
  Hardest: Bram slip flip (rot ~75 + squash on landing) [pure rotate + drop], Beam topple rot 90 [slide-down + fade shadow], receipt ribbon along floor [straight line, no curves].

## ANIMATOR NOTES
Camera pushes are the only continuous motion; every other tween is 0.2-0.5 s, ease-out, landing exactly on the trigger word's next syllable. No shake except the four marked hits, one per beat B2-B5 (10.72, 21.35, 29.77, 39.55); B1 has none. Chips never appear together. Beat 1 chip prop (small chip) is NOT an on-screen chip.
