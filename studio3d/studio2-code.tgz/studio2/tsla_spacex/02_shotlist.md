# TSLA x SPACEX - SHOT LIST (Director) - timed to vo_exact.json (speech 0.03-42.83 s, clip 42.97 s)
Rules obeyed: ONE mover per row (+ gentle camera push 1.00 -> 1.05 per shot), <= 3 characters, hard cuts only inside the 0.17 s VO gaps, no slow-mo, VO never stops (largest gap 0.17 s), title card is visible from frame 0.
Notation: `@word t` = trigger word with its exact start; the action starts on that frame. TS=TESLA, SX=SPACEX, BO=BOSS. SFX* = the beat's one bigger hit (all SFX >= 9 dB under the voice, low-passed 6 kHz, never on top of a stressed word: placed on the unstressed word after it or in the gap). 12 SFX total.
TITLE CARD: "TESLA x SPACEX?" (3 words) huge at y~420 from frame 0; shrinks to a small top pill at 4.5 s (0.3 s ease); grows back at 41.27 s ("So,") and holds to the end.

## HARD CUTS (all inside gaps)
3.25 | 5.40 | 7.96 | 10.03 | 12.12 | 13.88 | 15.62 | 18.01 | 20.38 | 22.33 | 24.00 | 26.20 | 27.92 | 30.40 | 36.78 | 39.20 | 41.06  (17 cuts; B4 is one continuous shot)

## SHOT TABLE
| time (s) | spoken | THE ONE FOCAL ACTION (trigger) | freezes / leaves | expression | SFX | text |
|---|---|---|---|---|---|---|
| **BEAT 1 - SET A "Track", Shot 1 wide (TS left, SX right, title card)** |||||||
| 0.03-0.60 | Tesla and | TS hops once, lands in P0 by 0.50 (`@Tesla 0.07`) | SX, card | grin | boing | card |
| 0.60-1.90 | SpaceX might | SX hops once, lands by 1.35 (`@SpaceX 0.745`) | TS | grin | - | card |
| 1.90-2.80 | become one company. | Both lean toward each other (`@become 2.145`) and bonk shoulders on `@company 2.795`, squash and settle | all | surprised O, then grin | bonk | card |
| 2.80-3.25 | (company.) | Hold, leaning together | all | grin | - | card |
| **Shot 2 tight TS (SX leaves)** |||||||
| 3.25-4.35 | Meet Tesla. | TS waves one hand (`@Tesla. 3.754`), TESLA tag visible | camera push only | smile | - | - |
| 4.35-5.40 | He makes cars. | TS honks: windshield bobs once (`@cars 4.754`); CARS sub-label pops on its tag; card shrinks to pill at 4.50 | - | proud | - | pill |
| **Shot 3 tight SX (TS leaves)** |||||||
| 5.40-6.70 | Meet SpaceX. | SX waves one hand (`@SpaceX. 5.904`), SPACEX tag visible | push only | smile | - | pill |
| 6.70-7.96 | He makes rockets. | Small exhaust puff under SX feet and ROCKETS sub-label pops (`@rockets 7.279`) | - | proud | - | pill |
| **Shot 4 wide (TS left, SX right)** |||||||
| 7.96-8.80 | They share one boss, | BO slides in from the right edge to centre (`@share 8.292`), lands `@boss 8.792`; TS and SX turn their heads to him | TS, SX (heads only) | BO calm, bots curious | whoomp (under "share") | - |
| 8.80-9.95 | Elon Musk. | BO tips one hand in a wave (`@Elon 9.267`); holds; BOSS tag visible | bots | BO smile | - | - |
| **BEAT 2 - SET A, shot 5 medium (BO left, bots right, bench far left)** |||||||
| 10.03-11.30 | Musk says it would be a | BO takes one step forward, chest out (`@says 10.435`) | bots | confident | - | - |
| 11.30-12.04 | good idea. | BO thumbs-up, held (`@good 11.335`) | all | big grin | ding at 11.95 | - |
| **Shot 6 wide (tape)** |||||||
| 12.12-12.79 | But he can't | BO strides toward the bots (`@But 12.240`); a yellow tape line zips across the floor in front of him (`@can't 12.490`) | bots | determined | - | - |
| 12.79-13.80 | join the talks. | BO bonks the tape, squashes, bounces back one step (`@join 12.790`) | bots, tape | dazed | bonk* (12.90) | - |
| **Shot 7 medium (BO + bench; bots frozen far right)** |||||||
| 13.88-14.56 | So he just sits | BO turns and trudges left (`@So 14.034`, `@just 14.259`) | bots | sheepish | - | - |
| 14.56-15.54 | on the bench. | BO plops onto the bench, bench bounces (`@bench 15.134`) | bots | slump, flat mouth | plop (15.20) | - |
| **Shot 8 tight bots (BO leaves frame)** |||||||
| 15.62-16.40 | Two special | Hold, bots stand side by side, push only (`@Two 15.750`) | all | curious | - | - |
| 16.40-17.03 | committees | One post with TWO blank paddles rises from the floor between them (`@committees 16.400`) | bots | curious | - | - |
| 17.03-17.53 | study | Paddles swing: left toward TS, right toward SX (`@study 17.025`) | bots | worry | - | - |
| 17.53-17.93 | it instead. | Both paddles flip to "MAYBE" (`@instead 17.525`) | bots | frown | - | MAYBE |
| **BEAT 3 - SET A (ribbon beat; ribbon is the only recurring prop)** |||||||
| 18.01-19.24 | Think of it like a | Wide: bots crouch in race pose, ribbon lying between them; hold, push | all | focused | - | - |
| 19.24-20.38 | three-legged race. | Bots lean forward, inner leg up (`@three-legged 19.242`); freeze on `@race 19.867` | ribbon | determined | whistle peep (19.95) | - |
| 20.38-21.43 | Nobody has | Cut tight on ribbon (bots off-frame). Hold | - | - | - | - |
| 21.43-22.33 | tied the knot yet. | Ribbon middle rises and loops (`@tied 21.429`), loop tightens and pops open (`@knot 21.804`), ribbon flops flat (`@yet 22.129`) | - | - | soft flop (22.20) | - |
| 22.33-23.60 | The rope is still on the | Wide: bots stand apart, heads look down at the ribbon (`@rope 22.622`) | ribbon | puzzled | - | - |
| 23.60-24.00 | ground. | TS prods the ribbon with a wheel, it wiggles once (`@ground 23.597`) | SX | puzzled | - | - |
| 24.00-24.46 | No | Cut: chip centre, bots small and frozen behind. Hold | all | shrug | - | - |
| 24.46-25.03 | price, | Chip NO PRICE drops in, squash (`@price 24.459`) | bots | shrug | - | NO PRICE |
| 25.03-25.73 | no plan, | Chip swaps to NO PLAN (`@plan 25.284`), old chip leaves | bots | shrug | - | NO PLAN |
| 25.73-26.12 | no date. | Chip swaps to NO DATE (`@date 25.984`) | bots | shrug | stamp* (26.05) | NO DATE |
| 26.20-26.69 | It's just | Cut: bots face each other. Hold | all | calm | - | - |
| 26.69-27.14 | talk, | TS speech bubble pops (`@talk 26.691`) | SX | chatty | - | BLAH |
| 27.14-27.59 | not a | SX bubble pops (`@not 27.141`), TS bubble stays | TS | chatty | - | BLAH |
| 27.59-27.84 | deal. | Both bubbles puff to nothing; bots shrug (`@deal 27.591`) | - | shrug | - | - |
| 27.92-28.83 | Musk says the | Cut wide: ribbon on floor, bots apart. Hold | all | calm | - | - |
| 28.83-29.46 | committees | MAYBE post rises between the bots (`@committees 28.830`) | bots | worry | - | MAYBE |
| 29.46-30.03 | may never | Paddles wobble (`@may 29.455`), start turning (`@never 29.755`) | bots | worry | - | MAYBE |
| 30.03-30.31 | agree. | Paddles turn their backs on each other (`@agree 30.030`); ribbon lifts, tries a knot, flops (30.25) | bots | frown | soft flop (30.25) | - |
| **BEAT 4 - SET B "High bar" (one continuous shot; TS only)** |||||||
| 30.40-30.85 | Then | Cut: tall bar on two posts, TS small at far left. Hold | - | calm | - | - |
| 30.85-32.08 | Tesla's owners would | TS trots to the bar (`@Tesla's 30.854`), stops under it (`@would 31.729`) | bar | eager | - | - |
| 32.08-32.89 | need to vote. | TS looks up (`@need 32.079`); chip pops in (`@vote 32.479`) | bar | worry | - | OWNERS VOTE |
| 32.89-33.72 | More than half | Chip swaps (`@More 32.891`); bar rises one notch (`@half 33.316`) | TS | worry | - | OVER HALF OF ALL |
| 33.72-34.49 | of all shares. | Bar rises a second notch (`@all 33.716`) | TS | wide eyes | - | OVER HALF OF ALL |
| 34.66-35.64 | Musk calls that | Chip leaves; TS steps back one step, still looking up (`@calls 35.094`) | bar | awed | - | - |
| 35.64-36.47 | quite a high | TS head tips further back (`@quite 35.644`) | bar | awed | - | - |
| 36.47-36.70 | hurdle. | TS tips over and sits on its bumper (`@hurdle 36.469`) | bar | dizzy | thump* (36.60) | - |
| **BEAT 5 - SET A, loop beat (BO on bench, ribbon on floor)** |||||||
| 36.78-37.51 | Anonymous | Cut: bots lean in and whisper behind cupped hands (`@Anonymous 36.938`) | ribbon | sly | - | - |
| 37.51-38.61 | sources say maybe | Whisper continues: their lean pulses once (`@sources 37.513`) | ribbon | sly | - | - |
| 38.61-39.11 | next year. | Chip pops over them (`@year 38.938`) | bots | unsure | - | 2027? |
| 39.20-40.01 | But nothing is | Cut: BO on bench joins bots in frame; chip leaves (`@nothing 39.531`) | - | blank | - | - |
| 40.01-40.98 | decided yet. | All three hold palms up in a shrug (`@decided 40.156`); ribbon visible on the floor | - | shrug | - | - |
| 41.06-41.27 | So, | Cut to frame-0 shot, bots in P0. Hold | - | grin | - | pill |
| 41.27-42.30 | could they really | Title card grows back from the pill (`@So 41.272`, 0.4 s) | bots | grin | - | card |
| 42.30-42.83 | become one? | Bots lean together almost touching (`@become 42.297`) | card | hopeful | - | card |
| 42.83-42.97 | (end) | Bots spring apart to P0 = frame 0 pose (0.14 s) | - | grin | boing | card |

## GAGS (setup -> hit -> callback; callback prop = the ribbon)
- B1 hop, hop, BONK shoulders -> callback the lean at the end (B5).  B2 thumbs-up -> tape BONK -> bench plop.  B3 ribbon fails to knot -> NO DATE stamp -> ribbon fails again.  B4 bar rises twice -> Tesla sits down.  B5 whisper -> shrug -> spring back to P0.
- SFX = exactly 12: boing 0.07, bonk 2.80, whoomp 8.30 | ding 11.95, bonk* 12.90, plop 15.20 | peep 19.95, flop 22.20, stamp* 26.05, flop 30.25 | thump* 36.60 | boing 42.97. Beat 1 and 4-5 have one hit each; the big hits are bonk* / stamp* / thump*.

## SET + CAST SHEET
- **Set A "Track"**: cream wall (252,226,186) + one tan floor band (214,170,126) + one thin floor line + one white START LINE on the floor; bench far left (only seen in B2 shots 6-7 and B5); NO shelves. Used by B1, B2, B3, B5.
- **Set B "High bar"**: same wall and floor, no bench, no start line; two posts and one bar (flat red/white). Used by B4 only. (Max 2 sets.)
- Camera: one gentle push per shot (1.00 -> 1.05), no pans; frame 0 camera = last frame camera (scale 1.00).
- Safe area y 330-1520; feet ~y 1250. Sizes: TS and SX >= 400 px tall in wide shots (>= 340 rule), tight shots 640 px; BO ~480 px; bar tall enough that TS reaches the lower third.
- **Characters** (name tags via `tagtile("TESLA",...)`, `subtile("CARS",...)` in chars.py):
  - TESLA: car-bot. New `tesla_cv` built from `bram_tile` tinted red (`tint_hue`) + two `wheel_tile` feet + a visor stripe. Tag TESLA, sub CARS.
  - SPACEX: rocket-bot. New `rocket_cv`: `beam_tile` body tinted white/grey with a nose-cone hat (`beam_cv(hat=True)` code path) + two fins; exhaust puff via `puff()`. Tag SPACEX, sub ROCKETS.
  - BOSS: ORIGINAL plain figure, new `boss_cv`: `bram_tile` recoloured grey with a plain tie; no hair, glasses or any likeness. Tag BOSS. Needs arms (al/ar) for thumbs-up and shrug.
- **Props (6)**: ribbon (long straight strip, `paper_tile` tint), bench (`bench_tile`), yellow tape line (flat rect), post with two paddles (flat; MAYBE text via `ptxt`), high bar + posts, speech bubbles (`pill`). Chips via `price_chip` / `pill`; title card/pill via `pill`.
- **Poses, easiest first (fallback in brackets)**: 1 stand/grin/hop (squash-stretch only). 2 wave via al/ar arms. 3 look at / turn head (eyes lookl/lookr). 4 shrug via arms up [arms down + flat mouth]. 5 thumbs-up via `thumb` flag [wave arm]. 6 lean toward each other (rotate +-8 deg + shift) [slide together]. 7 whisper hand (cupped arm up) [lean only]. 8 BO plop-sit on bench (squash + drop) [stand beside bench]. 9 TS tips back and sits on bumper (rot -60 + drop) [rotate 90 and fade shadow]. 10 ribbon knot loop (3 keyframes: line, loop ring, flat) [ribbon lifts and drops, no loop].
- **Hardest**: ribbon loop and flop (B3), BO bonk-bounce on tape, TS tip-over sit. Each has the fallback above.
