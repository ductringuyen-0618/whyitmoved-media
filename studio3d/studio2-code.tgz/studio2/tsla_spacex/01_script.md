# TSLA x SPACEX - SCRIPT (wall-to-wall VO, 5 beats)

## 1. THE ONE IDEA + THE ONE METAPHOR
**Idea:** Tesla and SpaceX, two companies that share one boss, are only TALKING about becoming one company: two special committees are studying it, there is no price, plan or date, and Tesla's owners would still have to vote.
**Metaphor: the three-legged race.** Two racers, one coach, and the ribbon that would tie their legs together is still lying on the ground (= "talk, not a deal"). The vote is a high-jump bar.
**Cast (max 3 on screen ever):** TESLA (car-bot, sub-label CARS), SPACEX (rocket-bot, sub-label ROCKETS), BOSS (original plain figure, tag BOSS, NO likeness; he only stands for "the one boss both companies share"). No real person is drawn. No logos.
**Recurring prop (callback object):** ONE ribbon (the would-be leg tie). It fails to tie in B3 (knot flops twice) and lies untouched in the loop.
**Topic-first hook:** title card "TESLA x SPACEX?" visible from frame 0 and the first words are "Tesla and SpaceX might become one company." Card shrinks to a small pill at 4.5 s, grows back at 41.3 s on "So," and ends in the exact frame-0 pose (loop).

## 2. VOICEOVER (20 lines, 126 words, longest sentence 8 words; Kokoro am_michael, speed 0.88)
Files: `vo.wav` (24 kHz mono), `vo_timing.json` (per line + estimated words), `vo_exact.json` (exact word starts from Kokoro phoneme durations). Re-run: `VSP=0.88 python3 vo_measure.py && python3 exact_timing.py`. Lines are butted with only the natural 0.17 s pad; speed 0.88 was chosen (1.0 gave only 36.8 s) for a calm friend-telling-a-story pace.

| # | Line | Start | End | Gap before |
|---|------|------|-----|-----|
| 1 | Tesla and SpaceX might become one company. | 0.03 | 3.17 | - |
| 2 | Meet Tesla. He makes cars. | 3.34 | 5.32 | 0.17 |
| 3 | Meet SpaceX. He makes rockets. | 5.49 | 7.87 | 0.17 |
| 4 | They share one boss, Elon Musk. | 8.04 | 9.95 | 0.17 |
| 5 | Musk says it would be a good idea. | 10.12 | 12.04 | 0.17 |
| 6 | But he can't join the talks. | 12.21 | 13.80 | 0.17 |
| 7 | So he just sits on the bench. | 13.97 | 15.54 | 0.17 |
| 8 | Two special committees study it instead. | 15.71 | 17.93 | 0.17 |
| 9 | Think of it like a three-legged race. | 18.10 | 20.30 | 0.17 |
| 10 | Nobody has tied the knot yet. | 20.47 | 22.25 | 0.17 |
| 11 | The rope is still on the ground. | 22.42 | 23.92 | 0.17 |
| 12 | No price, no plan, no date. | 24.09 | 26.12 | 0.17 |
| 13 | It's just talk, not a deal. | 26.29 | 27.84 | 0.17 |
| 14 | Musk says the committees may never agree. | 28.01 | 30.31 | 0.17 |
| 15 | Then Tesla's owners would need to vote. | 30.48 | 32.63 | 0.17 |
| 16 | More than half of all shares. | 32.80 | 34.49 | 0.17 |
| 17 | Musk calls that quite a high hurdle. | 34.66 | 36.70 | 0.17 |
| 18 | Anonymous sources say maybe next year. | 36.87 | 39.11 | 0.17 |
| 19 | But nothing is decided yet. | 39.28 | 40.98 | 0.17 |
| 20 | So, could they really become one? | 41.15 | 42.83 | 0.17 |

**TOTAL speech 42.83 s (WAV 42.97 s), 126 words, largest gap 0.17 s (all gaps equal; silence <= 0.4 s everywhere).** Loop: line 20 "...really become one?" flows straight into line 1 "Tesla and SpaceX might become one company." The last frame (42.97) = frame 0.

## 3. THE 5 BEATS (one scene, one focal action at a time, one gag: setup -> hit -> callback)

### BEAT 1 - "Two racers, one boss" (L1-4, 0.03-9.95 s, Set A)
Visual: TESLA and SPACEX stand on the start line under the big title card. They hop on their own names, lean together and bump shoulders on "company"; each gets a close-up and a sub-label; then BOSS slides in between them.
Gag: SETUP the two bots hop one at a time, politely (L1-3). HIT they lean in and bonk shoulders (L1 "company") and BOSS arrives to a doubled "wave" from both bots (L4). CALLBACK the bump returns in the loop ending.
Text: title card/pill "TESLA x SPACEX?"; sub-labels CARS, ROCKETS (on the tags).

### BEAT 2 - "The boss on the bench" (L5-8, 10.12-17.93 s, Set A)
Visual: BOSS gives a thumbs-up ("a good idea"), walks toward the bots, and bonks into a yellow tape line that drops in front of him ("can't join"); he trudges to the bench and plops down. Then a single post with two paddles rises between the bots; the paddles swing to point at each bot and flip to "MAYBE".
Gag: SETUP thumbs-up (L5). HIT tape bonk (L6). CALLBACK he sits meekly on the bench while the two "MAYBE" paddles take over (L7-8).
Text: "MAYBE" (on the paddles). Facts: Musk quote F1, recusal F2, committees study F1.

### BEAT 3 - "The rope on the ground" (L9-14, 18.10-30.31 s, Set A)
Visual: the bots crouch in race pose with a long ribbon between them. The ribbon lifts to tie a knot and flops (twice, L10 and L14); chips NO PRICE / NO PLAN / NO DATE appear one at a time; talk bubbles pop and vanish; the paddles turn away from each other on "agree".
Gag: SETUP ribbon tries a knot, flops (L10). HIT three chips knocked out one by one (L12), bubbles that poof (L13). CALLBACK the ribbon tries again and flops again as the paddles turn their backs (L14). Hardest beat, 12 s: kept as ONE prop (the ribbon) driving every action.
Text: NO PRICE, NO PLAN, NO DATE (one at a time), BLAH. Facts: F4 (no terms, "may never", "just talk").

### BEAT 4 - "The high bar" (L15-17, 30.48-36.70 s, Set B)
Visual: TESLA trots up to a high-jump bar alone. A chip says OWNERS VOTE, then OVER HALF OF ALL; the bar rises two notches with "half" and "all"; TESLA tips its head back and sits down on its bumper on "hurdle". (A reaction gag only: no jump is shown, so no outcome is implied.)
Gag: SETUP bar and chip (L15). HIT bar rises twice (L16). CALLBACK Tesla's head tips back and plops (L17).
Text: OWNERS VOTE; OVER HALF OF ALL. Facts: F8 (> 50% of ALL outstanding shares; Musk: "quite a high hurdle").

### BEAT 5 - "Just a whisper" (L18-20, 36.87-42.97 s, Set A = frame-0 set)
Visual: the bots lean in and whisper cupped-hand to each other ("anonymous"); a small chip 2027? pops; BOSS on the bench shrugs; then cut to the exact frame-0 shot, title card grows back, the bots lean together on "become one?" and spring back to the start pose.
Gag: SETUP whisper (L18). HIT both shrug, palms up, ribbon still on the ground (L19). CALLBACK the bump from B1 almost happens again, then they spring apart to P0 = the loop (L20).
Text: 2027? (hedged by the VO); title card returns. Facts: F7 (Bloomberg, anonymous sources, H1 2027), F4.

## 4. FACT AND HEDGE CHECK (vs FACTS_TSLA_SPACEX)
- "Musk says it would be a good idea": F1 quote ("I think it would be a good idea"). Named only to report what he said; no invented dialogue.
- "He can't join the talks": F2 (recused, "conflicted party"). "Two special committees study it": F1 (independent directors, study).
- "No price, no plan, no date", "just talk, not a deal", "may never agree": F4 (no terms found as of Nov 3; Musk: "may never"). Framed as talk, not negotiation.
- "Tesla's owners would need to vote", "More than half of all shares", "quite a high hurdle": F8 (> 50% of ALL outstanding shares; Musk quote).
- "Anonymous sources say maybe next year": F7 (Bloomberg, anonymous, H1 2027, single source). Conflict noted: Barclays/Reuters said possibly before the Dec meeting; the line stays vague on purpose.
- "They share one boss": Musk runs both (summary + F13). BOSS is a generic figure; the VO names Musk only on the quoted lines.
- Dropped on purpose: all stock moves and closes (+3.41%, +5.21%) so there is no cause claim; SpaceX-buys-Tesla direction; the $3.5T size; Alphabet; Barclays.
- Wording avoided: "cartoon", "not advice", any price/prediction, "deal agreed", "negotiating".

## 5. NOTES FOR THE DIRECTOR
- Time every action to `vo_exact.json` word starts; hard cuts only in the 0.17 s gaps (see 02_shotlist.md).
- Pace is calm: about 2.9 words/s. One mover per row; the ribbon is the only recurring prop.

## V2 FACT FIXES (QA Nov 3) - lines changed, beats re-pinned (build/v2/vo_exact.json, speech 0.03-43.90 s, WAV 44.04 s, every gap 0.17 s)
- L5 "Musk said it would be a good idea." (small shrug-thumb, hedge) / L6 "But the committees decide." (two hand-held MAYBE signs) / L7 "He runs both, so he stays out of the talks." (BOSS behind a rope + KEEP OUT sign, neutral face; bench gag removed) / L8 "Two special committees study it."
- L12 "No agreed price, terms or deal yet." chips NO PRICE / NO TERMS / NO DEAL; L13 "So far, it's just talk."
- L14 "Reuters says they may never agree." ('may never' is Reuters' wording, never Musk's). L18 "Anonymous sources say twenty twenty-seven." chip 2027?
- Beat 3 ribbon is now tied between TESLA's inner wheel and SPACEX's inner foot; the knot forms and fails between the legs (L10), fails again on the floor (L14). Speech bubbles removed.
