"""Exact word times from Kokoro's own phoneme durations (same audio as vo_v2.wav).
Rebuilds the vo_measure.py timeline and maps phoneme groups to script words. Writes vo_exact.json"""
import sys, os, json, hashlib
sys.dont_write_bytecode=True
sys.path.insert(0,'/home/claude/studio2/pilot2/build')
import numpy as np, soundfile as sf
import stockshort_B3 as S
from kokoro_onnx import Kokoro, timings as ktimings
K=Kokoro('/tmp/claude-0/kokoro_dur.onnx',os.path.expanduser('~/.cache/stockshort/voices-v1.0.bin'))
SR=24000; EXTRA=0.08
LINES=json.load(open('/home/claude/studio2/tsla_spacex/lines.json'))
cache='/home/claude/studio2/tsla_spacex/.vcache/'
out=[]; t=0.0
for n,text in LINES:
    voice,phon,batches=K._prepare(text,"am_michael",0.88,'en-us',False,0.25,0.1)
    assert len(batches)==1
    audio,edges=K._create_batch(batches[0][0],voice,0.88,True,0.0)
    tm=ktimings(K.tokenizer.known(batches[0][0]),edges,SR)
    ck=cache+hashlib.md5(f"{text}|am_michael|0.88".encode()).hexdigest()+".wav"
    a,sr=sf.read(ck,dtype='float32'); assert sr==SR and len(a)==len(audio),(len(a),len(audio))
    s0,s1=S.speech_bounds(a,SR)
    lead=max(0,int((s0-.03)*SR))/SR
    end=int((s1+.06)*SR); piece_len=(end-max(0,int((s0-.03)*SR)))/SR
    flat=[p for p in tm if p.phoneme not in ' .?!,;:']
    toks=text.split(); per=[]  # per token: list of group char-counts
    for tk in toks:
        ph=K.tokenizer.phonemize(tk,'en-us')
        per.append([len([c for c in g if c not in '.?!,;:']) for g in ph.split()])
    tot_exp=sum(sum(x) for x in per); tot=len(flat)
    scale=tot/tot_exp
    pos=0.0; L=lambda x: round(t+x-lead,3)
    for tk,gs in zip(toks,per):
        parts=[];p0=pos
        for c in gs:
            i=min(len(flat)-1,int(round(pos*scale))); parts.append(flat[i].start); pos+=c
        j=min(len(flat)-1,max(0,int(round(pos*scale))-1))
        out.append({"line":n,"word":tk,"start":L(parts[0]),"end":L(flat[j].end),"parts":[L(x) for x in parts],"exp_chars":sum(gs),"act_total":tot,"exp_total":tot_exp})
    t+=piece_len+EXTRA
json.dump(out,open('/home/claude/studio2/tsla_spacex/vo_exact.json','w'),indent=1)
old=json.load(open('/home/claude/studio2/tsla_spacex/vo_timing.json'))['words']
print("word, exact start, old estimate, diff")
mx=0
for e,o in zip(out,old):
    d=e['start']-o['start']; mx=max(mx,abs(d))
    print(f"{e['line']:2d} {e['word']:10s} {e['start']:7.3f} {o['start']:7.3f} {d:+.3f} {e['parts'] if len(e['parts'])>1 else ''}")
print("max abs diff",mx)
