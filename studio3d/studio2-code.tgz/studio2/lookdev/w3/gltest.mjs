import { createRequire } from 'module';
const require = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = require('playwright');
const b = await chromium.launch({ args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--enable-webgl'] });
const p = await b.newPage({viewport:{width:540,height:960}});
await p.setContent('<canvas id=c></canvas>');
console.log(await p.evaluate(()=>{const g=document.getElementById('c').getContext('webgl2');if(!g)return 'no webgl2';const e=g.getExtension('WEBGL_debug_renderer_info');return g.getParameter(e.UNMASKED_RENDERER_WEBGL)+' maxtex '+g.getParameter(g.MAX_TEXTURE_SIZE)}));
await b.close();
