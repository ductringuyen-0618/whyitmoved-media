import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const Q = new URLSearchParams(location.search);
const W = +(Q.get('w') || 1080), H = +(Q.get('h') || 1920);
const TL = await (await fetch('./timeline.json')).json();

// ---------------------------------------------------------------- helpers
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, k) => a + (b - a) * k;
const seg = (t, a, b) => clamp((t - a) / (b - a));
const smooth = x => x * x * (3 - 2 * x);
const eOut = x => 1 - Math.pow(1 - x, 3);
const eIn = x => x * x * x;
const eIO = x => x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
const eBack = (x, s = 1.9) => 1 + (s + 1) * Math.pow(x - 1, 3) + s * Math.pow(x - 1, 2);
const spring = (dt, f, d) => dt < 0 ? 0 : Math.exp(-d * dt) * Math.cos(2 * Math.PI * f * dt);
const rng = s => () => { s |= 0; s = s + 0x6D2B79F5 | 0; let t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const hash = n => { const r = rng(n * 9973 + 17); r(); return r(); };

// ---------------------------------------------------------------- renderer / scene
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(1); renderer.setSize(W, H);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.VSMShadowMap;
renderer.toneMapping = THREE.NeutralToneMapping; renderer.toneMappingExposure = 1.05;
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const pm = new THREE.PMREMGenerator(renderer);
scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
scene.environmentIntensity = 0.5;
scene.fog = new THREE.Fog(0xcfe6fb, 20, 80);
const camera = new THREE.PerspectiveCamera(30, W / H, 0.5, 400);
scene.add(camera);

// sky dome with day/storm colours
const skyU = { topA: { value: new THREE.Color('#4f9cf0') }, botA: { value: new THREE.Color('#cfe6fb') }, topB: { value: new THREE.Color('#3b4468') }, botB: { value: new THREE.Color('#8f9bb8') }, mixv: { value: 0 } };
const sky = new THREE.Mesh(new THREE.SphereGeometry(200, 32, 16), new THREE.ShaderMaterial({
  uniforms: skyU, side: THREE.BackSide, depthWrite: false, fog: false,
  vertexShader: 'varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }',
  fragmentShader: `uniform vec3 topA,botA,topB,botB; uniform float mixv; varying vec3 vP;
    void main(){ float h = clamp(normalize(vP).y*2.4+0.05,0.,1.); h = smoothstep(0.,1.,h);
      vec3 a = mix(botA,topA,h), b = mix(botB,topB,h); gl_FragColor = vec4(mix(a,b,mixv),1.); }`
}));
sky.renderOrder = -10; scene.add(sky);

// lights
const hemi = new THREE.HemisphereLight(0xd6e8ff, 0xf3dcc0, 1.0); scene.add(hemi);
const key = new THREE.DirectionalLight(0xfff1dc, 3.0);
key.position.set(-5, 12, 9); key.castShadow = true;
key.shadow.mapSize.set(2048, 2048); key.shadow.radius = 7; key.shadow.blurSamples = 20; key.shadow.bias = -0.0004;
Object.assign(key.shadow.camera, { left: -9, right: 9, top: 9, bottom: -9, near: 1, far: 50 });
scene.add(key); scene.add(key.target);
const rim = new THREE.DirectionalLight(0xa8c8ff, 1.4); rim.position.set(6, 5, -9); scene.add(rim);
const spot = new THREE.SpotLight(0xfff0d8, 130, 70, .95, 1, 1.2); spot.position.set(0, 16, 8); scene.add(spot); scene.add(spot.target);
const bounce = new THREE.PointLight(0xffe2bd, 14, 14, 1.6); scene.add(bounce);

// ---------------------------------------------------------------- materials
const M = (c, o = {}) => new THREE.MeshPhysicalMaterial(Object.assign({ color: c, roughness: .45, metalness: 0 }, o));
const mBody = M('#3b7bf0', { roughness: .32, clearcoat: .7, clearcoatRoughness: .22, sheen: .4, sheenColor: new THREE.Color('#9fc4ff'), sheenRoughness: .5 });
const mPin = M('#d3dae8', { roughness: .35, metalness: .25 });
const mLt = M('#9cc6ff', { roughness: .4, clearcoat: .4 });
const mHand = M('#d6e8ff', { roughness: .35, clearcoat: .5 });
const mWhite = M('#ffffff', { roughness: .18, clearcoat: 1, clearcoatRoughness: .1 });
const mInk = M('#0e1730', { roughness: .25, clearcoat: .6 });
const mMouth = M('#7c2230', { roughness: .5 });
const mGold = M('#ffd13b', { roughness: .28, metalness: .35, emissive: '#ff9f00', emissiveIntensity: .22, clearcoat: .6 });

function addShadow(o, cast = true, recv = true) { o.traverse(c => { if (c.isMesh) { c.castShadow = cast; c.receiveShadow = recv; } }); return o; }
function mesh(geo, mat, x = 0, y = 0, z = 0) { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); return m; }
function tube(pts, r, mat) { return new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p))), 24, r, 10, false), mat); }
function starGeo(r, depth = .14) {
  const s = new THREE.Shape();
  for (let i = 0; i < 10; i++) { const rr = i % 2 ? r * .47 : r, a = Math.PI / 2 + i * Math.PI / 5; (i ? s.lineTo : s.moveTo).call(s, Math.cos(a) * rr, Math.sin(a) * rr); }
  const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: true, bevelThickness: .05, bevelSize: .06, bevelSegments: 4, curveSegments: 2 });
  g.translate(0, 0, -depth / 2); return g;
}

// ---------------------------------------------------------------- floor, puddle, sky bokeh
function radialTex(stops, size = 512) {
  const c = document.createElement('canvas'); c.width = c.height = size; const g = c.getContext('2d');
  const gr = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  stops.forEach(([o, col]) => gr.addColorStop(o, col)); g.fillStyle = gr; g.fillRect(0, 0, size, size);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
const floorTex = radialTex([[0, '#f8e6c9'], [.35, '#f1d8b4'], [.75, '#e0c093'], [1, '#d2ae7d']], 1024);
const floor = new THREE.Mesh(new THREE.CircleGeometry(120, 64), new THREE.MeshStandardMaterial({ map: floorTex, roughness: .78, metalness: 0 }));
floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
// stage: soft raised disc edge to give a diorama feel is skipped; fog does the horizon.

const puddle = new THREE.Group();
const pMat = M('#6fb4f6', { roughness: .06, clearcoat: 1, clearcoatRoughness: .03, transparent: true, opacity: .9, envMapIntensity: 2.2 });
const pRim = M('#b9dcfb', { roughness: .2, transparent: true, opacity: .55 });
const pD = new THREE.Mesh(new THREE.CircleGeometry(1, 64), pMat); pD.rotation.x = -Math.PI / 2; pD.position.y = .018;
const pR = new THREE.Mesh(new THREE.CircleGeometry(1.07, 64), pRim); pR.rotation.x = -Math.PI / 2; pR.position.y = .01;
pD.receiveShadow = true; puddle.add(pR, pD); scene.add(puddle);
const PUD = { x: -0.35, z: 0.1 };

const bokehTex = radialTex([[0, 'rgba(255,255,255,.9)'], [.55, 'rgba(255,255,255,.55)'], [.9, 'rgba(255,255,255,.18)'], [1, 'rgba(255,255,255,0)']], 128);
const bokeh = [];
{ const r = rng(5); for (let i = 0; i < 22; i++) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: bokehTex, transparent: true, opacity: .2, depthWrite: false, fog: false, blending: THREE.AdditiveBlending })); const sc = 3 + r() * 7; s.scale.set(sc, sc, 1); s.userData = { x: -45 + r() * 90, y: 4 + r() * 32, z: -70 - r() * 20, ph: r() * 6.28, base: .1 + r() * .16 }; s.renderOrder = -5; scene.add(s); bokeh.push(s); } }

// soft far hills for depth (blurred silhouettes, fogged)
{ const hillMat = new THREE.MeshBasicMaterial({ color: '#b7cbe3', fog: true, transparent: true, opacity: .75, depthWrite: false });
  for (let i = 0; i < 7; i++) { const g = new THREE.SphereGeometry(1, 24, 12); const h = new THREE.Mesh(g, hillMat); const r = hash(i + 40); h.scale.set(14 + r * 12, 3 + r * 4, 6); h.position.set(-60 + i * 20 + r * 6, -1.2, -80 - r * 12); scene.add(h); } }

// contact shadow blob (fake AO) under characters
const blobTex = radialTex([[0, 'rgba(10,12,40,.62)'], [.45, 'rgba(10,12,40,.32)'], [1, 'rgba(10,12,40,0)']], 256);
function blob() { const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 })); m.rotation.x = -Math.PI / 2; m.position.y = .03; m.renderOrder = 2; scene.add(m); return m; }
const botBlob = blob(), cardBlob = blob();

// vignette + grade overlay attached to camera
{ const t = radialTex([[0, 'rgba(8,10,30,0)'], [.45, 'rgba(8,10,30,0)'], [.7, 'rgba(8,10,30,.05)'], [.85, 'rgba(8,10,30,.14)'], [1, 'rgba(8,10,30,.26)']], 512);
  const hh = 2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * 1, ww = hh * camera.aspect;
  const v = new THREE.Mesh(new THREE.PlaneGeometry(ww, hh), new THREE.MeshBasicMaterial({ map: t, transparent: true, depthTest: false, depthWrite: false, fog: false }));
  v.scale.set(1, 1, 1); v.position.z = -1; v.renderOrder = 999; camera.add(v); }

// ---------------------------------------------------------------- INTEL
function makeBot() {
  const root = new THREE.Group(), sq = new THREE.Group(); root.add(sq);
  const B = new THREE.Group(); sq.add(B);
  const body = mesh(new RoundedBoxGeometry(2.2, 2.2, 1.3, 8, .55), mBody); B.add(body);
  const pin = (w, h, x, y) => B.add(mesh(new RoundedBoxGeometry(w, h, .22, 3, .07), mPin, x, y, 0));
  [-.72, .72].forEach(x => { pin(.28, .44, x, 1.1 + .06); pin(.28, .44, x, -1.1 - .06); });
  [-.72, 0, .72].forEach(x => pin(.28, .44, x, -1.1 - .06));
  [-.62, .0, .62].forEach(y => { pin(.44, .28, -1.1 - .06, y); pin(.44, .28, 1.1 + .06, y); });
  // antenna
  const ant = new THREE.Group(); ant.position.set(0, 1.08, 0); B.add(ant);
  ant.add(mesh(new THREE.CapsuleGeometry(.1, .5, 6, 12), mLt, 0, .38, 0));
  ant.add(mesh(new RoundedBoxGeometry(.95, .34, .34, 5, .12), mLt, 0, .84, 0));
  ant.add(mesh(new RoundedBoxGeometry(.6, .06, .12, 2, .03), mWhite, -.08, .93, .13));
  // name tag
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 160; const g = cv.getContext('2d');
  g.font = '900 118px Inter'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#0e1730'; g.fillText('INTEL', 276, 86);
  const tt = new THREE.CanvasTexture(cv); tt.colorSpace = THREE.SRGBColorSpace; tt.anisotropy = 8;
  B.add(mesh(new RoundedBoxGeometry(1.8, .6, .1, 4, .12), mWhite, 0, .6, .66));
  B.add(mesh(new RoundedBoxGeometry(.24, .6, .12, 3, .1), M('#2450b8', { roughness: .4 }), -.78, .6, .67));
  const tagTxt = new THREE.Mesh(new THREE.PlaneGeometry(1.7, .53), new THREE.MeshBasicMaterial({ map: tt, transparent: true, toneMapped: false })); tagTxt.position.set(.06, .6, .72); B.add(tagTxt);
  // face
  const face = new THREE.Group(); face.position.set(0, 0, .66); B.add(face);
  const eyes = [];
  for (const sx of [-1, 1]) {
    const e = new THREE.Group(); e.position.set(sx * .43, -.2, 0); face.add(e);
    const scl = mesh(new THREE.SphereGeometry(.28, 32, 24), mWhite); scl.scale.set(1, 1.1, .5); e.add(scl);
    const pup = new THREE.Group(); e.add(pup);
    const p = mesh(new THREE.SphereGeometry(.125, 24, 16), mInk, 0, 0, .1); p.scale.set(1, 1.15, .45); pup.add(p);
    pup.add(mesh(new THREE.SphereGeometry(.045, 12, 8), new THREE.MeshBasicMaterial({ color: '#fff' }), .04, .06, .17));
    // squeezed > <
    const sqz = new THREE.Group(); sqz.visible = false; e.add(sqz);
    for (const s2 of [-1, 1]) { const b = mesh(new RoundedBoxGeometry(.34, .09, .08, 2, .04), mInk, -sx * .0 + 0, s2 * .09, .08); b.rotation.z = s2 * sx * -.55; b.position.x = -sx * .05 * 0; sqz.add(b); }
    // X
    const xx = new THREE.Group(); xx.visible = false; e.add(xx);
    for (const a of [Math.PI / 4, -Math.PI / 4]) { const b = mesh(new RoundedBoxGeometry(.6, .12, .08, 2, .05), mInk, 0, 0, .06); b.rotation.z = a; xx.add(b); }
    const brow = mesh(new RoundedBoxGeometry(.46, .095, .08, 2, .04), mInk, 0, .42, .04); e.add(brow);
    eyes.push({ g: e, scl, pup, sqz, xx, brow, sx });
  }
  // mouths
  const mouths = {};
  const addM = (k, o) => { o.visible = false; face.add(o); mouths[k] = o; };
  addM('smile', tube([[-.3, -.58, 0], [-.15, -.72, 0], [0, -.76, 0], [.15, -.72, 0], [.3, -.58, 0]], .05, mInk));
  addM('grin', (() => { const gp = new THREE.Group(); const s = new THREE.Shape(); s.moveTo(-.28, -.6); s.lineTo(.28, -.6); s.absarc(0, -.6, .28, 0, Math.PI, true); const sh = new THREE.Shape(); sh.absarc(0, 0, .28, Math.PI, 2 * Math.PI, false); const m = new THREE.Mesh(new THREE.ShapeGeometry(sh, 24), mMouth); m.position.set(0, -.6, .02); gp.add(m); return gp; })());
  addM('o', (() => { const m = mesh(new THREE.SphereGeometry(.17, 24, 16), mMouth, 0, -.68, .0); m.scale.set(.85, 1.1, .35); return m; })());
  addM('open', (() => { const gp = new THREE.Group(); const m = mesh(new THREE.SphereGeometry(.27, 28, 18), mMouth, 0, -.66, 0); m.scale.set(1.05, 1.15, .35); gp.add(m); const t = mesh(new THREE.SphereGeometry(.15, 18, 12), M('#ee6f86', { roughness: .5 }), 0, -.79, .02); t.scale.set(1.2, .6, .4); gp.add(t); return gp; })());
  addM('wob', tube([[-.34, -.68, 0], [-.21, -.6, 0], [-.07, -.74, 0], [.07, -.6, 0], [.21, -.74, 0], [.34, -.64, 0]], .045, mInk));
  addM('sad', tube([[-.3, -.8, 0], [-.15, -.68, 0], [0, -.64, 0], [.15, -.68, 0], [.3, -.8, 0]], .05, mInk));
  // sweat drop
  const sweat = new THREE.Group(); sweat.position.set(.9, .72, .62); B.add(sweat);
  const sm = M('#8fd6ff', { roughness: .05, clearcoat: 1, transparent: true, opacity: .92 });
  sweat.add(mesh(new THREE.SphereGeometry(.13, 16, 12), sm, 0, 0, 0)); const cone = mesh(new THREE.ConeGeometry(.12, .26, 16), sm, 0, .2, 0); sweat.add(cone); sweat.visible = false;
  // arms
  const arms = [];
  for (const sx of [-1, 1]) {
    const sh = new THREE.Group(); sh.position.set(sx * 1.2, .05, 0); B.add(sh);
    sh.add(mesh(new THREE.CapsuleGeometry(.13, .5, 6, 12), mLt, 0, -.38, 0));
    const hand = new THREE.Group(); hand.position.set(0, -.88, 0); sh.add(hand); hand.add(mesh(new THREE.SphereGeometry(.27, 24, 16), mHand));
    sh.add(mesh(new THREE.SphereGeometry(.17, 16, 12), mLt));
    arms.push({ sh, hand, sx });
  }
  addShadow(root);
  return { root, sq, B, ant, eyes, mouths, sweat, arms, face, tagTxt };
}
const bot = makeBot(); scene.add(bot.root);

function makeCard() {
  const g = new THREE.Group();
  g.add(mesh(new RoundedBoxGeometry(.96, 1.2, .07, 3, .05), M('#fbf8ee', { roughness: .5 })));
  g.add(mesh(new RoundedBoxGeometry(.96, .22, .08, 3, .04), M('#3d7be8', { roughness: .4 }), 0, .49, .004));
  const st = mesh(starGeo(.3, .06), mGold, 0, .06, .06); g.add(st);
  [-.3, -.42].forEach((y, i) => g.add(mesh(new RoundedBoxGeometry(.64 - i * .16, .05, .02, 2, .015), M('#aab4c6'), -.1 - i * .08, y - .0, .045)));
  return addShadow(g);
}
const cardHeld = makeCard(); bot.arms[1].hand.add(cardHeld); cardHeld.position.set(.2, .15, .28); cardHeld.rotation.set(-.15, -.25, -.12); cardHeld.scale.setScalar(.85);
const cardFly = makeCard(); cardFly.scale.setScalar(.85); cardFly.visible = false; scene.add(cardFly);

const stars = []; for (let i = 0; i < 3; i++) { const s = new THREE.Mesh(starGeo(.22, .1), mGold); s.castShadow = true; s.visible = false; scene.add(s); stars.push(s); }

// ---------------------------------------------------------------- storm cloud
function makeCloud() {
  const root = new THREE.Group(), sq = new THREE.Group(); root.add(sq);
  const mc = M('#7f87b6', { roughness: .85, sheen: .7, sheenColor: new THREE.Color('#b6bff0'), sheenRoughness: .6 });
  const mcD = M('#626a9a', { roughness: .9 });
  const puffs = [[0, 0, 0, 1.1], [-1.05, -.2, .05, .8], [1.05, -.15, 0, .85], [-.5, .65, -.05, .75], [.55, .7, -.1, .7], [1.75, -.35, 0, .5], [-1.75, -.35, 0, .52], [0, -.4, .45, .85], [-.9, -.55, .35, .55], [.9, -.5, .35, .6]];
  const pg = new THREE.Group(); pg.scale.set(1, 1, .62); sq.add(pg);
  puffs.forEach(([x, y, z, r], i) => pg.add(mesh(new THREE.SphereGeometry(r, 32, 24), i % 3 === 2 ? mcD : mc, x, y, z)));
  const face = new THREE.Group(); face.position.set(0, -.05, .86); sq.add(face);
  const E = [];
  for (const sx of [-1, 1]) {
    const e = new THREE.Group(); e.position.set(sx * .42, .05, 0); face.add(e);
    const s = mesh(new THREE.SphereGeometry(.22, 24, 16), mWhite); s.scale.set(1, 1.05, .5); e.add(s);
    e.add(mesh(new THREE.SphereGeometry(.09, 16, 12), mInk, sx * -.03, -.02, .08));
    const lid = mesh(new RoundedBoxGeometry(.58, .3, .1, 2, .04), mc, 0, .27, .06); lid.rotation.z = sx * .42; e.add(lid);
    const brow = mesh(new RoundedBoxGeometry(.5, .1, .09, 2, .04), mInk, 0, .43, .05); brow.rotation.z = sx * .42; e.add(brow);
    E.push({ e, lid, brow, sx });
  }
  const mouth = tube([[-.32, -.38, 0], [-.1, -.5, 0], [.12, -.46, 0], [.36, -.28, 0]], .05, mInk); face.add(mouth);
  const laugh = mesh(new THREE.SphereGeometry(.28, 24, 16), mMouth, 0, -.45, 0); laugh.scale.set(1.3, .8, .3); laugh.visible = false; face.add(laugh);
  addShadow(root);
  // lightning
  const bs = new THREE.Shape(); const pts = [[-.2, 0], [.25, 0], [.02, -1.4], [.4, -1.4], [-.35, -3.2], [-.1, -1.9], [-.42, -1.9]]; bs.moveTo(...pts[0]); pts.slice(1).forEach(p => bs.lineTo(...p));
  const bolt = new THREE.Mesh(new THREE.ExtrudeGeometry(bs, { depth: .1, bevelEnabled: false }), new THREE.MeshBasicMaterial({ color: '#fff6b0', toneMapped: false, fog: false })); bolt.visible = false; scene.add(bolt);
  return { root, sq, E, mouth, laugh, bolt };
}
const cloud = makeCloud(); scene.add(cloud.root);

// ---------------------------------------------------------------- rain + splash pools
const NR = 260; const rainMat = new THREE.MeshBasicMaterial({ color: '#d5ecff', transparent: true, opacity: .8, fog: false });
const rain = new THREE.InstancedMesh(new THREE.CapsuleGeometry(.02, .32, 3, 6), rainMat, NR); rain.frustumCulled = false; scene.add(rain);
const rseed = Array.from({ length: NR }, (_, i) => ({ o: hash(i + 1) * 3, P: .5 + hash(i + 300) * .35, dx: (hash(i + 600) - .5) * 2.7, dz: (hash(i + 900) - .5) * .9, th: hash(i + 1200), v: 13 + hash(i + 1500) * 4 }));
const NS = 60; const drop = new THREE.InstancedMesh(new THREE.SphereGeometry(.06, 8, 6), new THREE.MeshPhysicalMaterial({ color: '#cfe9ff', roughness: .05, clearcoat: 1, transparent: true, opacity: .9 }), NS); drop.frustumCulled = false; scene.add(drop);
const dseed = Array.from({ length: NS }, (_, i) => { const a = hash(i + 2000) * 6.283, sp = 1.4 + hash(i + 2100) * 3.2; return { vx: Math.cos(a) * sp, vz: Math.sin(a) * sp * .7, vy: 3 + hash(i + 2200) * 4.2, s: .6 + hash(i + 2300) * 1.2 }; });
const NRING = 18; const rings = [];
for (let i = 0; i < NRING; i++) { const r = new THREE.Mesh(new THREE.RingGeometry(.86, 1, 40), new THREE.MeshBasicMaterial({ color: '#e8f5ff', transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -3 })); r.rotation.x = -Math.PI / 2; r.position.y = .03; r.visible = false; scene.add(r); rings.push(r); }
const rseedR = Array.from({ length: NRING }, (_, i) => ({ P: .6 + hash(i + 3000) * .5, o: hash(i + 3100) * 2, u: hash(i + 3200) * 2 - 1, w: hash(i + 3300) * 2 - 1, r: .25 + hash(i + 3400) * .35 }));

// ---------------------------------------------------------------- timeline logic
const X0 = -1.0, HB = 1.41, REST = 0.65;
const botX = t => {
  let x = X0;
  x += 0.72 * eIO(seg(t, TL.hop1 + .08, TL.hop1 + .5));
  x += 0.72 * eIO(seg(t, TL.hop2 + .08, TL.hop2 + .5));
  x += 1.15 * eOut(seg(t, TL.slip, TL.land + .15)) ;     // skid across the puddle
  return x;
};
function airArc(t, t0, dur, h) { const u = (t - t0) / dur; return u > 0 && u < 1 ? h * 4 * u * (1 - u) : 0; }

function botState(t) {
  const s = { x: botX(t), y: 0, rx: 0, rz: 0, sx: 1, sy: 1, sz: 1, eyes: 'open', mouth: 'smile', lx: 0, ly: 0, brow: 0, wide: 1, sweat: 0, blink: 0, aL: [.28, 0], aR: [.42, -.35], ant: 0, grounded: true, lift: 0 };
  // breathing + antenna
  const br = Math.sin(t * 2.6) * .012; let dy = -br;
  // blinks
  for (const bt of [0.85, 1.55, 3.7, 4.1, 5.25]) s.blink = Math.max(s.blink, Math.sin(Math.PI * clamp((t - bt) / .13)));
  s.ant = Math.sin(t * 3.1) * .05;
  // idle arms
  s.aL = [.26 + Math.sin(t * 2.2) * .04, 0];
  s.aR = [.4 + Math.sin(t * 2.2 + 1) * .04, -.45];
  // look up + worry
  const up = seg(t, TL.look_up, TL.look_up + .2); s.ly = up * 1.0; s.brow = up * .5; s.mouth = up > .5 ? 'o' : 'smile';
  if (t > TL.look_up + .15) { s.sweat = clamp((t - TL.look_up - .15) / .2); }
  // anticipation: small crouch + shrink as cloud rises
  dy += .12 * smooth(seg(t, TL.cloud_rise, TL.flash1)) * (t < TL.hit ? 1 : 0);
  s.wide = 1 + .15 * smooth(seg(t, TL.flash1 - .1, TL.flash1 + .04)) * (t < TL.hit ? 1 : 0);
  if (t > TL.cloud_rise && t < TL.hit) { s.aL = [.9, -.2]; s.aR = [1.0, -.3]; s.mouth = 'o'; s.brow = .9; s.ly = 1; }
  // cloud bonk: squash + spring back with overshoot
  const hd = t - TL.hit;
  if (hd >= 0) {
    const sqd = hd < .09 ? .34 * eOut(hd / .09) : .34 * spring(hd - .09, 3.1, 6.5);
    dy += sqd;
    s.eyes = hd < .55 ? 'squeeze' : 'open'; s.mouth = hd < .5 ? 'open' : 'wob'; s.brow = .8; s.ly = hd < .55 ? 0 : -.5; s.lx = 0;
    s.aL = [.3 + .6 * smooth(seg(hd, 0, .1)) * (1 - seg(hd, .1, .6)), 0]; s.aR = [.35 + .5 * smooth(seg(hd, 0, .1)) * (1 - seg(hd, .1, .6)), -.2 * (1 - seg(hd, 0, .5))];
    s.ant = .5 * spring(hd, 3.0, 3.5) * (1 - seg(hd, 0, 2.5) * .0);
    s.rz = .06 * spring(hd - .1, 2.4, 4.5);
  }
  // wet shiver after rain starts
  if (t > TL.rain_on && t < TL.crouch + .3) {
    const k = smooth(seg(t, TL.rain_on, TL.rain_on + .5)); s.rz += Math.sin(t * 34) * .018 * k; s.eyes = 'open'; s.mouth = 'wob'; s.brow = .85; s.ly = -.35; s.sweat = 1;
    s.aL = [.18, 0]; s.aR = [.2, -.05]; s.ant = lerp(s.ant, -.22, k);   // droopy antenna
  }
  // sigh / look sideways to flee
  if (t > TL.sigh && t < TL.hop1) { s.lx = 1 * smooth(seg(t, TL.sigh, TL.sigh + .2)); s.ly = 0; s.mouth = 'o'; s.brow = .5; }
  // crouch anticipation (before each hop), hop arcs with stretch and landing squash
  const hops = [TL.hop1, TL.hop2], dur = .46, hh = .55;
  const crouchK = (t0) => { const a = seg(t, t0 - .35, t0); const rel = seg(t, t0, t0 + .08); return .24 * smooth(a) * (1 - rel); };
  dy += crouchK(hops[0]) * (t < hops[0] + .1 ? 1 : 0) + (t > hops[0] + .3 ? crouchK(hops[1]) : 0);
  for (const h0 of hops) {
    const a = airArc(t, h0 + .08, dur, hh); s.lift = Math.max(s.lift, a);
    if (t > h0 + .08 && t < h0 + .08 + dur) { dy -= .13 * Math.sin(Math.PI * seg(t, h0 + .08, h0 + .08 + dur)); }
    const ld = t - (h0 + .08 + dur); if (ld >= 0 && ld < .6 && h0 < TL.slip - .2) dy += .2 * spring(ld, 3.2, 7);
    if (t > h0 + .06 && t < h0 + .08 + dur + .1) { s.lx = 1; s.mouth = 'o'; s.aL = [.9, -.35]; s.aR = [.35, -.7]; s.rz += -.1 * Math.sin(Math.PI * seg(t, h0 + .08, h0 + .08 + dur)); }
  }
  s.sy = 1 - dy; s.sx = 1 + dy * .65; s.sz = 1 + dy * .5;
  s.y = HB * s.sy + s.lift;
  if (t > TL.hop2 + .35 && t < TL.slip) { s.mouth = 'o'; s.eyes = 'open'; }

  // ---- slip -> flip -> flat landing
  if (t >= TL.slip) {
    const dur2 = TL.land - TL.slip, u = clamp((t - TL.slip) / dur2);
    const u1 = clamp(u / .32);
    const part = eOut(u1) * .42 + eIn(u) * .58;
    s.rx = -Math.PI / 2 * part * 1.0;
    s.rz = Math.sin(u * Math.PI) * -.28 + .03 * spring(t - TL.land, 2.5, 5);
    const h = 1.75 * 4 * u * (1 - u);
    s.y = lerp(HB, REST, eIn(u) * .85 + .15 * u) + h * 1.0 * (u < 1 ? 1 : 0);
    s.sx = 1; s.sy = 1; s.sz = 1;
    // stretch in air (vertical velocity), anticipation hang
    const stretch = .12 * Math.sin(Math.PI * clamp(u * 1.0)); s.sy = 1 + stretch; s.sx = 1 - stretch * .45;
    s.eyes = 'open'; s.wide = 1.18; s.mouth = 'open'; s.brow = -.7; s.ly = 0; s.lx = 0; s.sweat = 0;
    const wind = t * 15; s.aL = [1.9 + Math.sin(wind) * .6, -.5 + Math.sin(wind * .8) * .4]; s.aR = [2.0 + Math.cos(wind) * .6, -.5 + Math.cos(wind * .9) * .4];
    s.ant = Math.sin(wind * .5) * .3 - .25;
    // landing
    const ld = t - TL.land;
    if (ld >= 0) {
      const sqz = ld < .06 ? .38 * eOut(ld / .06) : .38 * spring(ld - .06, 2.8, 7.5);
      s.rx = -Math.PI / 2; s.rz = .04 * spring(ld, 2.4, 3.5) - .05;
      const b1 = airArc(t, TL.land + .05, .34, .5 * Math.exp(-0)), b2 = airArc(t, TL.land + .42, .22, .1);
      s.sz = 1 - sqz; s.sx = 1 + sqz * .55; s.sy = 1 + sqz * .55;
      s.y = REST * s.sz + b1 + b2; s.lift = b1 + b2;
      s.eyes = 'x'; s.mouth = ld < .5 ? 'open' : 'wob'; s.brow = .3 * (ld > .6 ? 1 : 0); s.wide = 1;
      s.aL = [1.25 + .1 * spring(ld, 2, 3), .3]; s.aR = [1.35 + .1 * spring(ld + .1, 2, 3), .25];
      s.aL[0] += -.12 * seg(ld, .6, 1.2) * 0 ; s.ant = .55 * spring(ld, 2.6, 2.6) - .05;
    }
  }
  return s;
}

function applyBot(s) {
  bot.root.position.set(s.x, s.y, 0); bot.root.rotation.set(s.rx, 0, s.rz);
  bot.sq.scale.set(s.sx, s.sy, s.sz); bot.ant.rotation.z = s.ant;
  bot.sweat.visible = s.sweat > .01; bot.sweat.scale.setScalar(Math.max(.01, s.sweat));
  bot.arms.forEach((a, i) => { const [o, f] = i ? s.aR : s.aL; a.sh.rotation.set(f, 0, a.sx * o); });
  for (const e of bot.eyes) {
    const xm = s.eyes === 'x', sqm = s.eyes === 'squeeze';
    e.scl.visible = e.pup.visible = !xm && !sqm; e.xx.visible = xm; e.sqz.visible = sqm;
    e.g.scale.set(s.wide, s.wide * (1 - s.blink * .92), 1);
    e.pup.position.set(s.lx * .09, s.ly * .08, 0);
    { const k = s.wide > 1.1 ? .8 : 1; e.pup.scale.set(k, k, 1); }
    e.brow.rotation.z = -e.sx * s.brow * .5 * -1; e.brow.position.y = .42 + (s.brow < 0 ? .06 : 0) + (s.wide - 1) * .35;
    e.brow.visible = Math.abs(s.brow) > .05;
    if (sqm) e.sqz.scale.x = -e.sx;
  }
  for (const k in bot.mouths) bot.mouths[k].visible = k === s.mouth;
  bot.face.updateMatrixWorld;
}

function cloudState(t) {
  const c = { x: 0, y: 6.3, sx: 1, sy: 1, ang: 0, laugh: 0, bolt: 0, boltX: 0 };
  const botx = botX(t);
  const enter = eOut(seg(t, TL.cloud_in, TL.cloud_in + 1.1));
  let x = lerp(4.6, X0 + .1, enter);
  let y = 5.75 + Math.sin(t * 1.7) * .12;
  y += (1 - enter) * .6;
  // anticipation rise + rumble
  const ant = smooth(seg(t, TL.cloud_rise, TL.cloud_drop));
  y += .75 * ant; c.sy = 1 + .1 * ant; c.sx = 1 - .05 * ant;
  x += Math.sin(t * 38) * .06 * ant;
  // drop
  const du = seg(t, TL.cloud_drop, TL.hit);
  if (t >= TL.cloud_drop) {
    const yFall = lerp(6.5, 4.5, eIn(du));
    y = yFall; c.sy = 1 + .22 * du; c.sx = 1 - .12 * du;
  }
  const hd = t - TL.hit;
  if (hd >= 0) {
    const sq = hd < .1 ? .3 * eOut(hd / .1) : .3 * spring(hd - .1, 2.6, 6);
    c.sy = 1 - sq; c.sx = 1 + sq * .7;
    // bounce up to hover
    const rise = eBack(seg(hd, .08, .8), 1.4);
    y = lerp(4.5, 5.15 + Math.sin(t * 1.9) * .1, rise);
    x = lerp(X0 + .1, botx + .05, 1) + Math.sin(t * 1.3) * .12;
  }
  if (t > TL.hop1) { x = lerp(x, botX(t - .25) + .1, 1); }
  if (t > TL.slip - .1 && t <= TL.land) y += 1.1 * smooth(seg(t, TL.slip - .1, TL.slip + .45));
  if (t > TL.land) { y = 6.1 + Math.sin(t * 2.1) * .1 + .25 * smooth(seg(t, TL.flash2 - .3, TL.flash2)); }
  // laugh after the fall
  const lt = seg(t, TL.land + .5, TL.land + .6);
  c.laugh = lt; if (lt > 0 && t < 10) { const k = Math.sin((t - TL.land) * 22) * .035; c.sy *= 1 + k; c.sx *= 1 - k; y += Math.abs(Math.sin((t - TL.land) * 11)) * .08; }
  c.x = x; c.y = y;
  const fl = (t0, w) => clamp(1 - Math.abs(t - t0) / w) > 0 ? 1 : 0;
  c.bolt = (t > TL.flash1 && t < TL.flash1 + .12) || (t > TL.flash2 && t < TL.flash2 + .1) ? 1 : 0;
  return c;
}
function applyCloud(c, t) {
  cloud.root.position.set(c.x, c.y, -.1); cloud.sq.scale.set(c.sx * .95, c.sy * .95, .95);
  cloud.root.visible = t > TL.cloud_in - .05;
  cloud.laugh.visible = c.laugh > .5; cloud.mouth.visible = c.laugh <= .5;
  cloud.bolt.visible = !!c.bolt; cloud.bolt.position.set(c.x - .5, c.y - 1.0, .3); cloud.bolt.scale.set(1.1, 1.1, 1);
  cloud.bolt.scale.y = (c.y - .1) / 3.2 * 1.0;
}

// ---------------------------------------------------------------- frame renderer
const tmpV = new THREE.Vector3();
let cardStart = null;
window.TL = TL;
window.render = (t) => {
  const s = botState(t); applyBot(s);
  const c = cloudState(t); applyCloud(c, t);
  bot.root.updateMatrixWorld(true);

  // sky/lighting mood: sunny -> storm
  const storm = smooth(seg(t, TL.cloud_in + .2, TL.hit + .2)) * (1 - .15 * smooth(seg(t, 8.2, 10)));
  skyU.mixv.value = storm;
  const fogCol = new THREE.Color('#cfe6fb').lerp(new THREE.Color('#9aa5c0'), storm); scene.fog.color.copy(fogCol);
  let flash = 0; if ((t > TL.flash1 && t < TL.flash1 + .22) || (t > TL.flash2 && t < TL.flash2 + .2)) flash = (t < TL.flash2 ? Math.exp(-(t - TL.flash1) * 14) : Math.exp(-(t - TL.flash2) * 14));
  key.intensity = lerp(3.1, 1.9, storm) + flash * 3.5; hemi.intensity = lerp(.8, .6, storm) + flash * .8; spot.intensity = lerp(130, 85, storm); spot.target.position.set(s.x * .6, 0, 0.5); spot.position.set(s.x * .6, 16, 8); scene.environmentIntensity = lerp(.55, .4, storm) + flash * .5;
  key.color.set('#fff1dc').lerp(new THREE.Color('#d7e2ff'), storm);
  hemi.color.set('#d6e8ff').lerp(new THREE.Color('#aab8e0'), storm);
  rim.intensity = lerp(1.2, 1.6, storm);
  renderer.toneMappingExposure = lerp(1.08, .98, storm) + flash * .15;
  for (const b of bokeh) { const u = b.userData; b.position.set(u.x + Math.sin(t * .2 + u.ph) * 1.4, u.y + Math.cos(t * .17 + u.ph) * .8, u.z); b.material.opacity = u.base * (1 - storm * .55); }
  key.target.position.set(s.x * .6, 0, 0); key.position.set(s.x * .6 - 5, 12, 9);
  bounce.position.set(s.x, .8, 2.6); bounce.intensity = lerp(14, 8, storm);

  // contact blob under INTEL
  { const lying = t >= TL.slip; const gap = Math.max(0, s.lift * (lying ? 1 : 1)) + (t >= TL.slip && t < TL.land ? Math.max(0, s.y - REST) : 0);
    const w = (lying ? 3.6 : 2.7) * (1 + .1 * s.sx - .1) * (1 + gap * .08), op = (t < TL.slip || t >= TL.land ? 1 : 1) / (1 + gap * 1.15);
    botBlob.position.set(s.x + (lying ? 0 : 0), .035, lying ? -.15 : -.05); botBlob.scale.set(w, lying ? 3.0 : 2.0, 1); botBlob.material.opacity = clamp(op, 0, 1) * (1 - 0 * storm); }

  // puddle growth + ambient ripples
  const pg = smooth(seg(t, TL.rain_on - .05, TL.rain_on + 2.9));
  const prx = .001 + 2.35 * pg, prz = .001 + 1.35 * pg;
  puddle.visible = pg > .01; puddle.position.set(PUD.x, 0, PUD.z); puddle.scale.set(prx, 1, prz);
  const rainAmt = smooth(seg(t, TL.rain_on - .15, TL.rain_on + .5)) * (1 - .35 * smooth(seg(t, 8.8, 10)));

  // rain drops (deterministic spawn cycles)
  const cm = new THREE.Matrix4(), q = new THREE.Quaternion(), sc = new THREE.Vector3(), pos = new THREE.Vector3();
  rain.count = NR;
  for (let i = 0; i < NR; i++) {
    const r = rseed[i]; const n = Math.floor((t - r.o) / r.P), ts = r.o + n * r.P, age = t - ts;
    const cs = cloudState(ts); const on = smooth(seg(ts, TL.rain_on - .15, TL.rain_on + .5)) > r.th * .9 && n >= 0 && ts > TL.rain_on - .2;
    const cy = cs.y - .75 * cs.sy; let y = cy - r.v * age; const x = cs.x + r.dx * (1 - .0), z = r.dz;
    let vis = on && y > .02;
    // drops hit INTEL's top: stop at his top surface when overhead
    const dxb = Math.abs(x - s.x), topY = s.y + (t >= TL.slip ? 0 : 1.1 * s.sy) + (t >= TL.slip ? .7 : 0);
    if (dxb < 1.15 && Math.abs(z) < .8 && y < topY + .3 && cy > topY) vis = false;
    if (!vis) { cm.makeScale(0, 0, 0); rain.setMatrixAt(i, cm); continue; }
    pos.set(x, y, z); q.identity(); sc.set(1, 1 + (r.v - 13) * .08, 1); cm.compose(pos, q, sc); rain.setMatrixAt(i, cm);
  }
  rain.instanceMatrix.needsUpdate = true;

  // ripples
  rings.forEach((rg, i) => {
    const r = rseedR[i]; const n = Math.floor((t - r.o) / r.P), age = (t - r.o - n * r.P) / r.P; const ts = r.o + n * r.P;
    const on = pg > .25 && smooth(seg(ts, TL.rain_on + .4, TL.rain_on + 1.2)) > .3 && t < 10;
    if (!on || n < 0) { rg.visible = false; return; }
    rg.visible = true; const hh2 = hash(n * 31 + i * 7); const hh3 = hash(n * 17 + i * 5 + 3);
    rg.position.set(PUD.x + (hh2 * 2 - 1) * prx * .82, .032, PUD.z + (hh3 * 2 - 1) * prz * .7);
    const rr = r.r * (.25 + age * 1.6); rg.scale.set(rr, rr * .72, rr); rg.rotation.x = -Math.PI / 2; rg.scale.set(rr, rr, rr);
    rg.material.opacity = .75 * (1 - age) * (1 - age); rg.scale.y = rr;
    rg.rotation.set(-Math.PI / 2, 0, 0);
    rg.scale.set(rr, rr * .75, 1);
  });
  // impact splash: big rings + droplets
  const ld = t - TL.land;
  { const ri = NRING - 1; const rg = rings[ri]; }
  for (let k = 0; k < 3; k++) { const rg = rings[k]; const a = (ld - k * .09) / .9; if (ld > 0 && a >= 0 && a < 1) { rg.visible = true; rg.position.set(s.x + .0, .034 + k * .001, .0); const rr = .8 + a * (3.2 - k * .5); rg.scale.set(rr, rr * .7, 1); rg.material.opacity = .9 * (1 - a) * (1 - a); } }
  drop.count = NS;
  for (let i = 0; i < NS; i++) {
    const d = dseed[i]; const tt = ld - 0.0; if (tt < 0 || tt > 1.1) { cm.makeScale(0, 0, 0); drop.setMatrixAt(i, cm); continue; }
    const y = .15 + d.vy * tt - 9 * tt * tt; if (y < .03) { cm.makeScale(0, 0, 0); drop.setMatrixAt(i, cm); continue; }
    pos.set(s.x + d.vx * tt * .9 + (i % 5 - 2) * .1, y, d.vz * tt * .8 + .6); sc.setScalar(d.s * (1 - tt * .5)); q.identity(); cm.compose(pos, q, sc); drop.setMatrixAt(i, cm);
  }
  drop.instanceMatrix.needsUpdate = true;

  // card: held -> flung -> lands
  const tf = TL.fling, tl = TL.card_land;
  if (t < tf) { cardHeld.visible = true; cardFly.visible = false; cardBlob.visible = false; }
  else {
    cardHeld.visible = false; cardFly.visible = true;
    if (!cardStart) { const s0 = botState(tf); applyBot(s0); bot.root.updateMatrixWorld(true); cardHeld.visible = true; cardHeld.updateWorldMatrix(true, false); cardStart = new THREE.Vector3().setFromMatrixPosition(cardHeld.matrixWorld); cardHeld.visible = false; applyBot(s); bot.root.updateMatrixWorld(true); }
    const D = tl - tf, tau = t - tf, g = 17; const P1 = new THREE.Vector3(2.0, .06, 2.1);
    const vy = (P1.y - cardStart.y + .5 * g * D * D) / D;
    const k = clamp(tau / D);
    const x = lerp(cardStart.x, P1.x, k), z = lerp(cardStart.z, P1.z, k);
    let y = cardStart.y + vy * Math.min(tau, D) - .5 * g * Math.min(tau, D) ** 2;
    const bd = t - tl; if (bd > 0) y = P1.y + .22 * Math.abs(Math.sin(Math.PI * clamp(bd / .28))) * Math.exp(-bd * 6) * (bd < .5 ? 1 : 0);
    cardFly.position.set(x, y, z);
    const rotK = eOut(k); cardFly.rotation.set(-Math.PI / 2 * rotK + Math.PI * 2 * 1.5 * (1 - k) * (1 - k), .8 * (1 - k) + .15, Math.PI * 3 * (1 - rotK) - .25 * rotK);
    cardBlob.visible = true; cardBlob.position.set(x, .035, z - .05); const hgt = Math.max(0, y - .06); cardBlob.scale.set(1.6, 1.3, 1); cardBlob.material.opacity = .9 / (1 + hgt * 1.6);
  }
  // dizzy stars
  stars.forEach((st, i) => {
    const a = (t - TL.stars) * 4.2 + i * 2.094; const k = smooth(seg(t, TL.stars, TL.stars + .25)) * (1 - smooth(seg(t, 9.55, 10)));
    st.visible = k > .01; st.position.set(s.x + Math.cos(a) * 1.05, 1.85 + Math.sin(a * 2) * .08, -.3 + Math.sin(a) * .55 ); st.scale.setScalar(k * (.9 + .12 * Math.sin(a * 3)));
    st.rotation.set(0, a * 2, .2);
  });

  // ---- camera: slow push, crane up after the fall, tiny hit shake
  const push = eIO(seg(t, 0, 10));
  const dist = lerp(16.8, 14.4, push) - .8 * smooth(seg(t, TL.slip - .2, TL.land)) + 0 * 1;
  const elev = THREE.MathUtils.degToRad(lerp(10, 12.5, seg(t, 0, TL.slip)) + 28 * eIO(seg(t, TL.land - .05, TL.land + 1.5)));
  const az = THREE.MathUtils.degToRad(Math.sin(t * .35) * 2.2 - 2.0 * eIO(seg(t, 5, 10)));
  const tgt = new THREE.Vector3(lerp(-.2, s.x * .5 + .1, smooth(seg(t, 3, 9))), lerp(2.7, 1.0, eIO(seg(t, TL.land - .1, TL.land + 1.5))), 0);
  const shake = ld > 0 ? Math.exp(-ld * 11) * .09 : 0;
  camera.position.set(tgt.x + Math.sin(az) * dist * Math.cos(elev), tgt.y + Math.sin(elev) * dist, Math.cos(az) * dist * Math.cos(elev));
  camera.lookAt(tgt); camera.position.y += Math.sin(ld * 70) * shake; camera.position.x += Math.sin(ld * 57) * shake * .6;
  sky.position.copy(camera.position);
  renderer.render(scene, camera);
};
window.dataURL = (fmt = 'image/png', qual = .95) => renderer.domElement.toDataURL(fmt, qual);
window.ready = true;
render(0);
