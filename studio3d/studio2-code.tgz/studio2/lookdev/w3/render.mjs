// usage: node render.mjs --out dir --w 1080 --h 1920 [--times 1,2,3 | --from 0 --to 300 --fps 30] [--fmt png|jpeg]
import { createRequire } from 'module';
import http from 'http'; import fs from 'fs'; import path from 'path';
const require = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = require('playwright');
const A = Object.fromEntries(process.argv.slice(2).reduce((a, v, i, r) => (v.startsWith('--') ? a.concat([[v.slice(2), r[i + 1]]]) : a), []));
const W = +(A.w || 1080), H = +(A.h || 1920), fps = +(A.fps || 30), out = A.out || 'frames', fmt = A.fmt || 'png';
fs.mkdirSync(out, { recursive: true });
const root = path.dirname(new URL(import.meta.url).pathname);
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.json': 'application/json' };
const srv = http.createServer((q, r) => { const f = path.join(root, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': mime[path.extname(f)] || 'application/octet-stream' }); r.end(d); } }); });
await new Promise(r => srv.listen(0, r)); const port = srv.address().port;
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl'] });
const p = await b.newPage({ viewport: { width: W, height: H } });
p.on('pageerror', e => console.log('PAGEERR', e.message)); p.on('console', m => { if (m.type() === 'error') console.log('CONSOLE', m.text()); });
await p.goto(`http://localhost:${port}/index.html?w=${W}&h=${H}`); await p.waitForFunction('window.ready === true', null, { timeout: 120000 });
let list;
if (A.times) list = A.times.split(',').map(Number).map(t => [Math.round(t * fps), t]);
else { list = []; for (let f = +(A.from || 0); f < +(A.to || 300); f += +(A.step || 1)) list.push([f, f / fps]); }
if (A.skip) list = list.filter(([f]) => !fs.existsSync(path.join(out, `f${String(f).padStart(4,'0')}.${fmt==='jpeg'?'jpg':'png'}`)));
const t0 = Date.now();
for (const [f, t] of list) {
  const url = await p.evaluate(([t, fmt]) => { render(t); return dataURL('image/' + fmt, .97); }, [t, fmt]);
  fs.writeFileSync(path.join(out, `f${String(f).padStart(4, '0')}.${fmt === 'jpeg' ? 'jpg' : 'png'}`), Buffer.from(url.split(',')[1], 'base64'));
  if (f % 10 === 0 || list.length < 12) console.log('frame', f, ((Date.now() - t0) / 1000 / (list.indexOf(list.find(x => x[0] === f)) + 1)).toFixed(2), 's/frame');
}
console.log('done', list.length, 'frames', ((Date.now() - t0) / 1000).toFixed(1), 's total');
await b.close(); srv.close();
