import bpy, time, sys
bpy.ops.wm.read_factory_settings(use_empty=True)
sc=bpy.context.scene
print(bpy.app.version_string)
bpy.ops.mesh.primitive_plane_add(size=40); 
bpy.ops.mesh.primitive_cube_add(size=2,location=(0,0,1.2))
c=bpy.context.object; bpy.ops.object.modifier_add(type='BEVEL'); c.modifiers[-1].width=0.5; c.modifiers[-1].segments=8
bpy.ops.object.shade_smooth()
bpy.ops.object.light_add(type='AREA',location=(3,-3,6)); bpy.context.object.data.energy=800; bpy.context.object.data.size=5
bpy.ops.object.camera_add(location=(0,-9,3),rotation=(1.35,0,0)); sc.camera=bpy.context.object
eng=sys.argv[-2]; res=int(sys.argv[-1])
sc.render.resolution_x=res; sc.render.resolution_y=res*16//9
sc.render.resolution_percentage=100
if eng=='cycles':
    sc.render.engine='CYCLES'; sc.cycles.device='CPU'; sc.cycles.samples=32; sc.cycles.use_denoising=True
    sc.cycles.use_adaptive_sampling=True
else:
    sc.render.engine='BLENDER_EEVEE'
    print('eevee engine set', sc.render.engine)
sc.render.filepath=f'/home/claude/studio2/lookdev/tmp/bt_{eng}_{res}.png'
for i in range(3):
    t=time.time(); bpy.ops.render.render(write_still=True); print(eng,res,"sec",time.time()-t)
