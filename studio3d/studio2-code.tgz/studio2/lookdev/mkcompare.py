from PIL import Image, ImageDraw
a=Image.open('ref/intel_28.png').convert('RGB'); b=Image.open('frames/f0192.png').convert('RGB')
W=540;H=960
sh=Image.new('RGB',(W*2+30,H+60),(20,20,28)); d=ImageDraw.Draw(sh)
sh.paste(a.resize((W,H),Image.LANCZOS),(10,50)); sh.paste(b.resize((W,H),Image.LANCZOS),(W+20,50))
d.text((10,18),"CURRENT 2D (INTEL_v2 @28.0s)",fill=(255,255,255)); d.text((W+20,18),"THREE.JS 3D TEST (@6.4s skid/flip)",fill=(255,255,255))
sh.save('compare.png')
