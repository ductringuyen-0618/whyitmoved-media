// Deterministic particle effects (pure functions of time since emission): coin/star/confetti bursts and water splashes.
import { THREE, M, starGeo, mGold } from './kit.js';
import { hash, clamp, seg, smooth } from './util.js';

const dummy = new THREE.Object3D(), col = new THREE.Color();
const CONF = ['#ff4d6d', '#ffd23f', '#3ddc97', '#4cc9f0', '#b388ff', '#ff9f1c'];
let coinGeo = null, starG = null, confGeo = null;

/** kind: coin | star | confetti. Returns {obj, update(age, opts)}; source = local origin, floorY = local y of the ground. */
export function makeBurst(kind = 'coin', n = 24, seed = 1) {
  let geo, mat;
  if (kind === 'star') { starG = starG || starGeo(.2, .09); geo = starG; mat = mGold; }
  else if (kind === 'confetti') { confGeo = confGeo || new THREE.PlaneGeometry(.2, .12); geo = confGeo; mat = new THREE.MeshStandardMaterial({ roughness: .5, side: THREE.DoubleSide }); }
  else {
    if (!coinGeo) { coinGeo = new THREE.CylinderGeometry(.17, .17, .05, 24, 1); coinGeo.rotateX(Math.PI / 2); }
    geo = coinGeo; mat = mGold;
  }
  const im = new THREE.InstancedMesh(geo, mat, n); im.frustumCulled = false; im.castShadow = kind !== 'confetti';
  const P = Array.from({ length: n }, (_, i) => {
    const h = k => hash(seed * 131 + i * 17 + k);
    const a = h(1) * Math.PI * 2, sp = 1.6 + h(2) * 3.4, up = 5.5 + h(3) * 5;
    return { vx: Math.cos(a) * sp, vz: Math.sin(a) * sp * .8, vy: up, sx: (h(4) - .5) * 14, sz: (h(5) - .5) * 9, ph: h(6) * 6.28, c: Math.floor(h(7) * CONF.length) };
  });
  if (kind === 'confetti') P.forEach((p, i) => im.setColorAt(i, col.set(CONF[p.c])));
  const g = kind === 'confetti' ? 4.2 : kind === 'star' ? 6 : 15;
  function update(age, { power = 1, spread = 1, size = 1, life = 2.8, floorY = -1e3 } = {}) {
    for (let i = 0; i < n; i++) {
      const p = P[i], pw = power * (kind === 'star' ? .8 : 1);
      if (age < 0 || age > life) { dummy.scale.setScalar(0); dummy.updateMatrix(); im.setMatrixAt(i, dummy.matrix); continue; }
      const vy = p.vy * pw, vx = p.vx * spread * pw, vz = p.vz * spread * pw;
      let x, y, z, resting = false, th = 0;
      const drag = kind === 'confetti' ? Math.exp(-age * 1.6) : 1;
      if (kind === 'confetti') { x = vx * (1 - drag) / 1.6; z = vz * (1 - drag) / 1.6; y = Math.max(floorY + .02, (vy * .55) * (1 - drag) / 1.6 - g * .5 * age * age * .5 - age * .6); resting = y <= floorY + .03; }
      else {
        const disc = Math.sqrt(vy * vy + 2 * g * Math.max(0, -floorY)); th = (vy + disc) / g;       // time to first floor hit
        if (kind === 'star' || age < th) { x = vx * age; z = vz * age; y = vy * age - .5 * g * age * age; }
        else {
          const tau = age - th, vb = (disc) * .38;
          x = vx * th + vx * .22 * (1 - Math.exp(-5 * tau)) / 5 * 5 * .2; z = vz * th + vz * .22 * (1 - Math.exp(-5 * tau)) / 5 * 5 * .2;
          y = floorY + vb * tau - .5 * g * tau * tau; if (y <= floorY || tau > 2 * vb / g) { y = floorY; resting = true; }
        }
      }
      dummy.position.set(x, y + (resting && kind === 'coin' ? .03 : 0), z);
      const rest = resting ? 1 : 0;
      if (kind === 'coin') dummy.rotation.set(rest ? Math.PI / 2 : age * p.sx, rest ? 0 : age * p.sz * .4, rest ? p.ph : 0);
      else if (kind === 'confetti') dummy.rotation.set(rest ? Math.PI / 2 : age * p.sx * .6 + p.ph, age * p.sz, p.ph);
      else dummy.rotation.set(0, age * p.sx * .4, p.ph * .3);
      const sc = size * clamp(age / .06) * (1 - smooth(seg(age, life - .5, life)));
      dummy.scale.setScalar(sc); dummy.updateMatrix(); im.setMatrixAt(i, dummy.matrix);
    }
    im.instanceMatrix.needsUpdate = true;
  }
  return { obj: im, update };
}

/** Water splash: droplets + expanding ground rings. */
export function makeSplash(seed = 1) {
  const g = new THREE.Group(), N = 30;
  const im = new THREE.InstancedMesh(new THREE.SphereGeometry(.05, 10, 8), M('#cfe9ff', { roughness: .05, clearcoat: 1, transparent: true, opacity: .92 }), N); im.frustumCulled = false; g.add(im);
  const rings = [0, 1, 2].map(() => { const r = new THREE.Mesh(new THREE.RingGeometry(.86, 1, 48), new THREE.MeshBasicMaterial({ color: '#e8f5ff', transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -3 })); r.rotation.x = -Math.PI / 2; g.add(r); return r; });
  const P = Array.from({ length: N }, (_, i) => { const a = hash(seed + i * 3 + 1) * 6.283, sp = 1.4 + hash(seed + i * 3 + 2) * 3.2; return { vx: Math.cos(a) * sp, vz: Math.sin(a) * sp * .7, vy: 3 + hash(seed + i * 3 + 3) * 4.2, s: .6 + hash(seed + i * 7) * 1.2 }; });
  function update(age, { power = 1, size = 1, floorY = 0 } = {}) {
    for (let i = 0; i < N; i++) {
      const p = P[i], y = floorY + .12 + p.vy * power * age - 9 * age * age;
      if (age < 0 || age > 1.2 || y < floorY + .02) { dummy.scale.setScalar(0); }
      else { dummy.position.set(p.vx * age * .9 * power, y, p.vz * age * .8 * power); dummy.scale.setScalar(p.s * size * (1 - age * .5)); }
      dummy.rotation.set(0, 0, 0); dummy.updateMatrix(); im.setMatrixAt(i, dummy.matrix);
    }
    im.instanceMatrix.needsUpdate = true;
    rings.forEach((r, k) => {
      const a = (age - k * .09) / .9;
      r.visible = a >= 0 && a < 1; if (!r.visible) return;
      const rr = (.8 + a * (3.2 - k * .5)) * size; r.position.set(0, floorY + .034 + k * .001, 0); r.scale.set(rr, rr * .7, 1); r.material.opacity = .9 * (1 - a) * (1 - a);
    });
  }
  return { obj: g, update };
}
