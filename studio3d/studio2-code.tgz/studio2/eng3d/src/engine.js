// eng3d shot-sheet player. Exposes window.loadShots(json), window.renderAt(t), window.dataURL(), window.report().
import { THREE, Entity, radialTex } from './kit.js';
import { makeChar } from './chars.js';
import { PROPS } from './props.js';
import { makeSet, LOOKS, blendLook } from './sets.js';
import { evalClips } from './clips.js';
import { buildTracks, sample, integrate, getEase, clamp, lerp, seg, smooth, D2R, hash } from './util.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const Q = new URLSearchParams(location.search);
const W = +(Q.get('w') || 1080), H = +(Q.get('h') || 1920), AA = Q.get('aa') !== '0', SHADOW = +(Q.get('shadow') || 2048);
await document.fonts.load('900 100px Inter').catch(() => {});

// ------------------------------------------------------------------ renderer / world
const renderer = new THREE.WebGLRenderer({ antialias: AA, preserveDrawingBuffer: true });
renderer.setPixelRatio(1); renderer.setSize(W, H);
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.VSMShadowMap;
renderer.toneMapping = THREE.NeutralToneMapping; renderer.toneMappingExposure = 1.05;
document.body.appendChild(renderer.domElement);
const scene = new THREE.Scene();
scene.environment = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), 0.04).texture;
scene.fog = new THREE.Fog(0xcfe6fb, 20, 80);
const camera = new THREE.PerspectiveCamera(30, W / H, 0.5, 400); scene.add(camera);

const skyU = { top: { value: new THREE.Color() }, bot: { value: new THREE.Color() } };
const sky = new THREE.Mesh(new THREE.SphereGeometry(200, 32, 16), new THREE.ShaderMaterial({
  uniforms: skyU, side: THREE.BackSide, depthWrite: false, fog: false,
  vertexShader: 'varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }',
  fragmentShader: 'uniform vec3 top,bot; varying vec3 vP; void main(){ float h = clamp(normalize(vP).y*2.4+0.05,0.,1.); h = smoothstep(0.,1.,h); gl_FragColor = vec4(mix(bot,top,h),1.); }',
}));
sky.renderOrder = -10; scene.add(sky);

const hemi = new THREE.HemisphereLight(0xd6e8ff, 0xf3dcc0, 1); scene.add(hemi);
const key = new THREE.DirectionalLight(0xfff1dc, 3); key.castShadow = true;
key.shadow.mapSize.set(SHADOW, SHADOW); key.shadow.radius = 7; key.shadow.blurSamples = 20; key.shadow.bias = -0.0004;
Object.assign(key.shadow.camera, { left: -9, right: 9, top: 9, bottom: -9, near: 1, far: 50 });
scene.add(key, key.target);
const rim = new THREE.DirectionalLight(0xa8c8ff, 1.2); rim.position.set(6, 5, -9); scene.add(rim);
const spot = new THREE.SpotLight(0xfff0d8, 130, 70, .95, 1, 1.2); scene.add(spot, spot.target);
const bounce = new THREE.PointLight(0xffe2bd, 14, 14, 1.6); scene.add(bounce);

// overlays glued to the camera: vignette, flash, fade
function camPlane(mat, order, z = -1) { const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), mat); m.position.z = z; m.renderOrder = order; camera.add(m); return m; }
const vig = camPlane(new THREE.MeshBasicMaterial({ map: radialTex([[0, 'rgba(8,10,30,0)'], [.45, 'rgba(8,10,30,0)'], [.7, 'rgba(8,10,30,.05)'], [.85, 'rgba(8,10,30,.14)'], [1, 'rgba(8,10,30,.26)']], 512), transparent: true, depthTest: false, depthWrite: false, fog: false }), 999);
const flashQ = camPlane(new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0, depthTest: false, depthWrite: false, fog: false, blending: THREE.AdditiveBlending, toneMapped: false }), 1000, -.9);
const fadeQ = camPlane(new THREE.MeshBasicMaterial({ color: '#000', transparent: true, opacity: 0, depthTest: false, depthWrite: false, fog: false, toneMapped: false }), 1001, -.89);
flashQ.visible = fadeQ.visible = false;
const fitPlanes = fov => { const hh = 2 * Math.tan(fov * D2R / 2), ww = hh * camera.aspect; for (const [m, z] of [[vig, 1], [flashQ, .9], [fadeQ, .89]]) m.scale.set(ww * z * 1.02, hh * z * 1.02, 1); };

// ------------------------------------------------------------------ shot sheet model
let SHEET = null; const sets = {}, rigs = {}, built = new Map(); let active = null, activeSet = null;
const D3 = [0, 0, 0], ONE = [1, 1, 1];

function getSet(name) { if (!sets[name]) { const s = makeSet(name); s.group.visible = false; scene.add(s.group); sets[name] = s; } return sets[name]; }

function camTracks(cam) {
  const kfs = (cam?.keyframes || cam?.kf || [{ t: 0 }]).map(k => ({ ...k })).sort((a, b) => a.t - b.t);
  let tgt = [0, 2.2, 0]; const out = [];
  for (const k of kfs) {
    if (k.target) tgt = k.target;
    const o = { t: k.t, target: tgt, ease: k.ease };
    const ob = k.orbit || {};
    if (k.pos) { const d = new THREE.Vector3(k.pos[0] - tgt[0], k.pos[1] - tgt[1], k.pos[2] - tgt[2]); o.dist = d.length(); o.el = Math.asin(d.y / o.dist) / D2R; o.az = Math.atan2(d.x, d.z) / D2R; }
    for (const n of ['az', 'el', 'dist']) { const v = ob[n] ?? k[n]; if (v !== undefined) o[n] = v; }
    if (k.fov !== undefined) o.fov = k.fov; if (k.roll !== undefined) o.roll = k.roll;
    out.push(o);
  }
  return buildTracks(out, { az: 0, el: 10, dist: 15, fov: 30, roll: 0, target: [0, 2.2, 0] });
}

function resolveLook(x) { if (!x) return LOOKS.day; if (typeof x === 'string') return LOOKS[x] || LOOKS.day; return { ...(LOOKS[x.base || 'day']), ...x }; }
function lookKeys(l) { const a = Array.isArray(l) ? l : [{ t: -1e9, look: l || 'day' }]; return a.map(k => ({ t: k.t ?? -1e9, look: resolveLook(k.look ?? k.name), ease: k.ease })).sort((p, q) => p.t - q.t); }
function lookAtTime(keys, t) {
  if (t <= keys[0].t || keys.length === 1) return keys[0].look;
  for (let i = 0; i < keys.length - 1; i++) if (t < keys[i + 1].t) return blendLook(keys[i].look, keys[i + 1].look, getEase(keys[i + 1].ease || 'inout')(seg(t, keys[i].t, keys[i + 1].t)));
  return keys[keys.length - 1].look;
}

const ACTOR_META = new Set(['kf', 'clips', 'char', 'tag']);
function buildShot(shot, idx) {
  const S = { shot, idx, set: getSet(shot.set || 'stage'), actors: [], props: [], cam: camTracks(shot.camera), looks: lookKeys(shot.look), events: shot.events || [], nodes: [] };
  for (const id in (shot.actors || {})) {
    const cfg = shot.actors[id], type = String(cfg.char || id).toUpperCase();
    if (!rigs[id]) { const r = makeChar(type, { tag: cfg.tag, id }); r.ent.blob && scene.add(r.ent.blob); scene.add(r.ent.root); r.ent.setVisible(false); rigs[id] = r; }
    const base = {}; for (const k in cfg) if (!ACTOR_META.has(k)) base[k] = cfg[k];
    S.actors.push({ id, rig: rigs[id], ent: rigs[id].ent, tr: buildTracks(cfg.kf || [], base), clips: cfg.clips || [], phase: hash(id.length * 13 + id.charCodeAt(0)) * 6.28, size: base.size });
  }
  const plist = [...(shot.props || [])];
  (shot.events || []).forEach((ev, i) => {   // burst / splash events become short-lived particle props
    if (ev.type === 'burst') plist.push({ id: '_burst' + i, type: 'burst', params: { kind: ev.kind || 'coin', n: ev.n || 26, seed: ev.seed || i + 1, at: ev.t, power: ev.amp ?? 1, life: ev.life, size: ev.size }, pos: ev.pos || [0, 1, 0], ground: ev.ground });
    if (ev.type === 'splash') plist.push({ id: '_splash' + i, type: 'splash', params: { at: ev.t, power: ev.amp ?? 1, seed: ev.seed || i + 1, size: ev.size }, pos: ev.pos || [0, 0, 0], ground: ev.ground });
  });
  for (const pc of plist) {
    const def = PROPS[pc.type]; if (!def) { console.error('unknown prop type', pc.type); continue; }
    const P = pc.params || {}, inst = def(P);
    for (const k in inst.anchors || {}) if (!inst.anchors[k].parent) inst.content.add(inst.anchors[k]);
    const ent = new Entity(inst); scene.add(ent.root); if (ent.blob) scene.add(ent.blob); ent.root.visible = false; if (ent.blob) ent.blob.visible = false;
    const base = {}; for (const k in pc) if (!['id', 'type', 'params', 'kf'].includes(k)) base[k] = pc[k];
    S.props.push({ id: pc.id || pc.type + S.props.length, ent, inst, P, tr: buildTracks(pc.kf || [], base), pkeys: new Set([...Object.keys(P), ...(pc.kf || []).flatMap(k => Object.keys(k.p || {}))]), baseP: P });
  }
  return S;
}

function shotAt(t) {
  const sh = SHEET.shots; let i = 0;
  for (let k = 0; k < sh.length; k++) if (t >= sh[k].t0 - 1e-6) i = k;
  if (!built.has(i)) built.set(i, buildShot(sh[i], i));
  return built.get(i);
}
function activate(S) {
  if (active === S) return;
  if (active) { active.actors.forEach(a => a.ent.setVisible(false)); active.props.forEach(p => { p.ent.setVisible(false); if (p.ent.attached) { scene.add(p.ent.root); p.ent.attached = null; } }); }
  if (activeSet && activeSet !== S.set) activeSet.group.visible = false;
  S.set.group.visible = true; activeSet = S.set; active = S;
  scene.fog.near = S.set.fog[0]; scene.fog.far = S.set.fog[1];
}

// ------------------------------------------------------------------ per-frame evaluation
const wp = new THREE.Vector3(), tmp = new THREE.Vector3();
function entCenter(ent) { return tmp.set((ent.box.x0 + ent.box.x1) / 2, (ent.box.y0 + ent.box.y1) / 2, (ent.box.z0 + ent.box.z1) / 2); }
function findEntity(S, id) { const a = S.actors.find(x => x.id === id); if (a) return a.ent; const p = S.props.find(x => x.id === id); return p ? p.ent : null; }
function targetPos(S, spec, out) {
  if (Array.isArray(spec)) return out.set(...spec);
  const ent = findEntity(S, spec); if (!ent) return null;
  if (ent.attached) return ent.root.getWorldPosition(out);
  return out.copy(entCenter(ent));
}

function evalActor(S, a, t) {
  const g = (k, d) => sample(a.tr, k, t, d), c = evalClips(a.clips, t);
  const size = g('size', a.rig.size), sq = g('sq', ONE), idle = g('idle', 1);
  const br = Math.sin(t * 2.6 + a.phase) * .012 * idle;
  const pos = g('pos', D3), rot = g('rot', D3);
  const A = {
    a, t, idle, ground: g('ground', 0),
    pos: [pos[0] + c.dpos[0], pos[1] + c.dpos[1], pos[2] + c.dpos[2]], rot: [rot[0] + c.drot[0], rot[1] + c.drot[1], rot[2] + c.drot[2]],
    scale: [size * sq[0] * c.msq[0] * (1 + br * .65), size * sq[1] * c.msq[1] * (1 - br), size * sq[2] * c.msq[2] * (1 + br * .5)],
    solid: g('solid', true) !== false, faceTo: g('faceTo', null), faceW: g('faceW', .5), lookAt: g('lookAt', null), lookW: g('lookW', 1),
  };
  const ex = c.expr, L = g('armL', [16, 0]), R = g('armR', [16, 0]), aw = c.arms ? c.arms.w : 0;
  const mixA = (b, o) => (o ? [lerp(b[0], o[0], aw), lerp(b[1] || 0, o[1] || 0, aw)] : b);
  A.st = {
    t, idle, blink: g('blink', true),
    eyes: ex.eyes ?? g('eyes', 'open'), mouth: ex.mouth ?? g('mouth', 'smile'), brow: ex.brow ?? g('brow', 0), browY: ex.browY ?? g('browY', 0),
    lookx: g('lookx', 0), looky: g('looky', 0), wide: ex.wide ?? g('wide', 1), sweat: ex.sweat ?? g('sweat', 0), wig: g('wig', 0),
    armL: mixA(L, c.arms?.L), armR: mixA(R, c.arms?.R),
    fan: a.rig.hasFans ? integrate(a.tr, 'fan', t, 4) : 0,
  };
  return A;
}

function separate(list) {
  const act = list.filter(A => A.solid);
  for (let it = 0; it < 2; it++) for (let i = 0; i < act.length; i++) for (let j = i + 1; j < act.length; j++) {
    const a = act[i], b = act[j];
    const ax = a.hx, bx = b.hx, az = a.hz, bz = b.hz;
    const ya0 = a.ground + a.pos[1], yb0 = b.ground + b.pos[1];
    if (ya0 > yb0 + b.hy * .9 || yb0 > ya0 + a.hy * .9) continue;          // one is airborne above the other
    const ox = (ax + bx) - Math.abs(a.pos[0] - b.pos[0]), oz = (az + bz) - Math.abs(a.pos[2] - b.pos[2]);
    if (ox <= 0 || oz <= 0) continue;
    if (ox < oz * 1.6) { const s = a.pos[0] <= b.pos[0] ? -1 : 1; a.pos[0] += s * ox / 2; b.pos[0] -= s * ox / 2; }
    else { const s = a.pos[2] <= b.pos[2] ? -1 : 1; a.pos[2] += s * oz / 2; b.pos[2] -= s * oz / 2; }
  }
}

function evalProp(S, p, t) {
  const g = (k, d) => sample(p.tr, k, t, d);
  const sc = g('scale', 1), sq = g('sq', ONE), s3 = Array.isArray(sc) ? sc : [sc, sc, sc];
  const q = {};
  for (const k of p.pkeys) q[k] = sample(p.tr, 'p:' + k, t, p.baseP[k]);
  return { pos: g('pos', D3), rot: g('rot', D3), scale: [s3[0] * sq[0], s3[1] * sq[1], s3[2] * sq[2]], vis: g('vis', true) !== false, attach: g('attach', null), ground: g('ground', 0), q };
}

const camBase = new THREE.Vector3();
let lastReport = null, lastCam = null;
function renderAt(t) {
  const S = shotAt(t); activate(S);
  const sh = S.shot, u = clamp((t - sh.t0) / Math.max(.001, sh.t1 - sh.t0));

  // ---- props (world-placed)
  const PS = S.props.map(p => ({ p, s: evalProp(S, p, t) }));
  for (const { p, s } of PS) { const vis = s.vis; if (!s.attach) { if (p.ent.attached) { scene.add(p.ent.root); p.ent.attached = null; } p.ent.setVisible(vis); if (vis) p.ent.place({ pos: s.pos, rot: s.rot, scale: s.scale, ground: s.ground }); } }

  // ---- actors
  const AL = S.actors.map(a => evalActor(S, a, t));
  for (const A of AL) {   // body turns toward a target (partial yaw so the face stays readable)
    A.ent = A.a.ent;
    if (A.faceTo) { const tp = targetPos(S, A.faceTo, wp); if (tp) { const dx = tp.x - A.pos[0], dz = tp.z - A.pos[2]; A.rot[1] += Math.atan2(dx, Math.max(dz, .2)) / D2R * A.faceW; } }
    // extents for separation (half-size of the footprint)
    const mn = A.ent.min, mx = A.ent.max, sx = A.scale[0], sz = A.scale[2];
    A.hx = Math.max(-mn[0], mx[0]) * sx * .82; A.hz = Math.max(-mn[2], mx[2]) * sz * .8; A.hy = (mx[1] - mn[1]) * A.scale[1] * .5;
  }
  separate(AL);
  for (const A of AL) { A.ent.setVisible(true); A.ent.place({ pos: A.pos, rot: A.rot, scale: A.scale, ground: A.ground }); A.a.rig.pose(A.st); }

  // ---- attach props to actor/prop anchors
  for (const { p, s } of PS) {
    if (!s.attach) continue;
    const [oid, an = 'top'] = String(s.attach).split('.'); const owner = findEntity(S, oid), anchor = owner?.anchors?.[an];
    if (!anchor) { p.ent.setVisible(false); continue; }
    if (p.ent.attached !== s.attach) { anchor.add(p.ent.root); p.ent.attached = s.attach; }
    const os = owner.sq.scale; p.ent.setVisible(s.vis);
    p.ent.placeLocal({ pos: s.pos, rot: s.rot, scale: [s.scale[0] / os.x, s.scale[1] / os.y, s.scale[2] / os.z] });
  }
  scene.updateMatrixWorld(true);

  // ---- eye tracking toward targets
  for (const A of AL) {
    if (!A.lookAt) continue;
    const tp = targetPos(S, A.lookAt, wp); if (!tp) continue;
    A.ent.root.worldToLocal(tp); const dz = Math.max(tp.z, .6);
    const lx = clamp(Math.atan2(tp.x, dz) / .8, -1, 1), ly = clamp(Math.atan2(tp.y, Math.hypot(tp.x, dz)) / .55, -1, 1);
    A.st.lookx = lerp(A.st.lookx, lx, A.lookW); A.st.looky = lerp(A.st.looky, ly, A.lookW);
    A.a.rig.pose(A.st);
  }

  // ---- prop animation (rain avoids actors)
  const solids = AL.map(A => A.ent.box);
  for (const { p, s } of PS) if (p.inst.update && p.ent.root.visible) p.inst.update(s.q, t, p.ent, { solids, t });

  // ---- look + lights
  const lk = lookAtTime(S.looks, t), look = lk;
  skyU.top.value.set(look.top); skyU.bot.value.set(look.bot); scene.fog.color.set(look.fog);
  S.set.update(look, t);
  let fl = 0, shakeX = 0, shakeY = 0, flashCol = null;
  for (const ev of S.events) {
    const lt = t - ev.t;
    if (ev.type === 'flash' && lt >= 0 && lt < (ev.dur ?? .25) * 2) { const f = (ev.amp ?? 1) * Math.exp(-lt * 4 / (ev.dur ?? .25)); if (f > fl) { fl = f; flashCol = ev.color; } }
    if (ev.type === 'shake' && lt >= 0 && lt < (ev.dur ?? .5) * 2) { const d = Math.exp(-lt * 5 / (ev.dur ?? .5)) * (ev.amp ?? .1), fr = ev.freq ?? 60; shakeY += Math.sin(lt * fr) * d; shakeX += Math.sin(lt * fr * .83 + 1) * d * .6; }
  }
  let cx = 0, cz = 0, n = 0; for (const A of AL) { cx += A.pos[0]; cz += A.pos[2]; n++; } if (n) { cx /= n; cz /= n; }
  hemi.color.set(look.hemiSky); hemi.groundColor.set(look.hemiGnd); hemi.intensity = look.hemiI + fl * .8;
  key.color.set(look.key); key.intensity = look.keyI + fl * 3.5; key.target.position.set(cx * .8, 0, cz); key.position.set(cx * .8 - 5, 12, 9 + cz);
  rim.color.set(look.rim); rim.intensity = look.rimI; spot.color.set(look.spot); spot.intensity = look.spotI; spot.position.set(cx * .6, 16, 8); spot.target.position.set(cx * .6, 0, .5);
  bounce.intensity = look.bounce; bounce.position.set(AL[0] ? AL[0].pos[0] : cx, .8, 2.6);
  scene.environmentIntensity = look.env + fl * .5; renderer.toneMappingExposure = look.exp + fl * .15;
  flashQ.visible = fl > .01; flashQ.material.opacity = Math.min(1, fl * .28); if (flashCol) flashQ.material.color.set(flashCol); else flashQ.material.color.set('#ffffff');
  const fin = sh.fadeIn ? 1 - clamp((t - sh.t0) / sh.fadeIn) : 0, fout = sh.fadeOut ? clamp((t - (sh.t1 - sh.fadeOut)) / sh.fadeOut) : 0;
  fadeQ.visible = Math.max(fin, fout) > .005; fadeQ.material.opacity = Math.max(fin, fout);

  // ---- camera: keyframed orbit + slow push-in + sway + shake events
  const cam = sh.camera || {}, ct = S.cam, gg = (k, d) => sample(ct, k, t, d);
  const tgt = gg('target', [0, 2.2, 0]).slice();
  if (cam.follow) { const fe = findEntity(S, cam.follow.id); if (fe) { const k = cam.follow.k ?? .5; tgt[0] = lerp(tgt[0], fe.root.position.x, k); if (cam.follow.y) tgt[1] = lerp(tgt[1], fe.root.position.y, cam.follow.y); } }
  const push = cam.push ?? .05, sway = cam.sway ?? .25;
  const dist = gg('dist', 15) * (1 - push * (u * u * (3 - 2 * u))), fov = gg('fov', 30);
  const az = (gg('az', 0) + Math.sin(t * .35) * sway) * D2R, el = (gg('el', 10) + Math.sin(t * .27 + 1) * sway * .5) * D2R;
  camera.position.set(tgt[0] + Math.sin(az) * Math.cos(el) * dist, tgt[1] + Math.sin(el) * dist, tgt[2] + Math.cos(az) * Math.cos(el) * dist);
  camera.up.set(0, 1, 0); camera.lookAt(tgt[0], tgt[1], tgt[2]);
  const roll = gg('roll', 0); if (roll) camera.rotateZ(roll * D2R);
  camera.translateX(shakeX); camera.translateY(shakeY);
  if (camera.fov !== fov) { camera.fov = fov; camera.updateProjectionMatrix(); } fitPlanes(fov);
  sky.position.copy(camera.position);
  camera.updateMatrixWorld(true);

  lastReport = { S, AL };
  renderer.render(scene, camera);
}

// ------------------------------------------------------------------ public API
window.loadShots = async (json) => {
  SHEET = json; SHEET.fps = SHEET.fps || 30;
  SHEET.shots.forEach((s, i) => { if (s.t1 === undefined) s.t1 = (SHEET.shots[i + 1]?.t0 ?? SHEET.dur ?? s.t0 + 3); });
  SHEET.dur = SHEET.dur || SHEET.shots[SHEET.shots.length - 1].t1;
  built.clear(); active = null; return { fps: SHEET.fps, dur: SHEET.dur, shots: SHEET.shots.length };
};
window.renderAt = t => { renderAt(t); return true; };
window.dataURL = (fmt = 'image/png', q = .95) => renderer.domElement.toDataURL(fmt, q);
/** On-screen size of every actor in the last rendered frame (pixels) + warnings. */
window.report = () => {
  if (!lastReport) return [];
  return lastReport.AL.map(A => {
    const bb = new THREE.Box3().setFromObject(A.ent.root), c = [];
    for (let i = 0; i < 8; i++) c.push(new THREE.Vector3(i & 1 ? bb.max.x : bb.min.x, i & 2 ? bb.max.y : bb.min.y, i & 4 ? bb.max.z : bb.min.z).project(camera));
    const x0 = Math.min(...c.map(v => v.x)), x1 = Math.max(...c.map(v => v.x)), y0 = Math.min(...c.map(v => v.y)), y1 = Math.max(...c.map(v => v.y));
    const px = v => [(v[0] * .5 + .5) * W, (1 - (v[1] * .5 + .5)) * H];
    const [l, top] = px([x0, y1]), [r, bot] = px([x1, y0]);
    const warn = []; if (l < -2 || r > W + 2 || top < -2 || bot > H + 2) warn.push('clipped by frame');
    if (A.ent.box.y0 < A.ground - .02) warn.push('below floor'); if ((bot - top) * 1920 / H < 340) warn.push('under 340px@1080x1920');
    return { id: A.a.id, hpx: Math.round((bot - top) * 1920 / H), wpx: Math.round((r - l) * 1920 / H), left: Math.round(l), top: Math.round(top), right: Math.round(r), bottom: Math.round(bot), warn };
  });
};
window.ready = true;
