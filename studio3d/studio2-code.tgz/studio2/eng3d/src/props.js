// Prop library. Each entry: (params) => { content, pivot, min, max, clamp?, blob?, anchors?, update?(p, t, ent, ctx) }
// Content is authored with its origin at the base-centre (y up). `pos` in the shot sheet places that base-centre.
// Everything is soft-material, bevelled, and gets an automatic contact shadow unless noted.
import { THREE, M, mesh, tube, rbox, extrude, addShadow, canvasTex, radialTex, woodTex, starGeo, mGold, mWhite, mInk, mMouth, mMetal } from './kit.js';
import { makeBurst, makeSplash } from './fx.js';
import { clamp, lerp, seg, smooth, hash, D2R } from './util.js';

const V = (...a) => new THREE.Vector3(...a);
const fit = (c, text, max, px, weight = 900) => { let s = px; c.font = `${weight} ${s}px Inter, sans-serif`; while (c.measureText(text).width > max && s > 20) { s -= 4; c.font = `${weight} ${s}px Inter, sans-serif`; } return s; };

export const PROPS = {};

// ================================================================== storm cloud
PROPS.cloud = (P) => {
  const C = new THREE.Group(), Y0 = 1.25; C.position.y = Y0;
  const mc = M('#7f87b6', { roughness: .85, sheen: .7, sheenColor: new THREE.Color(P.tint || '#b6bff0'), sheenRoughness: .6 });
  const mcD = M('#626a9a', { roughness: .9 });
  if (P.color) { mc.color.set(P.color); mcD.color.set(P.color).multiplyScalar(.78); }
  const puffs = [[0, 0, 0, 1.1], [-1.05, -.2, .05, .8], [1.05, -.15, 0, .85], [-.5, .65, -.05, .75], [.55, .7, -.1, .7], [1.75, -.35, 0, .5], [-1.75, -.35, 0, .52], [0, -.4, .45, .85], [-.9, -.55, .35, .55], [.9, -.5, .35, .6]];
  const pg = new THREE.Group(); pg.scale.set(1, 1, .62); C.add(pg);
  puffs.forEach(([x, y, z, r], i) => pg.add(mesh(new THREE.SphereGeometry(r, 32, 24), i % 3 === 2 ? mcD : mc, x, y, z)));
  const face = new THREE.Group(); face.position.set(0, -.05, .86); C.add(face);
  const E = [];
  for (const sx of [-1, 1]) {
    const e = new THREE.Group(); e.position.set(sx * .42, .05, 0); face.add(e);
    const s = mesh(new THREE.SphereGeometry(.22, 24, 16), mWhite); s.scale.set(1, 1.05, .5); e.add(s);
    e.add(mesh(new THREE.SphereGeometry(.09, 16, 12), mInk, sx * -.03, -.02, .08));
    const lid = mesh(rbox(.58, .3, .1, .04, 2), mc, 0, .27, .06); e.add(lid);
    const brow = mesh(rbox(.5, .1, .09, .04, 2), mInk, 0, .43, .05); e.add(brow);
    E.push({ lid, brow, sx });
  }
  const smug = tube([[-.32, -.38, 0], [-.1, -.5, 0], [.12, -.46, 0], [.36, -.28, 0]], .05, mInk); face.add(smug);
  const laugh = mesh(new THREE.SphereGeometry(.28, 24, 16), mMouth, 0, -.45, 0); laugh.scale.set(1.3, .8, .3); laugh.visible = false; face.add(laugh);
  addShadow(C);
  const bs = new THREE.Shape(); [[-.2, 0], [.25, 0], [.02, -1.4], [.4, -1.4], [-.35, -3.2], [-.1, -1.9], [-.42, -1.9]].forEach((p, i) => (i ? bs.lineTo(...p) : bs.moveTo(...p)));
  const bolt = new THREE.Mesh(new THREE.ExtrudeGeometry(bs, { depth: .1, bevelEnabled: false }), new THREE.MeshBasicMaterial({ color: '#fff6b0', toneMapped: false, fog: false })); bolt.visible = false; bolt.position.set(-.5, -1.0, .3); C.add(bolt);
  return {
    content: C, pivot: [0, Y0, 0], min: [-2.3, 0, -.9], max: [2.3, 2.65, .9], clamp: false, blob: .45, anchors: { under: bolt, face },
    // params: mood 'smug'|'laugh', rage 0..1 (angry lids), bolt 0/1 (lightning to the ground), rumble 0..1 (shiver), tint
    update(p, t, ent) {
      const rage = p.rage ?? .3;
      E.forEach(e => { e.lid.rotation.z = e.sx * (.42 + rage * .35); e.lid.position.y = .27 - rage * .03; e.brow.rotation.z = e.sx * (.42 + rage * .35); });
      const lau = p.mood === 'laugh'; laugh.visible = lau; smug.visible = !lau;
      C.position.x = Math.sin(t * 38) * .06 * (p.rumble || 0);
      bolt.visible = (p.bolt || 0) > .5;
      if (bolt.visible) { const sy = ent.sq.scale.y; bolt.scale.set(1.1, Math.max(.2, (ent.root.position.y - 1.0 * sy - ent.ground) / 3.2 / sy), 1); }
      face.position.y = -.05 + (lau ? Math.abs(Math.sin(t * 11)) * .05 : 0);
    },
  };
};

// ================================================================== rain (emitter: pos = centre of the TOP edge; falls to world floor)
PROPS.rain = (P) => {
  const N = P.n || 220, W = P.w || 6, Dp = P.d || 2.4, root = new THREE.Group();
  const mat = new THREE.MeshBasicMaterial({ color: P.color || '#d5ecff', transparent: true, opacity: .8, fog: false });
  const im = new THREE.InstancedMesh(new THREE.CapsuleGeometry(.02, .32, 3, 6), mat, N); im.frustumCulled = false; root.add(im);
  const S = Array.from({ length: N }, (_, i) => ({ o: hash(i + 1), dx: hash(i + 600) - .5, dz: hash(i + 900) - .5, th: hash(i + 1200), v: (P.speed || 13) + hash(i + 1500) * 4 }));
  const NR = 14, rings = [];
  for (let i = 0; i < NR; i++) { const r = new THREE.Mesh(new THREE.RingGeometry(.86, 1, 32), new THREE.MeshBasicMaterial({ color: '#e8f5ff', transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -3 })); r.rotation.x = -Math.PI / 2; r.visible = false; root.add(r); rings.push(r); }
  const d = new THREE.Object3D();
  return {
    content: root, pivot: [0, 0, 0], min: [-W / 2, 0, -Dp / 2], max: [W / 2, .01, Dp / 2], clamp: false, blob: 0, noShadow: true,
    // params: w, d, n, speed, amt 0..1 (animated intensity), slant (x drift per unit fall), floor (world y of ground), ripples
    update(p, t, ent, ctx) {
      const amt = p.amt ?? 1, H = Math.max(.5, ent.root.position.y - (P.floor || ent.ground || 0)), rp = ent.root.position, slant = P.slant ?? -.12;
      for (let i = 0; i < N; i++) {
        const s = S[i]; const run = ((t * s.v / H + s.o) % 1 + 1) % 1, fall = run * H;
        const x = s.dx * W, z = s.dz * Dp, wx = rp.x + x + slant * fall, wy = rp.y - fall;
        let vis = amt > s.th * .98 + .02;
        if (vis && ctx.solids) for (const b of ctx.solids) { const mx = (b.x1 - b.x0) * .12; if (wx > b.x0 + mx && wx < b.x1 - mx && rp.z + z > b.z0 && rp.z + z < b.z1 && wy < b.y1 + .1 && wy > b.y0 - .5) { vis = false; break; } }
        if (!vis) d.scale.setScalar(0); else { d.position.set(x + slant * fall, -fall, z); d.scale.set(1, 1 + (s.v - 13) * .08, 1); d.rotation.z = -Math.atan(slant); }
        d.updateMatrix(); im.setMatrixAt(i, d.matrix);
      }
      im.instanceMatrix.needsUpdate = true;
      const on = (P.ripples !== false) && amt > .3;
      rings.forEach((r, i) => {
        if (!on) { r.visible = false; return; }
        const per = .6 + hash(i + 3000) * .5, o = hash(i + 3100) * 2, n = Math.floor((t - o) / per), age = (t - o - n * per) / per;
        r.visible = n >= 0; if (!r.visible) return;
        const rr = (.25 + hash(i + 3400) * .3) * (.25 + age * 1.6);
        r.position.set((hash(n * 31 + i * 7) - .5) * W * .8, -H + .035, (hash(n * 17 + i * 5 + 3) - .5) * Dp * .8); r.scale.set(rr, rr * .72, 1); r.material.opacity = .7 * (1 - age) * (1 - age);
      });
    },
  };
};

// ================================================================== puddle
PROPS.puddle = (P) => {
  const rx = P.rx || 2.3, rz = P.rz || 1.3, G = new THREE.Group(), s = new THREE.Group(); G.add(s);
  const pMat = M(P.color || '#6fb4f6', { roughness: .06, clearcoat: 1, clearcoatRoughness: .03, transparent: true, opacity: .9, envMapIntensity: 2.2 });
  const pRim = M('#b9dcfb', { roughness: .2, transparent: true, opacity: .55 });
  const pD = mesh(new THREE.CircleGeometry(1, 64), pMat, 0, .018, 0), pR = mesh(new THREE.CircleGeometry(1.07, 64), pRim, 0, .01, 0);
  pD.rotation.x = pR.rotation.x = -Math.PI / 2; pD.receiveShadow = true; s.add(pR, pD);
  const rings = Array.from({ length: 8 }, () => { const r = new THREE.Mesh(new THREE.RingGeometry(.86, 1, 32), new THREE.MeshBasicMaterial({ color: '#e8f5ff', transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide })); r.rotation.x = -Math.PI / 2; r.position.y = .03; G.add(r); return r; });
  return {
    content: G, pivot: [0, 0, 0], min: [-rx, 0, -rz], max: [rx, .02, rz], clamp: false, blob: 0, noShadow: true,
    // params: rx, rz, grow 0..1 (animated), ripples 0..1 (rain intensity), color
    update(p, t) {
      const gr = clamp(p.grow ?? 1), rpl = p.ripples ?? 1;
      G.visible = gr > .01; s.scale.set(rx * Math.max(gr, .001), 1, rz * Math.max(gr, .001));
      rings.forEach((r, i) => {
        const per = .7 + hash(i + 11) * .5, o = hash(i + 33) * 2, n = Math.floor((t - o) / per), age = (t - o - n * per) / per;
        r.visible = gr > .25 && rpl > .2 && n >= 0; if (!r.visible) return;
        const rr = (.25 + hash(i + 55) * .3) * (.25 + age * 1.6);
        r.position.set((hash(n * 31 + i * 7) * 2 - 1) * rx * gr * .75, .032, (hash(n * 17 + i * 5 + 3) * 2 - 1) * rz * gr * .65); r.scale.set(rr, rr * .72, 1); r.material.opacity = .75 * (1 - age) * (1 - age);
      });
    },
  };
};

// ================================================================== RAM stick (stand | stack | fan)
const ramGeo = {};
function ramStick(P, mats) {
  const g = new THREE.Group();
  ramGeo.pcb = ramGeo.pcb || rbox(.95, 2.45, .12, .06, 3); ramGeo.chip = ramGeo.chip || rbox(.62, .4, .07, .04, 2); ramGeo.lab = ramGeo.lab || rbox(.5, .22, .02, .02, 2);
  ramGeo.led = ramGeo.led || rbox(.8, .09, .08, .04, 2); ramGeo.fin = ramGeo.fin || rbox(.05, .22, .04, .015, 2); ramGeo.dot = ramGeo.dot || new THREE.CylinderGeometry(.035, .035, .02, 10);
  g.add(mesh(ramGeo.pcb, mats.pcb, 0, 1.5, 0));
  [.0, .5, 1.0, 1.5].forEach((o, i) => { g.add(mesh(ramGeo.chip, mats.chip, 0, 1.05 + o * .86, .09)); g.add(mesh(ramGeo.dot, mats.dotm, -.2, 1.05 + o * .86 + .11, .13)).rotation.x = Math.PI / 2; });
  g.add(mesh(ramGeo.lab, mats.sp, 0, .72, .075));
  g.add(mesh(ramGeo.led, mats.led, 0, 2.66, .02));
  for (let i = 0; i < 9; i++) if (i !== 5) g.add(mesh(ramGeo.fin, mats.gold, -.4 + i * .1, .42, .0));
  return addShadow(g);
}
PROPS.ram = (P) => {
  const layout = P.layout || 'stand', n = Math.max(1, P.count || (layout === 'stand' ? 1 : 6));
  const mats = {
    pcb: M(P.color || '#14d6a2', { roughness: .35, clearcoat: .7 }), sp: M('#f6f8ff', { roughness: .3, clearcoat: .6 }), dotm: M('#8aa0b8', { roughness: .3 }),
    chip: M('#1a1f2e', { roughness: .4, clearcoat: .5 }), gold: mGold, led: new THREE.MeshStandardMaterial({ color: '#000', emissive: P.led || '#34e0ff', emissiveIntensity: 2, toneMapped: true }),
  };
  const G = new THREE.Group(); let min, max;
  const socket = (w) => { const s = new THREE.Group(); s.add(mesh(rbox(w, .34, .5, .08, 3), M('#2a3148', { roughness: .45, clearcoat: .4 }), 0, .17, 0)); [-1, 1].forEach(sx => s.add(mesh(rbox(.14, .5, .3, .05, 2), M('#f7d046', { roughness: .4 }), sx * (w / 2 - .02), .3, 0))); return addShadow(s); };
  if (layout === 'stand') {
    G.add(socket(1.3)); const s = ramStick(P, mats); s.position.y = 0; G.add(s); min = [-.7, 0, -.3]; max = [.7, 2.8, .3];
  } else if (layout === 'fan') {
    G.add(socket(1.6)); const sp = P.spread || 13;
    for (let i = 0; i < n; i++) { const a = (i - (n - 1) / 2) * sp; const s = ramStick(P, mats); const holder = new THREE.Group(); holder.position.set(0, .3, (i - (n - 1) / 2) * .03); holder.rotation.z = -a * D2R; s.position.y = -.3; holder.add(s); G.add(holder); }
    const ext = Math.sin(Math.min(80, (n - 1) / 2 * sp) * D2R) * 2.8 + .6; min = [-ext, 0, -.3]; max = [ext, 2.9, .3 + n * .03];
  } else {   // stack: lying flat, face up, slightly rotated
    for (let i = 0; i < n; i++) {
      const s = ramStick(P, mats), in1 = new THREE.Group(), out = new THREE.Group();
      s.position.y = -1.5; in1.add(s); in1.rotation.z = -Math.PI / 2; out.add(in1); out.rotation.x = -Math.PI / 2;
      out.position.set((hash(i + 7) - .5) * .25, .1 + i * .27, (hash(i + 9) - .5) * .2); out.rotation.y = (hash(i + 3) - .5) * .35; G.add(out);
    }
    min = [-1.45, 0, -.75]; max = [1.45, .3 + n * .27, .75];
  }
  return {
    content: G, pivot: [0, (min[1] + max[1]) / 2, 0], min, max, clamp: true, blob: .8, anchors: { top: Object.assign(G.add(new THREE.Object3D()) && G.children[G.children.length - 1], {}) },
    // params: layout stand|stack|fan, count, color (spreader), pcb, led, glow (LED pulse), spread (fan degrees)
    update(p, t) { mats.led.emissiveIntensity = (p.glow ?? 1) * (2 + .6 * Math.sin(t * 4)); },
  };
};

// ================================================================== cheap PC (laptop | box | tower)
PROPS.pc = (P) => {
  const kind = P.kind || 'laptop', G = new THREE.Group(), body = P.color || '#cfd5df';
  const mB = M(body, { roughness: .5, clearcoat: .35 });
  let min, max, update = null, anchors = {};
  if (kind === 'laptop') {
    G.add(mesh(rbox(2.7, .18, 1.9, .07, 4), mB, 0, .09, 0));
    const kb = canvasTex(256, 192, (g, w, h) => { g.fillStyle = '#272c3a'; g.fillRect(0, 0, w, h); g.fillStyle = '#4a5166'; for (let r = 0; r < 5; r++) for (let c = 0; c < 14; c++) g.fillRect(10 + c * 17, 10 + r * 18, 14, 14); g.fillStyle = '#3a4054'; g.fillRect(80, 106, 96, 60); }, 4);
    const kbm = mesh(new THREE.PlaneGeometry(2.3, 1.5), new THREE.MeshStandardMaterial({ map: kb, roughness: .6 }), 0, .185, .1); kbm.rotation.x = -Math.PI / 2; G.add(kbm);
    const hinge = new THREE.Group(); hinge.position.set(0, .2, -.9); G.add(hinge);
    const lid = new THREE.Group(); hinge.add(lid);
    lid.add(mesh(rbox(2.7, 1.8, .12, .07, 4), mB, 0, .9, 0));
    lid.add(mesh(rbox(2.5, 1.62, .04, .04, 2), M('#12141c', { roughness: .3, clearcoat: .8 }), 0, .9, .06));
    const st = P.text || 'PC';
    const sc = canvasTex(512, 320, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#9fd0ff'); gr.addColorStop(1, '#4b86e8'); g.fillStyle = gr; g.fillRect(0, 0, w, h); g.fillStyle = 'rgba(255,255,255,.9)'; g.fillRect(30, 30, w - 60, 40); g.fillStyle = 'rgba(255,255,255,.75)'; for (let i = 0; i < 5; i++) g.fillRect(50 + i * 70, 260 - (30 + (i * 47) % 100), 44, 30 + (i * 47) % 100); g.fillStyle = '#16315e'; fit(g, st, 300, 90); g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(st, w / 2, 130); });
    lid.add(mesh(new THREE.PlaneGeometry(2.36, 1.48), new THREE.MeshBasicMaterial({ map: sc, toneMapped: false }), 0, .9, .085));
    min = [-1.4, 0, -1], max = [1.4, 2.1, 1]; anchors.top = new THREE.Object3D(); anchors.top.position.set(0, .2, 0); G.add(anchors.top);
    update = (p) => { lid.rotation.x = lerp(90, -12, clamp(p.open ?? 1)) * D2R; };
  } else if (kind === 'box') {
    const cb = M(P.color || '#c99a62', { roughness: .8 });
    G.add(mesh(rbox(2.6, 1.9, 2.0, .09, 3), cb, 0, .95, 0));
    G.add(mesh(rbox(.5, 1.94, 2.04, .03, 2), M('#e7c690', { roughness: .6 }), 0, .95, 0));     // tape band over the top
    const lab = P.text || 'PC';
    const lt = canvasTex(256, 160, (g, w, h) => { g.fillStyle = '#fffaf0'; g.fillRect(0, 0, w, h); g.fillStyle = '#c9cfdd'; g.fillRect(14, 112, 150, 12); g.fillRect(14, 132, 100, 10); g.fillStyle = '#1a2036'; fit(g, lab, 180, 84); g.textAlign = 'left'; g.textBaseline = 'middle'; g.fillText(lab, 16, 50); }, 4);
    const lm = mesh(new THREE.PlaneGeometry(1.5, .94), new THREE.MeshStandardMaterial({ map: lt, roughness: .7 }), -.45, 1.0, 1.015); G.add(lm);
    min = [-1.3, 0, -1.02]; max = [1.3, 1.9, 1.02]; anchors.top = new THREE.Object3D(); anchors.top.position.set(0, 1.9, 0); G.add(anchors.top);
  } else {   // tower
    const mT = M(P.color || '#d9d4c7', { roughness: .55, clearcoat: .3 });
    G.add(mesh(rbox(1.6, 3.1, 2.1, .14, 4), mT, 0, 1.55, 0));
    [0, 1].forEach(i => G.add(mesh(rbox(1.2, .26, .06, .03, 2), M('#2a2f3c', { roughness: .4 }), 0, 2.45 - i * .42, 1.07)));
    G.add(mesh(new THREE.CylinderGeometry(.14, .14, .06, 20), new THREE.MeshStandardMaterial({ color: '#000', emissive: '#4cff9a', emissiveIntensity: 2 }), 0, 1.4, 1.08)).rotation.x = Math.PI / 2;
    for (let i = 0; i < 6; i++) G.add(mesh(rbox(1.0, .04, .04, .015, 2), M('#8a8f9c'), 0, .5 + i * .1, 1.07));
    min = [-.8, 0, -1.05]; max = [.8, 3.1, 1.05]; anchors.top = new THREE.Object3D(); anchors.top.position.set(0, 3.1, 0); G.add(anchors.top);
  }
  addShadow(G);
  return { content: G, pivot: [0, (max[1]) / 2, 0], min, max, clamp: true, blob: .85, anchors, update };   // params: kind laptop|box|tower, color, text, open 0..1 (laptop lid)
};

// ================================================================== AI boom: server tower | rocket
PROPS.server = (P) => {
  const kind = P.kind || 'server', G = new THREE.Group(), glowCol = P.glow || '#56e1ff';
  const gl = new THREE.Sprite(new THREE.SpriteMaterial({ map: radialTex([[0, 'rgba(255,255,255,.95)'], [.4, 'rgba(255,255,255,.4)'], [1, 'rgba(255,255,255,0)']], 256), color: glowCol, transparent: true, opacity: .0, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
  let leds = [], flame = null, update, min, max;
  if (kind === 'rocket') {
    const R = 0.62, Hh = 3.8, prof = (y) => { const u = y / Hh; return R * Math.min(1, Math.pow(Math.sin(Math.min(1, u * 1.5) * Math.PI / 2), .6)) * Math.pow(Math.cos(Math.max(0, (u - .45) / .55) * Math.PI / 2), .75); };
    const pts = [], npts = 40; for (let i = 0; i <= npts; i++) { const y = .25 + (i / npts) * (Hh - .25); pts.push(new THREE.Vector2(Math.max(.001, prof(y - .25 + .0001) + (i < 3 ? i * .05 : 0)), y)); }
    const bodyPts = pts.filter(p => p.y < 2.75), nosePts = pts.filter(p => p.y >= 2.7);
    const mBodyR = M(P.color || '#f6f7ff', { roughness: .25, clearcoat: 1, clearcoatRoughness: .1 }), mNose = M(P.accent || '#ff4b4b', { roughness: .3, clearcoat: .8 });
    G.add(mesh(new THREE.LatheGeometry(bodyPts, 40), mBodyR)); G.add(mesh(new THREE.LatheGeometry(nosePts, 40), mNose));
    G.add(mesh(new THREE.CylinderGeometry(.34, .44, .3, 24), M('#3a4156', { roughness: .4, metalness: .4 }), 0, .15, 0));
    for (let i = 0; i < 3; i++) { const f = mesh(extrude([[0, 0], [.75, -.25], [.75, -.8], [0, -1.2]].map(p => [p[0] + .45, p[1] + 1.35]), .1, .05), mNose, 0, 0, 0); const h = new THREE.Group(); h.rotation.y = i * Math.PI * 2 / 3; f.rotation.y = Math.PI / 2; f.position.set(0, 0, 0); h.add(f); G.add(h); }
    const win = new THREE.Group(); win.position.set(0, 2.15, .55); G.add(win);
    win.add(mesh(new THREE.TorusGeometry(.26, .07, 12, 28), mMetal)); const gm = mesh(new THREE.CircleGeometry(.26, 24), M('#2a6ae0', { roughness: .1, clearcoat: 1, emissive: '#1b4fb5', emissiveIntensity: .5 }), 0, 0, .0); win.add(gm); win.rotation.x = -.1;
    flame = new THREE.Group(); flame.position.y = .0; G.add(flame);
    const fo = mesh(new THREE.ConeGeometry(.42, 1.6, 20, 1, true), new THREE.MeshBasicMaterial({ color: '#ff9a2a', transparent: true, opacity: .9, side: THREE.DoubleSide, toneMapped: false })); fo.rotation.x = Math.PI; fo.position.y = -.8;
    const fi = mesh(new THREE.ConeGeometry(.24, 1.0, 20, 1, true), new THREE.MeshBasicMaterial({ color: '#fff3a8', side: THREE.DoubleSide, toneMapped: false })); fi.rotation.x = Math.PI; fi.position.y = -.55; flame.add(fo, fi);
    if (P.pad !== false) G.add(mesh(new THREE.CylinderGeometry(1.2, 1.35, .22, 32), M('#8892a8', { roughness: .6 }), 0, -.0, 0)).position.y = .0;
    min = [-1.4, 0, -1.4]; max = [1.4, Hh + .05, 1.4];
    gl.position.set(0, 1.8, -.6); gl.scale.setScalar(8);
    update = (p, t) => { const th = clamp(p.thrust ?? 0); flame.visible = th > .02; flame.scale.set(.6 + th * .5, th * (1 + .18 * Math.sin(t * 40)) + .01, .6 + th * .5); gl.material.opacity = (p.glow ?? 0) * .55; };
  } else {
    const mR = M(P.color || '#1c2646', { roughness: .35, clearcoat: .8, clearcoatRoughness: .2 }), mBl = M('#2b3865', { roughness: .35, clearcoat: .7 });
    G.add(mesh(rbox(2.2, .3, 1.7, .1, 3), M('#10162b', { roughness: .5 }), 0, .15, 0));
    G.add(mesh(rbox(1.95, 3.9, 1.5, .16, 4), mR, 0, 2.25, 0));
    G.add(mesh(rbox(2.1, .22, 1.6, .09, 3), mBl, 0, 4.3, 0));
    const ledCols = ['#56e1ff', '#5dffa1', '#ff6bd5', '#ffd25a'];
    for (let i = 0; i < 7; i++) {
      const y = .75 + i * .5; G.add(mesh(rbox(1.66, .4, .12, .06, 3), i % 2 ? mBl : M('#243055', { roughness: .35, clearcoat: .7 }), 0, y, .76));
      G.add(mesh(rbox(.7, .06, .05, .02, 2), M('#0b0f1e'), -.35, y, .83));
      for (let k = 0; k < 4; k++) { const lm = new THREE.MeshBasicMaterial({ color: ledCols[(i + k) % 4], toneMapped: false }); leds.push({ lm, base: new THREE.Color(ledCols[(i + k) % 4]), i: i * 4 + k }); G.add(mesh(rbox(.1, .1, .05, .03, 2), lm, .25 + k * .17, y, .84)); }
    }
    addShadow(G); min = [-1.15, 0, -.9]; max = [1.15, 4.45, .9];
    gl.position.set(0, 2.4, -.5); gl.scale.setScalar(9);
    update = (p, t) => { const gw = p.glow ?? 0; gl.material.opacity = gw * .6; leds.forEach(l => { const on = hash(l.i * 3 + Math.floor(t * 5 + l.i)) > .3 ? 1 : .15; l.lm.color.copy(l.base).multiplyScalar(on * (.4 + gw * .8)); }); };
  }
  G.add(gl); addShadow(G);
  if (flame) flame.traverse(o => { o.castShadow = false; });
  return { content: G, pivot: [0, max[1] / 2, 0], min, max, clamp: true, blob: .9, update, anchors: {} };   // params: kind server|rocket, color, glow (0..1 aura), thrust (rocket flame 0..1), pad
};

// ================================================================== big arrow (down|up|left|right)
PROPS.arrow = (P) => {
  const dir = P.dir || 'down', col = P.color || '#e5322b', G = new THREE.Group(), Hh = P.h || 3.4, Wh = P.w || 2.3, Ws = Wh * .42;
  const pts = [[-Ws / 2, Hh], [Ws / 2, Hh], [Ws / 2, Hh * .46], [Wh / 2, Hh * .46], [0, 0], [-Wh / 2, Hh * .46], [-Ws / 2, Hh * .46]];
  const mA = M(col, { roughness: .28, clearcoat: .9, clearcoatRoughness: .15, emissive: col, emissiveIntensity: .12 });
  const shape = mesh(extrude(pts.map(p => [p[0] * .86, p[1] * .9 + .09]), .34, .13, 6), mA, 0, 0, 0); G.add(shape);
  const hl = mesh(rbox(Ws * .25, Hh * .42, .04, .02, 2), M('#ffffff', { roughness: .3, transparent: true, opacity: .35 }), -Ws * .22, Hh * .72, .3); G.add(hl);
  const holder = new THREE.Group(); holder.add(G); const rotz = { down: 0, up: 180, left: 90, right: -90 }[dir] || 0;
  const pv = [0, Hh / 2, 0]; G.position.y = -Hh / 2; holder.rotation.z = rotz * D2R; holder.position.y = Hh / 2;
  addShadow(holder); const w2 = Wh / 2 + .15, h2 = Hh / 2 + .1;
  const outer = new THREE.Group(); outer.add(holder);
  const horiz = dir === 'left' || dir === 'right';
  const hx = horiz ? h2 : w2, hy = horiz ? w2 : h2;
  holder.position.y = hy; // centre sits hy above base
  return { content: outer, pivot: [0, hy, 0], min: [-hx, 0, -.3], max: [hx, hy * 2, .3], clamp: true, blob: .5, anchors: {}, update(p, t) { mA.emissiveIntensity = .12 + (p.pulse || 0) * (.35 + .25 * Math.sin(t * 8)); } };   // params: dir, color, w, h, pulse 0..1
};

// ================================================================== slide / ramp
PROPS.ramp = (P) => {
  const len = P.len || 5, h = P.h || 3, w = P.w || 2, dir = P.dir || 1, G = new THREE.Group(), col = P.color || '#ffb62e';
  const mS = M(col, { roughness: .35, clearcoat: .7 }), mR = M('#e9edf7', { roughness: .4, clearcoat: .4 });
  const ang = Math.atan2(h - .3, len - 1.2), L = Math.hypot(len - 1.2, h - .3);
  const sl = new THREE.Group(); sl.position.set(-len / 2 + 1.2, h - .15, 0); sl.rotation.z = -ang; G.add(sl);
  sl.add(mesh(rbox(L, .22, w, .08, 3), mS, L / 2, -.0, 0));
  [-1, 1].forEach(s => sl.add(mesh(rbox(L, .34, .16, .06, 3), mR, L / 2, .22, s * (w / 2 - .04))));
  G.add(mesh(rbox(1.3, .28, w, .09, 3), mR, -len / 2 + .65, h - .14, 0));
  [-1, 1].forEach(s => { G.add(mesh(new THREE.CylinderGeometry(.09, .09, h - .28, 14), mMetal, -len / 2 + .3, (h - .28) / 2, s * (w / 2 - .15))); G.add(mesh(new THREE.CylinderGeometry(.09, .09, h * .5, 14), mMetal, -len / 2 + 1.25, h * .22, s * (w / 2 - .15))); });
  addShadow(G); G.scale.x = dir; const a = new THREE.Object3D(); a.position.set(-len / 2 + .7, h, 0); G.add(a);
  return { content: G, pivot: [0, h / 2, 0], min: [-len / 2, 0, -w / 2], max: [len / 2, h + .3, w / 2], clamp: true, blob: .7, anchors: { top: a } };   // params: len, h, w, dir (1 = high on the left, -1 mirrored), color
};

// ================================================================== wooden shelf / podium
PROPS.podium = (P) => {
  const h = P.h || 1.5, G = new THREE.Group(), tex = woodTex(P.color || '#c58b4e'), mW = new THREE.MeshPhysicalMaterial({ map: tex, roughness: .55, clearcoat: .3 }), mD = new THREE.MeshPhysicalMaterial({ map: woodTex('#a96f38', 5), roughness: .6, clearcoat: .2 });
  const w = P.w || 2.6, d = P.d || 2.0;
  G.add(mesh(rbox(w, .3, d, .08, 3), mD, 0, .15, 0)); G.add(mesh(rbox(w - .4, h - .5, d - .3, .08, 3), mW, 0, h / 2 - .02, 0));
  G.add(mesh(rbox(w, .24, d, .09, 3), mD, 0, h - .12, 0)); G.add(mesh(rbox(w - .8, h - 1.0, .06, .04, 2), mD, 0, h * .5 - .05, (d - .3) / 2 + .02));
  addShadow(G); const top = new THREE.Object3D(); top.position.y = h; G.add(top);
  return { content: G, pivot: [0, h / 2, 0], min: [-w / 2, 0, -d / 2], max: [w / 2, h, d / 2], clamp: true, blob: .8, anchors: { top } };   // params: w, d, h, color. Top surface y = h.
};
PROPS.shelf = (P) => {
  const w = P.w || 3.8, h = P.h || 3.3, d = P.d || 1.1, tiers = P.tiers || 3, th = .16, G = new THREE.Group();
  const tex = woodTex(P.color || '#c58b4e', 2), mW = new THREE.MeshPhysicalMaterial({ map: tex, roughness: .55, clearcoat: .3 }), mD = new THREE.MeshPhysicalMaterial({ map: woodTex('#a96f38', 4), roughness: .6, clearcoat: .2 });
  [-1, 1].forEach(s => G.add(mesh(rbox(.18, h, d, .06, 3), mD, s * (w / 2 - .09), h / 2, 0)));
  G.add(mesh(rbox(w - .2, h, .08, .03, 2), mD, 0, h / 2, -d / 2 + .04));
  const anchors = {}, gap = (h - th) / tiers;
  for (let k = 0; k <= tiers; k++) { const yTop = th + k * gap; G.add(mesh(rbox(w, th, d, .05, 3), mW, 0, yTop - th / 2, 0)); const a = new THREE.Object3D(); a.position.y = yTop; G.add(a); anchors['p' + k] = a; }
  anchors.top = anchors['p' + tiers];
  addShadow(G);
  return { content: G, pivot: [0, h / 2, 0], min: [-w / 2, 0, -d / 2], max: [w / 2, h, d / 2], clamp: true, blob: .8, anchors };   // params: w,h,d,tiers. Plank k top surface y = 0.16 + k*(h-0.16)/tiers (anchors p0..pN, top)
};

// ================================================================== price-tag sign on a stick (any text via canvas)
PROPS.sign = (P) => {
  const w = P.w || 2.6, h = P.h || 1.7, ph = P.pole || 3.0, G = new THREE.Group();
  const W = 512, Hh = Math.round(512 * h / w);
  const tex = canvasTex(W, Hh, () => {}); const cv = tex.userData.canvas, g = tex.userData.g;
  let last = null;
  const redraw = (main, sub) => {
    const key = main + '|' + sub; if (key === last) return; last = key;
    g.clearRect(0, 0, W, Hh); g.fillStyle = P.bg || '#fff7df'; g.fillRect(0, 0, W, Hh);
    g.fillStyle = P.accent || '#e5322b'; g.fillRect(0, 0, W, Hh * .17);
    g.fillStyle = 'rgba(0,0,0,.08)'; g.beginPath(); g.arc(Hh * .12 + 8, Hh * .1, Hh * .045, 0, 6.3); g.fill();
    g.fillStyle = P.ink || '#1a2036'; g.textAlign = 'center'; g.textBaseline = 'middle';
    if (sub) { fit(g, sub, W - 80, 62, 800); g.fillText(sub, W / 2, Hh * .33); }
    const size = fit(g, main, W - 70, sub ? 190 : 230); g.fillText(main, W / 2, sub ? Hh * .64 : Hh * .6);
    tex.needsUpdate = true;
  };
  const mp = M(P.bg || '#fff7df', { roughness: .45, clearcoat: .5 });
  const pole = mesh(new THREE.CylinderGeometry(.07, .07, ph, 14), M('#8a6a45', { roughness: .6 }), 0, ph / 2, 0); G.add(pole);
  const foot = mesh(new THREE.SphereGeometry(.55, 24, 12), M('#6b7288', { roughness: .5, clearcoat: .3 }), 0, 0, 0); foot.scale.y = .25; G.add(foot);
  const panel = new THREE.Group(); panel.position.set(0, ph - .1, .12); G.add(panel);
  panel.add(mesh(rbox(w, h, .14, .2, 4), mp, 0, h / 2, 0));
  const face = mesh(new THREE.PlaneGeometry(w - .12, (w - .12) * Hh / W), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false }), 0, h / 2, .075); panel.add(face);
  panel.add(mesh(new THREE.TorusGeometry(.09, .03, 8, 16), mMetal, -w / 2 + .3, h - .22, .08));
  addShadow(G); face.castShadow = false;
  return {
    content: G, pivot: [0, (ph + h) / 2, 0], min: [-w / 2, 0, -.2], max: [w / 2, ph + h * .9, .25], clamp: true, blob: .6, anchors: {},
    // params: text | value+prefix+suffix+dec (animated number), sub (small line), bg, ink, accent, w, h, pole, tilt (deg), swing (deg amplitude)
    update(p, t) {
      let main = p.text ?? P.text ?? ''; if (p.value !== undefined) main = (P.prefix || '') + Number(p.value).toFixed(P.dec ?? 0) + (P.suffix || '');
      redraw(String(main), String(p.sub ?? P.sub ?? ''));
      panel.rotation.z = ((p.tilt || 0) + Math.sin(t * 3) * (p.swing || 0)) * D2R;
    },
  };
};

// ================================================================== coins / star / burst
PROPS.coins = (P) => {   // static pile of coins
  const n = P.count || 8, G = new THREE.Group(), cg = new THREE.CylinderGeometry(.5, .5, .12, 28);
  for (let i = 0; i < n; i++) { const c = mesh(cg, mGold, (hash(i + 3) - .5) * .12, .07 + i * .125, (hash(i + 5) - .5) * .12); c.rotation.y = hash(i) * 6; G.add(c); }
  addShadow(G); const tp = new THREE.Object3D(); tp.position.y = .15 + n * .125; G.add(tp); return { content: G, pivot: [0, .5, 0], min: [-.6, 0, -.6], max: [.6, .15 + n * .125, .6], clamp: true, blob: .6, anchors: { top: tp } };
};
PROPS.star = (P) => {
  const m = mesh(starGeo((P.r || .6), .22), P.color ? M(P.color, { roughness: .3, emissive: P.color, emissiveIntensity: .25, clearcoat: .6 }) : mGold, 0, (P.r || .6), 0); addShadow(m);
  const G = new THREE.Group(); G.add(m);
  return { content: G, pivot: [0, (P.r || .6), 0], min: [-.7, 0, -.2], max: [.7, 1.3, .2], clamp: false, blob: .3, update(p, t) { m.rotation.y = (p.spin || 0) * t; } };   // params: r, color, spin (rad/s)
};
PROPS.burst = (P) => {
  const b = makeBurst(P.kind || 'coin', P.n || 26, P.seed || 1), G = new THREE.Group(); G.add(b.obj);
  return { content: G, pivot: [0, 0, 0], min: [0, 0, 0], max: [.01, .01, .01], clamp: false, blob: 0, noShadow: true,
    // params: kind coin|star|confetti, n, seed, at (absolute emission time), power, spread, size, life
    update(p, t, ent) { b.update(t - (p.at ?? P.at ?? 0), { power: p.power ?? 1, spread: p.spread ?? 1, size: p.size ?? 1, life: p.life ?? P.life ?? 2.8, floorY: (ent.ground || 0) - ent.root.position.y }); } };
};
PROPS.splash = (P) => {
  const s = makeSplash(P.seed || 1), G = new THREE.Group(); G.add(s.obj);
  return { content: G, pivot: [0, 0, 0], min: [0, 0, 0], max: [.01, .01, .01], clamp: false, blob: 0, noShadow: true, update(p, t, ent) { s.update(t - (p.at ?? P.at ?? 0), { power: p.power ?? 1, size: p.size ?? 1, floorY: (ent.ground || 0) - ent.root.position.y }); } };
};

// ================================================================== balloon (origin = end of the string)
PROPS.balloon = (P) => {
  const L = P.len || 2.6, G = new THREE.Group(), col = P.color || '#ff4d6d', R = .8;
  const mB = M(col, { roughness: .12, clearcoat: 1, clearcoatRoughness: .05, sheen: .5, sheenColor: new THREE.Color('#ffffff'), sheenRoughness: .4 });
  const b = mesh(new THREE.SphereGeometry(R, 40, 28), mB, 0, L + R * 1.05, 0); b.scale.y = 1.12; G.add(b);
  G.add(mesh(new THREE.ConeGeometry(.12, .2, 12), mB, 0, L - .02, 0)).rotation.x = Math.PI;
  const hl = mesh(new THREE.SphereGeometry(.14, 12, 8), new THREE.MeshBasicMaterial({ color: '#fff', transparent: true, opacity: .55 }), -.28, L + R * 1.05 + .4, R * .72); hl.scale.set(1, 1.5, .4); G.add(hl);
  let sm = null; const sMat = M('#e8ecf5', { roughness: .6 });
  const mkString = (t) => { const sw = Math.sin(t * 2.2) * .12; const pts = [[0, L, 0], [sw, L * .66, .05], [-sw * .8, L * .33, 0], [0, 0, 0]]; const g = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p => V(...p))), 16, .018, 5, false); if (sm) { sm.geometry.dispose(); sm.geometry = g; } else { sm = new THREE.Mesh(g, sMat); G.add(sm); } };
  mkString(0); addShadow(b); b.castShadow = true;
  return { content: G, pivot: [0, L / 2, 0], min: [-.9, 0, -.9], max: [.9, L + 2.1, .9], clamp: false, blob: .2, anchors: { string: G.add(new THREE.Object3D()) && G.children[G.children.length - 1] }, update(p, t) { mkString(t); b.rotation.z = Math.sin(t * 1.6) * .06; } };   // params: color, len
};

// ================================================================== balance scale | seesaw
PROPS.scale = (P) => {
  const kind = P.kind || 'balance', G = new THREE.Group(), beamL = P.len || 4.2;
  const mS = M(P.color || '#b9c2d6', { roughness: .3, metalness: .4, clearcoat: .6 }), mA = M(P.accent || '#ffcf4a', { roughness: .35, clearcoat: .6 });
  const beam = new THREE.Group(), anchors = {};
  let py, min, max, pans = [];
  if (kind === 'seesaw') {
    py = 1.0; const tri = mesh(extrude([[-.8, 0], [.8, 0], [0, py - .1]], .9, .08), M('#6b7288', { roughness: .5, clearcoat: .4 }), 0, .1, 0); G.add(tri);
    beam.position.y = py; G.add(beam); beam.add(mesh(rbox(beamL + .6, .2, 1.1, .08, 3), mA, 0, .1, 0));
    [-1, 1].forEach(s => { beam.add(mesh(rbox(.14, .45, .14, .04, 2), mS, s * (beamL / 2 - .4), .4, .0)); const a = new THREE.Object3D(); a.position.set(s * (beamL / 2 - .2), .2, 0); beam.add(a); anchors[s < 0 ? 'endL' : 'endR'] = a; });
    min = [-beamL / 2 - .5, 0, -.6]; max = [beamL / 2 + .5, py + 1.2, .6];
  } else {
    py = 3.3; G.add(mesh(new THREE.CylinderGeometry(1.0, 1.25, .25, 32), mS, 0, .125, 0)); G.add(mesh(new THREE.CylinderGeometry(.12, .16, py, 16), mS, 0, py / 2, 0));
    G.add(mesh(new THREE.SphereGeometry(.26, 20, 14), mA, 0, py, 0)); beam.position.y = py; G.add(beam); beam.add(mesh(rbox(beamL, .16, .2, .06, 3), mS, 0, 0, 0));
    [-1, 1].forEach(s => {
      const hang = new THREE.Group(); hang.position.set(s * beamL / 2, 0, 0); beam.add(hang);   // counter-rotated each frame so pans stay level
      [-1, 1].forEach(q => { const c = mesh(new THREE.CylinderGeometry(.018, .018, 1.35, 6), mS, q * .45, -.67, 0); c.rotation.z = -q * .31; hang.add(c); });
      const pan = mesh(new THREE.CylinderGeometry(.9, .7, .16, 32), mA, 0, -1.4, 0); hang.add(pan);
      const a = new THREE.Object3D(); a.position.set(0, -1.32, 0); hang.add(a); anchors[s < 0 ? 'panL' : 'panR'] = a; pans.push(hang);
    });
    min = [-beamL / 2 - 1, 0, -1]; max = [beamL / 2 + 1, py + .4, 1];
  }
  addShadow(G);
  return {
    content: G, pivot: [0, (max[1]) / 2, 0], min, max, clamp: true, blob: .8, anchors,
    // params: kind balance|seesaw, tilt (deg, + = right side down), len, color, accent. Anchors: panL/panR (balance), endL/endR (seesaw)
    update(p) { const a = -(p.tilt || 0) * D2R; beam.rotation.z = a; pans.forEach(h => { h.rotation.z = -a; }); },
  };
};
