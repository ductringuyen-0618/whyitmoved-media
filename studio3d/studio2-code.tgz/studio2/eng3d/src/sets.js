// Sets (stage | sky | street) and looks (day | storm | golden | dark | red). Sets are lazy singletons; the engine shows one per shot.
import { THREE, M, mesh, rbox, radialTex, canvasTex } from './kit.js';
import { rng, hash, lerp, clamp, smooth } from './util.js';

// ------------------------------------------------------------------ looks
export const LOOKS = {
  day:    { top: '#4f9cf0', bot: '#cfe6fb', fog: '#cfe6fb', hemiSky: '#d6e8ff', hemiGnd: '#f3dcc0', hemiI: .85, key: '#fff1dc', keyI: 3.1, rim: '#a8c8ff', rimI: 1.2, spot: '#fff0d8', spotI: 130, env: .55, exp: 1.08, bounce: 14, floor: '#ffffff', night: 0, bokeh: 1 },
  storm:  { top: '#3b4468', bot: '#8f9bb8', fog: '#9aa5c0', hemiSky: '#aab8e0', hemiGnd: '#d3c4b0', hemiI: .6, key: '#d7e2ff', keyI: 1.9, rim: '#a8c8ff', rimI: 1.6, spot: '#fff0d8', spotI: 85, env: .4, exp: .98, bounce: 8, floor: '#c9cde0', night: .25, bokeh: .45 },
  golden: { top: '#e8794f', bot: '#ffd9a0', fog: '#f6c999', hemiSky: '#ffd9b0', hemiGnd: '#b98a66', hemiI: .8, key: '#ffc27a', keyI: 3.5, rim: '#ff9a6a', rimI: 1.7, spot: '#ffd9a8', spotI: 110, env: .5, exp: 1.06, bounce: 14, floor: '#ffe6c4', night: .3, bokeh: 1.2 },
  dark:   { top: '#0b1020', bot: '#2a3552', fog: '#1d263e', hemiSky: '#6b7fb8', hemiGnd: '#2a2f45', hemiI: .45, key: '#a9bbff', keyI: 1.5, rim: '#5b78ff', rimI: 1.7, spot: '#bcd0ff', spotI: 70, env: .28, exp: 1.0, bounce: 6, floor: '#7f8ab0', night: 1, bokeh: .5 },
  red:    { top: '#2a0a12', bot: '#8a2230', fog: '#5a1520', hemiSky: '#ff8a8a', hemiGnd: '#4a1a1a', hemiI: .45, key: '#ff9a8a', keyI: 2.0, rim: '#ff3b3b', rimI: 2.0, spot: '#ffb0a0', spotI: 80, env: .3, exp: 1.0, bounce: 8, floor: '#c98a8a', night: .8, bokeh: .5 },
};
const COLOR_KEYS = new Set(['top', 'bot', 'fog', 'hemiSky', 'hemiGnd', 'key', 'rim', 'spot', 'floor']);
const _ca = new THREE.Color(), _cb = new THREE.Color();
export function blendLook(a, b, k) {
  const o = {};
  for (const key in a) { o[key] = COLOR_KEYS.has(key) ? '#' + _ca.set(a[key]).lerp(_cb.set(b[key]), k).getHexString() : lerp(a[key], b[key], k); }
  return o;
}

// ------------------------------------------------------------------ helpers
const fogged = c => new THREE.MeshBasicMaterial({ color: c, fog: true, transparent: true, opacity: .75, depthWrite: false });

function stage() {
  const g = new THREE.Group();
  const floorTex = radialTex([[0, '#f8e6c9'], [.35, '#f1d8b4'], [.75, '#e0c093'], [1, '#d2ae7d']], 1024);
  const fm = new THREE.MeshStandardMaterial({ map: floorTex, roughness: .78, metalness: 0 });
  const floor = new THREE.Mesh(new THREE.CircleGeometry(120, 64), fm); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; g.add(floor);
  const hm = fogged('#b7cbe3');
  for (let i = 0; i < 7; i++) { const h = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), hm); const r = hash(i + 40); h.scale.set(14 + r * 12, 3 + r * 4, 6); h.position.set(-60 + i * 20 + r * 6, -1.2, -80 - r * 12); g.add(h); }
  const bt = radialTex([[0, 'rgba(255,255,255,.9)'], [.55, 'rgba(255,255,255,.55)'], [.9, 'rgba(255,255,255,.18)'], [1, 'rgba(255,255,255,0)']], 128);
  const bokeh = [], r = rng(5);
  for (let i = 0; i < 22; i++) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: bt, transparent: true, opacity: .2, depthWrite: false, fog: false, blending: THREE.AdditiveBlending })); const sc = 3 + r() * 7; s.scale.set(sc, sc, 1); s.userData = { x: -45 + r() * 90, y: 4 + r() * 32, z: -70 - r() * 20, ph: r() * 6.28, base: .1 + r() * .16 }; s.renderOrder = -5; g.add(s); bokeh.push(s); }
  return { group: g, fog: [20, 80], update(look, t) {
    fm.color.set(look.floor);
    for (const b of bokeh) { const u = b.userData; b.position.set(u.x + Math.sin(t * .2 + u.ph) * 1.4, u.y + Math.cos(t * .17 + u.ph) * .8, u.z); b.material.opacity = u.base * look.bokeh; }
  } };
}

function skySet() {
  const g = new THREE.Group();
  const fm = new THREE.MeshStandardMaterial({ map: radialTex([[0, '#ffffff'], [.5, '#f3f8ff'], [1, '#dfeaf8']], 512), roughness: .95 });
  const floor = new THREE.Mesh(new THREE.CircleGeometry(150, 64), fm); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; g.add(floor);
  const pm = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 1, emissive: '#cfe0ff', emissiveIntensity: .25 });
  const geo = new THREE.SphereGeometry(1, 18, 12), r = rng(9), puffs = [];
  for (let i = 0; i < 60; i++) {
    const a = r() * Math.PI * 2, d = 9 + r() * r() * 70 + (i < 20 ? 0 : 12), s = 1.6 + r() * 3.6 + d * .05;
    const p = new THREE.Mesh(geo, pm); p.scale.set(s * (1.2 + r() * .6), s * (.55 + r() * .3), s); p.position.set(Math.cos(a) * d, -s * .2 + (r() - .5) * .6, Math.sin(a) * d - (Math.sin(a) < 0 ? 0 : 0)); p.userData.baseY = p.position.y; g.add(p); puffs.push(p);
  }
  // keep the foreground clear around the cast
  puffs.forEach(p => { if (Math.hypot(p.position.x, p.position.z - 1) < 8) { p.position.multiplyScalar(1.9); p.position.y = p.userData.baseY; } });
  const sun = new THREE.Sprite(new THREE.SpriteMaterial({ map: radialTex([[0, 'rgba(255,250,230,1)'], [.25, 'rgba(255,240,200,.55)'], [1, 'rgba(255,240,200,0)']], 256), transparent: true, depthWrite: false, fog: false, blending: THREE.AdditiveBlending, opacity: .9 }));
  sun.scale.setScalar(70); sun.position.set(-40, 55, -120); sun.renderOrder = -6; g.add(sun);
  return { group: g, fog: [34, 120], update(look, t) { fm.color.set(look.floor); pm.color.set(look.floor).lerp(new THREE.Color('#ffffff'), .5); pm.emissiveIntensity = .25 * (1 - look.night * .7); sun.material.opacity = .9 * (1 - look.night); puffs.forEach((p, i) => { p.position.y = p.userData.baseY + Math.sin(t * .3 + i) * .08; }); } };
}

function street() {
  const g = new THREE.Group();
  const road = new THREE.Mesh(new THREE.PlaneGeometry(260, 60), new THREE.MeshStandardMaterial({ color: '#3d4252', roughness: .9 })); road.rotation.x = -Math.PI / 2; road.position.set(0, 0, 24); road.receiveShadow = true; g.add(road);
  const mk = M('#f5f1e1', { roughness: .8 }), my = M('#ffd34a', { roughness: .8 });
  for (let i = -14; i < 14; i++) { const d = mesh(new THREE.PlaneGeometry(2.2, .22), my, i * 5, .012, -3.4); d.rotation.x = -Math.PI / 2; d.receiveShadow = true; g.add(d); }
  const edge = mesh(new THREE.PlaneGeometry(260, .18), mk, 0, .012, -6.1); edge.rotation.x = -Math.PI / 2; g.add(edge);
  for (let i = 0; i < 7; i++) { const z = mesh(new THREE.PlaneGeometry(.7, 4.4), mk, 11 + i * 1.2, .013, 3.4); z.rotation.x = -Math.PI / 2; g.add(z); }   // crosswalk off to the right
  const walkM = new THREE.MeshStandardMaterial({ color: '#cfd2d9', roughness: .85 });
  const walk = mesh(rbox(260, .26, 5, .05, 2), walkM, 0, .13, -8.7); walk.receiveShadow = true; g.add(walk);
  g.add(mesh(rbox(260, .3, .35, .08, 2), M('#e6e8ee', { roughness: .7 }), 0, .15, -6.2));
  const r = rng(21), bmats = [];
  const pastel = ['#e9b6a5', '#a9c5e8', '#f2d6a0', '#b8d9c0', '#c9b6e0', '#e8a0a8', '#9fcfd6', '#d9c7a0'];
  const winTex = (c, seed, em) => {
    const t = canvasTex(256, 512, (cg, w, h) => {
      cg.fillStyle = em ? '#000' : c; cg.fillRect(0, 0, w, h); const rr = rng(seed);
      for (let y = 0; y < 14; y++) for (let x = 0; x < 6; x++) { const lit = rr() > .55; if (em && !lit) continue; cg.fillStyle = lit ? '#ffe9a8' : '#4d5a78'; cg.fillRect(14 + x * 40, 20 + y * 34, 26, 22); }
    }, 4); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
  };
  for (let i = 0; i < 12; i++) {
    const w = 5 + r() * 4, h = 9 + r() * 16, x = -48 + i * 9 + r() * 2, c = pastel[i % pastel.length];
    const tex = winTex(c, i + 1, false), etex = winTex(c, i + 1, true); [tex, etex].forEach(q => q.repeat.set(Math.max(.7, w / 7), h / 16));
    const mat = new THREE.MeshStandardMaterial({ map: tex, emissiveMap: etex, emissive: '#ffffff', emissiveIntensity: 0, roughness: .8 }); bmats.push(mat);
    const b = mesh(rbox(w, h, 6, .3, 3), mat, x, h / 2, -15 - r() * 3); b.castShadow = false; g.add(b);
    g.add(mesh(rbox(w + .4, .5, 6.4, .15, 2), M('#d9dbe2', { roughness: .7 }), x, h + .1, b.position.z));
  }
  for (let i = 0; i < 8; i++) { const w = 8 + r() * 6, h = 22 + r() * 22; g.add(mesh(new THREE.BoxGeometry(w, h, 8), new THREE.MeshBasicMaterial({ color: '#a4b0cc', fog: true }), -60 + i * 18 + r() * 4, h / 2, -42 - r() * 6)); }
  const lampM = M('#4a5163', { roughness: .5, metalness: .3 }), lampL = new THREE.MeshStandardMaterial({ color: '#fff3c4', emissive: '#ffe9a0', emissiveIntensity: .3 });
  for (const x of [-9, 9, 27]) {
    g.add(mesh(new THREE.CylinderGeometry(.1, .14, 6, 12), lampM, x, 3.1, -7.4)); const arm = mesh(rbox(1.6, .1, .1, .04, 2), lampM, x + .7, 6.05, -7.4); g.add(arm); g.add(mesh(new THREE.SphereGeometry(.28, 16, 12), lampL, x + 1.4, 5.9, -7.4));
  }
  return { group: g, fog: [26, 100], update(look, t) { walkM.color.set(look.floor); road.material.color.set('#3d4252').multiply(new THREE.Color(look.floor)); bmats.forEach(m => { m.emissiveIntensity = look.night * .9; m.color.set('#ffffff').lerp(new THREE.Color(look.floor), .4); }); lampL.emissiveIntensity = .3 + look.night * 3; } };
}

const BUILDERS = { stage, sky: skySet, street };
export function makeSet(name) { return (BUILDERS[name] || stage)(); }
