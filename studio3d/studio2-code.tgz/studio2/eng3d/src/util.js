// Math, easing, seeded random and keyframe-track sampling. No THREE dependency.
export const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a, b, k) => a + (b - a) * k;
export const seg = (t, a, b) => (b === a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a)));
export const smooth = x => x * x * (3 - 2 * x);
export const D2R = Math.PI / 180;
export const rng = s => () => { s |= 0; s = s + 0x6D2B79F5 | 0; let t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
export const hash = n => { const r = rng(Math.floor(n * 9973) + 17); r(); return r(); };
export const spring = (dt, f, d) => dt < 0 ? 0 : Math.exp(-d * dt) * Math.cos(2 * Math.PI * f * dt);

// ------------------------------------------------------------------ easing
// Each easing maps u in [0,1] -> [0,1] (may overshoot). Spec strings: 'name' or 'name:a:b'.
const bounceOut = x => { const n = 7.5625, d = 2.75; if (x < 1 / d) return n * x * x; if (x < 2 / d) return n * (x -= 1.5 / d) * x + .75; if (x < 2.5 / d) return n * (x -= 2.25 / d) * x + .9375; return n * (x -= 2.625 / d) * x + .984375; };
const EASES = {
  linear: () => x => x,
  smooth: () => smooth,
  in: () => x => x * x * x,
  out: () => x => 1 - Math.pow(1 - x, 3),
  inout: () => x => x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2,
  in2: () => x => x * x,
  out2: () => x => 1 - (1 - x) * (1 - x),
  sine: () => x => 0.5 - 0.5 * Math.cos(Math.PI * x),
  // overshoot then settle. back:2.2 = stronger overshoot
  back: (s = 1.9) => x => 1 + (+s + 1) * Math.pow(x - 1, 3) + (+s) * Math.pow(x - 1, 2),
  // anticipation: pulls back before moving
  backin: (s = 1.9) => x => (+s + 1) * x * x * x - (+s) * x * x,
  // damped oscillation around the target. spring:freqCycles:damping
  spring: (f = 1.5, d = 6) => { const raw = x => 1 - Math.exp(-d * x) * Math.cos(2 * Math.PI * f * x); const c = 1 - raw(1); return x => raw(x) + c * x; },
  bounce: () => bounceOut,
  hold: () => x => (x >= 1 ? 1 : 0),   // stays at previous value until the keyframe time
};
const easeCache = {};
export function getEase(spec) {
  spec = spec || 'inout';
  if (typeof spec === 'function') return spec;
  if (easeCache[spec]) return easeCache[spec];
  const [n, ...a] = String(spec).split(':');
  const f = (EASES[n] || EASES.inout)(...a.map(Number));
  return (easeCache[spec] = f);
}

// ------------------------------------------------------------------ tracks
// A keyframe list [{t, <prop>:value, ease}] becomes per-property tracks. Properties may be sparse.
// Numbers/arrays of numbers interpolate; anything else (strings, booleans, null) steps.
// `ease` on a keyframe shapes the move INTO that keyframe (from the previous keyframe of that property).
// `ease` may be a string or {prop: spec, '*': spec}.
const RESERVED = new Set(['t', 'ease', 'p']);
export function buildTracks(kfs, base) {
  const tr = {};
  const add = (k, t, v, e) => { (tr[k] || (tr[k] = [])).push({ t, v, e }); };
  const list = (base ? [{ t: -1e9, ...base }] : []).concat(kfs || []);
  for (const kf of list) {
    const ease = kf.ease;
    const ef = k => (ease && typeof ease === 'object' ? (ease[k] || ease['*']) : ease);
    for (const k in kf) {
      if (RESERVED.has(k)) continue;
      add(k, kf.t ?? 0, kf[k], ef(k));
    }
    if (kf.p) for (const k in kf.p) add('p:' + k, kf.t ?? 0, kf.p[k], ef('p:' + k) || ef(k));
  }
  for (const k in tr) tr[k].sort((a, b) => a.t - b.t);
  return tr;
}
const isNum = v => typeof v === 'number';
const isVec = v => Array.isArray(v) && v.every(isNum);
export function sample(tr, key, t, def) {
  const a = tr[key]; if (!a) return def;
  if (t <= a[0].t) return a[0].v;
  const n = a.length;
  if (t >= a[n - 1].t) return a[n - 1].v;
  let i = 0; while (i < n - 1 && a[i + 1].t <= t) i++;
  const A = a[i], B = a[i + 1];
  if (isNum(A.v) && isNum(B.v)) return lerp(A.v, B.v, getEase(B.e)(seg(t, A.t, B.t)));
  if (isVec(A.v) && isVec(B.v)) { const u = getEase(B.e)(seg(t, A.t, B.t)); return A.v.map((x, j) => lerp(x, B.v[j] ?? x, u)); }
  return A.v;
}
// numeric integral of a track (used for fan spin angle). Trapezoid, step dt.
export function integrate(tr, key, t, def, dt = 1 / 20) {
  let s = 0, p = sample(tr, key, 0, def);
  for (let x = dt; x < t + dt; x += dt) { const xx = Math.min(x, t), q = sample(tr, key, xx, def); s += (p + q) * .5 * (xx - (x - dt)); p = q; }
  return s;
}
