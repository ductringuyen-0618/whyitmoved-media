// Shared helpers: materials, textures, geometry shortcuts and the Entity wrapper (placement + floor clamp + contact shadow).
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { D2R } from './util.js';
export { THREE, RoundedBoxGeometry };

// ------------------------------------------------------------------ materials
export const M = (c, o = {}) => new THREE.MeshPhysicalMaterial(Object.assign({ color: c, roughness: .45, metalness: 0 }, o));
export const mWhite = M('#ffffff', { roughness: .18, clearcoat: 1, clearcoatRoughness: .1 });
export const mInk = M('#0e1730', { roughness: .25, clearcoat: .6 });
export const mMouth = M('#7c2230', { roughness: .5 });
export const mTongue = M('#ee6f86', { roughness: .5 });
export const mGold = M('#ffd13b', { roughness: .28, metalness: .35, emissive: '#ff9f00', emissiveIntensity: .22, clearcoat: .6 });
export const mMetal = M('#d3dae8', { roughness: .35, metalness: .25 });
export const mSweat = M('#8fd6ff', { roughness: .05, clearcoat: 1, transparent: true, opacity: .92 });

// ------------------------------------------------------------------ geometry shortcuts
export const rbox = (w, h, d, r = .1, s = 3) => new RoundedBoxGeometry(w, h, d, s, Math.min(r, w / 2 - .001, h / 2 - .001, d / 2 - .001));
export function mesh(geo, mat, x = 0, y = 0, z = 0) { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); return m; }
export function tube(pts, r, mat, seg = 24) { return new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p))), seg, r, 10, false), mat); }
export function addShadow(o, cast = true, recv = true) { o.traverse(c => { if (c.isMesh) { c.castShadow = cast; c.receiveShadow = recv; } }); return o; }
export function starGeo(r, depth = .14) {
  const s = new THREE.Shape();
  for (let i = 0; i < 10; i++) { const rr = i % 2 ? r * .47 : r, a = Math.PI / 2 + i * Math.PI / 5; (i ? s.lineTo : s.moveTo).call(s, Math.cos(a) * rr, Math.sin(a) * rr); }
  const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: true, bevelThickness: depth * .35, bevelSize: r * .12, bevelSegments: 3, curveSegments: 2 });
  g.translate(0, 0, -depth / 2); return g;
}
// extruded outline with bevel, centred on z
export function extrude(pts, depth, bevel = .08, curveSeg = 4) {
  const s = new THREE.Shape(); pts.forEach((p, i) => (i ? s.lineTo(p[0], p[1]) : s.moveTo(p[0], p[1])));
  const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 4, curveSegments: curveSeg });
  g.translate(0, 0, -depth / 2); return g;
}

// ------------------------------------------------------------------ textures
export function canvasTex(w, h, draw, aniso = 8) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = aniso; t.userData = { canvas: c, g }; return t;
}
export function radialTex(stops, size = 512) {
  return canvasTex(size, size, (g, w) => { const gr = g.createRadialGradient(w / 2, w / 2, 0, w / 2, w / 2, w / 2); stops.forEach(([o, col]) => gr.addColorStop(o, col)); g.fillStyle = gr; g.fillRect(0, 0, w, w); }, 4);
}
export function woodTex(base = '#c58b4e', seed = 3) {
  return canvasTex(512, 512, (g, w, h) => {
    g.fillStyle = base; g.fillRect(0, 0, w, h);
    let s = seed * 7919; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
    for (let i = 0; i < 90; i++) { g.strokeStyle = `rgba(${r() > .5 ? '90,50,20' : '255,230,190'},${.05 + r() * .12})`; g.lineWidth = 1 + r() * 4; const x = r() * w; g.beginPath(); g.moveTo(x, 0); g.bezierCurveTo(x + (r() - .5) * 40, h * .3, x + (r() - .5) * 40, h * .7, x + (r() - .5) * 20, h); g.stroke(); }
  });
}
export function textTex(text, { w = 512, h = 160, font = '900 118px Inter, sans-serif', color = '#0e1730', x = .5, y = .54 } = {}) {
  return canvasTex(w, h, g => { g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = color; g.fillText(text, w * x, h * y); });
}

// ------------------------------------------------------------------ Entity
// Wraps authored content (origin = base-centre of the object, y up) so it can be placed with
// pos/rot/scale, rotated about its `pivot`, clamped to the floor and given an automatic contact shadow.
const _q = new THREE.Quaternion(), _e = new THREE.Euler(), _v = new THREE.Vector3();
const blobTex = radialTex([[0, 'rgba(10,12,40,.62)'], [.45, 'rgba(10,12,40,.32)'], [1, 'rgba(10,12,40,0)']], 256);
const blobGeo = new THREE.PlaneGeometry(1, 1);
export class Entity {
  /** content: Object3D; pivot: rotation centre in content coords; min/max: content-space bounding box;
   *  clamp: keep above floor; blob: contact shadow strength (0 = none); anchors: {name: Object3D} */
  constructor({ content, pivot, min, max, clamp = true, blob = 1, anchors = {}, update = null, size = 1 }) {
    this.root = new THREE.Group(); this.sq = new THREE.Group(); this.root.add(this.sq);
    this.content = content; this.sq.add(content); content.position.set(-pivot[0], -pivot[1], -pivot[2]);
    this.pivot = pivot; this.min = min; this.max = max; this.clamp = clamp; this.anchors = anchors; this.update = update; this.size = size;
    this.blobK = blob;
    if (blob > 0) {
      this.blob = new THREE.Mesh(blobGeo, new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, fog: false }));
      this.blob.rotation.x = -Math.PI / 2; this.blob.renderOrder = 2;
    }
    this.attached = null; this.box = { x0: 0, x1: 0, z0: 0, z1: 0, y0: 0, y1: 0 };
  }
  get nodes() { return this.blob ? [this.root, this.blob] : [this.root]; }
  setVisible(v) { this.root.visible = v; if (this.blob) this.blob.visible = v && !this.attached; }
  /** world placement. pos = base-centre (x, height above ground, z). rot degrees (YXZ). scale = [sx,sy,sz] incl. size. */
  place({ pos, rot, scale, ground = 0 }) {
    const [sx, sy, sz] = scale, pv = this.pivot, mn = this.min, mx = this.max;
    this.sq.scale.set(sx, sy, sz);
    _e.set(rot[0] * D2R, rot[1] * D2R, rot[2] * D2R, 'YXZ'); _q.setFromEuler(_e); this.root.quaternion.copy(_q);
    let minY = 1e9, x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9, y1 = -1e9;
    for (let i = 0; i < 8; i++) {
      _v.set(((i & 1 ? mx[0] : mn[0]) - pv[0]) * sx, ((i & 2 ? mx[1] : mn[1]) - pv[1]) * sy, ((i & 4 ? mx[2] : mn[2]) - pv[2]) * sz).applyQuaternion(_q);
      minY = Math.min(minY, _v.y); y1 = Math.max(y1, _v.y); x0 = Math.min(x0, _v.x); x1 = Math.max(x1, _v.x); z0 = Math.min(z0, _v.z); z1 = Math.max(z1, _v.z);
    }
    const upright = ground + pos[1] + (pv[1] - mn[1]) * sy;
    const cy = this.clamp ? Math.max(upright, ground - minY) : upright;
    this.root.position.set(pos[0], cy, pos[2]);
    this.box = { x0: pos[0] + x0, x1: pos[0] + x1, z0: pos[2] + z0, z1: pos[2] + z1, y0: cy + minY, y1: cy + y1 };
    this.ground = ground;
    if (this.blob) {
      const gap = Math.max(0, cy + minY - ground);
      const w = (x1 - x0) * 1.22 + .5, d = (z1 - z0) * 1.22 + .9 + gap * .25;
      this.blob.position.set(pos[0] + (x0 + x1) / 2, ground + .03, pos[2] + (z0 + z1) / 2);
      this.blob.scale.set(w * (1 + gap * .06), d, 1);
      this.blob.material.opacity = Math.min(1, this.blobK / (1 + gap * 1.15));
    }
  }
  /** local placement under an anchor (pos/rot place the pivot relative to the anchor) */
  placeLocal({ pos, rot, scale }) {
    this.sq.scale.set(...scale);
    this.root.position.set(...pos); this.root.rotation.set(rot[0] * D2R, rot[1] * D2R, rot[2] * D2R, 'YXZ');
    if (this.blob) this.blob.visible = false;
  }
}
