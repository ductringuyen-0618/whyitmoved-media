// Characters: INTEL (square chip with pins), NVIDIA (wide GPU card with two fan cheeks), AMD (tall chip with heat-spreader lid).
// All three share one rig API (see pose()). Original designs; the company name appears only on the name tag.
import { THREE, M, mesh, tube, rbox, extrude, addShadow, canvasTex, Entity, mWhite, mInk, mMouth, mTongue, mGold, mMetal, mSweat } from './kit.js';
import { clamp, D2R, hash } from './util.js';

// ------------------------------------------------------------------ shared face
function buildFace() {
  const face = new THREE.Group(), eyes = [], mouths = {};
  for (const sx of [-1, 1]) {
    const e = new THREE.Group(); e.position.set(sx * .43, -.2, 0); face.add(e);
    const scl = mesh(new THREE.SphereGeometry(.28, 32, 24), mWhite); scl.scale.set(1, 1.1, .5); e.add(scl);
    const pup = new THREE.Group(); e.add(pup);
    const p = mesh(new THREE.SphereGeometry(.125, 24, 16), mInk, 0, 0, .1); p.scale.set(1, 1.15, .45); pup.add(p);
    pup.add(mesh(new THREE.SphereGeometry(.045, 12, 8), new THREE.MeshBasicMaterial({ color: '#fff' }), .04, .06, .17));
    const sqz = new THREE.Group(); sqz.visible = false; e.add(sqz);        // squeezed  > <
    for (const s2 of [-1, 1]) { const b = mesh(rbox(.34, .09, .08, .04, 2), mInk, 0, s2 * .09, .08); b.rotation.z = s2 * sx * -.55; sqz.add(b); }
    const xx = new THREE.Group(); xx.visible = false; e.add(xx);            // dizzy  X
    for (const a of [Math.PI / 4, -Math.PI / 4]) { const b = mesh(rbox(.6, .12, .08, .05, 2), mInk, 0, 0, .06); b.rotation.z = a; xx.add(b); }
    const hp = tube([[-.24, -.06, .06], [-.12, .08, .06], [0, .12, .06], [.12, .08, .06], [.24, -.06, .06]], .05, mInk, 12); hp.visible = false; e.add(hp);   // happy ^ ^
    const brow = mesh(rbox(.46, .095, .08, .04, 2), mInk, 0, .42, .04); e.add(brow);
    eyes.push({ g: e, scl, pup, sqz, xx, hp, brow, sx });
  }
  const addM = (k, o) => { o.visible = false; face.add(o); mouths[k] = o; };
  addM('smile', tube([[-.3, -.58, 0], [-.15, -.72, 0], [0, -.76, 0], [.15, -.72, 0], [.3, -.58, 0]], .05, mInk));
  addM('flat', tube([[-.24, -.7, 0], [0, -.7, 0], [.24, -.7, 0]], .05, mInk, 8));
  addM('grin', (() => { const gp = new THREE.Group(); const sh = new THREE.Shape(); sh.absarc(0, 0, .3, Math.PI, 2 * Math.PI, false); const m = new THREE.Mesh(new THREE.ShapeGeometry(sh, 24), mMouth); m.position.set(0, -.58, .02); gp.add(m); gp.add(mesh(rbox(.5, .07, .02, .02, 2), mWhite, 0, -.62, .035)); return gp; })());
  addM('o', (() => { const m = mesh(new THREE.SphereGeometry(.17, 24, 16), mMouth, 0, -.68, 0); m.scale.set(.85, 1.1, .35); return m; })());
  addM('open', (() => { const gp = new THREE.Group(); const om = mesh(new THREE.SphereGeometry(.27, 28, 18), mMouth, 0, -.66, 0); om.scale.set(1.05, 1.15, .35); gp.add(om); const t = mesh(new THREE.SphereGeometry(.15, 18, 12), mTongue, 0, -.79, .02); t.scale.set(1.2, .6, .4); gp.add(t); return gp; })());
  addM('shout', (() => { const gp = new THREE.Group(); const m = mesh(new THREE.SphereGeometry(.3, 28, 18), mMouth, 0, -.72, .02); m.scale.set(1.2, 1.15, .35); gp.add(m); gp.add(mesh(rbox(.5, .09, .03, .03, 2), mWhite, 0, -.43, .07)); const t = mesh(new THREE.SphereGeometry(.2, 18, 12), mTongue, 0, -.92, .04); t.scale.set(1.3, .55, .4); gp.add(t); return gp; })());
  addM('wob', tube([[-.34, -.68, 0], [-.21, -.6, 0], [-.07, -.74, 0], [.07, -.6, 0], [.21, -.74, 0], [.34, -.64, 0]], .045, mInk));
  addM('sad', tube([[-.3, -.8, 0], [-.15, -.68, 0], [0, -.64, 0], [.15, -.68, 0], [.3, -.8, 0]], .05, mInk));
  return { face, eyes, mouths };
}

function buildSweat(x, y, z) {
  const g = new THREE.Group(); g.position.set(x, y, z);
  g.add(mesh(new THREE.SphereGeometry(.13, 16, 12), mSweat)); g.add(mesh(new THREE.ConeGeometry(.12, .26, 16), mSweat, 0, .2, 0)); g.visible = false; return g;
}
function buildArms(parent, xs, y, mArm, mHand, len = 1) {
  const arms = [];
  for (const sx of [-1, 1]) {
    const sh = new THREE.Group(); sh.position.set(sx * xs, y, 0); parent.add(sh);
    sh.add(mesh(new THREE.CapsuleGeometry(.13, .5 * len, 6, 12), mArm, 0, -.38 * len, 0));
    const hand = new THREE.Group(); hand.position.set(0, -.88 * len, 0); sh.add(hand); hand.add(mesh(new THREE.SphereGeometry(.27, 24, 16), mHand));
    sh.add(mesh(new THREE.SphereGeometry(.17, 16, 12), mArm));
    arms.push({ sh, hand, sx });
  }
  return arms;
}
function buildTag(text, cap, w = 1.8, fontPx = 118) {
  const g = new THREE.Group();
  g.add(mesh(rbox(w, .6, .1, .12, 4), mWhite));
  g.add(mesh(rbox(.24, .6, .12, .1, 3), M(cap, { roughness: .4 }), -w / 2 + .12, 0, .01));
  const tex = canvasTex(512, 160, (c, W, H) => {
    let px = fontPx; c.font = `900 ${px}px Inter, sans-serif`;
    while (c.measureText(text).width > 400 && px > 40) { px -= 4; c.font = `900 ${px}px Inter, sans-serif`; }
    c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#0e1730'; c.fillText(text, 276, 86);
  });
  const tt = new THREE.Mesh(new THREE.PlaneGeometry(w - .1, (w - .1) * 160 / 512), new THREE.MeshBasicMaterial({ map: tex, transparent: true, toneMapped: false }));
  tt.position.set(.06 * (w / 1.8), 0, .06); g.add(tt);
  return g;
}

// ------------------------------------------------------------------ INTEL: blue square chip, pins on all sides, antenna
function buildIntel(tag) {
  const mBody = M('#3b7bf0', { roughness: .32, clearcoat: .7, clearcoatRoughness: .22, sheen: .4, sheenColor: new THREE.Color('#9fc4ff'), sheenRoughness: .5 });
  const mLt = M('#9cc6ff', { roughness: .4, clearcoat: .4 }), mHand = M('#d6e8ff', { roughness: .35, clearcoat: .5 });
  const B = new THREE.Group(), HB = 1.41; B.position.y = HB;
  B.add(mesh(rbox(2.2, 2.2, 1.3, .55, 8), mBody));
  const pin = (w, h, x, y) => B.add(mesh(rbox(w, h, .22, .07, 3), mMetal, x, y, 0));
  [-.72, .72].forEach(x => pin(.28, .44, x, 1.16));
  [-.72, 0, .72].forEach(x => pin(.28, .44, x, -1.16));
  [-.62, 0, .62].forEach(y => { pin(.44, .28, -1.16, y); pin(.44, .28, 1.16, y); });
  const part = new THREE.Group(); part.position.set(0, 1.08, 0); B.add(part);   // antenna
  part.add(mesh(new THREE.CapsuleGeometry(.1, .5, 6, 12), mLt, 0, .38, 0));
  part.add(mesh(rbox(.95, .34, .34, .12, 5), mLt, 0, .84, 0));
  part.add(mesh(rbox(.6, .06, .12, .03, 2), mWhite, -.08, .93, .13));
  const t = buildTag(tag, '#2450b8'); t.position.set(0, .6, .66); B.add(t);
  const { face, eyes, mouths } = buildFace(); face.position.set(0, 0, .66); B.add(face);
  const sweat = buildSweat(.9, .72, .62); B.add(sweat);
  const arms = buildArms(B, 1.2, .05, mLt, mHand);
  const content = new THREE.Group(); content.add(B);
  return { content, pivot: [0, HB, 0], min: [-1.5, 0, -.75], max: [1.5, HB + 2.1, .75], face, eyes, mouths, sweat, arms, part, partSign: 1, size: .8 };
}

// ------------------------------------------------------------------ NVIDIA: wide dark-green GPU card, two fan cheeks, gold edge fingers
function buildNvidia(tag) {
  const mBody = M('#17231d', { roughness: .34, clearcoat: .85, clearcoatRoughness: .2, sheen: .3, sheenColor: new THREE.Color('#5fa05a'), sheenRoughness: .5 });
  const mLime = M('#8fd32b', { roughness: .35, clearcoat: .5, emissive: '#3b6a08', emissiveIntensity: .35 });
  const mDark = M('#0b100e', { roughness: .4, clearcoat: .5 });
  const mArm = M('#2c3a33', { roughness: .4, clearcoat: .4 }), mHand = M('#c4ee7a', { roughness: .35, clearcoat: .5 });
  const HB = 1.48; const B = new THREE.Group(); B.position.y = HB;
  B.add(mesh(rbox(3.9, 2.4, 1.3, .36, 6), mBody));
  B.add(mesh(rbox(3.3, .1, .06, .03, 2), mLime, 0, -.98, .64));               // lime trim bar
  B.add(mesh(rbox(.12, 1.6, .06, .03, 2), mLime, -1.74, .1, .64)); B.add(mesh(rbox(.12, 1.6, .06, .03, 2), mLime, 1.74, .1, .64));
  for (let i = 0; i < 9; i++) B.add(mesh(rbox(.24, .3, .34, .06, 2), mGold, -1.4 + i * .35, -1.3, 0));   // PCIe finger "feet"
  // fans (cheeks)
  const fans = [];
  for (const sx of [-1, 1]) {
    const f = new THREE.Group(); f.position.set(sx * 1.38, -.22, .655); B.add(f);
    f.add(mesh(new THREE.TorusGeometry(.62, .09, 14, 44), mDark, 0, 0, .05));
    f.add(mesh(new THREE.TorusGeometry(.5, .028, 8, 40), mLime, 0, 0, .03));
    f.add(mesh(new THREE.CircleGeometry(.58, 40), M('#101713', { roughness: .5, clearcoat: .4 }), 0, 0, .012));
    const spin = new THREE.Group(); spin.position.z = .05; f.add(spin);
    for (let i = 0; i < 7; i++) { const bl = new THREE.Group(); bl.rotation.z = i * Math.PI * 2 / 7; const b = mesh(rbox(.46, .27, .05, .06, 2), i % 2 ? M('#34443b', { roughness: .4, clearcoat: .6 }) : M('#2a3730', { roughness: .4, clearcoat: .6 }), .31, 0, 0); b.rotation.x = .5; b.rotation.z = .3; bl.add(b); spin.add(bl); }
    const hub = mesh(new THREE.CylinderGeometry(.17, .17, .1, 24), mLime, 0, 0, .04); hub.rotation.x = Math.PI / 2; spin.add(hub);
    fans.push(spin);
  }
  const part = new THREE.Group(); part.position.set(1.15, 1.2, -.1); B.add(part);   // power plug on top
  part.add(mesh(rbox(.9, .42, .55, .1, 3), mDark, 0, .2, 0)); part.add(mesh(rbox(.7, .08, .56, .03, 2), mLime, 0, .3, 0));
  const t = buildTag(tag, '#6ab01a'); t.position.set(0, .78, .66); B.add(t);
  const { face, eyes, mouths } = buildFace(); face.scale.setScalar(.86); face.position.set(0, -.08, .66); B.add(face);
  const sweat = buildSweat(.95, .95, .62); B.add(sweat);
  const arms = buildArms(B, 2.12, .0, mArm, mHand, .9);
  const content = new THREE.Group(); content.add(B);
  return { content, pivot: [0, HB, 0], min: [-2.4, 0, -.75], max: [2.4, HB + 1.75, .75], face, eyes, mouths, sweat, arms, part, partSign: -1, fans, size: .64 };
}

// ------------------------------------------------------------------ AMD: tall red chip, notched orange heat-spreader lid, fin crest
function buildAmd(tag) {
  const mBody = M('#cf2b1d', { roughness: .34, clearcoat: .8, clearcoatRoughness: .2, sheen: .35, sheenColor: new THREE.Color('#ff8a70'), sheenRoughness: .5 });
  const mLid = M('#ff8d2b', { roughness: .3, metalness: .45, clearcoat: .55, clearcoatRoughness: .25 });
  const mArm = M('#ff9d50', { roughness: .4, clearcoat: .4 }), mHand = M('#ffd9ae', { roughness: .35, clearcoat: .5 });
  const HB = 1.88; const B = new THREE.Group(); B.position.y = HB;
  B.add(mesh(rbox(2.3, 3.2, 1.25, .38, 7), mBody));
  // lid with two notched corners (original silhouette)
  const w = .97, h = 1.42, n = .34;
  const lid = mesh(extrude([[-w, -h + n], [-w, h], [w - n, h], [w - n, h - n], [w, h - n], [w, -h], [-w + n, -h], [-w + n, -h + n]].map(p => p), .16, .09), mLid, 0, 0, .74);
  B.add(lid);
  const tri = new THREE.Shape(); tri.moveTo(0, 0); tri.lineTo(.3, 0); tri.lineTo(0, .3); B.add(mesh(new THREE.ExtrudeGeometry(tri, { depth: .03, bevelEnabled: false }), mGold, -w + .08, -h + .52, .93));
  for (let i = 0; i < 5; i++) B.add(mesh(rbox(.3, .22, .5, .06, 2), mGold, -.8 + i * .4, -1.68, 0));   // contact pads (feet)
  const part = new THREE.Group(); part.position.set(0, 1.55, 0); B.add(part);        // fin crest
  [[-.62, .95, 17], [0, 1.2, 0], [.62, .95, -17]].forEach(([x, hh, a]) => { const h = new THREE.Group(); h.position.set(x, -.05, 0); h.rotation.z = a * Math.PI / 180; h.add(mesh(rbox(.46, hh, .8, .15, 3), mLid, 0, hh / 2, 0)); h.add(mesh(rbox(.12, hh * .6, .06, .03, 2), M('#ffc27a', { roughness: .3, clearcoat: .6 }), 0, hh * .52, .41)); part.add(h); });
  const t = buildTag(tag, '#9c1a10', 1.6); t.position.set(0, -.98, .95); B.add(t);
  const { face, eyes, mouths } = buildFace(); face.position.set(0, .42, .95); B.add(face);
  const sweat = buildSweat(.78, 1.1, .92); B.add(sweat);
  const arms = buildArms(B, 1.3, .35, mArm, mHand, 1);
  const content = new THREE.Group(); content.add(B);
  return { content, pivot: [0, HB, 0], min: [-1.55, 0, -.65], max: [1.55, HB + 1.55 + 1.2, .95], face, eyes, mouths, sweat, arms, part, partSign: 1, size: .62 };
}


// ------------------------------------------------------------------ ALPHABET: soft white cloud-bodied character with blue arms and a cloud-puff tuft
function buildAlphabet(tag) {
  const mBody = M('#c4dcff', { roughness: .3, clearcoat: .7, clearcoatRoughness: .25, sheen: .5, sheenColor: new THREE.Color('#9cc6ff'), sheenRoughness: .5 });
  const mBlue = M('#4a8df0', { roughness: .35, clearcoat: .5 }), mHand = M('#ffffff', { roughness: .3, clearcoat: .6 });
  const HB = 1.15; const B = new THREE.Group(); B.position.y = HB;
  B.add(mesh(rbox(2.5, 1.9, 1.25, .75, 8), mBody));
  [[-.75, 1.0, .0, .62], [.1, 1.2, 0, .8], [.95, .95, 0, .56]].forEach(([x, y, z, r]) => B.add(mesh(new THREE.SphereGeometry(r, 32, 24), mBody, x, y, z)));
  [-.7, .7].forEach(x => B.add(mesh(rbox(.7, .22, .8, .1, 3), mBlue, x, -1.0, .05)));        // feet
  const part = new THREE.Group(); part.position.set(.1, 1.85, 0); B.add(part);           // puff on top
  part.add(mesh(new THREE.SphereGeometry(.26, 20, 14), mBody, -.2, .12, 0)); part.add(mesh(new THREE.SphereGeometry(.2, 20, 14), mBody, .12, .3, 0)); part.add(mesh(new THREE.SphereGeometry(.15, 16, 12), mBlue, .36, .1, 0));
  const t = buildTag(tag, '#2f6fd8', 2.0, 104); t.position.set(0, -.78, .66); B.add(t);
  const { face, eyes, mouths } = buildFace(); face.scale.setScalar(.92); face.position.set(0, .22, .64); B.add(face);
  const sweat = buildSweat(1.0, .85, .6); B.add(sweat);
  const arms = buildArms(B, 1.3, -.05, mBlue, mHand, .9);
  const content = new THREE.Group(); content.add(B);
  return { content, pivot: [0, HB, 0], min: [-1.6, 0, -.7], max: [1.6, HB + 2.4, .7], face, eyes, mouths, sweat, arms, part, partSign: 1, size: .7 };
}

// ------------------------------------------------------------------ AMAZON: cardboard shipping box with tape and open flaps
function buildAmazon(tag) {
  const mBox = M('#c98a4b', { roughness: .55, clearcoat: .15 }), mTape = M('#ecd2a2', { roughness: .4, clearcoat: .4 }), mDarkB = M('#9a6430', { roughness: .6 });
  const mArm = M('#b4783c', { roughness: .5 }), mHand = M('#f3dcb4', { roughness: .4, clearcoat: .3 });
  const HB = 1.1; const B = new THREE.Group(); B.position.y = HB;
  B.add(mesh(rbox(2.5, 2.2, 1.45, .2, 5), mBox));
  B.add(mesh(rbox(2.54, .08, 1.49, .03, 2), mDarkB, 0, .72, 0));                           // lid seam
  B.add(mesh(rbox(.55, .1, 1.5, .03, 2), mTape, 0, 1.12, 0));                              // tape strip on top
  B.add(mesh(rbox(.55, .5, .05, .03, 2), mTape, 0, .9, .74));                              // tape tab on front
  const part = new THREE.Group(); part.position.set(0, 1.12, 0); B.add(part);             // open flaps
  [-1, 1].forEach(sx => { const f = new THREE.Group(); f.position.set(sx * 1.2, 0, 0); f.rotation.z = -sx * .75; f.add(mesh(rbox(1.0, .08, 1.35, .04, 2), mBox, sx * .5, .04, 0)); part.add(f); });
  const t = buildTag(tag, '#7a4b1c', 1.9); t.position.set(0, -.8, .76); B.add(t);
  const { face, eyes, mouths } = buildFace(); face.scale.setScalar(.95); face.position.set(0, .18, .76); B.add(face);
  const sweat = buildSweat(1.0, .8, .72); B.add(sweat);
  const arms = buildArms(B, 1.37, 0.0, mArm, mHand, .95);
  const content = new THREE.Group(); content.add(B);
  return { content, pivot: [0, HB, 0], min: [-1.7, 0, -.8], max: [1.7, HB + 1.5, .8], face, eyes, mouths, sweat, arms, part, partSign: 1, size: .72 };
}

const BUILD = { INTEL: buildIntel, NVIDIA: buildNvidia, AMD: buildAmd, ALPHABET: buildAlphabet, AMAZON: buildAmazon };
const TAGS = { INTEL: 'INTEL', NVIDIA: 'NVIDIA', AMD: 'AMD', ALPHABET: 'ALPHABET', AMAZON: 'AMAZON' };

/** Create a character rig. type: INTEL | NVIDIA | AMD. */
export function makeChar(type, { tag, id = type } = {}) {
  const b = BUILD[type](tag || TAGS[type]);
  addShadow(b.content);
  const ent = new Entity({ content: b.content, pivot: b.pivot, min: b.min, max: b.max, blob: 1, anchors: { handL: b.arms[0].hand, handR: b.arms[1].hand, top: b.part, front: b.face }, size: b.size });
  const seed = hash(id.length * 31 + id.charCodeAt(0));
  // deterministic blink schedule
  const blinks = []; { let tt = .6 + seed * 1.5, k = 1; while (tt < 120) { blinks.push(tt); tt += 2.1 + hash(k++ + seed * 100) * 2.6; if (hash(k * 7 + seed) > .8) { blinks.push(tt + .22); } } }
  /** Apply expression/limb state. st: eyes, mouth, brow, browY, lookx, looky, wide, sweat, armL, armR [deg out, deg fwd], wig, fan(angle rad), idle, blink(bool), t */
  function pose(st) {
    const t = st.t, idle = st.idle;
    let bl = 0; if (st.blink !== false) for (const bt of blinks) { if (bt > t + .2) break; bl = Math.max(bl, Math.sin(Math.PI * clamp((t - bt) / .13))); }
    const ey = st.eyes, xm = ey === 'x', sqm = ey === 'squeeze', hp = ey === 'happy';
    for (const e of b.eyes) {
      e.scl.visible = e.pup.visible = !(xm || sqm || hp); e.xx.visible = xm; e.sqz.visible = sqm; e.hp.visible = hp;
      e.g.scale.set(st.wide, st.wide * (1 - bl * .92), 1);
      e.pup.position.set(st.lookx * .09, st.looky * .08, 0);
      const k = st.wide > 1.1 ? .8 : 1; e.pup.scale.set(k, k, 1);
      e.brow.rotation.z = -e.sx * st.brow * .5;
      e.brow.position.y = .42 + st.browY * .12 + (st.wide - 1) * .35;
      e.brow.visible = Math.abs(st.brow) > .05 || Math.abs(st.browY) > .05;
      if (sqm) e.sqz.scale.x = -e.sx;
    }
    for (const k in b.mouths) b.mouths[k].visible = k === (b.mouths[st.mouth] ? st.mouth : 'smile');
    b.sweat.visible = st.sweat > .01; b.sweat.scale.setScalar(Math.max(.01, st.sweat));
    b.arms.forEach((a, i) => {
      const [o, f] = i ? st.armR : st.armL; const sw = Math.sin(t * 2.2 + i) * 3 * idle;
      a.sh.rotation.set(-(f || 0) * D2R, 0, a.sx * (o + sw) * D2R);
    });
    if (b.fans) b.fans.forEach((f, i) => { f.rotation.z = -st.fan * (i ? 1 : -1) * 1; });
    b.part.rotation.z = b.partSign * (st.wig * .5 + Math.sin(t * 3.1) * .05 * idle);
    if (type === 'AMD') b.part.children.forEach((f, i) => { f.rotation.z = (i - 1) * -.3 + Math.sin(t * 3.1 + i * .7) * .05 * idle + st.wig * .18 * (i - 1); });
  }
  return { type, id, ent, pose, size: b.size, hasFans: !!b.fans };
}
export const CHAR_TYPES = Object.keys(BUILD);
