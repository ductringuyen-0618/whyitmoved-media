// Motion clips: reusable additive animations for actors, evaluated statelessly from time.
// Clip: {t, type, dur, ...params, expr?:{eyes,mouth,brow,wide,sweat,...}}. They add to the keyframed pose
// (position offset, rotation offset in degrees, squash multiplier) and may override expression / arms while active.
import { clamp, seg, smooth, spring, getEase } from './util.js';

const eOut = x => 1 - Math.pow(1 - x, 3), eIn = x => x * x * x;
const arc = (u, h) => (u > 0 && u < 1 ? h * 4 * u * (1 - u) : 0);

/** @returns {{dpos:number[], drot:number[], msq:number[], expr:object, arms:{w:number,L:number[],R:number[]}|null, dizzy:number}} */
export function evalClips(clips, t) {
  const out = { dpos: [0, 0, 0], drot: [0, 0, 0], msq: [1, 1, 1], expr: {}, arms: null };
  if (!clips) return out;
  const mulSq = (a, b, c) => { out.msq[0] *= a; out.msq[1] *= b; out.msq[2] *= c; };
  for (const c of clips) {
    const lt = t - c.t; if (lt < -.5) continue;
    const ty = c.type;
    if (ty === 'jump') {
      const h = c.h ?? 1.3, air = c.dur ?? .7, an = c.anticip ?? .2, ld = c.land ?? .5;
      const ta = lt + an;                                  // clip time 't' = lift-off; anticipation precedes it
      if (ta < 0 || lt > air + ld) continue;
      if (lt < 0) { const k = smooth(clamp(ta / an)); mulSq(1 + .13 * k, 1 - .26 * k, 1 + .1 * k); }
      else if (lt < air) {
        const u = lt / air; out.dpos[1] += arc(u, h);
        const st = .14 * Math.sin(Math.PI * u) * (1 - Math.abs(u - .5) * 0); mulSq(1 - st * .45, 1 + st, 1 - st * .3);
        if (c.arms !== false) out.arms = { w: smooth(clamp(lt / .12)) * (1 - smooth(seg(lt, air - .1, air))), L: [150, 10], R: [150, 10], ...(out.arms || {}) };
        Object.assign(out.expr, c.expr || { mouth: 'grin', eyes: 'happy' });
      } else {
        const tau = lt - air, sq = tau < .06 ? .3 * eOut(tau / .06) : .3 * spring(tau - .06, 2.8, 7);
        mulSq(1 + sq * .5, 1 - sq, 1 + sq * .4);
        if (tau < .35) Object.assign(out.expr, c.expr || { mouth: 'grin' });
      }
    } else if (ty === 'slip') {
      const dur = c.dur ?? .6, h = c.h ?? 1.6, dir = c.dir ?? 1, gu = c.getup, dz = c.dizzy ?? 1.5;
      if (lt < 0) continue;
      const u = clamp(lt / dur), u1 = clamp(u / .32), part = eOut(u1) * .42 + eIn(u) * .58;
      let rx = -90 * part, rz = Math.sin(u * Math.PI) * -16 * dir;
      if (lt < dur) {
        out.dpos[1] += arc(u, h); const st = .12 * Math.sin(Math.PI * u); mulSq(1 - st * .45, 1 + st, 1);
        const wind = lt * 15; out.arms = { w: smooth(clamp(lt / .1)), L: [130 + Math.sin(wind) * 35, -20 + Math.sin(wind * .8) * 25], R: [135 + Math.cos(wind) * 35, -20 + Math.cos(wind * .9) * 25] };
        Object.assign(out.expr, { eyes: 'open', mouth: 'shout', wide: 1.18, brow: -.5, browY: 1, ...c.expr });
      } else {
        const ld = lt - dur;
        rz = .6 * spring(ld, 2.4, 3.5);
        const sq = ld < .06 ? .34 * eOut(ld / .06) : .34 * spring(ld - .06, 2.8, 7.5); mulSq(1 + sq * .55, 1 + sq * .55, 1 - sq);
        out.dpos[1] += arc((ld - .05) / .34, .5) + arc((ld - .42) / .22, .1);
        out.arms = { w: 1, L: [95 + 6 * spring(ld, 2, 3), 15], R: [100 + 6 * spring(ld + .1, 2, 3), 12] };
        Object.assign(out.expr, ld < dz ? { eyes: 'x', mouth: ld < .5 ? 'open' : 'wob', brow: .4, wide: 1 } : { eyes: 'open', mouth: 'wob', brow: .6 }, c.expr);
        if (gu !== undefined && lt > dur + gu) {   // stand back up
          const k = clamp((lt - dur - gu) / .7), e = getEase('back:1.5')(k);
          rx = -90 * (1 - e); out.dpos[1] += arc(clamp((lt - dur - gu - .1) / .45), .5) * 0; out.arms = { w: 1 - k * .8, L: [95, 15], R: [100, 12] };
          if (k < 1) mulSq(1 - .15 * Math.sin(Math.PI * k), 1 + .12 * Math.sin(Math.PI * k), 1);
        }
      }
      out.drot[0] += rx; out.drot[2] += rz;
    } else if (ty === 'shiver') {
      const dur = c.dur ?? 1.2, k = lt >= 0 && lt < dur ? Math.min(1, lt / .1) * Math.min(1, (dur - lt) / .15) : 0;
      if (k > 0) { out.drot[2] += Math.sin(lt * (c.freq ?? 34)) * (c.amp ?? 1.4) * k; out.dpos[0] += Math.sin(lt * (c.freq ?? 34) * 1.3) * .015 * k; }
    } else if (ty === 'boing') {   // squash & spring back (a bonk, a landing, a surprise)
      if (lt < 0 || lt > (c.dur ?? 1.2)) continue;
      const a = c.amp ?? .3, sq = lt < .08 ? a * eOut(lt / .08) : a * spring(lt - .08, c.f ?? 2.8, c.d ?? 6.5);
      mulSq(1 + sq * .6, 1 - sq, 1 + sq * .45);
    } else if (ty === 'spin') {
      const dur = c.dur ?? .6, ax = { x: 0, y: 1, z: 2 }[c.axis || 'y'], turns = c.turns ?? 1;
      if (lt < 0) continue; out.drot[ax] += 360 * turns * getEase(c.ease || 'inout')(clamp(lt / dur));
    } else if (ty === 'wobble') {
      const dur = c.dur ?? 1.4; if (lt < 0 || lt > dur) continue;
      out.drot[2] += (c.amp ?? 9) * spring(lt, c.f ?? 2.2, 3) * (1 - lt / dur);
    }
  }
  return out;
}
