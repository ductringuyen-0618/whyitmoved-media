# eng3d - declarative 3D shot engine (Three.js, headless SwiftShader)

Author a whole clip as JSON; no per-clip JS.

    node render.mjs --shots demo/shots.json --out frames --from 0 --to 450      # frames f00000.png ... (to exclusive)
    node render.mjs --shots demo/shots.json --out stills --stills 0.4,1.4,2.9   # look-dev, defaults to 540x960, prints per-actor px sizes
    options: --w --h (default 1080x1920) --fmt png|jpeg --skip 1 (resume) --report 1 --aa 0 --shadow 1024

Everything is a pure function of time, so ranges can be split across processes (on 2 cores it gives no speedup; see timing).

## Layout
src/engine.js (player, camera, looks, events) | chars.js (INTEL, NVIDIA, AMD) | props.js | sets.js (stage, sky, street + looks) | clips.js | fx.js | kit.js (materials, Entity) | util.js (easing, tracks)

## Conventions
x right, y up, z toward default camera; characters face +z. Angles in degrees. All keyframe times `t` are ABSOLUTE clip seconds.
Keyframes are sparse per property. `ease` on a keyframe shapes the move INTO it: linear, in, out, inout, in2, out2, sine, back[:s], backin[:s], spring[:cycles:damp], bounce, hold. Strings/booleans step.
Top-level fields of an actor/prop (besides kf/clips) act as base values.

## Schema
    { fps, dur, shots:[{
      t0, t1, set:'stage|sky|street',
      look: 'day|storm|golden|dark|red' | [{t, look, ease}] (blends) | {base:'day', top:'#..', ...},
      fadeIn, fadeOut,
      camera:{ push:0.05, sway:0.25, follow:{id,k,y}, keyframes:[{t, pos:[x,y,z] | orbit:{az,el,dist}, target:[x,y,z], fov, roll, ease}] },
      actors:{ INTEL|NVIDIA|AMD (or id with "char"): {
         tag, size, clips:[{t,type,...}],
         kf:[{t, pos, rot, sq:[sx,sy,sz], size, ground,
              eyes:'open|squeeze|x|happy', mouth:'smile|grin|o|open|wob|sad|shout|flat',
              brow (+worried/-angry), browY, lookx, looky (-1..1), wide, sweat 0..1,
              armL:[outDeg, fwdDeg], armR, wig, fan (rad/s, NVIDIA), idle 0..1, blink:false,
              lookAt:'id'|[x,y,z], lookW, faceTo:'id'|[x,y,z], faceW, solid:false, ease}] } },
      props:[{ id, type, params:{...}, pos (base-centre), rot, scale, sq, vis, ground,
               attach:'ACTOR.handL|handR|top' or 'propId.anchor' (pos/rot then relative to the anchor),
               kf:[{t, pos, rot, scale, vis, attach, p:{animated params}, ease}] }],
      events:[{t, type:'shake|flash|splash|burst', amp, dur, pos, kind:'coin|star|confetti', n, color}] }] }

Clips (additive, stateless): jump {h,dur,anticip,land} | slip {dur,h,dir,getup,dizzy} | shiver {dur,amp} | boing {amp} | spin {turns,axis,dur} | wobble {amp}; optional `expr` overrides expression.
Automatic: blink, breathing, arm/antenna sway, floor clamp (rotated boxes never go below `ground`), contact shadow, character-vs-character separation, rain avoids actors.

## Props (type: params; animated params via kf.p)
cloud: mood smug|laugh, rage, bolt, rumble | rain: w,d,n,amt,slant (pos = top of fall) | puddle: rx,rz,grow,ripples | ram: layout stand|stack|fan, count, color, led, glow |
pc: kind laptop|box|tower, text, open | server: kind server|rocket, glow, thrust, pad | arrow: dir, color, pulse | ramp: len,h,w,dir | podium: w,d,h (top y=h) |
shelf: w,h,d,tiers (anchors p0..pN, top; plank k top y = 0.16 + k*(h-0.16)/tiers) | sign: text | value+prefix+suffix+dec, sub, bg, ink, accent, tilt, swing |
coins: count | star: r,color,spin | burst: kind,n,at | splash | balloon (pos = string end) | scale: kind balance|seesaw, tilt (anchors panL/panR, endL/endR).

## Sizes
Default character sizes INTEL .8, NVIDIA .64, AMD .62. At fov 32 / dist 19-20 with NVIDIA in front (z~2) and the other two at x=+-1.9, all three are 360-530 px tall at 1080x1920. `--stills` prints px size and flags clipped/under-340.

## Timing
~2.7 s/frame at 540x960 stills incl. startup; ~3.4 s/frame at 1080x1920 for the 3-character demo (2 CPU cores). Two parallel processes each took ~6.8 s/frame, so no net gain.
