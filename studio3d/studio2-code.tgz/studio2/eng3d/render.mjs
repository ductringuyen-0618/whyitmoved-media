// eng3d renderer. Headless Chromium (SwiftShader WebGL) renders a shot sheet to PNG/JPEG frames.
//   node render.mjs --shots shots.json --out frames [--from 0 --to 300] [--w 1080 --h 1920] [--fmt png|jpeg] [--skip 1]
//   node render.mjs --shots shots.json --out stills --stills 0.5,1.2,3 [--w 540 --h 960] [--report 1]
// Frames are named f00000.png (zero-padded 5 digits, index = frame number at the sheet's fps). --from inclusive, --to exclusive,
// so two processes can render halves in parallel:  --from 0 --to 450   and   --from 450 --to 900.
import { createRequire } from 'module';
import http from 'http'; import fs from 'fs'; import path from 'path';
const require = createRequire('/opt/npm-tools/node_modules/');
const { chromium } = require('playwright');
const A = Object.fromEntries(process.argv.slice(2).reduce((a, v, i, r) => (v.startsWith('--') ? a.concat([[v.slice(2), r[i + 1]]]) : a), []));
if (!A.shots) { console.error('usage: node render.mjs --shots shots.json --out dir [--from F --to F | --stills t1,t2,...] [--w --h --fmt --skip --report --aa 0 --shadow 1024]'); process.exit(1); }
const stills = !!A.stills;
const W = +(A.w || (stills ? 540 : 1080)), H = +(A.h || (stills ? 960 : 1920)), fmt = A.fmt || 'png', ext = fmt === 'jpeg' ? 'jpg' : 'png';
const out = A.out || (stills ? 'stills' : 'frames'); fs.mkdirSync(out, { recursive: true });
const sheet = JSON.parse(fs.readFileSync(A.shots, 'utf8')); const fps = +(A.fps || sheet.fps || 30);
const root = path.dirname(new URL(import.meta.url).pathname);
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.json': 'application/json' };
const srv = http.createServer((q, r) => { const f = path.join(root, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); r.end(); } else { r.writeHead(200, { 'content-type': mime[path.extname(f)] || 'application/octet-stream' }); r.end(d); } }); });
await new Promise(r => srv.listen(0, r)); const port = srv.address().port;
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl'] });
const p = await b.newPage({ viewport: { width: W, height: H } });
p.on('pageerror', e => console.log('PAGEERR', e.message)); p.on('console', m => { if (m.type() === 'error') console.log('CONSOLE', m.text()); });
await p.goto(`http://localhost:${port}/index.html?w=${W}&h=${H}${A.aa === '0' ? '&aa=0' : ''}${A.shadow ? '&shadow=' + A.shadow : ''}`);
await p.waitForFunction('window.ready === true', null, { timeout: 120000 });
const info = await p.evaluate(j => loadShots(j), sheet); const dur = info.dur;
let list;
if (stills) list = A.stills.split(',').map(Number).map(t => [Math.round(t * fps), t]);
else { list = []; const f0 = +(A.from || 0), f1 = +(A.to ?? Math.round(dur * fps)); for (let f = f0; f < f1; f += +(A.step || 1)) list.push([f, f / fps]); }
const name = (f, t) => stills ? `still_${t.toFixed(2)}.${ext}` : `f${String(f).padStart(5, '0')}.${ext}`;
if (A.skip) list = list.filter(([f, t]) => !fs.existsSync(path.join(out, name(f, t))));
const t0 = Date.now(); let n = 0, tr = 0;
for (const [f, t] of list) {
  const url = await p.evaluate(([t, fmt]) => { renderAt(t); return dataURL('image/' + fmt, .95); }, [t, fmt]);
  fs.writeFileSync(path.join(out, name(f, t)), Buffer.from(url.split(',')[1], 'base64')); n++;
  if (stills || A.report) { const rep = await p.evaluate(() => report()); console.log(`t=${t.toFixed(2)}`, rep.map(r => `${r.id} ${r.wpx}x${r.hpx}px${r.warn.length ? ' [' + r.warn.join(', ') + ']' : ''}`).join(' | ')); }
  else if (n % 10 === 0 || list.length < 12) console.log('frame', f, ((Date.now() - t0) / 1000 / n).toFixed(2), 's/frame');
}
console.log('done', n, 'frames', ((Date.now() - t0) / 1000).toFixed(1), 's total,', ((Date.now() - t0) / 1000 / Math.max(1, n)).toFixed(2), 's/frame');
await b.close(); srv.close();
